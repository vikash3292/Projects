
<?php


return [
	
	'fromName' => 'Not_To_Reply',
	'sendEmil' =>'usrivastava@kloudrac.com'

];



?>
