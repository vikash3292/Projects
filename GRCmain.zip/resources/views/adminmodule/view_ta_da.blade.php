@extends('layouts.superadmin_layout')

   @section('content')

<div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Claiming TA/DA</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="#">Claiming TA/DA</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <a href="work_order.html" class="btn btn-primary float-right">Back to List</a>
                            </div>
                        </div>  
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div style="background-color: #eee;">
                                        <h5 style="margin:0;width:100%;font-size:16px;text-align: center;">
                                            <p style="margin:0">GRASS ROOTS RESEARCH &amp; CREATION INDIA (P) LTD</p>
                                            <p style="margin:0">FORM FOR CLAIMING TA/DA</p>
                                        </h5>
                                    </div>
                                    <div style="border:1px solid #eee">
                                        <div>
                                            <table width="100%" border="1"
                                                style="border-color: #ededed;font-size: 13px;">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding:5px;font-weight:500">
                                                            Name
                                                        </td>
                                                        <td style="padding:5px">
                                                            {{$view->name}}
                                                        </td>
                                                        <td style="padding:5px;font-weight: 500;">
                                                            Designation
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->desination}}
                                                        </td>
                                                        <td style="padding:5px;font-weight: 500;">
                                                            Section
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->section}}
                                                        </td>
                                                        <td style="padding:5px;font-weight: 500;">
                                                            Place to be Visit
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->visit}}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px; font-weight:500">
                                                        {{$view->ctgry}}
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->ctgry}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            ADV. REQ#
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->adv}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            Start Date(MM/DD/YY HH:HRS)
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->s_date}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            End Date
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->e_date}}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px; font-weight:500">
                                                            Project ID
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->project_id}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            Project Name
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->project_name}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            Project Sector
                                                        </td>
                                                        <td style="padding:5px">
                                                        {{$view->sector}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            Advance
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->advance}}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px; font-weight:500">
                                                            DA Claiming
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->claim}}
                                                        </td>
                                                        <td  style="padding:5px; font-weight:500">
                                                            DAY/HRS
                                                        </td>
                                                        <td style="padding:5px;">
                                                        {{$view->day_hr}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            Claim Number
                                                        </td>
                                                        <td style="padding:5px">
                                                        {{$view->claim_no}}
                                                        </td>
                                                        <td style="padding:5px; font-weight:500">
                                                            DA Amount
                                                        </td>
                                                        <td style="padding:5px">
                                                        {{$view->amt}}
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td  style="padding:5px;font-weight: 500;">Detail of the Tour</td>
                                                        <td colspan="7" style="padding:5px">
                                                        {{$view->desc}}
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </div>
                                        <div>
                                            <table border="1" style="border-collapse: collapse; border-spacing: 0; width: 100%;font-size: 13px;border-color: #ededed">
                                                <thead>
                                                    <tr>
                                                        <th style="padding:5px">S.No</th>
                                                        <th style="padding:5px">Expense Head</th>
                                                        <th style="padding:5px">Trnpt Mode</th>
                                                        <th style="padding:5px">Start Date</th>
                                                        <th style="padding:5px">From Location</th>
                                                        <th style="padding:5px">To Location</th>
                                                        <th style="padding:5px">End Date</th>
                                                        <th style="padding:5px">Remarks</th>
                                                        <th style="padding:5px">Exp MET</th>
                                                        <th style="padding:5px">City CAT</th>
                                                        <th style="padding:5px">KM/Days/Number</th>
                                                        <th style="padding:5px">Rate/Price/Amount</th>
                                                               <th style="padding:5px">Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td style="padding:5px">1</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                        <td style="padding:5px">dummy</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px"></td>
                                                        <td colspan="11" style="text-align:right;font-weight:600; padding:5px;">TOTAL
                                                        </td>
                                                        <td  style="padding:5px">0.00</td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </div>
                                        <div class="col-sm-12 p-0 m-t-10">
                                            <table width="100%" border="1" style="border-color: #ededed;font-size:13px">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center padding-5" colspan="6">
                                                            <h5>SUMMARY</h5>
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <th class="padding-5">Officer Claimed</th>
                                                        <th class="padding-5">Spent by GRC</th>
                                                        <th class="padding-5">Total Claimed</th>
                                                        <th class="padding-5">Approved AMT</th>
                                                        <th class="padding-5">Bal-Officer/Bal-GRC Claimed</th>
                                                        <th class="padding-5">Bal to GRC/Bal-Officer Approved</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="padding-5">dummy</td>
                                                        <td class="padding-5">dummy</td>
                                                        <td class="padding-5">dummy</td>
                                                        <td class="padding-5">dummy</td>
                                                        <td class="padding-5">dummy</td>
                                                        <td class="padding-5">dummy</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div style="margin-top:20px">
                                            <table border="0" width="100%" style="font-size: 13px;">
                                                <thead>
                                                    <tr style="text-align: center;">
                                                      
                                                        <th class="font-500 padding-5 p-t-10">Coordinator/HOD</th>
                                                        <th class="font-500 padding-5 p-t-10">Accounts Manager</th>
                                                        <th class="font-500 padding-5 p-t-10">Approved by President</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <tr style="text-align: center;">
                                                    
                                                    <td  style="padding:5px;">

                                                   
                                                    
                                                    {{$view->hod_name}}

                                                    @if($view->hod_approvel == 0 && $approval > 0 && in_array($role,[30,31]))
                                                     
                                                    <div>

                                                    <span onclick="approvel_status('{{$view->id}}',1)"><i class="fa fa-check" aria-hidden="true"></i></span>
                                                    <span onclick="approvel_status('{{$view->id}}',2)"> <i class="fa fa-times" aria-hidden="true"></i></span>
                                                     </div>
                                                   

                                                    @else
                                                    <div>
                                                    {{($view->hod_approvel ==1?'Approved' : ($view->hod_approvel ==2?'Reject' : 'Pending'))}}
                                                      
                                                    </div>
                                                    @endif
                                                    
                                                    </td>
                                                    <td  style="padding:5px;">{{$view->ac_name}}
                                                    
                                                    @if($view->account_mnt_approval == 0 && $approval > 0 && in_array($role,[11]))
                                                    <div>
<span onclick="approvel_status('{{$view->id}}',1)"><i class="fa fa-check" aria-hidden="true"></i></span>
<span onclick="approvel_status('{{$view->id}}',2)"> <i class="fa fa-times" aria-hidden="true"></i></span>
</div>


@else 
<div>
{{($view->account_mnt_approval ==1?'Approved' : ($view->account_mnt_approval ==2?'Reject' : 'Pending'))}}
</div>
@endif

                                                    
                                                    
                                                    </td>
                                                    <td  style="padding:5px;"> {{$view->direct_name}} 
                                                    
                                                    
                                                    @if($view->director_approvel == 0 && $approval > 0 && in_array($role,[1]))
                                                    <div>
<span onclick="approvel_status('{{$view->id}}',1)"><i class="fa fa-check" aria-hidden="true"></i></span>
<span onclick="approvel_status('{{$view->id}}',2)"> <i class="fa fa-times" aria-hidden="true"></i></span>
</div>


@else 
 <div>
{{($view->director_approvel ==1?'Approved' : ($view->director_approvel ==2?'Reject' : 'Pending'))}}
</div>

@endif

                                                    
                                                    
                                                     </td>
                                                </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                     
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>

            @stop

            @section('extra_js')

<script>

function approvel_status(advance_id,status){

    var _token = "{{csrf_token()}}";


$.ajax({
url: '/ta_da_status',
type: "post",
data: {"_token": _token,"advance_id" : advance_id,"status" : status},
dataType: 'JSON',
  beforeSend: function() {
// setting a timeout
$('#loadingDiv').show();
},
success: function (data) {
  //console.log(data); // this is good

  $('#loadingDiv').hide();

  alertify.success(data.msg); 

  location.reload();


  
   
}

});

}

</script>

@stop