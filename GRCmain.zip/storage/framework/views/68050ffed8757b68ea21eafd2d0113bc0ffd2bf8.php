    
   <?php $__env->startSection('content'); ?>
            <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h3 class="page-title">Create Lead</h3>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                           <li class="breadcrumb-item active"><a href="create_lead.html">Create Lead</a></li>
                        </ol>
                     </div>
                  </div>
               </div>
               <!-- end row -->

                <form  method="post">
               <div class="row">
                 
                  <div class="col-12">
                      <?php if(session()->has('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('msg')); ?>

                        </div>
                           <?php endif; ?>
                     <div class="card m-t-20">
                        <div class="card-body">
                           <div class="width-float">
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="empcode" class="col-lg-4 col-form-label">Lead Owner</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="owner" id="owner" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <?php echo e(csrf_field()); ?>

                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="empid" class="col-lg-4 col-form-label">Phone No.</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="phone" id="phone" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="prifix" class="col-lg-4 col-form-label">Mobile</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="mobile" id="mobile" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="firstname" class="col-lg-4 col-form-label">First Name</label>
                                       <div class="col-lg-2 p-r-0">
                                          <select class="form-control" name="prefix" id="prefix">
                                             <option>Miss</option>
                                             <option>Mr.</option>
                                             <option>Mrs.</option>
                                          </select>
                                       </div>
                                       <div class="col-lg-6">
                                          <input type="text" name="fname" id="fname" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="logo" class="col-lg-4 col-form-label">Last Name</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="lname" id="lname" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="email" class="col-lg-4 col-form-label">Company</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="company" id="company" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="cid" class="col-lg-4 col-form-label">Fax</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="fax" id="fax" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="mode" class="col-lg-4 col-form-label">Title</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="title" id="title" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Email</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="email_data" id="email_data" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Lead Source</label>
                                       <div class="col-lg-8">
                                          <select class="form-control" name="sourse" id="sourse">
                                             <option>Self</option>
                                             <option>MD</option>
                                             <option>BA</option>
                                             <option>Tenders</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>

                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Website</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="website" id="website" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Industry</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="industry" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Lead Status</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="lead_status" id="lead_status" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Annual Revenue</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="annual_revenue" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Rating</label>
                                       <div class="col-lg-8">

                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">No of Employees</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="no_of_emp" id="no_of_emp" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Product Interest</label>
                                       <div class="col-lg-8">
                                          <select class="form-control" name="product_interst" name="product_interst">
                                             <option>EIA</option>
                                             <option>CTE</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Project Type</label>
                                       <div class="col-lg-8">
                                          <input type="text" class="form-control" name="product_type" id="product_type">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                          <div class="row">
                                  <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="role" class="col-lg-4 col-form-label">Country</label>
                                          <div class="col-lg-8">
                                        <?php

                                       $Country = DB::table('main_countries')->where('isactive','=',1)->get();
                                             
                                           ?>
                                            
                                             <select class="form-control" id="country" name="country">
                                                <option value="">Select Country</option>
                                                <?php $__currentLoopData = $Country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Country->id); ?>" <?php if(!empty($contactinfo)): ?>  <?php if($Country->id == $contactinfo->perm_country): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($Country->country); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                             </select>
                                             <div id="country_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                     <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="role" class="col-lg-4 col-form-label">State</label>
                                          <div class="col-lg-8">
                                      
                                        <?php

                                       $state = DB::table('alm_states')->get();

                                             
                                           ?>
                                            
                                             <select class="form-control" id="state" name="state">
                                                <option value="">Select State</option>

                                                 <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($states->id); ?>" <?php if(!empty($contactinfo)): ?>  <?php if($states->id == $contactinfo->perm_state): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($states->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                             </select>
                                            <div id="state_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              <div class="row">
                                <div class="col-md-6">
                                        <?php

                                       $alm_cities = DB::table('alm_cities')->get();
                                             
                                           ?>
                                       <div class="form-group row">
                                          <label for="role" class="col-lg-4 col-form-label">City</label>
                                          <div class="col-lg-8">
                                      
                                             <select class="form-control" id="city" name="city">
                                                <option value="">Select City</option>

                                                 <?php $__currentLoopData = $alm_cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alm_citiess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($alm_citiess->id); ?>" <?php if(!empty($contactinfo)): ?>  <?php if($alm_citiess->id == $contactinfo->perm_city): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($alm_citiess->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                               
                                             </select>
                                             <div id="city_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Street</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="street" id="street" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Zip Code</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="zip_code" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Estimated
                                          Order Value</label>
                                       <div class="col-lg-8">
                                          <select class="form-control" name="order_val" id="order_val">
                                             <option>EIA</option>
                                             <option>CTE</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>

                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row">
                                       <label for="role" class="col-lg-4 col-form-label">Proposed Site Address</label>
                                       <div class="col-lg-8">
                                          <input type="text" name="site_address"  id="site_address" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6 text-right">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               
                  <!-- end col -->
               </div>
               </form>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
           <?php $__env->stopSection(); ?>

           <?php $__env->startSection('extra_js'); ?>



           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>