    
   <?php $__env->startSection('content'); ?>
            
         <!-- Start content -->
                    <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Attendance Correction Form</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="attendance_correction.html">Attendance
                                            Correction Form</a></li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body correctionform">
                                    <h6 class="mt-0">Current Attendance Data Correction</h6>
                                    <p class="green-text">EMPLOYEE CURRENT STATUS</p>
                                    <p id="error_msg"></p>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Select
                                                    Employee <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="userid">
                                                        <option value="">Select</option>
                                                        <option value="<?php echo e($users->id); ?>"><?php echo e($users->userfullname); ?></option>
                                                        
                                                    </select>
                                                    <div id="userid_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Select
                                                    Date <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <input type="date" class="form-control" id="checkdate">
                                                     <div id="checkdate_error"></div> 
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <button id="checkstatus" class="btn btn-primary">Check Current
                                                Status</button>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">In
                                                    Time <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <input type="time" id="inTime" readonly class="form-control">
                                                    <div id="inTime_error"></div> 
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Out
                                                    Time <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <input type="time" id="OutTime" readonly class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Present
                                                    Status <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <input type="text" id="pstatus"  readonly class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="green-text">CORRECTION FORM</p>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Preposed InTime
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="preposedInTime">
                                                        <option value="">HH:MM</option>
                                                        <option>12:00</option>
                                                        <option>12:15</option>
                                                        <option>12:30</option>
                                                        <option>1:00</option>
                                                        <option>1:15</option>
                                                        <option>1:30</option>
                                                    </select>
                                                    <div id="preposedInTime_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Preposed OutTime
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="preposedOutTime">
                                                        <option value="">HH:MM</option>
                                                        <option>12:00</option>
                                                        <option>12:15</option>
                                                        <option>12:30</option>
                                                        <option>1:00</option>
                                                        <option>1:15</option>
                                                        <option>1:30</option>
                                                    </select>
                                                     <div id="preposedOutTime_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Preposed Status
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="preposedStatus">
                                                        <option value="">Status to be..</option>
                                                        <option value="CORR">Correction</option>
                                                    </select>
                                                     <div id="preposedStatus_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Select Date
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <input type="date" class="form-control" id="showcheckdate">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Explanation
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <textarea class="form-control" maxlength="500" id="reason"></textarea>
                                                     <div id="reason_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <button id="addCorrection" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
           <?php $__env->stopSection(); ?>

           <?php $__env->startSection('extra_js'); ?>

           <script type="text/javascript">

            $(document).on('click','#checkstatus',function(){
                error = 1;
                var userid = $('#userid').val();
                 var checkdate = $('#checkdate').val();

        if(userid ==''){
         $('#userid_error').text('Select User is Required').attr('style','color:red');
         $('#userid_error').show();
           error = 0;
              return false;
      }else{$('#userid_error').hide();  error = 1;}

       if(checkdate ==''){
         $('#checkdate_error').text('Select Date is Required').attr('style','color:red');
         $('#checkdate_error').show();
           error = 0;
              return false;
      }else{$('#checkdate_error').hide();  error = 1;}

      if(error ==1){

          $('#loadingDiv').show();

    var _token = "<?php echo e(csrf_token()); ?>";

  $.ajax({
        url: '/get_attendace',
        type: "post",
        data: {"_token": _token,"userid":userid,"checkdate":checkdate},
        dataType: 'JSON',
         
        success: function (data) {
        //console.log(data.attendace); // this is good

       // return false;
    
          if(data.status ==200){
             $('#loadingDiv').hide();

           

              $('#error_msg').hide();

             $('#inTime').val(data.attendace.actual_intime);
              $('#OutTime').val(data.attendace.actual_outtime);
               $('#pstatus').val(data.attendace.actual_status);
                $('#showcheckdate').val(checkdate);
         
             
        
          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");


          }else{
           $('#loadingDiv').hide();
           $('#error_msg').html('No Recoud Found').attr('style','color:red');
              $('#error_msg').show();
               $('#inTime').val('');
              $('#OutTime').val('');
               $('#pstatus').val('');
                $('#showcheckdate').val('');

          }
          
        }
      });

      }



            });


            

              $(document).on('click','#addCorrection',function(){
                error = 1;

                var userid = $('#userid').val();
                 var checkdate = $('#checkdate').val();

                  var preposedInTime = $('#preposedInTime').val();
                   var preposedOutTime = $('#preposedOutTime').val();
                    var preposedStatus = $('#preposedStatus').val();
                     var reason = $('#reason').val();
                      var inTime = $('#inTime').val();
                 

        if(userid ==''){
         $('#userid_error').text('Select User is Required').attr('style','color:red');
         $('#userid_error').show();
           error = 0;
              return false;
      }else{$('#userid_error').hide();  error = 1;}

       if(checkdate ==''){
         $('#checkdate_error').text('Select Date is Required').attr('style','color:red');
         $('#checkdate_error').show();
           error = 0;
              return false;
      }else{$('#checkdate_error').hide();  error = 1;}
      
          if(inTime ==''){
         $('#inTime_error').text('Select Time is Required').attr('style','color:red');
         $('#inTime_error').show();
           error = 0;
              return false;
      }else{$('#inTime_error').hide();  error = 1;}

        if(preposedInTime ==''){
         $('#preposedInTime_error').text('Select Time is Required').attr('style','color:red');
         $('#preposedInTime_error').show();
           error = 0;
              return false;
      }else{$('#preposedInTime_error').hide();  error = 1;}

        if(preposedOutTime ==''){
         $('#preposedOutTime_error').text('Select Time is Required').attr('style','color:red');
         $('#preposedOutTime_error').show();
           error = 0;
              return false;
      }else{$('#preposedOutTime_error').hide();  error = 1;}

        if(preposedStatus ==''){
         $('#preposedStatus_error').text('Select Status is Required').attr('style','color:red');
         $('#preposedStatus_error').show();
           error = 0;
              return false;
      }else{$('#preposedStatus_error').hide();  error = 1;}

       if(reason ==''){
         $('#reason_error').text('Write Descripation is Required').attr('style','color:red');
         $('#reason_error').show();
           error = 0;
              return false;
      }else{$('#reason_error').hide();  error = 1;}


        if(error ==1){

          $('#loadingDiv').show();

    var _token = "<?php echo e(csrf_token()); ?>";

  $.ajax({
        url: '/update_attendace',
        type: "post",
        data: {"_token": _token,"userid":userid,"checkdate":checkdate,"preposedInTime":preposedInTime,"preposedOutTime":preposedOutTime,"preposedStatus":preposedStatus,"reason":reason},
        dataType: 'JSON',
         
        success: function (data) {
      

       // return false;
    
          if(data.status ==200){
             $('#loadingDiv').hide();

          
           swal("Good job!", data.msg, "success");
             
        
          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");


          }else{

             $('#loadingDiv').hide();
            
             swal("Good job!", "You clicked the button!", "error");

          }
          
        }
      });

      }


            });
               
          

           </script>


           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>