
                          
  
  <div class="left side-menu">
         <div class="slimscroll-menu" id="remove-scroll">
            <!--- Sidemenu -->
            <div id="sidebar-menu">
               <!-- Left Menu Start -->


               <ul class="metismenu" id="side-menu">
                  <!-- <li class="menu-title">Main</li> -->

                  <?php ($role_id = Auth::guard('main_users')->user()->emprole); ?>

                  <?php if(!empty($menu)): ?>
                  <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if($role_id == 1): ?>

                  <?php ($roll  = (in_array($role_id,[1]))); ?>


                  <?php else: ?> 

                    <?php ($roll  = (in_array($menus['id'],$rolldata))); ?>

                  <?php endif; ?>



                  <?php if($roll): ?>


                  <li>
                     <a href="<?php echo e($menus['url']); ?>" class="waves-effect"><?php echo $menus['icon']; ?><span> <?php echo e($menus['title']); ?>

                           <span class="float-right menu-arrow">
                               <?php if(!empty($menus['sub'])): ?>
                              <i class="mdi mdi-chevron-right"></i>
                               <?php endif; ?>
                           </span></span></a>
                     <ul class="submenu">
                         <?php if(!empty($menus['sub'])): ?>
                      <?php $__currentLoopData = $menus['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                       <?php if($role_id == 1): ?>

                  <?php ($roll  = (in_array($role_id,[1]))); ?>


                  <?php else: ?> 

                    <?php ($roll  = (in_array($submenu['id'],$rolldata))); ?>

                  <?php endif; ?>

                  <?php if($roll): ?>
                        <li>
                           <a href="<?php echo e($submenu['url']); ?>" class="waves-effect"><span> <?php echo e($submenu['title']); ?>

                                 <span class="float-right menu-arrow">
                                       <?php if(!empty($submenu['sub'])): ?>
                              <i class="mdi mdi-chevron-right"></i>
                               <?php endif; ?>

                                    </span></span></a>
                           
                               <?php if(!empty($submenu['sub'])): ?>

                               <ul class="submenu">
                             <?php $__currentLoopData = $submenu['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                  <?php if($role_id == 1): ?>

                   <?php ($roll  = (in_array($role_id,[1]))); ?>


                  <?php else: ?> 

                    <?php ($roll  = (in_array($subsubmenu['id'],$rolldata))); ?>

                  <?php endif; ?>

                  <?php if($roll): ?>
                              <li><a href="<?php echo e($subsubmenu['url']); ?>"><?php echo e($subsubmenu['title']); ?></a></li>
                              <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                                 <?php endif; ?>
                             
                           
                        </li>
                        <?php endif; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>

                       
                     </ul>
                  </li>
                  <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>


               
                  <li>
                     <a href="<?php echo e(url('edit/myprofile/'.$id)); ?>" class="waves-effect"><i class="ti-face-smile"></i> <span>My Profile
                        </span></a>
                  </li>
                
                    <li>
                    <a class="waves-effect" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();"><i class="mdi mdi-power text-danger"></i>
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                  </li>
               </ul>
            </div>
            <!-- Sidebar -->
            <div class="clearfix"></div>
         </div>
         <!-- Sidebar -left -->
      </div>
    