<?php $__env->startSection('content'); ?>

 <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Form List</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><?php echo e($view->title); ?></li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                               <a href="<?php echo e(URL::to('view-form')); ?>/<?php echo e($view->title); ?>" class="btn btn-primary">View Question</a>
                            </div>
                        </div>
                    </div>

                    <?php if(Session::has('msg')): ?>
<p class="alert alert-danger"><?php echo e(Session::get('msg')); ?></p>
<?php endif; ?>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Form Name</th>
                                                <th>Category</th>
                                                <th title="Active/Inactive" data-toggle="tooltip">Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        	<?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($forms->question); ?></td>
                                                <td>
                                                
                                                
                                                <?php if($forms->category == 1): ?>
                                                 
                                                 Input Box

                                                <?php elseif($forms->category ==2): ?>

                                                Radio Button
                                                <?php elseif($forms->category ==3): ?>
                                         Select Box

                                                <?php elseif( $forms->category ==4): ?>

                                                Check Box

                                                <?php endif; ?>
                                                
                                                
                                                
                                                </td>
                                                <td class="active-text">
                                                  

                                           
                                 <div class="togglebutton custom-control custom-switch inline-block" <?php if($forms->status ==1): ?> title="Active" <?php else: ?> title="InActive" <?php endif; ?> >
                                                        <input type="checkbox" onclick="change_hide_status('<?php echo e($forms->status); ?>','<?php echo e($forms->id); ?>')" <?php if($forms->status ==1): ?> checked <?php else: ?> notchecked <?php endif; ?> class="custom-control-input"
                                                            id="customSwitches<?php echo e($forms->id); ?>">
                                                        <label class="custom-control-label" for="customSwitches<?php echo e($forms->id); ?>">
                                                        </label>

                                 

                                                </td>
                                                <td>

                                                	

                                                	   <a  href="<?php echo e(URL::to('edit-form')); ?>/<?php echo e($forms->id); ?>">
                                                       <i class="mdi mdi-pen text-warning" data-toggle="tooltip" title="Edit"></i> 
                                                </a>
                                                   
                                                   <a onclick="return confirm('Are you sure you want to delete this?');" href="<?php echo e(URL::to('delete-form')); ?>/<?php echo e($forms->id); ?>">
                                                   <i class="mdi mdi-delete text-danger" data-toggle="tooltip" title="Delete"></i>
                                               </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>

            <?php $__env->stopSection(); ?>

            <?php $__env->startSection('extra_js'); ?>

<script>


function change_hide_status(menustaus,menuid){
  
  var _token = "<?php echo e(csrf_token()); ?>";

   $.ajax({
       url: '/question_form',
       type: "post",
       data: {"_token": _token,"menuid":menuid,"menustaus":menustaus},
       dataType: 'JSON',
         beforeSend: function() {
       // setting a timeout
       $('#loadingDiv').show();
   },
       success: function (data) {
         //console.log(data); // this is good

          // return false;
         if(data.status ==200){
            $('#loadingDiv').hide();
        
            
           // swal("Good job!", data.msg, "success");
            alertify.success(data.msg);
            

         }else if(data.status ==202){

             $('#loadingDiv').hide();
             alertify.success(data.msg);
          // swal("Good job!",  data.msg, "success");
          // location.reload();

             }else if(data.status ==203){

             $('#loadingDiv').hide();
           //swal("Good job!",  data.msg, "success");
           alertify.success(data.msg);


         }else{

            $('#loadingDiv').hide();
           
           // swal("Good job!",  data.msg, "error");
            alertify.error(data.msg);

         }
         
       }
     });
}




</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>