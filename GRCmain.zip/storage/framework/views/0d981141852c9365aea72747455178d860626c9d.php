    

   <?php $__env->startSection('content'); ?>

 

            <!-- Start content -->

            <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6 col-6">

                                <h4 class="page-title">Site Menus</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>

                                    <li class="breadcrumb-item active"><a href="menu_list.html">Site Menus</a></li>

                                </ol>

                            </div>

                            <div class="col-sm-6 col-6">

                                <div class="float-right d-md-block">

                                    <div class="dropdown">

                                        <a href="<?php echo e(URL::to('/menuManagement')); ?>">

                                            <button

                                                class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"

                                                type="button">

                                                Add Menu</button>

                                        </a>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <!-- end row -->

                    <div class="row">

                        <div class="col-12">

                            <?php if(session()->has('message')): ?>

                        <div class="alert alert-success">

                            <?php echo e(session()->get('message')); ?>


                        </div>

                           <?php endif; ?>

                            <div class="card m-t-20">

                                <div class="card-body">

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"

                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                                        <thead>

                                            <tr>

                                                <th>S.No</th>

                                                <th>Menu Title</th>

                                                <th>URL</th>

                                               

                                                

                                              

                                               

                                                <th>Action</th>

                                            </tr>

                                        </thead>

                                        <tbody>

                                         <?php ($i = 1); ?>

                                          <?php $__currentLoopData = $menulist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menulists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>

                                                <td><?php echo e($i++); ?></td>

                                                <td>

                                                   <?php echo e($menulists->menu_title); ?>


                                                </td>

                                                <td><?php echo e($menulists->url); ?></td>

                                               

                                                

                                                <td>

                                                    <a href="<?php echo e(URL::to('/editmunu/')); ?>/<?php echo e($menulists->id); ?>">

                                                        <i class="mdi mdi-pen text-warning" data-toggle="modal" data-target="#editemp" title="Edit"></i></a>





                                                        <a href="<?php echo e(URL::to('/deletemunu/')); ?>/<?php echo e($menulists->id); ?>" onclick="return confirm('Are you sure you want to delete ?');">



                                                        <i class="mdi mdi-delete text-danger" data-toggle="modal" data-target="#deletemp" title="Delete"></i></a>





                                                    <div class="togglebutton custom-control custom-switch inline-block">

                                                        <input type="checkbox" onclick="changestatus('<?php echo e($menulists->is_active); ?>','<?php echo e($menulists->id); ?>','site_menu')" <?php if($menulists->is_active ==1): ?> checked <?php else: ?> notchecked <?php endif; ?> class="custom-control-input"

                                                            id="customSwitches<?php echo e($menulists->id); ?>">

                                                        <label class="custom-control-label" for="customSwitches<?php echo e($menulists->id); ?>">

                                                        </label>

                                                    </div>

                                                </td>

                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                          

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

         <!-- content -->

           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>