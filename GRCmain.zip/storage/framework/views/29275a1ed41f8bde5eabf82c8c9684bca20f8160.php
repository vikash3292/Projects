<?php $__env->startSection('content'); ?>
<!-- Begin page -->
<!-- Start content -->
<div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style m-b-20 p-10">
                     <div class="col-sm-6">
                        <h4 class="page-title">Dashboard</h4>
                     </div>
                  </div>
               </div>

              
               <!-- end row -->
               <div class="row">
                  <div class="col-sm-12">
                  <h4 class="mt-0 header-title m-0 p-10">Daily Transaction
                  </h4>
               </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">CASH
                           </h4>
                           <?php echo e($today[0]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">CARD</h4>
                           <?php echo e($today[1]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">UPI</h4>
                           <?php echo e($today[2]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
               </div>
                   <div class="row">
                  <div class="col-sm-12">
                  <h4 class="mt-0 header-title m-0 p-10">Weekly Transaction
                  </h4>
               </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">CASH
                           </h4>
                           <?php echo e($week[0]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">CARD</h4>
                           <?php echo e($week[1]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">UPI</h4>
                           <?php echo e($week[2]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-sm-12">
                  <h4 class="mt-0 header-title m-0 p-10">Monthly Transaction
                  </h4>
               </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">CASH
                           </h4>
                           <?php echo e($month[0]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">CARD</h4>
                           <?php echo e($month[1]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4 text-center">UPI</h4>
                           <?php echo e($month[2]->today_amt??0); ?>

                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- container-fluid -->
         </div><!-- end row -->
      <?php $__env->stopSection(); ?>   


      
      <?php $__env->startSection('extra_js'); ?>

     
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>