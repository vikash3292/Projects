<?php $__env->startSection('content'); ?>
<div id="wrapper">
   <div class="row columnreverse">
      <div class="col-sm-6">
         <div class="wrapper-page wrapper-page-margin">
            <div class="overflow-hidden account-card mx-3">
               <div class="account-card-content">
                  <div class="text-center position-relative">
                     <h1 class="m-b-30">GRC MAIN ERP</h1>
                     <p class="m-b-30">
                        GRC India has the in-house and empanelled experts for all the 12
                        functional
                        areas required, in order to successful culmination of project
                        within a
                        definite time frame. Besides, the company has a pool of experts
                        for the
                        entire range of functional areas, who can provide the most
                        satisfactory
                        solutions in the complete gamut of consultancy services in the
                        environment
                        field.
                     </p>
                  </div>
                  <div class="text-left">
                     <a href="<?php echo e(URL::to('admin')); ?>" class="logo">
                     <img src="<?php echo e(URL::to('/public/')); ?><?php echo e($mainsetting->company_logo); ?>" height="100" alt="logo">
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-sm-6 ">
         <div class="wrapper-page">
            <div class="card overflow-hidden account-card mx-3">

        

               <div class="account-card-content">
                  <div class="text-center position-relative">
                     <h4 class="font-30 m-b-5">Welcome to <span class="primary-color">Login</span></h4>
                  </div>
                  <form class="form-horizontal m-t-20" method="POST" action="<?php echo e(URL::to('/admin')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <div class="row">
                           <div class="col-1 p-r-0">
                              <i class="mdi mdi-account-circle font-20"></i>
                           </div>
                           <div class="col-11">
                              <input id="emaildata" type="text" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="email" maxlength="60" value="<?php echo e(old('email')); ?>"  autofocus placeholder="Enter valid Savior Card No">
                              <?php if($errors->has('email')): ?>
                              <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('email')); ?></strong>
                              </span>
                              <?php endif; ?>
                              <div id="email_error"></div>
                           </div>
                        </div>
                        <!--      <div class="row">
                           <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                           
                           <div class="col-md-6">
                               <input id="" type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                           
                               <?php if($errors->has('email')): ?>
                                   <span class="invalid-feedback" role="alert">
                                       <strong><?php echo e($errors->first('email')); ?></strong>
                                   </span>
                               <?php endif; ?>
                           </div>
                           </div> -->
                     </div>
                     <div class="form-group">
                        <div class="row">
                           <div class="col-1 p-r-0">
                              <i class="mdi mdi-lock font-20"></i>
                           </div>
                           <div class="col-11">
                              <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"  maxlength="60" placeholder="Enter password">
                              <?php if($errors->has('password')): ?>
                              <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('password')); ?></strong>
                              </span>
                              <?php endif; ?>
                              <span toggle="#password-field" onclick="login_psd()" class="fa fa-eye field-icon toggle-password"></span>
                            <div id="password_error"></div>
                           </div>
                          
                        </div>
                     </div>
                     <!--      <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                        
                        <div class="col-md-6">
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                        
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        </div> -->
                     <div class="form-group row m-t-20">
                        <div class="col-md-6">
                           <div class="custom-control custom-checkbox">
                              <input class="custom-control-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                              <!--  <input type="checkbox" class="custom-control-input" id="customControlInline"> -->
                              <label class="custom-control-label" for="customControlInline remember"> <?php echo e(__('Remember Me')); ?></label>
                           </div>
                           <!--  <div class="form-check">
                              <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                              
                              <label class="form-check-label" for="remember">
                                  <?php echo e(__('Remember Me')); ?>

                              </label>
                              </div> -->
                        </div>
                        <div class="col-sm-6">
                           <a href="<?php echo e(URL::to('forget')); ?>"><i class="mdi mdi-lock"></i>  <?php echo e(__('Forgot Your Password?')); ?></a>
                        </div>
                     </div>

                      <?php if(Session::has('message')): ?>
                              <div class="alert alert-danger alert-dismissible">
                         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php echo e(Session::get('message')); ?>

                       </div>
                          
                          
                            <?php endif; ?>
                     <div class="form-group m-t-10 mb-0 row">
                        <div class="col-12 m-t-20">
                           <button type="submit" id="login" class="btn btn-primary btn-block">
                           <?php echo e(__('Login')); ?>

                           </button>
                           <!--  <a href="index.html" class="loginbtn">LOGIN</a> -->
                        </div>
                     </div>
                     <!--       <div class="form-group row mb-0">
                        <div class="col-md-8 offset-md-4"> -->
                     <!--   <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Login')); ?>

                        </button> -->
                     <!--     <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                        </a> -->
                     <!--   </div>
                        </div> -->
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>