    
   <?php $__env->startSection('content'); ?>
                   
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Recruitment Tracker</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Leave</a></li>
                                    <li class="breadcrumb-item active"><a href="leaveapprove.html">Recruitment
                                            Tracker</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                     <?php if(PermissionHelper::frontendPermission('add-recruitment')): ?>
                                    <a href="<?php echo e(URL::to('/addnewrequest')); ?>" class="btn btn-primary float-right">New Request</a>
                                    <?php endif; ?>
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap text-center"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>
                                                    Job Title
                                                </th>
                                                <th>Department</th>
                                                <th>Role</th>
                                                <th>Reporting By</th>
                                                <th>Skill</th>
                                                <!-- <th>Deadline by Requisitioner (If any)</th> -->
                                                <!-- <th>Deadline By HR</th> -->
                                                <th>Action</th>
                                                <!-- <th>HR Recruiter Assigned</th>
                                                <th>Required Experience</th>
                                                <th>Actual Date of Closure</th>
                                                <th>Remarks by Recruiter</th>
                                                <th>Remarks by Director</th>
                                                <th>Remark By MS[Management
                                                    Secretariat]</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php ($i= 1); ?>
                                          <?php $__currentLoopData = $reqruiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reqruiments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>

                                                <td>
                                                   <?php echo e($reqruiments->job_title); ?>

                                                </td>
                                                <td> <?php echo e($reqruiments->deptname); ?></td>
                                                <td><?php echo e($reqruiments->rolename); ?></td>
                                                <td><?php echo e($reqruiments->reporting_user); ?></td>
                                                <td><?php echo e($reqruiments->skill); ?></td>
                                                <td>
                                                <?php if(PermissionHelper::frontendPermission('view-recruitment')): ?>
                                                <a href="<?php echo e(URL::to('downoload-requisition')); ?>/<?php echo e($reqruiments->id); ?>">
                                                <i class="fa fa-download" aria-hidden="true"></i>
                                                </a>
                                                <a href="<?php echo e(URL::to('view-requisition')); ?>/<?php echo e($reqruiments->id); ?>">
                                                <i class="fa fa-eye font-blue m-r-5" title="View"
                                                        data-toggle="modal" data-target="#recruitmentview<?php echo e($reqruiments->id); ?>"></i>
                                                </a>
                                                        <a href="<?php echo e(URL::to('edit-requisition')); ?>/<?php echo e($reqruiments->id); ?>">
                                                        <i class="mdi mdi-pen text-warning" title="View"
                                                        data-toggle="modal" data-target="#recruitmentview<?php echo e($reqruiments->id); ?>"></i>
                                                        </a>
                                                        <a href="<?php echo e(URL::to('delete-requisition')); ?>/<?php echo e($reqruiments->id); ?>">
                                                    <i class="mdi mdi-delete text-danger" title="View"
                                                        data-toggle="modal" data-target="#recruitmentview<?php echo e($reqruiments->id); ?>"></i>
                                                        </a>

                                                        <?php endif; ?>
                                                </td>
                                            </tr>



                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <!--   <tr>
                                                <td>2</td>

                                                <td>
                                                    Sales Force Developer
                                                </td>
                                                <td>IT</td>
                                                <td>13/12/2019</td>
                                                <td>Fresher</td>
                                                <td>Avni</td>
                                                <td>
                                                    <i class="fa fa-eye font-blue m-r-5" title="View"
                                                        data-toggle="modal" data-target="#recruitmentview"></i>
                                                </td>
                                            </tr> -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->


   
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>