<?php $__env->startSection('content'); ?>
<?php $__env->startSection('extra_css'); ?>
<style>
    .table>tbody>tr>td,
    .table>tfoot>tr>td,
    .table>thead>tr>td {
        padding: 8px 4px;
    }
</style>
<?php $__env->stopSection(); ?>
<!-- Begin page -->
<!-- Start content -->
<div class="content p-0">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center bredcrum-style m-b-20 p-10">
                <div class="col-sm-6">
                    <h4 class="page-title">Dashboard</h4>
                </div>
            </div>
        </div>
        <!-- end row -->
        <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-success-50 text-white">
                    <div class="card-body">
                        <div>
                            <h5 class="font-16 text-uppercase mt-0">My Leaves</h5>
                            <div class="time-list">
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['CL']??0); ?><h4>
                                            <p class="font-12">Casual Leaves</p>
                                </div>
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['RH']??0); ?></h4>
                                    <p class="font-12">Restriced</p>
                                </div>
                            </div>
                            <!-- <h4 class="font-500">18 </h4> -->
                            <div class="mini-stat-label bg-primary">
                                <p class="mb-0"><?php echo e($dashboad['totalCLleave']??0); ?></p>
                            </div>
                        </div>
                        <!--<div class="pt-2">-->
                        <!--   <div class="float-right">-->
                        <!--      <a href="<?php echo e(URL::to('/leavelist')); ?>" class="text-white">-->
                        <!--             <p class="mb-0">View More <i class="mdi mdi-arrow-right h5 font-14 text-white"></i></p>-->

                        <!--      </a>-->
                        <!--   </div>-->

                        <!--</div>-->
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-danger-50 text-white">
                    <div class="card-body">
                        <div>
                            <h5 class="font-16 text-uppercase mt-0">My Team</h5>
                            <div class="time-list">
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['TotalUnderUserActive']??0); ?></h4>
                                    <p class="font-12">Reportees</p>
                                </div>
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['pendingLeave']??0); ?></h4>
                                    <p class="font-12">Leaves To Approve</p>
                                </div>
                            </div>
                            <div class="mini-stat-label bg-primary">
                                <p class="mb-0"><?php echo e($dashboad['TotalUnderUser']??0); ?></p>
                            </div>
                        </div>
                        <!--<div class="pt-2">-->
                        <!--   <div class="float-right"><a href="#" class="text-white">-->
                        <!--        <p class="mb-0">View More-->
                        <!--       <i class="mdi mdi-arrow-right h5 font-14 text-white"></i></p></a></div>-->

                        <!--</div>-->
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-info-50 text-white">
                    <div class="card-body">
                        <div>
                            <h5 class="font-16 text-uppercase mt-0">Attendance</h5>
                            <div class="time-list">
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['FTS']??0); ?></h4>
                                    <p class="font-12">FTS</p>
                                </div>
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['AttedanceCorrection']??0); ?> </h4>
                                    <p class="font-12">To Approve</p>
                                </div>
                            </div>
                            <div class="mini-stat-label bg-primary">
                                <p class="mb-0"><?php echo e($dashboad['totalworkday']??0); ?></p>
                            </div>
                        </div>
                        <!--<div class="pt-2">-->
                        <!--   <div class="float-right"><a href="#" class="text-white">-->
                        <!--   <p class="mb-0">View More<i class="mdi mdi-arrow-right h5 font-14 text-white"></i></p>-->
                        <!--   </a></div>-->
                        <!--</div>-->
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-warning-50 text-white">
                    <div class="card-body">
                        <div>
                            <h5 class="font-16 text-uppercase mt-0">Projects</h5>
                            <div class="time-list">
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['managerProject']??0); ?></h4>
                                    <p class="font-12">As Project Manager</p>
                                </div>
                                <div class="dash-stats-list">
                                    <h4><?php echo e($dashboad['memberProject']??0); ?></h4>
                                    <p class="font-12">Just A Member</p>
                                </div>
                            </div>
                            <div class="mini-stat-label bg-primary">
                                <p class="mb-0"><?php echo e($dashboad['TotalProject']??0); ?></p>
                            </div>
                        </div>
                        <!--<div class="pt-2">-->
                        <!--   <div class="float-right"><a href="#" class="text-white">-->
                        <!--   <p class="mb-0">View More <i class="mdi mdi-arrow-right h5 font-14 text-white"></i></p>-->
                        <!--   </a></div>-->
                        <!--</div>-->
                    </div>
                </div>
            </div>
        </div>
        <?php if(count($userlist) > 0): ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Free Employees This Week
                        </h4>
              <div class="col-sm-12 table-responsive table_timesheet p-0">
                            <table border="0" width="100%" class="table text-center font-14" id="myTable">
                                <tbody>
                                   
                                 <tr
                                      class="bg-dark color-white float-none">
                                      <td>&nbsp;</td>
                                     <td>&nbsp;</td>
                                     <?php $__currentLoopData = $daterange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dateranges): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                 $hideDate= date('D',strtotime($dateranges));
                                         ?>
                                                                                  
                                     <td class="<?php echo e($hideDate); ?>">
                                     <?php echo e(date('D d M',strtotime($dateranges))); ?>

                                    </td>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <td>Hours</td>
                                        </tr>



                                                <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $userprojects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($userprojects->user_hour_mon_color == 'bg-green' || $userprojects->user_hour_tue_color == 'bg-green' || $userprojects->user_hour_wed_color == 'bg-green' || $userprojects->user_hour_thu_color == 'bg-green' || $userprojects->user_hour_fri_color == 'bg-green'): ?>
                                             <tr class="caret_row" data-sid="caret_0">

                                   


                                        <td class="width20 text_ellipses text-left" data-toggle="tooltip" title="" data-original-title="<?php echo e(ucwords($userprojects->userfullname??'')); ?>"><?php echo e(ucwords($userprojects->userfullname??'')); ?></td>
                                        <td><?php echo e($userprojects->repotingmanager??''); ?></td>
                                        
                                         <td class="text-left">
                                          <span>Free: 0 Hrs</span>
                                         </td>
                                                                                   
                                        <td class="text-left <?php echo e((abs($userprojects->user_hour_mon_diff) == 0)?'':$userprojects->user_hour_mon_color); ?> ">
                                                                                      
                                        <span><?php echo e(($userprojects->user_hour_mon_color == 'bg-red')?'Extra: '. abs($userprojects->user_hour_mon_diff). ' Hrs':(in_array('Mon',$userprojects->leaveDate)? 'Leave' : 'Free '. abs($userprojects->user_hour_mon_diff). ' Hrs')); ?></span>
                                                                                    
                                                        </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_tue_diff) == 0)?'':$userprojects->user_hour_tue_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_tue_color == 'bg-red')?'Extra: '.abs($userprojects->user_hour_tue_diff).' Hrs':(in_array('Tue',$userprojects->leaveDate)? 'Leave' : 'Free '.abs($userprojects->user_hour_tue_diff).' Hrs')); ?> </span>
                                                                                    </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_wed_diff) == 0)?'':$userprojects->user_hour_wed_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_wed_color == 'bg-red')?'Extra: '.abs($userprojects->user_hour_wed_diff).' Hrs':(in_array('Wed',$userprojects->leaveDate)? 'Leave' : 'Free '. abs($userprojects->user_hour_wed_diff).' Hrs')); ?>  </span>
                                                                                    </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_thu_diff) == 0)?'':$userprojects->user_hour_thu_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_thu_color == 'bg-red')?'Extra: '.abs($userprojects->user_hour_thu_diff).' Hrs':(in_array('Thu',$userprojects->leaveDate)? 'Leave' : 'Free '.abs($userprojects->user_hour_thu_diff).' Hrs')); ?>  </span>
                                                                                    </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_fri_diff) == 0)?'':$userprojects->user_hour_fri_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_fri_color == 'bg-red')?'Extra: '.abs($userprojects->user_hour_fri_diff).' Hrs':(in_array('Fri',$userprojects->leaveDate)? 'Leave' : 'Free '.abs($userprojects->user_hour_fri_diff).' Hrs')); ?>  </span>
                                                                                    </td>
                                                                                     <td class="text-left">
                                                                                        <span>Free: 0 Hrs</span>
                                                                                    </td>
                                                                                    <td class="text-left">
                                                                                        <?php echo e($userprojects->userhour??'00:00'); ?>

                                                                                    </td>
                                                                               

                                        
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                </table>

                                  
                                </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php

                $arrUser = [];
       $findunderUser = DB::table('main_users')->where('reporting_manager',$userid)->where('isactive',1)->select('id')->get();
       
       
       foreach($findunderUser as $key => $findunderUsers) {
         $arrUser[] =  $findunderUsers->id;
       }

               $nsunderUsewr = DB::table('main_ns_request')->join('main_users','main_ns_request.user_id','=','main_users.id');

        $nsunderUsewr->whereIn('main_users.id',$arrUser)->where('main_ns_request.status','pending');

    

      $nsunderUsewr =  $nsunderUsewr->orderBy('main_ns_request.id','DESC')->select('main_ns_request.*','main_users.userfullname')->get();


                 
               ?>
        <?php if(count($nsunderUsewr) > 0): ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Shift Request
                            <span class="float-right">
                                <button onclick="ns_Attedance(1)" class="btn btn-primary">Approve</button>
                                <button onclick="ns_Attedance(2)" class="btn btn-default">Reject</button>
                            </span>
                        </h4>
                        <table class="datatable table table-bordered dt-responsive nowrap font-14"
                            style="border-collapse: collapse; border-spacing: 0; width: 100%">
                            <thead>

                                <tr>
                                    <th>S.No</th>
                                    <th>
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input checkAll" name="checkAll" type="checkbox"
                                                id="remember">
                                            <label class="custom-control-label" for="customControlInline remember">

                                            </label>
                                        </div>
                                    </th>
                                    <th>Status</th>
                                    <th>Employee Name</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Shift</th>
                                </tr>

                            </thead>
                            <tbody>

                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $nsunderUsewr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nsunderUsewrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input  ns_user_id" type="checkbox"
                                                value="<?php echo e($nsunderUsewrs->id); ?>">
                                            <label class="custom-control-label" for="customControlInline remember">

                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <?php echo e(ucwords($nsunderUsewrs->status)); ?>

                                    </td>
                                    <td><?php echo e($nsunderUsewrs->userfullname); ?></td>
                                    <td><?php echo e(date('d-M-Y',strtotime($nsunderUsewrs->from_date))); ?></td>
                                    <td><?php echo e(date('d-M-Y',strtotime($nsunderUsewrs->to_date))); ?></td>
                                    <td> <?php echo e($nsunderUsewrs->user_status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php endif; ?>



        <?php if(count($expense_approval) > 0): ?>
            <div class="col-sm-12 p-0">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Expenses for Approval


                           
                          
                            <span class="float-right">
                                <button class="btn btn-primary" onclick="expenses_aprovel('Approve')">Approve</button>
                                <button class="btn btn-default" onclick="expenses_aprovel('reject')">Reject</button>
                            </span>
                           
                        </h4>
                        <table class="datatable table table-bordered dt-responsive nowrap font-14"
                            style="border-collapse: collapse; border-spacing: 0; width: 100%">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input checkAll" name="checkAll" type="checkbox"
                                                id="remember">
                                            <label class="custom-control-label" for="customControlInline remember">

                                            </label>
                                        </div>
                                    </th>
                                    <th>Action</th>
                                    <th>Expenses</th>
                                    <th>Emp Name</th>
                                    <th>Date</th>
                                   
                                    <th>Amount</th>
                                    <th>Desc</th>
                                     <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php ($i = 1); ?>
                                <?php $__currentLoopData = $expense_approval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_approvals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td>


                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input expenses" type="checkbox"
                                                name="check" id="remember_<?php echo e($expense_approvals->id); ?>"
                                                value="<?php echo e($expense_approvals->approval_id); ?>">
                                            <label class="custom-control-label" for="customControlInline remember">

                                            </label>
                                        </div>
                                    </td>


                                    
                                        
                                      
                                    <td class="pending-bg">
                                      <?php echo e($expense_approvals->aproval_status); ?>

                                    </td>




                                    <td> <?php echo e($expense_approvals->expense_name); ?>

                                    </td>
                                    <td> <?php echo e(ucwords($expense_approvals->userfullname)); ?></td>
                                    <td><?php echo e($expense_approvals->expense_date); ?></td>
                                   
                                    <td><?php echo e($expense_approvals->expense_amount); ?></td>
                                    <td class="text_ellipses" data-toggle="tooltip" title="<?php echo e($expense_approvals->description); ?>">
                                        <?php echo e($expense_approvals->description); ?></td>
                           <td><a href="<?php echo e(URL::to('view_expenses')); ?>/<?php echo e($expense_approvals->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i>  </a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>


            <?php if(count($leavelist) !=0): ?>
            <div class="col-sm-12 p-0">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Pending Leaves for Approval


                            <?php
                           
                           $arrUser = [];
                           $findunderUser = DB::table('main_users')->where('reporting_manager',$userid)->where('isactive',1)->select('id')->get();
                           
                           
                           foreach($findunderUser as $key => $findunderUsers) {
                             $arrUser[] =  $findunderUsers->id;
                           }
                           ?>
                            <?php if(count($arrUser) > 0): ?>
                            <span class="float-right">
                                <button class="btn btn-primary" onclick="aprovelstatus('Approve')">Approve</button>
                                <button class="btn btn-default" onclick="aprovelstatus('reject')">Reject</button>
                            </span>
                            <?php endif; ?>
                        </h4>
                        <table class="datatable table table-bordered dt-responsive nowrap font-14"
                            style="border-collapse: collapse; border-spacing: 0; width: 100%">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input checkAll" name="checkAll" type="checkbox"
                                                id="remember">
                                            <label class="custom-control-label" for="customControlInline remember">

                                            </label>
                                        </div>
                                    </th>
                                    <th>Action</th>
                                    <th>Type</th>
                                    <th>Emp Name</th>
                                    <th>Date</th>
                                   
                                    <th>Days</th>
                                    <th>Reason</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php ($i = 1); ?>
                                <?php $__currentLoopData = $leavelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leavelists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td>


                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input pendingleave" type="checkbox"
                                                name="check" id="remember_<?php echo e($leavelists->id); ?>"
                                                value="<?php echo e($leavelists->id); ?>" data-userid="<?php echo e($leavelists->user_id); ?>">
                                            <label class="custom-control-label" for="customControlInline remember">

                                            </label>
                                        </div>
                                    </td>


                                    <?php
                                        
                                         if($leavelists->leavetypeid ==1){
                        $title = 'CL';
                        $color = 'green';
                    }else if($leavelists->leavetypeid ==2){
                         $title = 'RH';
                          $color = 'Yellow';
                        
                    }else if($leavelists->leavetypeid ==5){
                          $title = 'MyLeave';
                           $color = 'Pink';
                    }else if($leavelists->leavetypeid ==4){
                        
                         $title = 'Maternity Leave';
                         $color = 'blue';
                        
                    }
                                        ?>

                                    <td class="pending-bg">
                                        <?php if($leavelists->leavestatus=="Pending for approval"): ?>
                                        Pending
                                        <?php else: ?>
                                        <?php echo e($leavelists->leavestatus); ?>

                                        <?php endif; ?>

                                    </td>




                                    <td><?php echo e($title); ?>

                                    </td>
                                    <td> <?php echo e(ucwords($leavelists->userfullname)); ?></td>
                                    <td><?php echo e($leavelists->from_date); ?></td>
                                   
                                    <td>1</td>
                                    <td class="text_ellipses" data-toggle="tooltip" title="<?php echo e($leavelists->reason); ?>">
                                        <?php echo e($leavelists->reason); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(count($approvalList) !=0): ?>
            <div class="col-sm-12 p-0">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Attendance Request Pending For Approval


                            <?php
                           
                           $arrUser = [];
                           $findunderUser = DB::table('main_users')->where('reporting_manager',$userid)->where('isactive',1)->select('id')->get();
                           
                           
                           foreach($findunderUser as $key => $findunderUsers) {
                             $arrUser[] =  $findunderUsers->id;
                           }
                           ?>
                            <?php if(count($arrUser) > 0): ?>


                            <span class="float-right">
                                <button onclick="correctionAttedance('Approve')"
                                    class="btn btn-primary">Approve</button>
                                <button onclick="correctionAttedance('Reject')" class="btn btn-default">Reject</button>
                            </span>
                            <?php endif; ?>
                        </h4>
                        <table class="datatable table table-bordered dt-responsive nowrap font-14"
                            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input checkall" type="checkbox" name="checkall"
                                                id="remember">
                                            <label class="custom-control-label" for="customControlInline remember">
                                            </label>
                                        </div>
                                    </th>
                                    <th>Status</th>
                                    <th>Employee</th>
                                    <th>Date</th>
                                    <th>A_InTime</th>
                                    <th>A_OutTime</th>
                                    <th>P_InTime</th>
                                    <th>P_OutTime</th>
                                    <th>A_Status</th>
                                    <th>P_Status</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php ($i =1); ?>
                                <?php $__currentLoopData = $approvalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approvalLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>

                                    <?php
                                        
                                         if($approvalLists->is_active ==4 || $approvalLists->is_active ==3){
                                             
                                            $attcls = 'disabled'; 
                                             
                                         }else{
                                             
                                             
                                             $attcls = '';
                                             
                                         }
                                        ?>


                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input pendingAttendace" type="checkbox"
                                                <?php echo e($attcls); ?> name="check" id="remember" value="<?php echo e($approvalLists->id); ?>"
                                                data-attDate="<?php echo e($approvalLists->entry_date); ?>"
                                                data-userid="<?php echo e($approvalLists->empid); ?>">
                                            <label class="custom-control-label" for="customControlInline remember">
                                            </label>
                                        </div>
                                    </td>
                                    <td class="pending-bg">
                                        <?php if($approvalLists->is_active == 2): ?>
                                        Pending
                                        <?php elseif($approvalLists->is_active == 3): ?>
                                        Approved
                                        <?php else: ?>

                                        Reject
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(ucwords($approvalLists->userfullname)); ?>

                                    </td>
                                    <td><?php echo e(date('d-M-Y',strtotime($approvalLists->entry_date))); ?></td>
                                    <td><?php echo e(date('H:i:s',strtotime($approvalLists->actual_intime))); ?></td>
                                    <td><?php echo e(date('H:i:s',strtotime($approvalLists->actual_outtime))); ?></td>
                                    <td><?php echo e(date('H:i:s',strtotime($approvalLists->preposed_intime))); ?></td>
                                    <td><?php echo e(date('H:i:s',strtotime($approvalLists->preposed_outtime))); ?></td>
                                    <td><?php echo e($approvalLists->actual_status); ?></td>
                                    <td><?php echo e($approvalLists->preposed_status); ?></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
            <?php endif; ?>
            <!-- <div class="col-sm-4">
                     <div class="card">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4">Today</h4>
                        </div>
                     </div>
                  </div> -->





        </div>


        <!-- end row -->
<div class="col-sm-12">
        <div class="row">
            <!-- <div class="col-sm-4">
                     <div class="card">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-4">Today</h4>
                        </div>
                     </div>
                  </div> -->
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Upcoming Holidays</h4>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <tbody>

                                    <?php $__currentLoopData = $holyDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holyDays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="p-tb-10">
                                            <div class="text-success"><?php echo e($holyDays->holidayname); ?></div>
                                        </td>

                                        <td class="p-tb-10"><?php echo e($holyDays->groupname); ?></td>
                                        <td class="p-tb-10"><?php echo e(date('d-M-Y',strtotime($holyDays->holidaydate))); ?></td>

                                        <td class="p-tb-10"><?php echo e(date('D',strtotime($holyDays->holidaydate))); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!--<tr>-->
                                    <!--   <td class="p-tb-10">-->
                                    <!--      <div class="text-success"> Good Friday</div>-->
                                    <!--   </td>-->
                                    <!--   <td class="p-tb-10">10-Apr-2020</td>-->
                                    <!--   <td class="p-tb-10">Friday</td>-->
                                    <!--</tr>-->
                                    <!--<tr>-->
                                    <!--   <td class="p-tb-10">-->
                                    <!--      <div class="text-success">Gandhi Jayanti</div>-->
                                    <!--   </td>-->
                                    <!--   <td class="p-tb-10">2-Oct-2020</td>-->
                                    <!--   <td class="p-tb-10">Friday</td>-->
                                    <!--</tr>-->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Birthday/Year Completion</h4>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <tbody>

                                    <?php $__currentLoopData = $birthday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $birthdays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <tr>
                                        <td class="p-tb-5">
                                            <div class="notice-board">
                                                <div class="table-img">
                                                    <div class="e-avatar mr-3">

                                                        <?php if(!empty($birthdays->profileimg)): ?>
                                                        <img class="img-fluid thumb-sm rounded-circle mr-2"
                                                            src="<?php echo e(URL::to('public')); ?><?php echo e($birthdays->profileimg); ?>">
                                                        <?php elseif($birthdays->prefix == 1): ?>

                                                        <img class="img-fluid thumb-sm rounded-circle mr-2"
                                                            src="<?php echo e(URL::to('public/uploads/male.png')); ?>">

                                                        <?php elseif($birthdays->prefix == 2 || $birthdays->prefix ==3 ): ?>

                                                        <img class="img-fluid thumb-sm rounded-circle mr-2"
                                                            src="<?php echo e(URL::to('public/uploads/female.png')); ?>">

                                                        <?php else: ?>

                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                                <div class="notice-body">
                                                    <h6 class="m-0 font-500"><?php echo e(ucwords($birthdays->userfullname)); ?></h6>
                                                    <?php if(date('d-m',strtotime($birthdays->dob)) ==
                                                    date('d-m',strtotime(date('Y-m-d')))): ?>
                                                    <span class="ctm-text-sm text-danger">Birthday | Today</span>
                                                    <?php else: ?>
                                                    <span
                                                        class="ctm-text-sm"><?php echo e(date('d M',strtotime($birthdays->dob))); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <?php if(date('d-m',strtotime($birthdays->dob)) ==
                                        date('d-m',strtotime(date('Y-m-d'))) && $birthdays->userid != $userid): ?>
                                        <td><span class="badge badge-success float-right cursorpointer"
                                                onclick="show_wish_dob(<?php echo e($birthdays->userid); ?>)"
                                                id="b_wish_<?php echo e($birthdays->dob); ?>">Wish</span></td>
                                        <?php endif; ?>

                                    </tr>
                                    <tr id="b_wish_<?php echo e($birthdays->userid); ?>" style="display:none;">
                                        <td>
                                            <input type="text" class="form-control" id="comment_<?php echo e($birthdays->userid); ?>"
                                                placeholder="Comment here...">
                                        </td>
                                        <td class="text-right">
                                            <span onclick="submitcomment(<?php echo e($birthdays->userid); ?>)"
                                                class="badge badge-success cursorpointer">Send</span>
                                            <span class="badge badge-primary cursorpointer"
                                                onclick="close_pop(<?php echo e($birthdays->userid); ?>)">Cancel</span>
                                        </td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
<?php if(count($policy) > 0): ?>
    <div class="col-sm-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title mb-4">Company Policy
                            <a href="<?php echo e(URL::to('/policy')); ?>"><i class="fa fa-plus float-right"></i></a>
                        </h4>
                        <div style="height: 335px;overflow-y: auto;">
                          
                        <?php $__currentLoopData = $policy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $policys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($k % 2 ==1): ?>
                        <?php ($class ='alert-success'); ?>
                        <?php else: ?>
                        <?php ($class ='alert-info'); ?>
                        <?php endif; ?>
                        <div class="alert <?php echo e($class); ?> cursorpointer" role="alert"><?php echo e(ucwords(substr($policys->title,0,20))); ?>...
                         <span class="font-12 text-dark float-right"><?php echo e(date('D, M d',strtotime($policys->updated_at))); ?></span>
                                
                               
                               
                                 <?php if(!empty($policys->files)): ?>

                                   <?php $__currentLoopData = explode(',',$policys->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <p>
                       
                       

                    <a class="text_ellipses m-0" title=" <?php echo e(str_replace('/uploads/attach/files/','',$files)); ?>" data-toggle="tooltip" href="<?php echo e(URL::to('public')); ?>/<?php echo e($files); ?>"> <?php echo e(str_replace('/uploads/attach/files/','',$files)); ?></a>
                 
                </p>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php endif; ?>
                  
                   <a href="<?php echo e(URL::to('view-policy')); ?>/<?php echo e($policys->id); ?>" class="text-info float-right">View More...</a>
                                </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                        <!-- <div class="alert alert-info" role="alert">Medical Policy for Parents. <span
                                class="font-12 text-dark">Mon, Apr 2</span></div>
                        <div class="alert alert-warning" role="alert">Laptop Desktop Equipment Policy. <span
                                class="font-12 text-dark">Thu, Mar 22</span></div>
                        <div class="alert alert-danger mb-0" role="alert">Medical Policy for Parents. <span
                                class="font-12 text-dark">Mon, Apr 2</span></div> -->
                            </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>


        </div>
      </div>
        <!-- <div class="row">
                  <div class="col-xl-9">
                     <div class="card crd-blue-border dashboard_leveheight" style="height:238px">
                        <div class="card-body">
                           <h3 class="mt-0 header-title mb-4 font-blue">Circulars</h3>
                           <hr>
                           <ul class="ulcolor">
                              <li>Leaves are restricted for month of October.</li>
                              <li>Policy of EC letter is updated by government.</li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3">
                     <div class="card dashboard_leveheight">
                        <div class="card-body crd-blue-border">
                           <div>
                              <h4 class="mt-0 header-title mb-4 font-blue">Total Leaves</h4>
                           </div>
                           <div>
                              <canvas id="leavechart"></canvas>
                           </div>
                        </div>
                     </div>
                  </div>
               </div> -->
        <!-- end row -->

        <!-- <div class="row">
                  <div class="col-xl-12">
                     <div class="card crd-blue-border">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-5 font-blue">Deparment Wise Head Count</h4>
                           <div class="row">
                              <div class="col-lg-12">
                                 <div>
                                    <canvas id="myChart" height="80"></canvas>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div> -->
        <!-- end row -->
    </div>
    <!-- container-fluid -->
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra_js'); ?>

<script>




    function show_wish_dob(dob) {
        $("#b_wish_" + dob).show();
    }


    function close_pop(id) {
        $("#b_wish_" + id).hide();
    }

    function submitcomment(birthday_user_id) {

        var comment = $('#comment_' + birthday_user_id).val();

        var _token = "<?php echo e(csrf_token()); ?>";

        $.ajax({
            url: '/sendnotification',
            type: "post",
            data: { "_token": _token, "birthday_user_id": birthday_user_id, "comment": comment },
            dataType: 'JSON',

            success: function (data) {
                //console.log(data.city); // this is good

                if (data.status == 200) {
                    $('#loadingDiv').hide();
                    $("#b_wish_" + birthday_user_id).hide();

                    alertify.success(data.msg);




                } else {

                    $('#loadingDiv').hide();


                    alertify.error(data.msg);

                }

            }
        });


    }

</script>



<script type="text/javascript">


    function aprovelstatus(status) {




        leaveid = [];
        userid = [];

        // if is checked
        if ($('.pendingleave').is(':checked')) {


            $('.pendingleave').parent().find('input[type=checkbox]:checked').each(function () {
                leaveid.push($(this).val());
                userid.push($(this).data('userid'));
            });



            leave_id = JSON.stringify(leaveid);
            user_id = JSON.stringify(userid);

            $('#loadingDiv').show();
            var _token = "<?php echo e(csrf_token()); ?>";

            $.ajax({
                url: '/leavestatus',
                type: "post",
                data: { "_token": _token, leave_id: leave_id, user_id: user_id, status: status },
                // dataType: 'JSON',

                success: function (data) {
                    //console.log(data.city); // this is good

                    if (data.status == 200) {
                        $('#loadingDiv').hide();


                        swal("Good job!", data.msg, "success");

                        location.reload();

                    } else if (data.status == 202) {

                        $('#loadingDiv').hide();
                        swal("Good job!", data.msg, "success");
                        location.reload();

                    } else if (data.status == 203) {

                        $('#loadingDiv').hide();
                        swal("Good job!", data.msg, "success");


                    } else {

                        $('#loadingDiv').hide();

                        swal("Good job!", data.msg, "error");

                    }

                }
            });



        }


    }





    function correctionAttedance(status) {




        attendace_id = [];
        user_id = [];
        attdanceDate = [];

        // if is checked
        if ($('.pendingAttendace').is(':checked')) {


            $('.pendingAttendace').parent().find('input[type=checkbox]:checked').each(function () {
                attendace_id.push($(this).val());
                user_id.push($(this).data('userid'));
                attdanceDate.push($(this).data('attDate'));
            });





            attendace_id = JSON.stringify(attendace_id);
            user_id = JSON.stringify(user_id);
            attdanceDate = JSON.stringify(attdanceDate);

            $('#loadingDiv').show();
            var _token = "<?php echo e(csrf_token()); ?>";

            $.ajax({
                url: '/attendancestatus',
                type: "post",
                data: { "_token": _token, attendace_id: attendace_id, user_id: user_id, status: status, attdanceDate: attdanceDate },
                // dataType: 'JSON',

                success: function (data) {
                    //console.log(data.city); // this is good

                    if (data.status == 200) {
                        $('#loadingDiv').hide();


                        swal("Good job!", data.msg, "success");

                        location.reload();

                    } else if (data.status == 202) {

                        $('#loadingDiv').hide();
                        swal("Good job!", data.msg, "success");
                        location.reload();

                    } else if (data.status == 203) {

                        $('#loadingDiv').hide();
                        swal("Good job!", data.msg, "success");


                    } else {

                        $('#loadingDiv').hide();

                        swal("Good job!", data.msg, "error");

                    }

                }
            });



        }


    }


    function expenses_aprovel(status) {




var expenses = [];


// if is checked
if ($('.expenses').is(':checked')) {


    $('.expenses').parent().find('input[type=checkbox]:checked').each(function () {
        expenses.push($(this).val());

    });





    expenses = JSON.stringify(expenses);


    $('#loadingDiv').show();
    var _token = "<?php echo e(csrf_token()); ?>";

    $.ajax({
        url: '/expenses_approvel',
        type: "post",
        data: { "_token": _token, expenses: expenses, status: status },
        // dataType: 'JSON',

        success: function (data) {
            //console.log(data.city); // this is good

            if (data.status == 200) {
                $('#loadingDiv').hide();


                swal("Good job!", data.msg, "success");

                location.reload();

            } else if (data.status == 202) {

                $('#loadingDiv').hide();
                swal("Good job!", data.msg, "success");
                location.reload();

            } else if (data.status == 203) {

                $('#loadingDiv').hide();
                swal("Good job!", data.msg, "success");


            } else {

                $('#loadingDiv').hide();

                swal("Good job!", data.msg, "error");

            }

        }
    });



}


}




    function ns_Attedance(status) {




        var ns_id = [];


        // if is checked
        if ($('.ns_user_id').is(':checked')) {


            $('.ns_user_id').parent().find('input[type=checkbox]:checked').each(function () {
                ns_id.push($(this).val());

            });





            ns_id = JSON.stringify(ns_id);


            $('#loadingDiv').show();
            var _token = "<?php echo e(csrf_token()); ?>";

            $.ajax({
                url: '/ns_approvel',
                type: "post",
                data: { "_token": _token, ns_id: ns_id, status: status },
                // dataType: 'JSON',

                success: function (data) {
                    //console.log(data.city); // this is good

                    if (data.status == 200) {
                        $('#loadingDiv').hide();


                        swal("Good job!", data.msg, "success");

                        location.reload();

                    } else if (data.status == 202) {

                        $('#loadingDiv').hide();
                        swal("Good job!", data.msg, "success");
                        location.reload();

                    } else if (data.status == 203) {

                        $('#loadingDiv').hide();
                        swal("Good job!", data.msg, "success");


                    } else {

                        $('#loadingDiv').hide();

                        swal("Good job!", data.msg, "error");

                    }

                }
            });



        }


    }



    // check all
    $(document).ready(function () {
        $('.checkAll').on('click', function () {
            $(this).closest('table').find('tbody :checkbox')
                .prop('checked', this.checked)
                .closest('tr').toggleClass('selected', this.checked);
        });

        $('tbody :checkbox').on('click', function () {
            $(this).closest('tr').toggleClass('selected', this.checked); //Classe de seleção na row

            $(this).closest('table').find('.checkAll').prop('checked', ($(this).closest('table').find('tbody :checkbox:checked').length == $(this).closest('table').find('tbody :checkbox').length)); //Tira / coloca a seleção no .checkAll
        });
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>