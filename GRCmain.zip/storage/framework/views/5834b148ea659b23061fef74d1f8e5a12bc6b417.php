   <?php $__env->startSection('content'); ?>


<div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Users</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Jaya Motors</a></li>
                                    <li class="breadcrumb-item active"><a href="users.html">All Users</a></li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right d-none d-md-block">
                                    <div class="dropdown">
                                        <button class="btn btn-primary" type="button" data-toggle="modal"
                                            data-target="#adduser" aria-expanded="false">
                                            Add User</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(Session::has('msg')): ?>
<p class="alert alert-info"><?php echo e(Session::get('msg')); ?></p>
<?php endif; ?>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Full Name</th>
                                                <th>Email</th>
                                                <th>User ID</th>
                                                <th>Type</th>
                                               
                                                <th>Password</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php ($i = 1); ?>
                                        <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($i++); ?>

                                                </td>
                                                <td><?php echo e($user_lists->userfullname); ?></td>
                                                <td><?php echo e($user_lists->emailaddress); ?></td>
                                                <td><?php echo e($user_lists->employeeId); ?></td>
                                                <td><?php echo e($user_lists->rolename); ?></td>
                                           
                                                <td>
                                                    <button class="btn btn-primary" onclick="change_password('<?php echo e($user_lists->id); ?>')">Reset</button>
                                                </td>
                                                <td>

                                                <?php if(PermissionHelper::frontendPermission('edit-user')): ?>


                                                    <i   onclick="get_user('<?php echo e($user_lists->id); ?>')" class="mdi mdi-pencil text-warning"></i>

                                                   <?php endif; ?> 
                                                    <?php if(PermissionHelper::frontendPermission('delete-user')): ?>


                                                    <a onclick="return confirm('Are you sure you want to delete this ?');" href="<?php echo e(URL::to('delete-user')); ?>/<?php echo e($user_lists->id); ?>">
                                                    <i class="mdi mdi-delete text-danger"></i>


                                                    </a>

                                                   
                                                    <?php endif; ?>
                                                    
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>


            <div id="adduser" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Create a New User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">

                <form id="user_add">
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">Full Name <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="full_name" id="full_name">
                            <div id="full_name_error"></div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">Email <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            <input type="email" class="form-control" name="email_id" id="email_id">
                            <div id="email_id_error"></div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">User ID <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="user_id" id="user_id">
                            <div id="user_id_error"></div>
                        </div>
                    </div>
                
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">Type <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            
                            <select  class="form-control" name="role" id="role">
                               <option value="">selct option</option>
                               <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($roles->id); ?>"><?php echo e($roles->rolename); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <div id="role_error"></div>
                            
                        </div>
                    </div>
                    <input type="hidden" name="user_edit_id" id="user_edit_id">
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">Password <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            <input class="form-control" type="password"  name="password" id="password" >
                            <div id="password_error"></div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">Confirm Password <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            <input class="form-control" type="password"  name="cpassword" id="cpassword" >
                            <div id="cpassword_error"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="create_user" class="btn btn-primary waves-effect">save</button>
                    <button type="button" class="btn btn-secondary waves-effect waves-light"
                        data-dismiss="modal">Cancel</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div id="password_reset" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Reset Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">New Password <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="change_password">
                            <div id="change_password_error"></div>
                        </div>
                    </div>
                    <input type="hidden" id="password_user_id">
                    <div class="form-group row">
                        <label for="example-text-input" class="col-sm-4 col-form-label">Confirm Password <span class="text-danger">*</span></label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="change_cpassword">
                            <div id="change_cpassword_error"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="change_password" class="btn btn-primary waves-effect">Save</button>
                    <button type="button" class="btn btn-secondary waves-effect waves-light"
                        data-dismiss="modal">Cancel</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

            <?php $__env->stopSection(); ?>

            <?php $__env->startSection('extra_js'); ?>

            <script>


            function get_user(user_id){

                var _token = "<?php echo e(csrf_token()); ?>";

$.ajax({
     url: '/get_user',
     type: "post",
     data: {"_token": _token,"user_id":user_id},
     dataType: 'JSON',
      
     success: function (data) {
     //console.log(data.city); // this is good

 
     var full_name = $('#full_name').val(data.user.userfullname);
    var email_id = $('#email_id').val(data.user.emailaddress);
    var user_id = $('#user_id').val(data.user.employeeId);
    var role = $('#role').val(data.user.userfullname);
      $('#myModalLabel').text('Edit User');
    $("#role > option").each(function() {
         if($(this).val() == data.user.emprole){
            $('#role').val(data.user.emprole).attr("selected"); 
         }

      });

       $('#user_edit_id').val(data.user.id);

       $('#adduser').modal('show');
     },
     error: function(xhr, status, error) {
      var err = eval("(" + xhr.responseText + ")");
      alert(err.Message);
      }
   });

            }


            function change_password(user_id){

             $('#password_user_id').val(user_id);
             $('#password_reset').modal('show');

            }

            $(document).on('click','#change_password',function(){
              error = 1;

              var change_password = $('#change_password').val();
              var change_cpassword = $('#change_cpassword').val();
              var password_user_id = $('#password_user_id').val();
              

         if(change_password ==''){
         $('#change_password_error').text('Password is Required').attr('style','color:red');
         $('#change_password_error').show();
           error = 0;
              return false;
      }else{$('#change_password_error').hide();  error = 1;}

      if(change_cpassword ==''){
         $('#change_cpassword_error').text('Confirm password is Required').attr('style','color:red');
         $('#change_cpassword_error').show();
           error = 0;
              return false;
     }else if(change_password != change_cpassword){

            $('#change_cpassword_error').text('Password Does Not Match').attr('style','color:red');
            $('#change_cpassword_error').show();
            error = 0;
            return false;

      }else{$('#change_cpassword_error').hide();  error = 1;}


      
      if(error ==1){

var _token = "<?php echo e(csrf_token()); ?>";

$.ajax({
     url: '/change_password',
     type: "post",
     data: {"_token": _token,"password_user_id":password_user_id,"change_password":change_password},
     dataType: 'JSON',
      
     success: function (data) {
     //console.log(data.city); // this is good
 
       if(data.status ==200){
          $('#loadingDiv').hide();
      
          
          swal("Good job!", data.msg, "success");

         location.reload();

       }else if(data.status ==202){

           $('#loadingDiv').hide();
         swal("Good job!",  data.msg, "success");
         $('#password_reset').modal('hide');
 
           }else if(data.status ==203){

           $('#loadingDiv').hide();
           swal("Good job!",  data.msg, "success");


       }else{

          $('#loadingDiv').hide();
         
          swal("Good job!",  data.msg, "error");

       }
       
     },
     error: function(xhr, status, error) {
      var err = eval("(" + xhr.responseText + ")");
      alert(err.Message);
      }
   });
   }


          });




$(document).on('click','#create_user',function(){
    error = 1;
    var full_name = $('#full_name').val();
    var email_id = $('#email_id').val();
    var user_id = $('#user_id').val();
    var role = $('#role').val();
     var password = $('#password').val();
     var cpassword = $('#cpassword').val();
     var user_edit_id =  $('#user_edit_id').val();


     if(full_name ==''){
         $('#full_name_error').text('Full Name is Required').attr('style','color:red');
         $('#full_name_error').show();
           error = 0;
              return false;
      }else{$('#full_name_error').hide();  error = 1;}


      if(email_id ==''){
         $('#email_id_error').text('Email is Required').attr('style','color:red');
         $('#email_id_error').show();
           error = 0;
              return false;
      }else{$('#email_id_error').hide();  error = 1;}


      if(user_id ==''){
         $('#user_id_error').text('UserID is Required').attr('style','color:red');
         $('#user_id_error').show();
           error = 0;
              return false;
      }else{$('#user_id_error').hide();  error = 1;}


      if(role ==''){
         $('#role_error').text('Type is Required').attr('style','color:red');
         $('#role_error').show();
           error = 0;
              return false;
      }else{$('#role_error').hide();  error = 1;}


      if(password ==''){
         $('#password_error').text('Password is Required').attr('style','color:red');
         $('#password_error').show();
           error = 0;
              return false;
      }else{$('#password_error').hide();  error = 1;}



        if(cpassword ==''){
         $('#cpassword_error').text('Password is Required').attr('style','color:red');
         $('#cpassword_error').show();
           error = 0;
              return false;
        }else if(password != cpassword){

            $('#cpassword_error').text('Password Does Not Match').attr('style','color:red');
         $('#cpassword_error').show();
           error = 0;
              return false;

      }else{$('#coursetype_error').hide();  error = 1;}


      if(error ==1){

  

var _token = "<?php echo e(csrf_token()); ?>";

$.ajax({
     url: '/add_user',
     type: "post",
     data: {"_token": _token,"full_name":full_name,"email_id":email_id,"role":role,"password":password,"user_id":user_id,"user_edit_id":user_edit_id},
     dataType: 'JSON',
      
     success: function (data) {
     //console.log(data.city); // this is good
 
       if(data.status ==200){
          $('#loadingDiv').hide();
      
          
          swal("Good job!", data.msg, "success");

         location.reload();

       }else if(data.status ==202){
        $('#adduser').modal('hide');
           $('#loadingDiv').hide();
         swal("Good job!",  data.msg, "success");
        

           }else if(data.status ==203){

           $('#loadingDiv').hide();
           swal("Good job!",  data.msg, "success");


       }else{

          $('#loadingDiv').hide();
         
          swal("Good job!",  data.msg, "error");

       }
       
     },
     error: function(xhr, status, error) {
      var err = eval("(" + xhr.responseText + ")");
      alert(err.Message);
      }
   });
   }


});

            </script>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>