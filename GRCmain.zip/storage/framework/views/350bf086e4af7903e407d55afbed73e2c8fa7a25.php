<?php $__env->startSection('content'); ?>
<?php 
 
 $current_year = date('Y')-1;
  $future_year = date('Y');


   ?>
<?php $__env->startSection('extra_css'); ?>

<style>

.without_ampm::-webkit-datetime-edit-ampm-field {
   display: none;
 }

 input[type=time]::-webkit-clear-button {
   -webkit-appearance: none;
   -moz-appearance: none;
   -o-appearance: none;
   -ms-appearance:none;
   appearance: none;
   margin: -10px; 
 }
option:hover{
    background:red;
}
</style>


<?php $__env->stopSection(); ?>

 <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Timesheet</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>"><?php echo e($mainsetting->site_title); ?></a></li>
                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Timesheet</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <!--<div class="float-right">-->
                                <!--<span class="font-600 m-r-10">Legend:</span>-->
                                <!--<span class="span_hr bg-blank widthauto float-none">Leave</span>-->
                                <!--<span class="span_hr bg-weekend widthauto float-none">Week Off</span>-->
                                <!--<span class="span_hr bg-approx widthauto float-none">Estimate Hr</span>-->
                                <!--<span class="span_hr bg-equalhr widthauto float-none">Actual Hr</span>-->
                                <!--<span class="span_hr bg-free widthauto float-none">Free Hr</span>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <ul class="nav nav-tabs nav-tabs-custom" role="tablist">
                                               
                                                   <?php if(PermissionHelper::frontendPermission('user-timsheet')): ?>
                                                <li  class="nav-item"><a href="<?php echo e(URL::to('/user-timesheet')); ?>" onclick="timesheet('user')" class="nav-link" ><span class="d-block d-sm-none"><i
                                                                class="fas fa-home"></i></span> <span
                                                            class="d-none d-sm-block">Timesheet</span></a></li>
                                                            <?php endif; ?>
                                                       <?php if(PermissionHelper::frontendPermission('assign-timesheet')): ?>        
                                                <li class="nav-item"><a  href="<?php echo e(URL::to('/timesheet')); ?>" onclick="timesheet('allocation')" class="nav-link active" ><span
                                                            class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                                        <span class="d-none d-sm-block">Timesheet Allocation</span></a>
                                                </li>
                                                      <?php endif; ?>
                                                   <?php if(PermissionHelper::frontendPermission('emp-approvel')): ?>        
                                                <li  class="nav-item"><a href="<?php echo e(URL::to('/emp-timesheet')); ?>" onclick="timesheet('emp')" class="nav-link " ><span class="d-block d-sm-none"><i
                                                                class="far fa-user"></i></span> <span
                                                            class="d-none d-sm-block">Employee Timesheet</span></a></li>
                                                                  <?php endif; ?>
                                            </ul>
                                            
                                            
                                            
                                            <!--<ul class="nav nav-tabs nav-tabs-custom" role="tablist">-->
                                            <!--    <li class="nav-item"><a class="nav-link active" data-toggle="tab"-->
                                            <!--            href="#home1" role="tab"><span class="d-block d-sm-none"><i-->
                                            <!--                    class="fas fa-home"></i></span> <span-->
                                            <!--                class="d-none d-sm-block">Timesheet</span></a></li>-->
                                            <!--    <li class="nav-item"><a class="nav-link" data-toggle="tab"-->
                                            <!--            href="#timeallocation" role="tab"><span-->
                                            <!--                class="d-block d-sm-none"><i class="far fa-user"></i></span>-->
                                            <!--            <span class="d-none d-sm-block">Timesheet Allocation</span></a>-->
                                            <!--    </li>-->
                                            <!--    <li class="nav-item"><a class="nav-link" data-toggle="tab"-->
                                            <!--            href="#profile1" role="tab"><span class="d-block d-sm-none"><i-->
                                            <!--                    class="far fa-user"></i></span> <span-->
                                            <!--                class="d-none d-sm-block">Employee Timesheet</span></a></li>-->
                                            <!--</ul>-->
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane p-3" id="home1" role="tabpanel">
                                                    <div class="row m-t-10">
                                                        <div class="col-sm-12 btn-tab">
                                                            <ul class="nav nav-tabs small justify-content-end"
                                                                role="tablist">
                                                                <li class="nav-item"><a class="nav-link active"
                                                                        data-toggle="tab" href="#tab1" role="tab">Week
                                                                        1</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab2" role="tab">Week
                                                                        2</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab3" role="tab">Week
                                                                        3</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab4" role="tab">Week
                                                                        4</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab5" role="tab">Week
                                                                        5</a></li>
                                                            </ul>
                                                            <div class="tab-content py-2">
                                                                <div class="tab-pane active" id="tab1" role="tabpanel">
                                                                    <div class="col-sm-12 p-0 timesheet">

                                                                        <ul class="bg-gray nav nav-tabs small justify-content-end"
                                                                            role="tablist">
                                                                            <li class="nav-item"><a
                                                                                    class="nav-link active"
                                                                                    data-toggle="tab" href="#tab1"
                                                                                    role="tab">Sun 27
                                                                                    Dec</a>
                                                                            </li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab2"
                                                                                    role="tab">Mon 28 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab3"
                                                                                    role="tab">Tue 29 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab4"
                                                                                    role="tab">Wed 30 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab5"
                                                                                    role="tab">Thurs 31 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab6"
                                                                                    role="tab">Fri 1 Jan</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab7"
                                                                                    role="tab">Sat 2 Jan</a></li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-sm-12 p-0 treeview">
                                                                        <!-- <ul id="" class="evendiv">
                                                                            <li>
                                                                                <span class="caret">Nisha Upreti</span>
                                                                                <span class="float-right">
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-approx">9
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                </span> -->
                                                                        <ul class="evendiv">
                                                                            <li><span
                                                                                    class="caret p-level1-span">Salesforce</span>
                                                                                <span class="float-right">
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-approx">9
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                </span>
                                                                                <ul class="nested">
                                                                                    <li>
                                                                                        <span
                                                                                            class="caret p-level2-span">HSBC</span>
                                                                                        <span class="span_45hr">45
                                                                                            Hr</span>
                                                                                        <ul class="nested lastul">
                                                                                            <li>
                                                                                                <span>Design</span>
                                                                                                <div
                                                                                                    class="text-right float-right padding-5 inline-block width85">
                                                                                                    <span
                                                                                                        class="timespan">--
                                                                                                    </span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="time" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00">
                                                                                                    </span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="time" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="time" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="time" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="time" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan">--
                                                                                                    </span>
                                                                                                </div>

                                                                                            </li>
                                                                                        </ul>
                                                                                    </li>
                                                                            </li>
                                                                        </ul>
                                                                        <!-- </li>
                                                                        </ul> -->
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab2" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">Primary</h3>
                                                                            <p class="card-text">With supporting text
                                                                                below as a natural
                                                                                lead-in to additional content.</p>
                                                                            <a href="#"
                                                                                class="btn btn-outline-secondary">Outline</a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">Primary</h3>
                                                                            <p class="card-text">With supporting text
                                                                                below as a natural
                                                                                lead-in to additional content.</p>
                                                                            <a href="#"
                                                                                class="btn btn-outline-secondary">Outline</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab3" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">week3</h3>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab4" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">week4</h3>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab5" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">week5</h3>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-12 m-t-20">
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <label>Weekly Notes</label>
                                                                    </div>
                                                                    <div>
                                                                        <textarea class="form-control"
                                                                            rows="3"></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12 m-t-20">
                                                                    <div class="float-right">
                                                                        <button class="btn btn-primary">Save</button>
                                                                        <button class="btn btn-success">Save &
                                                                            Submit</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <?php echo e($assignproject->appends(request()->query())->links()); ?>

                                                <div class="tab-pane active p-3" id="timeallocation" role="tabpanel">
                                                    <div class="col-sm-12 p-0 m-t-20">
                                                        
                                                    </div>
                                                     <?php
                                                                            
                                                                            $startDate = $daterange[0];
                                                                            $showDate = date('Y-m',strtotime($startDate));
                                                                            $showMonth = date('F',strtotime($daterange[6]));
                                                                             $endtDate = $daterange[1];
                                                                             $startDay = date('d',strtotime($startDate));
                                                                            $endDay = date('d',strtotime($endtDate));
                                                                            //dd($showDate);
                                                                          
                                                                            ?>     
                                                    <div class="row m-t-10">
                                                        <div class="col-sm-12 btn-tab">
                                                            <ul class="nav nav-tabs small justify-content-end"
                                                                role="tablist">
                                                                <div class="absolutemonth">
                                                                       <h6
                                                                    class="m-0 text-center relative bg-light padding-5 cursorpointer font-20">
                                                                    <i class="fa fa-calendar-alt m-r-5"
                                                                        id="datepicker"></i><input type="hidden"
                                                                        id="dp" /><?php echo e($showMonth); ?>

                                                                        
                                                                      
                                                                    <div class="tableabsolute">
                                                                           
                                                                        <table border="1">
                                                                            <thead>
                                                                                <tr>
                                                                                    <td colspan="3" class="form-group">
                                                                                        <select class="form-control" id="getyear">
                                                                                             <?php for($i=0; $i < 5; $i++){ 
                                                                                                 
                                                                                               
                                                     
                                                           ?>
                                            <option value="<?php echo ($current_year+$i); ?>" <?php echo ($future_year == $current_year+$i)?'selected':'';?>><?php echo ($current_year+$i); ?></option>
                                        <?php } ?>
                                                                                        </select>
                                                                                    </td>
                                                                                </tr>
                                                                            </thead>
                                                                            <tr>
                                                                                <td  onclick="getresult(1,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')"  >Jan</td>
                                                                                <td  onclick="getresult(2,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Feb</td>
                                                                                <td   onclick="getresult(3,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Mar</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td  onclick="getresult(4,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Apr</td>
                                                                                <td  onclick="getresult(5,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >May</td>
                                                                                <td   onclick="getresult(6,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Jun</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td  onclick="getresult(7,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Jul</td>
                                                                                <td  onclick="getresult(8,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Aug</td>
                                                                                <td  onclick="getresult(9,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Sep</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td  onclick="getresult(10,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Oct</td>
                                                                                <td  onclick="getresult(11,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Nov</td>
                                                                                <td  onclick="getresult(12,'<?php echo e($weekcountpassed); ?>','<?php echo e($currentweekCount); ?>','<?php echo e($totalweekCount); ?>','time')" >Dec</td>
                                                                            </tr>
                                                                        </table>
                                                                    </div>
                                                                </h6>
                                                                </div>
                                                                
                                                                <?php for($i = 1;$i <= $totalweekCount;$i++): ?>
                                                                

                                                                 <?php if($i== $weekcountpassed): ?>
                                                                   <?php
                                                                   $ac ='active';
                                                                   ?>
                                                                 <?php else: ?>
                                                                 
                                                                  <?php
                                                                   $ac ='';
                                                                   ?>
                                                                 
                                                                 <?php endif; ?>
                                                                <li  class="nav-item"><a class="nav-link <?php echo e($ac); ?>"
                                                                    onclick="assignHour('<?php echo e($PaginationDate); ?>','<?php echo e($i); ?>','<?php echo e($totalweekCount); ?>','time')" href="javascript:void(0)">Week
                                                                        <?php echo e($i); ?></a></li>
                                                                <?php endfor; ?>        
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab2" role="tab">Week-->
                                                                <!--        2</a></li>-->
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab3" role="tab">Week-->
                                                                <!--        3</a></li>-->
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab4" role="tab">Week-->
                                                                <!--        4</a></li>-->
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab5" role="tab">Week-->
                                                                <!--        5</a></li>-->
                                                            </ul>
                                                            <div class="tab-content py-2">
                                                                
                                                               
                                                                
                                                                  <?php for($i = 1;$i <= $currentweekCount;$i++): ?>
                                                                  
                                                                   <?php if($i== $currentweekCount): ?>
                                                                   <?php
                                                                   $ac ='active';
                                                                   ?>
                                                                 <?php else: ?>
                                                                 
                                                                  <?php
                                                                   $ac ='';
                                                                   ?>
                                                                 
                                                                 <?php endif; ?>
                                                                 
                                                                        <?php endfor; ?>
                                                                            
                                                                              
                                                                   
                                                                            
                                                                         
                                                                
                                                                <div class=" <?php echo e($ac); ?>" id="timetab1" role="tabpanel">
                                                                      <div
                                                                        class="col-sm-12 table-responsive table_timesheet">
                                                                        <table border="0" width="100%"
                                                                            class="table text-center font-14">
                                                                            <thead>
                                                                                
                                                                            
                                                                                
                                                                                 <?php
                                    $managerlist = DB::table('main_users')->where('emprole',3)->where('isactive',1)->orderBy('userfullname','ASC')->get();
                                    ?>
                                                                                <tr>
                                                                                    <th class="bg-naviblue text-left">Name
                                                                                    </th>
                                                                                    <th class="bg-naviblue text-center">
                                                                                        <form class="m-0" method="GET">
                                                                                        <select onchange="this.form.submit()" name="mid" id="mid" style="height: 22px;border-radius: 0;font-size: 14px;padding: 0px;border: none;">
                                                                                            <option value="">Select Manager</option>
                                                                                            <?php $__currentLoopData = $managerlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $managerlists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($managerlists->id); ?>" <?php if(!empty($_GET['mid'])): ?> <?php if($_GET['mid'] == $managerlists->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($managerlists->userfullname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </select> 
                                                                                        </form>
                                                                                    </th>
                                                                                    <th class="bg-naviblue text-center" colspan="8">
                                                                                        Allocation Hours
                                                                    in Week <?php echo e($currentweekCount??1); ?></th class="p-10">
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                                <tr
                                                                                    class="bg-dark color-white float-none">
                                                                                    <td>&nbsp;</td>
                                                                                      <td>&nbsp;</td>
                                                                                   <?php $__currentLoopData = $daterange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dateranges): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                   <?php
                                                                                  $hideDate= date('D',strtotime($dateranges));
                                                                                   ?>
                                                                                  
                                                                 <td class="<?php echo e($hideDate); ?>">
                                                                        <?php echo e(date('D d M',strtotime($dateranges))); ?>

                                                                 </td>
                                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <td>Hours</td>
                                                                                </tr>
                                                                             
                                                                                   <?php $__currentLoopData = $assignproject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $userprojects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                     <?php 
                                                                                    
                                                                                     
                                                                                     $s_id = 'caret_'.$key;
                                                                                     ?>
                                                                       <form method="post" id="timealocationentrytime">
                                                                                <tr class="caret_row" data-sid = "<?php echo e($s_id); ?>">
                                                                                    <td class="width20 text_ellipses text-left" data-toggle="tooltip" title="<?php echo e(ucwords($userprojects->userfullname??'')); ?>"><span class="caret"><?php echo e(ucwords($userprojects->userfullname??'')); ?></span></td>
                                                                                    <td><?php echo e($userprojects->repotingmanager??''); ?></td>
                                                                                    <td class="text-left">
                                                                                        <span>Free: 0 Hrs</span>
                                                                                    </td>
                                                                                   
                                                                                    <td class="text-left <?php echo e((abs($userprojects->user_hour_mon_diff) == 0)?'':$userprojects->user_hour_mon_color); ?> ">
                                                                                        <span><?php echo e(($userprojects->user_hour_mon_color == 'bg-red')?'Extra: ':'Free: '); ?> <?php echo e(abs($userprojects->user_hour_mon_diff)); ?> Hrs</span>
                                                                                    </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_tue_diff) == 0)?'':$userprojects->user_hour_tue_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_tue_color == 'bg-red')?'Extra: ':'Free: '); ?>  <?php echo e(abs($userprojects->user_hour_tue_diff)); ?> Hrs</span>
                                                                                    </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_wed_diff) == 0)?'':$userprojects->user_hour_wed_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_wed_color == 'bg-red')?'Extra: ':'Free: '); ?>  <?php echo e(abs($userprojects->user_hour_wed_diff)); ?> Hrs</span>
                                                                                    </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_thu_diff) == 0)?'':$userprojects->user_hour_thu_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_thu_color == 'bg-red')?'Extra: ':'Free: '); ?>  <?php echo e(abs($userprojects->user_hour_thu_diff)); ?> Hrs</span>
                                                                                    </td>
                                                                                     <td class="text-left <?php echo e((abs($userprojects->user_hour_fri_diff) == 0)?'':$userprojects->user_hour_fri_color); ?>">
                                                                                        <span><?php echo e(($userprojects->user_hour_fri_color == 'bg-red')?'Extra: ':'Free: '); ?>  <?php echo e(abs($userprojects->user_hour_fri_diff)); ?> Hrs</span>
                                                                                    </td>
                                                                                     <td class="text-left">
                                                                                        <span>Free: 0 Hrs</span>
                                                                                    </td>
                                                                                    <td class="text-left">
                                                                                        <?php echo e($userprojects->userhour??'00:00'); ?>

                                                                                    </td>
                                                                                </tr>
                                                                                  <input type="hidden" name="currentweek" value="<?php echo e($weekcountpassed); ?>">
                                                                                  <input type="hidden" name="emp_id[]" value="<?php echo e($userprojects->emp_id); ?>">
                                                                                  
                                                                                    <?php ($i = 1); ?>
                                                                                    <?php $__currentLoopData = $userprojects->userproject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    
                                                                                    
                                                                                   
                                                                                     <form method="post" id="timealocationentrytime">
                                                                                <tr class="caret_row1" data-sid = "<?php echo e($s_id); ?>">
                                                                                     <td class="width20 text_ellipses text-left" data-toggle="tooltip" title="<?php echo e(ucwords($projects->project_name)); ?>"><span class="caret p-l-15"><?php echo e(ucwords($projects->project_name)); ?></span></td>
                                                                                     <td>&nbsp;</td>
                                                                                     <td class="text-left">
                                                                        <span> 0 Hrs</span>
                                                                    </td>
                                                                    <td class="text-left ">
                                                                        <span><?php echo e(abs($projects->project_hour_mon??'')); ?> Hrs</span>
                                                                    </td>
                                                                     <td class="text-left ">
                                                                        <span> <?php echo e(abs($projects->project_hour_tue??'')); ?> Hrs</span>
                                                                    </td>
                                                                     <td class="text-left">
                                                                        <span> <?php echo e(abs($projects->project_hour_wed??'')); ?> Hrs</span>
                                                                    </td>
                                                                     <td class="text-left">
                                                                        <span> <?php echo e(abs($projects->project_hour_thu??'')); ?> Hrs</span>
                                                                    </td>
                                                                     <td class="text-left">
                                                                        <span> <?php echo e(abs($projects->project_hour_fri??'')); ?> Hrs</span>
                                                                    </td>
                                                                     <td class="text-left">
                                                                        <span> 0 Hrs</span>
                                                                    </td>
                                                                     <td class="text-left">
                                                                      <?php echo e($projects->project_hour??'00:00'); ?>

                                                                    </td>
                                                                                </tr>
                                                                                
                                                                                 <input type="hidden" name="project_id[]" value="<?php echo e($projects->project_id); ?>">
                                                                                  <?php $__currentLoopData = $projects->gettask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ke =>  $gettask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                  
                                                                                   <input type="hidden" name="project_taskId[<?php echo e($projects->project_id); ?>][]" value="<?php echo e($gettask->project_task_id); ?>">
                                                                                <tr class="caret_row2" data-sid = "<?php echo e($s_id); ?>">
                                                                                    <td class="text-left width20 text_ellipses text-left" data-toggle="tooltip" title="<?php echo e(ucwords($gettask->task)); ?>">
                                                                                        <span
                                                                                            class="p-l-35"><?php echo e(ucwords($gettask->task)); ?></span>
                                                                                    </td>
                                                                                    <td>&nbsp;</td>
                                                                                    <?php $__currentLoopData = $daterange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t => $dateranges): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                              
                                                                                                              <?php
                                                                                                              
                                                                                                              $Day =  date('D',strtotime($dateranges));
                                                                                                              
                                                                                                                if ($Day== 'Sun' || $Day == 'Sat'){
                                                                                                                    $display = 'none';
                                                                                                                    $cl = 'readonly';
                                                                                                                    $class="clr";
                                                                                                                    
                                                                                                                }else{
                                                                                                                    
                                                                                                                     $display = 'block';
                                                                                                                    
                                                                                                                      $cl = '';
                                                                                                                       $class="";
                                                                                                                    
                                                                                                                }
                                                                                                                
                                                                                                                   if(in_array($projects->project_id,$projectidlist) || in_array($userprojects->emp_id,$emp_list)){
                                                                                                                    $projectenbled = '';
                                                                                                                }else{
                                                                                                                     $projectenbled = 'futurDate';
                                                                                                                }
                                                                                                                
                                                                                                                
                                                                                                              
                                                                                                              ?>
                                                                                                              
                                                                                                              
                                                                                                            <td
                                                                                                                class="timespan">
                                                                                                                <input type="hidden" <?php echo e($cl); ?> name = "entrydate[<?php echo e($projects->project_id); ?>][<?php echo e($gettask->project_task_id); ?>][]" value="<?php echo e($dateranges); ?>">
                                                                                                                <input class="defaultEntry without_ampm <?php echo e($class); ?> <?php echo e($projectenbled); ?>"
                                                                                                                    type="text" step="1800" min="00:00" max="23:59"  required class="without" autofocus <?php echo e($cl); ?>  
                                                                                                                    placeholder="00:00" name = "entryhour[<?php echo e($projects->project_id); ?>][<?php echo e($gettask->project_task_id); ?>][]" value="<?php echo e($gettask->duration[$t]??'00:00'); ?>">
                                                                                                            </td>
                                                                                                           
                                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                            <td><?php echo e($gettask->task_hour); ?></td>
                                                                                </tr>
                                                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                             
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                
                                                                                   <tr class="row_update <?php echo e($s_id); ?>" >
                                                                                    <td colspan="10">
                                                                                          <button type="submit" class="btn btn-primary btn-sm float-right">Update</button>
                                                                                    </td>
                                                                                </tr>
                                                                                 </form>
                                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </tbody>
                                                                        </table>
                                                                        
                                                                        <?php echo e($assignproject->appends(request()->query())->links()); ?>

                                                                    </div>
                                                                </div>
                                                                 <div class="tab-pane" id="timetab2" role="tabpanel">
                                                                    week2
                                                                    
                                                                </div>
                                                                   <div class="tab-pane" id="timetab3" role="tabpanel">
                                                                    week3
                                                                    
                                                                </div>
                                                                   <div class="tab-pane" id="timetab4" role="tabpanel">
                                                                    week4
                                                                    
                                                                </div>
                                                                   <div class="tab-pane" id="timetab5" role="tabpanel">
                                                                    week5
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>




<script>

var currentweek = '<?php echo e($weekcountpassed); ?>';

function getresult(month,week,currentweek,totalweek,time){
    
     base_url = $('#base_url').val();
    
   var year = $('#getyear').val();
   

   
      var rurl = base_url+'/timesheet/'+year+'-'+month+'/'+week+'/'+totalweek+'/'+time;
   
     window.location = rurl;
   
   
    
}
 $('.datetime').datetimepicker({
        dateFormat: '', 
        timeFormat: 'hh:mm z', 
        timeOnly: true,
        showTimezone: true,
        timezone: "+0100"
    });
  </script>

<script>

   function timesheet(valname){
       
      
       
        base_url = $('#base_url').val();
        
        if(valname == 'user'){
            
              var URLval = base_url+'/user-timesheet/';
               
            
        }else if(valname == 'allocation'){
            
                var URLval = base_url+'/timesheet/';
                
        }else if(valname == 'emp'){
            
               var URLval = base_url+'/emp-timesheet/';
            
        }
         // $('#loadingDiv').show();
         
        // alert(URLval);

        window.location.href = URLval;

      
   }




      $("form#timealocationentrytime").submit(function(e) {

 
            e.preventDefault();

  $('#loadingDiv').show();

   var token = "<?php echo e(csrf_token()); ?>"; 


  $.ajax({
        url: '/hourdefinproject',
        headers: {'X-CSRF-TOKEN': token}, 
        type: "post",
        data:$(this).serialize(),
        
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
             
               alertify.success(data.msg);

           // location.reload();

          }else if(data.status ==202){

              $('#loadingDiv').hide();
             alertify.success(data.msg);
           // location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
              alertify.success(data.msg);
               //location.reload();

          }else{

             $('#loadingDiv').hide();
            
             alertify.success(data.msg);

          }
          
        }
      });

            

          });

 $('.number').keypress(function(event) {
     
    

     if(event.which == 8 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 46) 
          return true;

     else if((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57))
          event.preventDefault();

});

    function validateHhMm(inputField) {
        var isValid = /^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$/.test(inputField.value);

        if (isValid) {
            inputField.style.backgroundColor = '#bfa';
        } else {
            inputField.style.backgroundColor = '#fba';
        }

        return isValid;
    }
</script>


<script>



function assignHour(yearMonth,currentweek,totalWeek,time){
    
    base_url = $('#base_url').val();
  
      var editurl =   base_url+'/timesheet/'+yearMonth+'/'+currentweek+'/'+totalWeek+'/'+time;
 

     
          window.location = editurl;
    

    
}
// $(document).ready(function(){
//     $(".caret_row1").css("display","none");
//     $(".caret_row2").css("display","none");
//     //$(".row_update").css("display","none");
// });
// $(document).on("click",".caret_row",function(){
//     $(this).toggleClass("open").nextUntil(".caret_row").toggle();
//     $(this).siblings('.caret_row2').hide(); 
//      $(this).find(".caret").toggleClass("rotate");
//       //  $(this).siblings('.row_update').hide(); 
      
//       var sid = $(this).data('sid');
      
//       $('.'+sid).toggle(); 
//       $('.'+sid).hide(); 
//     //   $(this).siblings('.caret_row1').toggle();
//     //   $(this).find(".caret").toggleClass("rotate");
//     //   if($('.caret_row2').css('display') == 'table-row'){
//     //       debugger
//           //  $(this).siblings('.caret_row2').hide(); 
//     //   }
//     //      if($('.row_update').css('display') == 'table-row'){
//     //          $(this).siblings('.row_update').toggle(); 
//     //   }
// });
// $(document).on("click",".caret_row1",function(){
//     //debugger
//      $(this).toggleClass("open").nextUntil(".caret_row").toggle();
//      //$(this).nextUntil(".row_update").show();
//       $(this).find(".caret").toggleClass("rotate");
//     //   $(this).siblings('.caret_row2').toggle(); 
//     //   $(this).siblings('.row_update').toggle();
//     //     $(this).find(".caret").toggleClass("rotate");
    
//          var sid = $(this).data('sid');
        
//         $('.'+sid).toggle();
//           $('.'+sid).show();
// })

</script>
<script src="http://keith-wood.name/js/jquery.plugin.js"></script>
<script src="http://keith-wood.name/js/jquery.timeentry.js"></script>
<script>
$(function () {
	$('.defaultEntry').timeEntry({show24Hours: true,initialField:0,spinnerImage:'', defaultTime:"00:00"});
});
 $(document).on("click", ".relative", function () {
  $(".tableabsolute").css("display", "block");
  event.stopPropagation();
})
$('body').click(function () {
  $(".tableabsolute").css("display", "none");
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>