   <?php $__env->startSection('content'); ?>
  
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Performance Appraisal of Employees</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="appraisal_form.html">Performance
                                            Appraisal of Employees</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="row">

              <?php if(isset($userAppraisal) && !empty($userAppraisal)): ?>
              <?php $__currentLoopData = $userAppraisal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userAppraisal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-sm-3">
                                    <div class="card m-t-20">
                                        <div class="card-body">
                                            <?php if($userAppraisal->status ==1): ?>

                                             <a href="#">


                                            <?php else: ?>

                                             <a href="<?php echo e(URL::to('/appraisalfillform/'.$userAppraisal->id)); ?>">


                                            <?php endif; ?>
                           
                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="col-sm-12 font-18" title="Employee Name">
                                                            <i class="mdi mdi-face m-r-5 font-green font-20"></i>
                                                            <span><?php echo e(ucwords($userAppraisal->userfullname)); ?></span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Year">
                                                            <a href="appraisal_rating.html">
                                                                <i
                                                                    class="mdi mdi-calendar font-green m-r-5 font-20"></i>
                                                            </a>
                                            <span><?php echo e(date('Y',strtotime($userAppraisal->date))); ?></span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Status">
                                                            <div class="row">
                                                                <div class="col-sm-12 font-18">
                                                                    <a href="appraisal_rating.html">
                                                                        <i
                                                                            class="mdi mdi-account-search font-green m-r-5 font-20"></i>
                                                                    </a>
                                                                    <?php if($userAppraisal->status ==0): ?>
                                                                    <span>Awaited</span>

                                                                    <?php elseif($userAppraisal->status ==1): ?>

                                                                         <span>Filled</span>
                                                                    <?php else: ?>

                                                                     <span>Rejected</span>



                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                   <div class="col-sm-12">No Appraisal Found</div>


                                <?php endif; ?>
                           <!--      <div class="col-sm-3">
                                    <div class="card m-t-20">
                                        <div class="card-body">
                                            <div class="row"
                                                onclick="window.location.href = 'appraisal_form_fill.html'">
                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="col-sm-12 font-18" title="Employee Name">
                                                            <i class="mdi mdi-face m-r-5 font-green font-20"></i>
                                                            <span>Rishabh </span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Year">
                                                            <a href="appraisal_rating.html">
                                                                <i
                                                                    class="mdi mdi-calendar font-green m-r-5 font-20"></i>
                                                            </a>
                                                            <span>2019</span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Status">
                                                            <div class="row">
                                                                <div class="col-sm-12 font-18">
                                                                    <a href="appraisal_rating.html">
                                                                        <i
                                                                            class="mdi mdi-account-search font-green m-r-5 font-20"></i>
                                                                    </a>
                                                                    <span>Approved</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card m-t-20">
                                        <div class="card-body">
                                            <div class="row"
                                                onclick="window.location.href = 'appraisal_form_fill.html'">
                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="col-sm-12 font-18" title="Employee Name">
                                                            <i class="mdi mdi-face m-r-5 font-green font-20"></i>
                                                            <span>Diksha</span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Year">
                                                            <a href="appraisal_rating.html">
                                                                <i
                                                                    class="mdi mdi-calendar font-green m-r-5 font-20"></i>
                                                            </a>
                                                            <span>2019</span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Status">
                                                            <div class="row">
                                                                <div class="col-sm-12 font-18">
                                                                    <a href="appraisal_rating.html">
                                                                        <i
                                                                            class="mdi mdi-account-search font-green m-r-5 font-20"></i>
                                                                    </a>
                                                                    <span>Approved</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card m-t-20">
                                        <div class="card-body">
                                            <div class="row"
                                                onclick="window.location.href = 'appraisal_form_fill.html'">
                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="col-sm-12 font-18" title="Employee Name">
                                                            <i class="mdi mdi-face m-r-5 font-green font-20"></i>
                                                            <span>Rajesh Yadav</span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Year">
                                                            <a href="appraisal_rating.html">
                                                                <i
                                                                    class="mdi mdi-calendar font-green m-r-5 font-20"></i>
                                                            </a>
                                                            <span>2019</span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12" title="Status">
                                                            <div class="row">
                                                                <div class="col-sm-12 font-18">
                                                                    <a href="appraisal_rating.html">
                                                                        <i
                                                                            class="mdi mdi-account-search font-green m-r-5 font-20"></i>
                                                                    </a>
                                                                    <span>Approved</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                            <!-- <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Activities/Traits/Parameters</th>
                                                <th>Max Marks</th>
                                                <th>Self- Marking</th>
                                                <th>Marks by Coordinator [1-10]</th>
                                                <th>Marks by HoD [1-10]</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>
                                                    Java Developer
                                                </td>
                                                <td>IT</td>
                                                <td>Experienced</td>
                                                <td>3 yr</td>
                                                <td>
                                                    10/12/2019
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table> -->

                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
         <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>