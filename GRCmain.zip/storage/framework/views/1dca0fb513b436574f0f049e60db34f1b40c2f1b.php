    
   <?php $__env->startSection('content'); ?>
            
         <!-- Start content -->
                   <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Attendance to Approve</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Leave</a></li>
                                    <li class="breadcrumb-item active"><a href="leaveapprove.html">Attendance to
                                            Approve</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap text-center"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>
                                                    Employee
                                                </th>
                                                 <th>Action</th>
                                                <th>Date</th>
                                                <th>Actual In</th>
                                                <th>Actual Out</th>
                                                <th>Status</th>
                                                <th>Proposed In</th>
                                                <th>Proposed Out</th>
                                                 <th>Preposed Status</th>
                                                
                                              
                                                <th>Reason Of Correction</th> 
                                                 <?php if(PermissionHelper::frontendPermission('view-attendence')): ?>
                                                 <th>Action</th> 
                                                 <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php ($i =1); ?>
                                          <?php $__currentLoopData = $approvalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approvalLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>

                                                <td><?php echo e($approvalLists->userfullname); ?></td>
                                                
                                                
                                                  <td>
                                                      
                                                      <?php if($approvalLists->is_active == 2): ?>
                                                       Pending
                                                       <?php elseif($approvalLists->is_active == 3): ?>
                                                       Approved
                                                       <?php else: ?>
                                                       
                                                       Reject
                                                       <?php endif; ?>
                                                  
                                                  </td>
                                              
                                <td><?php echo e(date('d-M-Y',strtotime($approvalLists->entry_date))); ?></td>
                                <td><?php echo e(date('H:i:s',strtotime($approvalLists->actual_intime))); ?></td>
                                <td><?php echo e(date('H:i:s',strtotime($approvalLists->actual_outtime))); ?></td>
                                <td><?php echo e($approvalLists->actual_status); ?></td>
                                <td><?php echo e(date('H:i:s',strtotime($approvalLists->preposed_intime))); ?></td>
                                <td><?php echo e(date('H:i:s',strtotime($approvalLists->preposed_outtime))); ?></td>
                                <td><?php echo e($approvalLists->preposed_status); ?></td>
                                <td><?php echo e($approvalLists->reason); ?></td>
                                 <?php if(PermissionHelper::frontendPermission('view-attendence')): ?>

                                <td>

                                        <?php if($approvalLists->is_active == 2): ?>
                                    <i class="fa fa-eye font-blue m-r-5" title="View" data-toggle="modal"
                                        data-target="#attendanceapprove_<?php echo e($approvalLists->id); ?>"></i>
                                        <?php endif; ?>
                                     
                                        <!--   <?php if(PermissionHelper::frontendPermission('view-attendence')): ?>
                                    <i class="text-primary fa fa-check m-r-5" title="Approve"></i>
                                    <?php endif; ?>
                                       <?php if(PermissionHelper::frontendPermission('view-attendence')): ?>

                                    <i class="text-danger fa fa-times" title="Reject"></i>

                                    <?php endif; ?> -->
                                </td>
                                 <?php endif; ?>
                                <!-- <td>Correction</td> -->
                                </tr>

                                  <!-- attendance to approve -->
    <div id="attendanceapprove_<?php echo e($approvalLists->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Attendance to Approve</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-0">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Employee</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($approvalLists->userfullname); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empid" class="col-lg-8 col-form-label">Date</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e(date('d-M-Y',strtotime($approvalLists->entry_date))); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Actual In</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e(date('H:i:s',strtotime($approvalLists->actual_intime))); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Actual Out</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e(date('H:i:s',strtotime($approvalLists->actual_outtime))); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Status</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($approvalLists->actual_status); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Proposed In</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e(date('H:i:s',strtotime($approvalLists->preposed_intime))); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Proposed Out</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e(date('H:i:s',strtotime($approvalLists->preposed_outtime))); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Proposed Status</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($approvalLists->preposed_status); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-4 col-form-label">Reason</label>
                                        <div class="col-lg-8 col-form-label p-l-4">
                                            <label class="myprofile_label">
                                               <?php echo e($approvalLists->reason); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                      <?php if(PermissionHelper::frontendPermission('edit-attendence')): ?>
                    <button onclick="attendace('<?php echo e($approvalLists->id); ?>','<?php echo e($approvalLists->empid); ?>')" class="btn btn-primary float-right">Approve</button>
                    <?php endif; ?>
                    <?php if(PermissionHelper::frontendPermission('delete-attendence')): ?>
                    <button onclick="rejctattendace('<?php echo e($approvalLists->id); ?>','<?php echo e($approvalLists->empid); ?>')" class="btn btn-danger float-right">Reject</button>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Cancel</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>




                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                            </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- end col -->
            </div>




           <?php $__env->stopSection(); ?>


            <?php $__env->startSection('extra_js'); ?>

            <script type="text/javascript">

                function attendace(att_temp_id,user_id){

                           $('#loadingDiv').show();

    var _token = "<?php echo e(csrf_token()); ?>";

  $.ajax({
        url: '/approve_attendace',
        type: "post",
        data: {"_token": _token,"userid":user_id,"att_temp_id":att_temp_id},
        dataType: 'JSON',
         
        success: function (data) {
        //console.log(data.attendace); // this is good

       // return false;
    
          if(data.status ==200){
          

               $('#loadingDiv').hide();
            swal("Good job!",data.msg , "success");
            location.reload();

         
             
        
          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");


          }else{
           $('#loadingDiv').hide();
             swal("Good job!",data.msg , "error");
             

          }
          
        }
      });
                }
                
 function rejctattendace(att_temp_id,user_id){

     $('#loadingDiv').show();

    var _token = "<?php echo e(csrf_token()); ?>";

  $.ajax({
        url: '/reject_attendace',
        type: "post",
        data: {"_token": _token,"userid":user_id,"att_temp_id":att_temp_id},
        dataType: 'JSON',
         
        success: function (data) {
        //console.log(data.attendace); // this is good

       // return false;
    
          if(data.status ==200){
           

               $('#loadingDiv').hide();
            swal("Good job!",data.msg , "success");
            location.reload();

         
             
        
          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
              swal("Good job!", "Successfully Updated", "success");


          }else{


           $('#loadingDiv').hide();
             swal("Good job!",data.msg , "error");
             

          }
          
        }
      });

 }


            </script>


            <?php $__env->stopSection(); ?>

        
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>