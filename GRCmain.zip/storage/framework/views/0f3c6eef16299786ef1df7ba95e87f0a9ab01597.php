   <?php $__env->startSection('content'); ?>
            <!-- Start content -->
                   <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Leaves Report</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Leave</a></li>
                                    <li class="breadcrumb-item active"><a href="leaveapprove.html">Leaves Report</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                  <form method="get" action="<?php echo e(URL::to('/exportcsv')); ?>">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Select
                                                    Month <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" name="month" required="">
                                                        <option value="">Select</option>
                                                        <option value="1">January</option>
                                                        <option value="2">February</option>
                                                        <option value="3">March</option>
                                                        <option value="4">April</option>
                                                        <option value="5">May</option>
                                                        <option value="6">June</option>
                                                        <option value="7">July</option>
                                                        <option value="8">August</option>
                                                        <option value="9">September</option>
                                                        <option value="10">October</option>
                                                        <option value="11">November</option>
                                                        <option value="12">December</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Select
                                                    Employee <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" name="id" required="">
                                                        <option value="">Select</option>
                                                        <?php $__currentLoopData = $leavename; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leavenames): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($leavenames->userid); ?>"><?php echo e($leavenames->userfullname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if(PermissionHelper::frontendPermission('report-export-filter')): ?>
                                        <div class="col-sm-2">
                                          <input type="submit" class="btn btn-primary " value="Generate Report">
                                          
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                  </form>

                                    <hr>
                                    <?php if(PermissionHelper::frontendPermission('report-export-all')): ?>
                                    <div class="row float-right">
                                    <a href="<?php echo e(URL('/exportcsv')); ?>" class="btn btn-primary m-r-15">Export</a>
                                    </div>
                                    <?php endif; ?>
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap text-center"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Name</th>
                                                <th>Employee Code</th>
                                                <th>Date of Leave</th>
                                                <th>Type of Leave</th>
                                                <th>Comments</th>
                                                <th>Approver Status</th>
                                                <th>Leave Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                             <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $leavelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leavelists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e(ucwords($leavelists->userfullname)); ?></td>
                                                <td>  <?php echo e($leavelists->employeeId); ?></td>
                                                <td> <?php echo e(date('d-M-Y',strtotime($leavelists->leaveDate))); ?></td>
                                                <td><?php echo e($leavelists->leave_mode); ?></td>
                                                <td><?php echo e($leavelists->comment); ?></td>
                                                <td>

                                                <?php ($useridshowid = array_filter(explode(',',$leavelists->show_user_id))); ?>
                                                 

                                                    <?php if($leavelists->manager ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                    <?php elseif($leavelists->manager ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>
                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->hr ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                      <?php elseif($leavelists->hr ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>
                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->admin ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                        <?php elseif($leavelists->admin ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>

                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->director ==1 && count($useridshowid) > 5): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                           <?php elseif($leavelists->director ==0 && count($useridshowid) > 5): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>
                                                      <?php elseif(count($useridshowid) > 5): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                   <!--  <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i> -->
                                                </td>
                                                <?php if(count($useridshowid) > 5): ?>
                                               

                                               <?php if($leavelists->manager ==1 && $leavelists->hr ==1 && $leavelists->admin ==1 && $leavelists->director == 1): ?>

                                            
                                               <td class="approve-bg">
                                                   Approved
                                               </td>
                                               <?php elseif($leavelists->manager == 2 || $leavelists->hr ==2 || $leavelists->admin ==2 || $leavelists->director ==2): ?>

                                               <td class="reject-bg">
                                                   Rejected 
                                               </td>

                                               <?php else: ?>

                                          
                                                <td class="pending-bg">
                                                   Pending
                                               </td>

                                               <?php endif; ?>

                                               <?php else: ?>

                                               <?php if($leavelists->manager ==1 && $leavelists->hr ==1 && $leavelists->admin ==1 ): ?>

                                            
                                               <td class="approve-bg">
                                                   Approved
                                               </td>
                                               <?php elseif($leavelists->manager == 2 || $leavelists->hr ==2 || $leavelists->admin ==2 ): ?>

                                               <td class="reject-bg">
                                                   Rejected 
                                               </td>

                                               <?php else: ?>

                                          
                                                <td class="pending-bg">
                                                   Pending
                                               </td>

                                               <?php endif; ?>

                                               <?php endif; ?>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php if(count($leavelist) == 0): ?>
                                            <tr><td colspan="9">No Recoud Found</td></tr>

                                            <?php endif; ?>
                                            <!-- <tr>
                                                <td>2</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                </td>
                                                <td class="pending-bg"> Pending</td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                </td>
                                                <td class="approve-bg">Approved</td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>6</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>7</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>8</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>9</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>10</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>11</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>12</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>13</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>14</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>15</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>16</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>17</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>18</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr>
                                            <tr>
                                                <td>19</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL070</td>
                                                <td>1-sep-2019</td>
                                                <td>CL</td>
                                                <td>Health Issue</td>
                                                <td>
                                                    <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                </td>
                                                <td class="reject-bg"> Rejected</td>
                                            </tr> -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>

    
          
         <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>