<?php $__env->startSection('content'); ?>


<div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">KRA Detail</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Kloudrac</a></li>
                                    <li class="breadcrumb-item active"><a href="">KRA Detail</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right">
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#edittask">Edit</button>
                                    <button class="btn btn-primary">CSV Download</button>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div class="col-sm-12 p-0">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row m-0">
                                                    <label for="empid" class="col-lg-4 col-form-label">
                                                       Name<span class="text-danger">*</span></label>
                                                    <div class="col-lg-8 col-form-label">
                                                        <input type="text" value="adas" disabled class="form-control" value="<?php echo e($list->name); ?>">
                                                        <div id="assets_type_error"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row m-0">
                                                    <label for="empid" class="col-lg-4 col-form-label">Designation<span
                                                            class="text-danger">*</span></label>
                                                    <div class="col-lg-8 col-form-label">
                                                        <input type="text" value="dsdfs" disabled class="form-control" value="<?php echo e($list->positionname); ?>">
                                                        <div id="assets_type_error"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row m-0">
                                                    <label for="empid" class="col-lg-4 col-form-label">Status<span
                                                            class="text-danger">*</span></label>
                                                    <div class="col-lg-8 col-form-label">
                                                       <select class="form-control" disabled>
                                                            <option><?php echo e($list->status); ?></option>
                                                           
                                                       </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="col-sm-12 m-t-20">
                                        <h4 class="h4after">Task
                                            <button class="btn btn-primary float-right" data-toggle="modal"
                                                data-target="#addtask">Add Task</button>
                                        </h4>
                                    </div>
                                    <div class="col-sm-12 m-t-20">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Tasks</th>
                                                    <th>Contribution %</th>
                                                    <th>Measurment</th>
                                                    <th>Target</th>
                                                    <th>Actual</th>
                                                    
                                                    <th>Manager's Feedback(%)</th>
                                                    <th>Remarks</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $view_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr style="background-color: #ededed;">
                                                    <td><?php echo e($view_tasks->task); ?>(Task) </td>
                                                    <td><?php echo e($view_tasks->con_sum); ?></td>
                                                    <td><?php echo e($view_tasks->measurment); ?></td>
                                                    <td><?php echo e($view_tasks->target); ?></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>

                                                <?php $__currentLoopData = $view_tasks->sub_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><?php echo e($sub_task->sub_task); ?>(Sub Task)</td>
                                                    <td><?php echo e($sub_task->contribution); ?></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                             
                                                
                                            </tbody>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            
            <div id="addtask" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                style="display: none; padding-right: 5px;" aria-modal="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title mt-0" id="myModalLabel">Add Sub Task</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>

                        <form id="kra_task_form">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Task Name
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" id="task_name" name="task_name" required>
                                                    <div id="assets_name_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label">Measurment<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" id="measurment" name="measurment" required>
                                                    <div id="assets_type_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label p-r-0">Target<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" id="target" name="target" onkeypress="preventNonNumericalInput(event)" required>
                                                    <div id="assets_type_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 text-right" style="padding-right: 30px;padding-top: 10px;">
                                            <a href="javascript:void(0)" class="btn btn-primary" data-toggle="collapse" data-target="#addsubtask" class="font-blue p-10">Add Sub Task</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-12">
                                      
                                        <div class="col-sm-12">
                                        
                                            <div class="card-body m-t-10" style="border:1px solid #ededed;">
                                                <div class="col-sm-12 p-0">
                                                    <div class="row append_column">
                                                        <div class="col-md-5">
                                                            <div class="form-group row m-0">
                                                                <label for="empid" class="col-lg-4 col-form-label p-r-0">Add Sub Task<span
                                                                        class="text-danger">*</span></label>
                                                                <div class="col-lg-8 col-form-label">
                                                                    <input type="text" class="form-control" name="sub_task[]" required>
                                                                    <div id="assets_type_error"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-5">
                                                            <div class="form-group row m-0">
                                                                <label for="empid" class="col-lg-4 col-form-label">Contribution<span
                                                                        class="text-danger">*</span></label>
                                                                <div class="col-lg-8 col-form-label">
                                                                    <input type="text" class="form-control" name="contribution[]" onkeypress="preventNonNumericalInput(event)" required>
                                                                    <div id="assets_type_error"></div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-2">
                                                            <div class="form-group row m-0">
                                                            <a href="javascript:void(0)" onclick="add_row()"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                   
                                                </div>
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="row">
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="kra_id" value="<?php echo e($list->id); ?>">
                        <div class="modal-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary add_assets">Save</button>
                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                           </form>


                    </div>
                </div>
            </div>
            <div id="edittask" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
            style="display: none; padding-right: 5px;" aria-modal="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title mt-0" id="myModalLabel">Edit Task</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row m-0">
                                            <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Task Name
                                                <span class="text-danger">*</span></label>
                                            <div class="col-lg-8 col-form-label">
                                            <input type="text" class="form-control" id="name"  value="<?php echo e($list->name); ?>">
                                                    <div id="name_error"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <?php
                                        
                                        $posi = DB::table('main_positions')->where('isactive',1)->get();
                                        ?>
                                    <div class="col-md-6">
                                        <div class="form-group row m-0" id="fillsubtask">
                                            <label for="empid" class="col-lg-4 col-form-label">Designation<span
                                                    class="text-danger">*</span></label>
                                            <div class="col-lg-8 col-form-label">
                                            <select class="form-control" id="designation">

<option value="">Select option</option>
<?php $__currentLoopData = $posi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($posis->id); ?>"  <?php if($posis->id == $list->designation): ?> selected   <?php endif; ?>><?php echo e($posis->positionname); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div id="designation_error"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" id="kra_id" value="<?php echo e($list->id); ?>">
                                    <div class="col-md-6">
                                        <div class="form-group row m-0" id="fillsubtask">
                                            <label for="empid" class="col-lg-4 col-form-label">Status<span
                                                    class="text-danger">*</span></label>
                                            <div class="col-lg-8 col-form-label">
                                                <select class="form-control" id="status">
                                                <option <?php if($list->status == 'Active'): ?> selected   <?php endif; ?>>Active</option>
                                                <option  <?php if($list->status == 'Inactive'): ?> selected   <?php endif; ?>>Deactive</option>
                                                </select>
                                                <div id="status_error"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-sm-12">
                            <button onclick="save_kra()" id="save_kra" class="btn btn-primary add_assets">Save</button>
                            
                                <button class="btn btn-default" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

            <?php $__env->stopSection(); ?>

           



<?php $__env->startSection('extra_js'); ?>

<script>



function add_row(){

   

html_data = '';



   html_data += '<div class="row"><div class="col-10"><input type="text" id="vehicle1" name="sub_task[]" required><input type="text" name="contribution[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
html_data += '<div class="col-1"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20 p-10"></i></a></div></div>';





$('.append_column').append(html_data);

}

function remove_field(input){

console.log(input);

$(input).parent().parent().remove();
}



$("form#kra_task_form").submit(function(e) {

 
e.preventDefault();


task_name = $('#task_name').val();
measurment = $('#measurment').val();
target = $('#target').val();


if(task_name.replace(/\s/g,'') == ''){
    alertify.error('Task Name is Required');
    return false;
}

if(measurment.replace(/\s/g,'') == ''){
    alertify.error('Measurment is Required');
    return false;
}

if(target.replace(/\s/g,'') == ''){
    alertify.error('Target is Required');
    return false;
}


$('#loadingDiv').show();

var token = "<?php echo e(csrf_token()); ?>"; 


$.ajax({
url: '/kra_task_add',
headers: {'X-CSRF-TOKEN': token}, 
type: "post",
data:$(this).serialize(),

success: function (data) {
//console.log(data.city); // this is good

if(data.status ==200){
 $('#loadingDiv').hide();


alertify.success(data.msg);

 //swal("Good job!", "Added Successfully", "success");

location.reload();

}else if(data.status ==202){

  $('#loadingDiv').hide();
  alertify.success(data.msg);
// swal("Good job!", "User alert Exist", "success");
//location.reload();

  }else if(data.status ==203){

  $('#loadingDiv').hide();
  alertify.success(data.msg);
// swal("Good job!", "Successfully Updated", "success");
   //location.reload();

}else{

 $('#loadingDiv').hide();
 alertify.error(data.msg);
// swal("Good job!", "You clicked the button!", "error");

}

}
});



});





function save_kra(){


var name = $('#name').val();
var designation = $('#designation').val();
var kra_id = $('#kra_id').val();
var status = $('#status').val();

if(name.replace(/\s/g,'') ==''){
         $('#name_error').text('Name is Required').attr('style','color:red');
         $('#name_error').show();
           error = 0;
              return false;
      }else{$('#name_error').hide();  error = 1;}

      if(designation.replace(/\s/g,'') ==''){
         $('#designation_error').text('Designation is Required').attr('style','color:red');
         $('#designation_error').show();
           error = 0;
              return false;
      }else{$('#designation_error').hide();  error = 1;}


      var _token = "<?php echo e(csrf_token()); ?>";
      $('#save_kra').attr('disabled','disabled');

$.ajax({
    url: '/save_kra',
    type: "post",
    data: {"_token": _token,"name":name,"designation":designation,"kra_id" : kra_id,"status":status},
   // dataType: 'JSON',
      beforeSend: function() {
    // setting a timeout
    $('#loadingDiv').show();
},
    success: function (data) {
      //console.log(data); // this is good

      $('#save_kra').removeAttr('disabled','disabled');

       // return false;
      if(data.status ==200){
         $('#loadingDiv').hide();
     
         alertify.success(data.msg);
       
          location.reload();

         

      }else if(data.status ==202){

          $('#loadingDiv').hide();
          alertify.success(data.msg);
        location.reload();

          }else if(data.status ==203){

          $('#loadingDiv').hide();
          alertify.success(data.msg);


      }else{

         $('#loadingDiv').hide();
        
         alertify.error(data.msg);

      }
      
    }
  });

}



</script>

<script>
        $(document).ready(function(){
            $("#addsubtask").click(function(){
                $(this).css("display","none");
                $("#fillsubtask").css("display","flex");
            })
        })
    </script>


            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>