    
   <?php $__env->startSection('content'); ?>
            
         <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Lead</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="lead.html">Lead</a></li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right d-none d-md-block">
                                    <div class="dropdown">
                                        <a href="<?php echo e(URL::to('/createLead')); ?>">
                                            <button
                                                class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                                type="button">
                                                Create Lead</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                          <?php if(session()->has('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('msg')); ?>

                        </div>
                           <?php endif; ?>
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Lead</th>
                                                <th>Organization</th>
                                                <th>Email</th>
                                                <th>Lead Owner</th>
                                                <th>Created Date</th>
                                                <th>Project Type</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $leadlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leadlists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td>
                                                    <?php echo e($leadlists->title); ?>

                                                </td>
                                                <td> <?php echo e($leadlists->company); ?></td>
                                                <td>
                                                   <?php echo e($leadlists->email); ?>

                                                </td>
                                                <td> <?php echo e($leadlists->owner); ?>

                                                </td>
                                                <td><?php echo e(date('d-M-Y', strtotime($leadlists->created_at))); ?></td>
                                                <td><?php echo e($leadlists->product_type); ?></td>
                                                <td>
                                                    <a href="<?php echo e(URL::to('viewLead')); ?>/<?php echo e($leadlists->id); ?>"><i class="mdi mdi-eye font-blue"
                                                            title="View"></i></a>
                                                    <a href="<?php echo e(URL::to('editLead')); ?>/<?php echo e($leadlists->id); ?>"> <i class="mdi mdi-pen text-warning"
                                                            title="Edit"></i>
                                                       <a onclick="return confirm('Are you sure you want to delete?');" href="<?php echo e(URL::to('deletelead')); ?>/<?php echo e($leadlists->id); ?>"> <i class="mdi mdi-delete text-danger" id="sa-params"
                                                            title="Delete"></i>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
           <?php $__env->stopSection(); ?>

           <?php $__env->startSection('extra_js'); ?>



           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>