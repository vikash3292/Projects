<?php $__env->startSection('content'); ?>


<div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">KRA Master</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Kloudrac</a></li>
                                    <li class="breadcrumb-item active"><a href="users.html">KRA Master</a></li>
                                </ol>
                            </div>
                            <div class="col-sm-6 text-right">
                              <button class="btn btn-primary float-right" onclick="add_kra()">Add KRA</button>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th width="20%">Status</th>
                                                <th width="10%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                               
                                                <td><?php echo e($lists->name); ?></td>
                                                <td><?php echo e($lists->positionname); ?></td>
                                                <td><?php echo e($lists->status); ?></td>
                                                <td>

                                               

                                                  <a href="<?php echo e(URL::to('view-kra')); ?>/<?php echo e($lists->id); ?>">
             
                                                   <i class="mdi mdi-eye font-blue"></i>

                                                   </a>
       <a href="javascript:void(0)" onclick="getedit('<?php echo e($lists->name); ?>','<?php echo e($lists->designation); ?>','<?php echo e($lists->id); ?>','<?php echo e($lists->status); ?>')">

                                                   <i class="mdi mdi-pencil text-warning"></i>

                                                   </a>


                                                    <a onclick="return confirm('Are you sure you want to delete this ?');" href="<?php echo e(URL::to('delete-kra')); ?>/<?php echo e($lists->id); ?>">
                                                   <i class="mdi mdi-delete text-danger"></i>
                                                </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>


            <div id="addkra" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                style="display: none; padding-right: 5px;" aria-modal="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title mt-0" id="myModalLabel">KRA</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Name
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" id="name">
                                                    <div id="name_error"></div>
                                                </div>
                                            </div>
                                        </div>

                                        <input type="hidden" id="kra_id">
                                        <input type="hidden" id="status">
                                        <?php
                                        
                                        $posi = DB::table('main_positions')->where('isactive',1)->get();
                                        ?>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0" id="fillsubtask">
                                                <label for="empid" class="col-lg-4 col-form-label">Designation<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                <select class="form-control" id="designation">

<option value="">Select option</option>
<?php $__currentLoopData = $posi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($posis->id); ?>"><?php echo e($posis->positionname); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                  
                                                    <div id="designation_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <button onclick="save_kra()" id="save_kra" class="btn btn-primary add_assets">Save</button>
                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php $__env->stopSection(); ?>

 
<?php $__env->startSection('extra_js'); ?>

<script>

function add_kra(){

    $('#myModalLabel').text(' KRA');
     $('#kra_id').val('');
     var name = $('#name').val('');
     var name = $('#status').val('');
var designation = $('#designation').val('');

$('#addkra').modal('show')

}


function getedit(name,desig,id,status){

    $('#myModalLabel').text('Edit KRA');
     $('#kra_id').val(id);
     var name = $('#name').val(name);
     var name = $('#status').val(status);
var designation = $('#designation').val();

$("#designation > option").each(function() {
                              if(this.value == desig){
                                 $('#designation').val(desig).attr("selected"); 
                              }
                         
                           });

    $('#addkra').modal('show')

}


function save_kra(){


var name = $('#name').val();
var designation = $('#designation').val();
var kra_id = $('#kra_id').val();
var status = $('#status').val();

if(name.replace(/\s/g,'') ==''){
         $('#name_error').text('Name is Required').attr('style','color:red');
         $('#name_error').show();
           error = 0;
              return false;
      }else{$('#name_error').hide();  error = 1;}

      if(designation.replace(/\s/g,'') ==''){
         $('#designation_error').text('Designation is Required').attr('style','color:red');
         $('#designation_error').show();
           error = 0;
              return false;
      }else{$('#designation_error').hide();  error = 1;}


      var _token = "<?php echo e(csrf_token()); ?>";
      $('#save_kra').attr('disabled','disabled');

$.ajax({
    url: '/save_kra',
    type: "post",
    data: {"_token": _token,"name":name,"designation":designation,"kra_id" : kra_id,"status":status},
   // dataType: 'JSON',
      beforeSend: function() {
    // setting a timeout
    $('#loadingDiv').show();
},
    success: function (data) {
      //console.log(data); // this is good

      $('#save_kra').removeAttr('disabled','disabled');

       // return false;
      if(data.status ==200){
         $('#loadingDiv').hide();
     
         alertify.success(data.msg);
        
          location.reload();

         

      }else if(data.status ==202){

          $('#loadingDiv').hide();
          alertify.success(data.msg);
        location.reload();

          }else if(data.status ==203){

          $('#loadingDiv').hide();
          alertify.success(data.msg);


      }else{

         $('#loadingDiv').hide();
         alertify.error(data.msg);
         

      }
      
    }
  });

}


</script>


            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>