<?php $__env->startSection('content'); ?>

<div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Scope of Work</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="scope.html">Scope of Work</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right d-none d-md-block">
                                    <div class="dropdown">
                                        <a href="<?php echo e(URL::to('/add_scope')); ?>">
                                            <button
                                                class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                                type="button">
                                                Add Scope of Work</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Name of SOW</th>
                                                <th>Organization</th>
                                                <th>Work Order</th>
                                                <th>Contact</th>
                                                <th>Created By</th>
                                                <th>Modified By</th>
                                                <th>Modified DateTime</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php ($i = 1); ?>
                                        	<?php $__currentLoopData = $scope_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scope_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr >
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($scope_lists->scope_name); ?>

                                                </td>
                                                <td><?php echo e($scope_lists->org_name); ?></td>
                                                <td><?php echo e($scope_lists->work_order_name); ?></td>
                                                <td><?php echo e($scope_lists->contact_no); ?></td>
                                                <td><?php echo e($scope_lists->created_name); ?></td>
                                                <td><?php echo e($scope_lists->modifile_name); ?></td>
                                                <td><?php echo e($scope_lists->modifiled_at); ?></td>
                                                <td>

                                                    <a href="<?php echo e(URL::to('download_scope')); ?>/<?php echo e($scope_lists->id); ?>" class="font-blue">

                                                    <i class="mdi mdi-download" title="View" id="sa-params"
                                                        title="Pdf Download"></i> </a>
                                                    <a href="<?php echo e(URL::to('view_scope')); ?>/<?php echo e($scope_lists->id); ?>" class="font-blue"><i
                                                            class="fa fa-eye"></i></a>
                                                    <a href="<?php echo e(URL::to('edit_scope')); ?>/<?php echo e($scope_lists->id); ?>"> <i class="mdi mdi-pen text-warning"
                                                            title="Edit"></i></a>
                                                   <a onclick="return confirm('Are you sure you want to delete this?');" href="<?php echo e(URL::to('delete_scope')); ?>/<?php echo e($scope_lists->id); ?>">

                                                    <i class="mdi mdi-delete text-danger" id="sa-params"
                                                        title="Delete"></i>

                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>