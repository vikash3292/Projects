<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
          <div class="col-sm-6">
               <div class="wrapper-page wrapper-page-margin">
                  <div class="overflow-hidden account-card mx-3">
                     <div class="account-card-content">
                        <div class="text-center position-relative">
                           <h1 class="m-b-30">GRC GREEN ERP</h1>
                           <p class="m-b-30">
                              GRC India has the in-house and empanelled experts for all the 12 functional
                              areas required, in order to successful culmination of project within a
                              definite time frame. Besides, the company has a pool of experts for the
                              entire range of functional areas, who can provide the most satisfactory 
                              solutions in the complete gamut of consultancy services in the environment 
                              fields.
                           </p>
                        </div>
                        <div class="text-left">
                           <a href="<?php echo e(URL::to('/')); ?>" class="logo">
                           <img src="<?php echo e(asset('/assets/images/logo.png')); ?>" height="100" alt="logo">
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        <div class="col-md-6">
            <div class="wrapper-page">
                <div class="card overflow-hidden account-card mx-3">
                  <?php if(Session::has('message')): ?>
                     <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
                   <?php endif; ?>
                <div class="account-card-content">
                <div class="text-center position-relative">
                        <h4 class="font-30 m-b-5"><?php echo e(__('Forgot Password')); ?></h4>
                </div>
                <div class="card-body">
                         <div class="card">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" class="form-horizontal m-t-30" action="<?php echo e(URL::to('sendlink')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                        <div class="row">
                              <div class="col-1 p-r-0">
                                    <i class="mdi mdi-email-mark-as-unread font-20"></i>
                              </div>
                              <div class="col-11">
                        <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"  name="email" value="<?php echo e(old('email')); ?>" maxlength="60" required placeholder="Registered Email Id">
                        <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                     </div>
                  </div>

                        <div class="form-group m-t-10 mb-0 row">
                            <div class="col-12 m-t-20">
                                <button type="submit" class="btn btn-primary loginbtn">
                                    <?php echo e(__('Send Password Reset Link')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>