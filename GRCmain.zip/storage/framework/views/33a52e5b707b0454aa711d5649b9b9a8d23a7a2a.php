   <?php $__env->startSection('content'); ?>
         <!-- Start content -->
         <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6 col-6">
                        <?php if(!empty($editData)): ?>

                          <h3 class="page-title">Edit User</h3>


                        <?php else: ?>
                            <h3 class="page-title">Add User</h3>

                        <?php endif; ?>
                      
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>"><?php echo e($mainsetting->site_title); ?></a></li>
                             <?php if(!empty($editData)): ?>
                           <li class="breadcrumb-item active"><a href="<?php echo e(URL::to('/employees')); ?>">Edit User</a></li>
                           <?php else: ?>

                             <li class="breadcrumb-item active"><a href="<?php echo e(URL::to('/employees')); ?>">Add User</a></li>
                           <?php endif; ?>
                        </ol>
                     </div>
                     <div class="col-6 text-right">
                          <a href="javascript: history.go(-1)"  class="btn btn-primary"> Back</a>
                     </div>
                  </div>
               </div>

             <?php if(isset($_GET['profile']) && !empty($_GET['profile'])): ?>


               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body p-0">
                           <div class="row">
                              <div class="col-sm-12">
                                 <div class="row">
                                    <div class="col-sm-3 text-center">
                                       <div class="imguploadDiv">
                                          <img src="<?php echo e(URL::to('/public/')); ?><?php echo e(Auth::guard('main_users')->user()->profileimg??''); ?>" alt="Avatar"
                                             class="avatar img-responsive" width="100%">
                                          <div class="imgupload">
                                             <span><i class="mdi mdi-lead-pencil font-18"></i></span>
                                             <input type="file" id="profile" name="profile" accept="image">
                                          </div>
                                          <div>
                                            <div id="profile_error"></div>
                                             <button id="uploadImg" onclick="uploadprofile()"  class="btn btn-primary">Upload</button>
                                          </div>
                                       </div>
                                    </div>
                                        <div class="col-sm-9">
                                       <div class="row p-20">
                                          <div class="col-md-12">
                                             <div class="form-group row">
                                                <label for="empcode" class="col-lg-4">Name</label>
                                                <div class="col-lg-8">
                                                   <label class="myprofile_label"><?php echo e(Auth::guard('main_users')->user()->userfullname??''); ?>

                                                   </label>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="col-md-12">
                                             <div class="row form-group ">
                                                <label for="empcode" class="col-lg-4">Email ID</label>
                                                <div class="col-lg-8">
                                                   <label class="myprofile_label"><?php echo e(Auth::guard('main_users')->user()->emailaddress??''); ?></label>
                                                </div>
                                             </div>
                                          </div>

                                          <div class="col-md-12">
                                             <div class="row">
                                                <label for="empcode" class="col-lg-4">Contact N0.</label>
                                                <div class="col-lg-5">
                                                   <label class="myprofile_label"><?php echo e(Auth::guard('main_users')->user()->workphone??''); ?>

                                                   </label>
                                                </div>

                                             </div>
                                          </div>
                                          <div class="col-md-12 m-t-10">
                                             <div class="row form-group ">
                                                <label for="empcode" class="col-lg-4">Change Theme</label>
                                                <div class="col-lg-5">
                                                   <select class="form-control" id="themesdate">
                                                      <option>Default Theme</option>
                                                      <option value="Light" <?php if(!empty($editData)): ?> <?php if('Light' == Auth::guard('main_users')->user()->themes): ?> selected <?php endif; ?> <?php endif; ?> >Light</option>
                                                      <option value="Dark" <?php if(!empty($editData)): ?> <?php if('Dark' == Auth::guard('main_users')->user()->themes): ?> selected <?php endif; ?> <?php endif; ?>>Dark</option>
                                                   </select>
                                                </div>
                                                <div class="col-sm-3">
                                                   <button class="btn btn-primary" data-toggle="modal"
                                                      data-target="#changepsw">Change Password</button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>

                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

                          <div id="changepsw" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
               aria-hidden="true">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h5 class="modal-title mt-0" id="myModalLabel">Change Password</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                     </div>
                     <div class="modal-body">
                        <div class="form-group row">
                           <label for="currentpsd" class="col-lg-4 col-form-label">
                              Current Password</label>
                           <div class="col-lg-8">
                              <input id="cpassword" name="currentpsd" minlength="6" maxlength="20" type="text" class="form-control">
                              <div id="cpassword_error"></div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <label for="newpsd" class="col-lg-4 col-form-label">
                              New Password</label>
                           <div class="col-lg-8">
                              <input id="newpsd" name="newpsd" type="text" minlength="6" maxlength="20" class="form-control">
                              <div id="newpsd_error"></div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <label for="cnfpsd" class="col-lg-4 col-form-label">
                              Confirm Password</label>
                           <div class="col-lg-8">
                              <input id="cnfpsd" name="cnfpsd" type="text" minlength="6" maxlength="20" class="form-control">
                              <div id="cnfpsd_error"></div>
                           </div>
                        </div>
              
                     </div>
                     <div class="modal-footer">
                        <button type="button" id="changepassord" class="btn btn-primary waves-effect">Save</button>
                        <button type="button" class="btn btn-secondary waves-effect waves-light"
                           data-dismiss="modal">Cancel</button>
                     </div>
                  </div>
                  <!-- /.modal-content -->
               </div>
               <!-- /.modal-dialog -->
            </div>

            <?php endif; ?>


               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <div class="tab">
                              <button class="tablinks active" onclick="openTab(event, 'add-employees')" id="defaultOpen"><span class="d-none d-sm-block">Official
                                 Info</span><span class="d-block d-sm-none text-center"><i class="fa fa-info-circle" data-toggle="tooltip" title="Official Info"></i></span></button>
                              <!-- <button class="tablinks" onclick="openTab(event, 'leaves')">Leaves</button>
                              <button class="tablinks" onclick="openTab(event, 'holiday')">Holiday</button> -->
                              <button class="tablinks" onclick="openTab(event, 'addsalary')"><span class="d-none d-sm-block">Salary</span><span class="d-block d-sm-none text-center"><i class="fa fa-money-bill-alt" data-toggle="tooltip" title="Salary"></i></span></button>
                              <button class="tablinks" onclick="openTab(event, 'addPersonalInfo')"><span class="d-none d-sm-block">Personal Info</span>
                              <span class="d-block d-sm-none text-center"><i class="fa fa-user" data-toggle="tooltip" title="Personal Info"></i></span></button>
                              <button class="tablinks" onclick="openTab(event, 'addcontact')"><span class="d-none d-sm-block">Contact Info</span><span class="d-block d-sm-none text-center"><i class="fa fa-phone" data-toggle="tooltip" title="Contact Info"></i></span></button>
                              <button class="tablinks" onclick="openTab(event, 'addexperiance')"><span class="d-none d-sm-block">Experience</span><span class="d-block d-sm-none text-center"><i class="fa fa-history" data-toggle="tooltip" title="Experience"></i></span></button>
                              <button class="tablinks" onclick="openTab(event, 'addeducation')"><span class="d-none d-sm-block">Education</span><span class="d-block d-sm-none text-center"><i class="fa fa-graduation-cap" data-toggle="tooltip" title="Education"></i></span></button>
                              <button class="tablinks" onclick="openTab(event, 'addtraining')"><span class="d-none d-sm-block">Training &
                                 Certification</span><span class="d-block d-sm-none text-center"><i class="fa fa-certificate" data-toggle="tooltip" title="Training &
                                 Certification"></i></span></button>
                              <button class="tablinks" onclick="openTab(event, 'addvisa')"><span class="d-none d-sm-block">Visa & Immigration</span><span class="d-block d-sm-none text-center"><i class="fab fa-cc-visa" data-toggle="tooltip" title="Visa & Immigration"></i></span></button>
                              <button class="tablinks" onclick="openTab(event, 'addassetes')"><span class="d-none d-sm-block">Assets</span><span class="d-block d-sm-none text-center" data-toggle="tooltip" title="Assets"><i class="fa fa-list"></i></span></button>
                           </div>
                           <form id="offical" method="post">
                           <div id="official" class="tabcontent active">
                              <h3>Official Info</h3>
                              <div class="width-float">
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="empcode" class="col-lg-4 col-form-label">User ID<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                             <input id="empid" type="text"  value="<?php echo e(autoincrement()); ?>" maxlength="20" class="form-control" readonly="">
                                             <div id="empode_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="empid" class="col-lg-4 col-form-label">User Code<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                             <input  id="empcode"  type="text" onkeypress="preventNonNumericalInput(event)" value="<?php echo e($editData->employeeId??''); ?>"  maxlength="20" class="form-control">
                                              <div id="empid_error"></div>
                                          </div>
                                       </div>
                                    </div>



                                   <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="empid" class="col-lg-4 col-form-label">Sarvor Card No<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                             <input  id="sarvor_id"  type="text"  value="<?php echo e($editData->savior_card_id??''); ?>"  maxlength="20" class="form-control">
                                              <div id="sarvor_id_error"></div>
                                          </div>
                                       </div>
                                    </div>

                                 </div>

                                    <input type="hidden" id="userid" value="<?php echo e($editData->id??''); ?>">

                                       <?php

                                            $prefixdata = DB::table('main_prefix')->where('isactive','=',1)->get();
                                             
                                           ?>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="prifix" class="col-lg-4 col-form-label">Prefix
</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="prefix">
                                                <option value="">Select Option</option>
                                                <?php $__currentLoopData = $prefixdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefixdatas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($prefixdatas->id); ?>" <?php if(!empty($editData)): ?> <?php if($prefixdatas->id == $editData->prefix): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($prefixdatas->prefix); ?>.</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                             </select>
                                              <div id="prefix_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="firstname" class="col-lg-4 col-form-label">First Name<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                             <input id="fname" type="text" value="<?php echo e($editData->firstname??''); ?>" class="form-control">
                                              <div id="fname_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="logo" class="col-lg-4 col-form-label">Last Name<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                             <div class="form-group">
                                                <input id="lname" type="text" value="<?php echo e($editData->lastname??''); ?>"  class="form-control">
                                                 <div id="lname_error"></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="email" class="col-lg-4 col-form-label">Email
</label>
                                          <div class="col-lg-8">
                                              <input id="emaildata" value="<?php echo e($editData->emailaddress??''); ?>" type="text" class="form-control">
                                             <div id="email_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="cid" class="col-lg-4 col-form-label">Medical Policy Customer
                                             ID
</label>
                                          <div class="col-lg-8">
                                             <input id="mpcst" type="text" value="<?php echo e($editData->medicalpolicy??''); ?>" onkeypress="preventNonNumericalInput(event)" maxlength="30" class="form-control">
                                             <div id="mpcst_error"></div>
                                          </div>
                                       </div>
                                    </div>

                                    

                                       <?php

                                            $modeemp= DB::table('main_mode_emploment')->where('isactive','=',1)->get();
                                             
                                           ?>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="mode" class="col-lg-4 col-form-label">Mode of Employement
</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="modeemp">
                                                <option value="">Select option</option>
                                                 <?php $__currentLoopData = $modeemp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modeemps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($modeemps->id); ?>"  <?php if(!empty($editData)): ?> <?php if($modeemps->id == $editData->modeofentry): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($modeemps->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                             </select>
                                             <div id="modeemp_error"></div>
                                          </div>
                                       </div>
                                    </div>

                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="role" class="col-lg-4 col-form-label">Role<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                        <?php

                                            $role = DB::table('main_roles')->where('id','!=',1)->where('isactive','=',1)->get();
                                             
                                           ?>
                                            
                                             <select class="form-control" id="role">
                                                <option value="">Select Role</option>
                                                <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($roles->id); ?>"   <?php if(!empty($editData)): ?> <?php if($roles->id == $editData->emprole): ?> selected <?php endif; ?> <?php endif; ?>  ><?php echo e($roles->rolename); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                             </select>
                                             <div id="role_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="empcat" class="col-lg-4 col-form-label">Employee Category
</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="emp_category">
                                                <option value="">Select Category</option>
                                                <option <?php if(!empty($editData)): ?> <?php if('A' == $editData->emp_category): ?> selected <?php endif; ?> <?php endif; ?> >A</option>
                                                <option  <?php if(!empty($editData)): ?> <?php if('B' == $editData->emp_category): ?> selected <?php endif; ?> <?php endif; ?>>B</option>
                                             </select>
                                             <div id="empcode_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="crdno" class="col-lg-4 col-form-label">Card No.
</label>
                                          <div class="col-lg-8">
                                             <input id="crdno" type="text" value="<?php echo e($editData->medicalpolicy??''); ?>" onkeypress="preventNonNumericalInput(event)" maxlength="20" class="form-control">
                                               <div id="crdno_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                    
                                      <?php

                                     $businessunit = DB::table('main_businessunits')->where('isactive','=',1)->get();
                                             
                                           ?>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="busunit" class="col-lg-4 col-form-label">Business Unit</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="bsnit">
                                                <option value="">Select Business Unit</option>
                                                <?php $__currentLoopData = $businessunit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businessunits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($businessunits->id); ?>"   <?php if(!empty($editData)): ?> <?php if($businessunits->id == $editData->bussinessunit): ?> selected <?php endif; ?> <?php endif; ?>  ><?php echo e($businessunits->unitname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                             </select>
                                               <div id="bsnit_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                         <?php

                                            $department = DB::table('main_departments')->where('isactive','=',1)->get();
                                             
                                           ?>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="dep" class="col-lg-4 col-form-label">Department
</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="dprt">
                                                <option value="">Select Department</option>

                                                <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($departments->id); ?>"  <?php if(!empty($editData)): ?> <?php if($departments->id == $editData->department_id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($departments->deptname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                             </select>
                                               <div id="dprt_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                     <?php

                                          $reporting = DB::table('main_users')->where('isactive','=',1)->where('emprole',3)->get();
                                             
                                           ?>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="reporting" class="col-lg-4 col-form-label">Reporting
                                             Manager<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="reptmng">
                                                <option value="">Select Reporting Manager</option>
                                                <?php $__currentLoopData = $reporting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($reportings->id); ?>"  <?php if(!empty($editData)): ?> <?php if($reportings->id == $editData->reporting_manager): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($reportings->userfullname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             
                                             </select>
                                             <div id="reptmng_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                 

                                         <?php

                                            $jobtitle= DB::table('main_jobtitles')->where('isactive','=',1)->get();
                                             
                                           ?>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="jobtitle" class="col-lg-4 col-form-label">Job Title
</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="jobtitle">
                                                <option value="">Select Job Title</option>
                                                <?php $__currentLoopData = $jobtitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobtitles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($jobtitles->id); ?>" <?php if(!empty($editData)): ?> <?php if($jobtitles->id == $editData->jobtitle_id): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($jobtitles->jobtitlename); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                             </select>
                                             <div id="jobtitle_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                     <?php

                                            $positions= DB::table('main_positions')->where('isactive','=',1)->get();
                                             
                                           ?>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="position" class="col-lg-4 col-form-label">Position</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="positions">
                                                <option value="">Select Position</option>
                                                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $positionss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($positionss->id); ?>" <?php if(!empty($editData)): ?> <?php if($positionss->id == $editData->position_id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($positionss->positionname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                             </select>
                                              <div id="positions_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                 

                                       <?php

                                            $empstatus = DB::table('main_employmentstatus')->where('isactive','=',1)->get();
                                             
                                           ?>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="empstatus" class="col-lg-4 col-form-label">Employement
                                             Status
</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="empstatus">
                                                <option value="">Employement
                                                   Status</option>
                                                   <?php $__currentLoopData = $empstatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empstatuss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($empstatuss->id); ?>" <?php if(!empty($editData)): ?> <?php if($empstatuss->id == $editData->employee_status): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($empstatuss->workcode); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                             </select>
                                              <div id="empstatus_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="doj" class="col-lg-4 col-form-label">Date of Joining<span class="text-danger p-l-5">*</span>
</label>
                                          <div class="col-lg-8">
                                             <input id="doj" type="date" value="<?php echo e($editData->join_date??''); ?>" class="form-control">
                                              <div id="doj_error"></div>
                                          </div>
                                          
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="dol" class="col-lg-4 col-form-label">Date of Leaving</label>
                                          <div class="col-lg-8">
                                             <input id="dol" type="date" value="<?php echo e($editData->leave_date??''); ?>" class="form-control">
                                               <div id="dol_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                     
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="yoe" class="col-lg-4 col-form-label">Year of Experience</label>
                                          <div class="col-lg-8">
                                             <input id="yoe" type="text" onkeypress="preventNonNumericalInput(event)" maxlength="2" value="<?php echo e($editData->experience??''); ?>" class="form-control">
                                              <div id="yoe_error"></div>
                                          </div>
                                       </div>
                                    </div>


                                       <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="yoe" class="col-lg-4 col-form-label">Type</label>
                                          <div class="col-lg-8">
                                             <input id="yoe" type="text" maxlength="4" value="<?php echo e($editData->experience??''); ?>" class="form-control">
                                              <div id="yoe_error"></div>
                                          </div>
                                       </div>
                                    </div>

                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="workphn" class="col-lg-4 col-form-label">Work Phone</label>
                                          <div class="col-lg-8">
                                             <input id="workphn" onkeypress="preventNonNumericalInput(event)" type="text" maxlength="15" value="<?php echo e($editData->workphone??''); ?>" class="form-control">
                                              <div id="workphn_error"></div>
                                          </div>
                                       </div>
                                    </div>
                                   
                                    <div class="col-md-6">
                                       <div class="form-group row">
                                          <label for="extno" class="col-lg-4 col-form-label">Employee Type.</label>
                                          <div class="col-lg-8">
                                             <select class="form-control" id="emp_type">
                                             <option value="1" <?php if(!empty($editData)): ?> <?php if($editData->emp_type==1): ?> selected  <?php endif; ?> <?php endif; ?>>Employee</option>
                                              <option value="2" <?php if(!empty($editData)): ?>   <?php if($editData->emp_type==2): ?> selected  <?php endif; ?>  <?php endif; ?>>freelancer</option>     
                                              </select>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="form-group row">
                                          <div class="col-lg-12">
                                             <div class=" float-right">
                                               
                                                <button type="button" class="btn btn-primary addemp">Save</button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>

                           </form>
                         
                    
                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         <?php $__env->stopSection(); ?>
          <?php $__env->startSection('extra_js'); ?>
         <!--  <script type="text/javascript">
          	 $('#doj').datetimepicker();
          	 $(function () {
         
            });
          </script> -->
         
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>