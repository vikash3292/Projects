   <?php $__env->startSection('content'); ?>
   <!-- Begin page -->
   <div id="wrapper">
     
      <!-- Top Bar End -->
      
      <!-- Left Sidebar End -->
      <!-- ============================================================== -->
      <!-- Start right Content here -->
      <!-- ============================================================== -->
      <div id="colorPanel" class="colorPanel">
            <a id="cpToggle" href="#"></a>
            <ul></ul>
        </div>
      <div class="content-page">
         <!-- Start content -->
         <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style m-b-20 p-10">
                     <div class="col-sm-6">
                        <h4 class="page-title">Dashboard</h4>
                     </div>
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-xl-3 col-md-6">
                     <div class="mini-stat text-white">
                        <div class="card-body">
                           <div>
                              <h5 class="font-16 text-uppercase m-0 text-center"><i
                                    class="mdi mdi-account-multiple font-100"></i></h5>
                              <h4 class="font-500 text-center font-dark font-20 m-0">200 Users</h4>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-md-6">
                     <div class="mini-stat text-white">
                        <div class="card-body">
                           <div>
                              <h5 class="font-16 text-uppercase m-0 text-center"><i class="mdi mdi-face font-100"></i>
                              </h5>
                              <h4 class="font-500 text-center font-dark font-20 m-0">10 clients</h4>

                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-md-6">
                     <div class="mini-stat text-white">
                        <div class="card-body">
                           <div>
                              <h5 class="font-16 text-uppercase m-0 text-center"><i
                                    class="mdi mdi-mailbox font-100"></i></h5>
                              <h4 class="font-500 text-center font-dark font-20 m-0">200 Projects</h4>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-md-6">
                     <div class="card mini-stat bg-grc text-white">
                        <div class="card-body">
                           <h5 class="font-16 text-uppercase mt-0 m-b-15 font-dark text-center">Task Status</h5>
                           <div class="col-lg-12">
                              <div class="row">
                                 <div class="col-lg-6 text-center">
                                    <span class="peity-donut"
                                       data-peity='{ "fill": ["#5fe384", "#f2f2f2"], "innerRadius": 20, "radius": 30 }'
                                       data-width="72" data-height="55">4/5</span>
                                    <p class="text-dark m-t-20 mb-0">65 Done</p>
                                 </div>
                                 <div class="col-lg-6 text-center">
                                    <span class="peity-donut"
                                       data-peity='{ "fill": ["#f2f2f2","#fb9e9e"], "innerRadius": 20, "radius": 30 }'
                                       data-width="72" data-height="55">4/5</span>
                                    <p class="text-dark mb-0 m-t-20">30 panding</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-xl-9">
                     <div class="card crd-blue-border" style="height:238px">
                        <div class="card-body">
                           <h3 class="mt-0 header-title mb-4 font-blue">Circulars</h3>
                           <hr>
                           <ul class="ulcolor">
                              <li>Leaves are restricted for month of October.</li>
                              <li>Policy of EC letter is updated by government.</li>
                           </ul>
                        </div>
                     </div>
                     <!-- end card -->
                  </div>
                  <div class="col-xl-3">
                     <div class="card" style="height:238px">
                        <div class="card-body crd-blue-border">
                           <div>
                              <h4 class="mt-0 header-title mb-4 font-blue">Total Leaves</h4>
                           </div>
                           <div>
                              <canvas id="leavechart"></canvas>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- end row -->

               <div class="row">
                  <div class="col-xl-12">
                     <div class="card crd-blue-border">
                        <div class="card-body">
                           <h4 class="mt-0 header-title mb-5 font-blue">Deparment Wise Head Count</h4>
                           <div class="row">
                              <div class="col-lg-12">
                                 <div>
                                    <canvas id="myChart" height="80"></canvas>
                                 </div>
                              </div>
                           </div>
                           <!-- end row -->
                        </div>
                     </div>

                  </div>
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
         <!-- content -->
  <?php $__env->stopSection(); ?>      
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>