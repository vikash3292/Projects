<?php $__env->startSection('content'); ?>
<?php  //echo "<pre>"; print_r($classData); ?>
<!-- Content Wrapper. Contains page content -->
<?php $__env->startSection('extra_css'); ?>
<style>


.disabledTab{
    pointer-events: none;
}
</style>

<?php $__env->stopSection(); ?>
      <!-- Start content -->
        <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h3 class="page-title">Project View</h3>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>"><?php echo e($mainsetting->site_title); ?></a></li>
                           <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Project View</a>
                           </li>
                            <li class="breadcrumb-item active"><a href="javascript: history.go(-1)"><?php echo e($projectview->project_name); ?></a>
                           </li>
                           
                           
                        </ol>
                     </div>
                     
                     
                   <?php if($current_user_id == $projectview->manager_id): ?>
                      
                 
                     <div class="col-sm-6">
                        <div class="float-right d-none d-md-block">
                           <div class="dropdown">
                              <a href="<?php echo e(URL::to('/edit-project')); ?>/<?php echo e($projectview->id); ?>">
                                 <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Edit Project</button>
                              </a>
                           </div>
                        </div>
                     </div>
                      <?php elseif(PermissionHelper::frontendPermission('edit-project')): ?>
                     
                        <div class="col-sm-6">
                        <div class="float-right d-none d-md-block">
                           <div class="dropdown">
                              <a href="<?php echo e(URL::to('/edit-project')); ?>/<?php echo e($projectview->id); ?>">
                                 <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Edit Project</button>
                              </a>
                           </div>
                        </div>
                     </div>
                     
                     <?php endif; ?>
                
                     
                     
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body projectviewtab p-0">
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                            <li class="nav-item waves-effect waves-light"><a class="nav-link active"
                                                    data-toggle="tab" href="#home-1" role="tab">
                                                    <span class="d-none d-sm-block">Details</span></a></li>
                                            <li class="nav-item waves-effect waves-light"><a class="nav-link"
                                                    data-toggle="tab" href="#profile-1" role="tab">
                                                    <span class="d-none d-sm-block">Tasks</span></a></li>
                                            <li class="nav-item waves-effect waves-light"><a class="nav-link"
                                                    data-toggle="tab" href="#messages-1" role="tab">
                                                    <span class="d-none d-sm-block">Resources</span></a></li>
                                        </ul>
                                        <!-- Tab panes -->
                                        <div class="tab-content">
                                            <div class="tab-pane active p-3" id="home-1" role="tabpanel">
                                               <div class="col-12">
                                    <h5 class="h5after"><span>Details</span></h5>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="empcode" class="col-lg-4 col-form-label">Project
                                             Name</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->project_name); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="empid" class="col-lg-4 col-form-label">Client</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->client_name); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="prifix" class="col-lg-4 col-form-label">Description</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->description); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="firstname" class="col-lg-4 col-form-label">Currency</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->currencyname); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="logo" class="col-lg-4 col-form-label">Status</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->project_status); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="email" class="col-lg-4 col-form-label">Project Type</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->project_type); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="cid" class="col-lg-4 col-form-label">Start Date</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e(date('d-M-Y',strtotime($projectview->start_date))); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="mode" class="col-lg-4 col-form-label">End Date</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e(date('d-M-Y',strtotime($projectview->end_date))); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Estimated Hours</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->estimated_hrs); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Actual Hours</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e($projectview->actualhour); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                    
                                    
                                      <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Manager</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label"><?php echo e(ucwords($projectview->userfullname)); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                    <?php
                                    $stage  = DB::table('main_stage')->get();
                                    ?>
                                     <?php if($current_user_id == $projectview->manager_id): ?>
                                    
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Stage</label>
                                          <div class="col-lg-8 col-form-label">
                                             <select class="form-control" id="stage">
                                                      
                                                        <?php $__currentLoopData = $stage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($stages->id); ?>" <?php if($projectview->stage == $stages->id): ?> selected <?php endif; ?>><?php echo e($stages->stage_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                                    </select>
                                          </div>
                                       </div>
                                    </div>
                                     <?php elseif(PermissionHelper::frontendPermission('edit-project')): ?>
                                     
                                                  <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Stage</label>
                                          <div class="col-lg-8 col-form-label">
                                             <select class="form-control" id="stage">
                                                       
                                                        <?php $__currentLoopData = $stage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($stages->id); ?>" <?php if($projectview->stage == $stages->id): ?> selected <?php endif; ?>><?php echo e($stages->stage_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                                    </select>
                                          </div>
                                       </div>
                                    </div>
                                     
                                     <?php endif; ?>
                                    
                                    
                                    
                                 </div>
                                            </div>
                                            <div class="tab-pane p-3" id="profile-1" role="tabpanel">
                                              <div class="col-12">
                                    <h5 class="h5after"><span>Tasks</span></h5>
                                 </div>
                                 <div class="col-sm-12">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap font-14"
                                       style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                       <thead>
                                          <tr>
                                             <th>S.No</th>
                                             <th>Name</th>
                                             <th>Estimated Hours</th>
                                             <th>Actual Hours</th>
                                             <th>Start Date</th>
                                             <th>End Date</th>
                                             <th>Status</th>
                                             <th>Created By</th>
                                             <th>Action</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                        
                                           <?php ($i = 1); ?>
                                           <?php $__currentLoopData = $taskList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                           <?php
                               
        $taskAssign  = DB::table('tm_project_task_employees')->join('main_users','tm_project_task_employees.emp_id','=','main_users.id')->leftjoin('main_jobtitles','main_users.jobtitle_id','=','main_jobtitles.id')->join('tm_tasks','tm_project_task_employees.task_id','=','tm_tasks.id')->where('tm_project_task_employees.task_id',$taskLists->task_id)->where('tm_project_task_employees.project_id',$project_id)->select('tm_project_task_employees.*','main_users.userfullname','main_users.employeeId','main_users.prefix','main_users.profileimg','tm_tasks.task','main_jobtitles.jobtitlename')->get();
          // dd($taskAssign);                               
                                           
            	
        	     $all_seconds=0;
        	    $assignproject = DB::table('tm_emp_timesheets')->where('project_id',$project_id)->where('project_task_id',$taskLists->id)->get();
        	    if(isset($assignproject) && !empty($assignproject)){
        	        foreach($assignproject as $assignprojects){
        	        
        	         list($hour, $minute) = explode(':', $assignprojects->week_duration);
	                      $h = (int)$hour;
	                      $m  = (int)$minute;
	                        
	                     $all_seconds += $h * 3600;
                         $all_seconds += $m * 60;
        	        }
        	        
        	          $total_minutes = floor($all_seconds/60);
                    
                     $hours = floor($total_minutes / 60); 
                      $minutes = $total_minutes % 60;
                       
           
                  $week_hour =  sprintf('%02d:%02d', $hours, $minutes);
                  
        	        
        	        
        	        
        	    }
        	    
       
                                          
                                           ?>
                                          <tr>
                                             <td>
                                              <?php echo e($i++); ?>

                                             </td>
                                             <td class="text_ellipses" data-toggle="tooltip" title="<?php echo e($taskLists->task); ?>"><?php echo e($taskLists->task); ?></td>
                                             <td><?php echo e($taskLists->estimated_hrs); ?></td>
                                             <td><?php echo e($week_hour??'0'); ?></td>
                                             <td><?php echo e($taskLists->task_start_date); ?></td>
                                             <td><?php echo e($taskLists->task_end_date); ?></td>
                                             <td><?php echo e($taskLists->task_status); ?></td>
                                             <td><?php echo e($taskLists->userfullname); ?></td>
                                             <td>
                                                <a href="project_view.html" data-toggle="modal" data-target="#viewtask<?php echo e($taskLists->id); ?>">
                                                   <i class="fa fa-eye font-blue"></i>
                                                </a>
                                             </td>
                                          </tr>
                                          
                                          
                                             <div id="viewtask<?php echo e($taskLists->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title mt-0" id="myModalLabel">View Task Resources</h5>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
               <div class="col-sm-12 p-0">
                  <div class="row">
                     <div class="col-sm-6">
                        <span class="font-500">Task:</span>
                        <span><?php echo e($taskLists->task); ?></span>
                     </div>
                     <div class="col-sm-6 float-right">
                        <span class="font-500">Estimated Hours:</span>
                        <span><?php echo e($taskLists->estimated_hrs); ?></span>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-sm-6">
                        <h5>
                           <span>Resources</span>
                        </h5>
                     </div>
                    <div class="col-sm-6 float-right">
                        <span class="float-right">
                           <form role="search" class="app-search float-right"
                                                                style="height: 0;">
                                                                <div class="form-group mb-0">
                                                                    <input type="text" class="form-control m-0"
                                                                        placeholder="Search..">
                                                                    <button type="submit" style="top:10px"><i
                                                                            class="fa fa-search"></i></button></div>
                                                            </form>
                        </span>
                     </div>
                  </div>
               </div>
               <div class="row m-t-10">
                   <?php $__currentLoopData = $taskAssign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskAssigns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-sm-3">
                     <div class="card m-b-10 float-left width100 box-shadow">
                        <div class="media p-l-5 p-r-5 p-t-5">
                            <?php if(!empty($taskAssigns->profileimg)): ?>
                            <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/')); ?>/<?php echo e($taskAssigns->profileimg); ?>" alt="Generic placeholder image" height="40">
                              <?php elseif($taskAssigns->prefix == 1): ?>
                              
                               <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/male.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php elseif($taskAssigns->prefix == 2 || $taskAssigns->prefix == 3): ?>
                              
                                <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/female.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php else: ?>
                              
                              <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/human.png')); ?>" alt="Generic placeholder image" height="40">
                              <?php endif; ?>
                              
                           <div class="media-body">
                              <h6 class="mt-0 mb-0 font-16 text-info"><?php echo e(ucwords($taskAssigns->userfullname)); ?></h6>
                              <p class="m-0 font-12"><?php echo e($taskAssigns->employeeId); ?></p>
                              <p class="m-0 font-12"><?php echo e($taskLists->estimated_hrs); ?> Hrs</p>
                           </div>
                        </div>
                        <div class="mainhilight">
                           <span class="font-500"><?php echo e($taskAssigns->jobtitlename); ?></span>
                        </div>
                     </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!--<div class="col-sm-3">-->
                  <!--   <div class="card m-b-10 float-left width100 box-shadow">-->
                  <!--      <div class="media p-l-5 p-r-5 p-t-5"><img class="d-flex mr-3 rounded-circle"-->
                  <!--            src="assets/images/users/user-6.jpg" alt="Generic placeholder image" height="40">-->
                  <!--         <div class="media-body">-->
                  <!--            <h6 class="mt-0 mb-0 font-16 text-info">Nisha Upreti</h6>-->
                  <!--            <p class="m-0 font-12">KSPL1167</p>-->
                  <!--            <p class="m-0 font-12">2 Hrs</p>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--      <div class="mainhilight">-->
                  <!--         <span class="font-500">HTML Developer</span>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</div>-->
                  <!--<div class="col-sm-3">-->
                  <!--   <div class="card m-b-10 float-left width100 box-shadow">-->
                  <!--      <div class="media p-l-5 p-r-5 p-t-5"><img class="d-flex mr-3 rounded-circle"-->
                  <!--            src="assets/images/users/user-6.jpg" alt="Generic placeholder image" height="40">-->
                  <!--         <div class="media-body">-->
                  <!--            <h6 class="mt-0 mb-0 font-16 text-info">Nisha Upreti</h6>-->
                  <!--            <p class="m-0 font-12">KSPL1167</p>-->
                  <!--            <p class="m-0 font-12">2 Hrs</p>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--      <div class="mainhilight">-->
                  <!--         <span class="font-500">HTML Developer</span>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</div>-->
                  <!--<div class="col-sm-3">-->
                  <!--   <div class="card m-b-10 float-left width100 box-shadow">-->
                  <!--      <div class="media p-l-5 p-r-5 p-t-5"><img class="d-flex mr-3 rounded-circle"-->
                  <!--            src="assets/images/users/user-6.jpg" alt="Generic placeholder image" height="40">-->
                  <!--         <div class="media-body">-->
                  <!--            <h6 class="mt-0 mb-0 font-16 text-info">Nisha Upreti</h6>-->
                  <!--            <p class="m-0 font-12">KSPL1167</p>-->
                  <!--            <p class="m-0 font-12">2 Hrs</p>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--      <div class="mainhilight">-->
                  <!--         <span class="font-500">HTML Developer</span>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</div>-->
               </div>
            </div>
         </div>
      </div>
   </div>
                                          
                                          
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </tbody>
                                    </table>
                                 </div>
                                            </div>
                                            <div class="tab-pane p-3" id="messages-1" role="tabpanel">
                                                 <div class="col-12">
                                    <h5 class="h5after"><span>Resources</span></h5>
                                 </div>
                                 
                               
                                 <div class="col-sm-12">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap font-14"
                                       style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                       <thead>
                                          <tr>
                                             <th>S.No</th>
                                             <th>Name</th>
                                             <th>Role</th>
                                             <th>Billable Rate(INR)</th>
                                             <th>Cost Rate(INR)</th>
                                             <th>Action</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                           <?php ($i = 1); ?>
                                           <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userlists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                           <?php
                                           
                                           $usreasigntask = DB::table('tm_project_task_employees')->leftjoin('main_users','tm_project_task_employees.emp_id','=','main_users.id')->leftjoin('main_jobtitles','main_users.jobtitle_id','=','main_jobtitles.id')->leftjoin('tm_project_tasks','tm_project_task_employees.task_id','=','tm_project_tasks.task_id')->leftjoin('tm_tasks','tm_project_task_employees.task_id','=','tm_tasks.id')->where('tm_project_task_employees.emp_id',$userlists->id)->where('tm_project_task_employees.project_id',$project_id)->select('tm_project_tasks.estimated_hrs','tm_project_tasks.id','tm_tasks.task','main_users.userfullname','main_users.id as userid','main_users.profileimg','main_users.prefix','main_users.employeeId','main_jobtitles.jobtitlename')->get();
                                         
                                           ?>
                                           
                                          <tr>
                                             <td>
                                                <?php echo e($i++); ?>

                                             </td>
                                             <td class="text_ellipses" data-toggle="tooltip" title="<?php echo e(ucwords($userlists->userfullname)); ?>"><?php echo e(ucwords($userlists->userfullname)); ?></td>
                                             <td><?php echo e($userlists->rolename); ?></td>
                                             <td></td>
                                             <td></td>
                                             <td>
                                                <a href="project_view.html" data-toggle="modal"
                                                   data-target="#viewresource<?php echo e($userlists->id); ?>">
                                                   <i class="fa fa-eye font-blue"></i>
                                                </a>
                                             </td>
                                          </tr>
                                          
                                          <div id="viewresource<?php echo e($userlists->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
      aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title mt-0" id="myModalLabel">View Employee Task</h5>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
               <div class="row">
                  <div class="col-sm-12 m-b-10">
                     <span class="float-right">
                        <form role="search" class="app-search float-left width100" style="height: 0;">
                           <div class="form-group mb-0">
                              <input type="text" class="form-control m-0" placeholder="Search by Task..">
                              <button type="submit" style="top:10px"><i class="fa fa-search"></i></button></div>
                        </form>
                     </span>
                  </div>
                  <div class="col-sm-12">
                      
                      <?php $__currentLoopData = $usreasigntask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usreasigntasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      
                             
        	     $all_seconds=0;
        	    $assignproject = DB::table('tm_emp_timesheets')->where('emp_id',$usreasigntasks->userid)->where('project_id',$project_id)->where('project_task_id',$usreasigntasks->id)->get();
        	    if(isset($assignproject) && !empty($assignproject)){
        	        foreach($assignproject as $assignprojects){
        	        
        	         list($hour, $minute) = explode(':', $assignprojects->week_duration);
	                      $h = (int)$hour;
	                      $m  = (int)$minute;
	                        
	                     $all_seconds += $h * 3600;
                         $all_seconds += $m * 60;
        	        }
        	        
        	          $total_minutes = floor($all_seconds/60);
                    
                     $hours = floor($total_minutes / 60); 
                      $minutes = $total_minutes % 60;
                       
           
                   $week_hour =  sprintf('%02d:%02d', $hours, $minutes);

        	        
        	        
        	        
        	    }
        	    
        	
                      ?>
                     <div class="card m-b-10 float-left width100 box-shadow">

                        <div class="media padding-5">
                            
                             <?php if(!empty($usreasigntasks->profileimg)): ?>
                            <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/')); ?>/<?php echo e($usreasigntasks->profileimg); ?>" alt="Generic placeholder image" height="40">
                              <?php elseif($usreasigntasks->prefix == 1): ?>
                              
                               <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/male.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php elseif($usreasigntasks->prefix == 2 || $usreasigntasks->prefix == 3): ?>
                              
                                <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/female.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php else: ?>
                              
                              <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/human.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php endif; ?>
                            
                         
                              
                           <div class="media-body col-sm-4">
                              <h6 class="mt-0 mb-0 font-16 text-info"><?php echo e(ucwords($usreasigntasks->userfullname)); ?></h6>
                              <p class="m-0 font-12"><?php echo e($usreasigntasks->employeeId); ?></p>
                              <p class="m-0 font-12"><?php echo e($usreasigntasks->estimated_hrs); ?> Hrs</p>
                           </div>
                           <div class="media-body col-sm-8 text-center">
                              <div class="row">
                                 <div class="col-sm-4 div-right-b">
                                    <h6>Task</h6>
                                    <p class="m-b-5"><?php echo e($usreasigntasks->task); ?></p>
                                 </div>
                                 <div class="col-sm-4 div-right-b">
                                    <h6>Estimated hours</h6>
                                    <p class="m-b-5"><?php echo e($usreasigntasks->estimated_hrs); ?></p>
                                 </div>
                                 <div class="col-sm-4">
                                    <h6>Actual hours</h6>
                                    <p class="m-b-5"><?php echo e($week_hour??'00:00'); ?></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="mainhilight col-sm-12">
                           <span class="font-500"><?php echo e($usreasigntasks->jobtitlename); ?></span>
                        </div>
                     </div>
                     
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php if(count($usreasigntask) == 0): ?>
                     
                     <p>Task Not Assign</p>
                     <?php endif; ?>
                     
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
                                          
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </tbody>
                                    </table>
                                 </div>
                                            </div>
                                        </div>

                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
         
         
     

         
         
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>

<script>

var project_id = '<?php echo e($project_id); ?>';

$(document).on('change','#stage',function(){
    
    var stage = this.value;
   
 
   
   var _token = "<?php echo e(csrf_token()); ?>";

  $.ajax({
        url: '/update_stage',
        type: "post",
        data: {"_token": _token,"project_id":project_id,"stage":stage},
        dataType: 'JSON',
         
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
             
             swal("Good job!", "Change Successfully", "success");

            location.reload();

          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");


          }else{

             $('#loadingDiv').hide();
            
             swal("Good job!", "Not change", "error");

          }
          
        }
      });

});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>