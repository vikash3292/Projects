<?php $__env->startSection('content'); ?>



<div class="content p-0">

	<div class="container-fluid">

		<div class="page-title-box">

			<div class="row align-items-center bredcrum-style">

				<div class="col-sm-6">

					<h4 class="page-title">All Expenses</h4>

					<ol class="breadcrumb">

						<li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>"><?php echo e($mainsetting->site_title); ?></a></li>

					</ol>

				</div>

				<div class="col-sm-6">

					<div class="float-right d-none d-md-block">

						<div class="dropdown">

							<a href="<?php echo e(URL::to('/add-expense')); ?>">

								<button

								class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"

								type="button">

							Add New Expenses</button>

						</a>

					</div>

				</div>

			</div>

		</div>

	</div>

	<!-- end row -->

	<!-- end row -->

	<div class="row">

		<div class="col-12">

			<div class="card m-t-20">

				<div class="card-body">

					<form method="GET">

						<div class="row">

							<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Select Year

										<span class="text-danger">*</span>

									</label>

									<div class="col-lg-8">

										<select class="form-control" name="year" required="">

											<option value="">Select Year</option>

											<?php for($i=date('Y')-1;$i <= date('Y'); $i++ ): ?>

											<option <?php if(!empty($_GET['year'])): ?>  <?php if($_GET['year'] == $i): ?> selected    <?php endif; ?> <?php endif; ?>><?php echo e($i); ?></option>



											<?php endfor; ?>



										</select>





									</div>

								</div>



							</div>

							<div class="col-md-6">

									<div class="form-group row">

										<label for="empcode" class="col-lg-4 col-form-label">Select Month

											<span class="text-danger"></span>

										</label>

										<div class="col-lg-8">

											<select class="form-control" name="month" >

												<option value="">Select Month</option>

												<option value="01" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 1): ?> selected    <?php endif; ?> <?php endif; ?>>January</option>

												<option value="02" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 2): ?> selected    <?php endif; ?> <?php endif; ?>>February</option>

												<option value="03" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 3): ?> selected    <?php endif; ?> <?php endif; ?>>March</option>

												<option value="04" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 4): ?> selected    <?php endif; ?> <?php endif; ?>>April</option>

												<option value="05" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 5): ?> selected    <?php endif; ?> <?php endif; ?>>May</option>

												<option value="06" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 6): ?> selected    <?php endif; ?> <?php endif; ?>>June</option>

												<option value="07" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 7): ?> selected    <?php endif; ?> <?php endif; ?>>July</option>

												<option value="08" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 8): ?> selected    <?php endif; ?> <?php endif; ?>>August</option>

												<option value="09" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 9): ?> selected    <?php endif; ?> <?php endif; ?>>September</option>

												<option value="10" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 10): ?> selected    <?php endif; ?> <?php endif; ?>>October</option>

												<option value="11" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 11): ?> selected    <?php endif; ?> <?php endif; ?>>November</option>

												<option value="12" <?php if(!empty($_GET['month'])): ?>  <?php if($_GET['month'] == 12): ?> selected    <?php endif; ?> <?php endif; ?>>December</option>

											</select>

										</div>

									</div>

								</div>

						</div>

						<div class="row">

							<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Employee Name

										<span class="text-danger">*</span>

									</label>

									<div class="col-lg-8">

										<select class="form-control" name="user" id="user" onchange="get_project(this.value)" required="">

											<option value="">Select Name</option>
                                            <?php if($role == 1 || $role ==11 || $role ==4): ?>
											<option value="all" <?php if(!empty($_GET['user'])): ?>  <?php if($_GET['user'] == 'all'): ?> selected    <?php endif; ?>  <?php endif; ?>>All EMP</option>
                                           <?php endif; ?>


											<?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userlists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

											<option value="<?php echo e($userlists->id); ?>" <?php if(!empty($_GET['user'])): ?>  <?php if($_GET['user'] == $userlists->id): ?> selected    <?php endif; ?> <?php endif; ?>><?php echo e($userlists->userfullname); ?></option>

											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



										</select>

									</div>

								</div>

							</div>

							<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Project Name

										<span class="text-danger"></span>

									</label>

									<div class="col-lg-8">

										<select class="form-control" id="project" name="project" >

											<option value="">Select Project</option>



											<?php if(!empty($_GET['user'])): ?>

	
											<?php $__currentLoopData = $project_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

											<option value="<?php echo e($project_lists->id); ?>"  <?php if($_GET['project'] == $project_lists->id): ?> selected    <?php endif; ?> ><?php echo e($project_lists->project_name); ?></option>

											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					

											<?php endif; ?>



										</select>

									</div>

								</div>

							</div>
							
							
							
														<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Expense Date

										<span class="text-danger"></span>

									</label>

									<div class="col-lg-8">

                                    <input type="date" name="expense_date"  class="form-control">
									</div>

								</div>

							</div>
							
																	<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Reimbursable  Date

										<span class="text-danger"></span>

									</label>

									<div class="col-lg-8">

                                    <input type="date" name="reimbursable_date"  class="form-control">
									</div>

								</div>

							</div>
							
																	<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Manager Approval Date

										<span class="text-danger"></span>

									</label>

									<div class="col-lg-8">

                                    <input type="date" name="manager_date"  class="form-control">
									</div>

								</div>

							</div>
							
																	<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Accountant Approval Date

										<span class="text-danger"></span>

									</label>

									<div class="col-lg-8">

                                    <input type="date" name="account_date"  class="form-control">
									</div>

								</div>

							</div>
							
							<div class="col-md-6">

								<div class="form-group row">

									<label for="empcode" class="col-lg-4 col-form-label">Status

										<span class="text-danger"></span>

									</label>

									<div class="col-lg-8">

        	<select class="form-control" id="status" name="status">
        	    <option value=""> Select option </option>
<option value="submitted"  <?php if(!empty($_GET['status'])): ?>  <?php if($_GET['status'] == 'submitted'): ?>  selected <?php endif; ?> <?php endif; ?>>Submitted</option>
<option value="reimbursed"   <?php if(!empty($_GET['status'])): ?> <?php if($_GET['status'] == 'reimbursed'): ?>  selected <?php endif; ?> <?php endif; ?>>Reimbursed</option>

<option value="approved"   <?php if(!empty($_GET['status'])): ?> <?php if($_GET['status'] == 'approved'): ?>  selected <?php endif; ?> <?php endif; ?>>Approved</option>

<option value="rejected"  <?php if(!empty($_GET['status'])): ?> <?php if($_GET['status'] == 'rejected'): ?>  selected <?php endif; ?> <?php endif; ?>>Rejected</option>

</select>
									</div>

								</div>

							</div>
							
							
							

						</div>

						<div class="row">

							<div class="col-sm-12 text-center">

								<button type="submit" class="btn btn-primary">Search</button>

							</div>

							


						</div>


					

					<hr>
<div class="col-sm-12 text-right p-0 mb-4">

<button type="submit" name="export" value="export" class="btn btn-primary">Export</button>

</div>
</form>
					<!-- <button class="btn btn-primary float-right">Reimburse</button> -->
<div class="col-sm-12 p-0 table-responsive">
					<table id="datatable" class="table table-bordered dt-responsive nowrap"

					style="border-collapse: collapse; border-spacing: 0; width: 100%;">

					<thead>

						<tr>

							<th>S.No</th>

						<!-- 	<th>

								<div class="custom-control custom-checkbox">

									<input class="custom-control-input checkall" type="checkbox" name="checkall" id="remember">

									<label class="custom-control-label" for="customControlInline remember">

									</label>

								</div>

							</th> -->

							<th>Employee </th>

								<th>Expense </th>

							<th>Project</th>
                            <th>Apply Date</th>
							<th>Expense Date</th>

							<th tooltip="Reimbursable Amount" data-toggle="tooltip">R.Amount</th>

							<th>Amount</th>

							<th class="text_ellipses"> Receipt</th>
							
								<th> Manager Approval Date</th>
									<th> Account Approval Date </th>
								<th> Reimbursable Date</th>

							<th>Status</th>

							<th>Action</th>

						</tr>

					</thead>

					<tbody>

                       <?php ($i = 1); ?>
                       <?php if(!empty($expense_approval_other)): ?>
                       <?php $__currentLoopData = $expense_approval_other; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>

							<td><?php echo e($i++); ?></td>

							<!-- <td>

								<div class="custom-control custom-checkbox">

									<input class="custom-control-input" type="checkbox" name="checkall" id="remember" value="<?php echo e($expense_lists->id); ?>">

									<label class="custom-control-label" for="customControlInline remember">

									</label>

								</div>

							</td> -->

							<td><?php echo e($expense_lists->userfullname); ?></td>

							<td>

								<?php echo e($expense_lists->expense_name); ?>


							</td>

							<td><?php echo e($expense_lists->project_name??''); ?></td>

							<td>

								<?php echo e(date('d-M-Y',strtotime($expense_lists->createddate))); ?>


							</td>

							<td>

								<?php echo e(date('d-M-Y',strtotime($expense_lists->expense_date))); ?>


							</td>

							<td>


							
								<?php echo e($expense_lists->reimbursed_ammount??''); ?>



							</td>

							<td><?php echo e($expense_lists->expense_amount??''); ?></td>

							<td>

								

								<?php if(!empty($expense_lists->reciept)): ?>

								<ul>

								<?php $__currentLoopData = $expense_lists->reciept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<li>

								<a download href="<?php echo e(URL::to('/public/uploads/expenses_receipts')); ?>/<?php echo e($files->receipt_filename??''); ?>"><?php echo e($files->receipt_name); ?></a>

							     </li>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</ul>

								<?php endif; ?>

                                

							</td>
							
								<td>
								     <?php if(!empty($expense_lists->approaval_date) && $expense_lists->approaval_status[0] != 'pending'): ?>
								    <?php echo e($expense_lists->approaval_date[0]??''); ?>

								    <?php endif; ?>
								    </td>
								
									<td>
									     <?php if(!empty($expense_lists->approaval_date) && $expense_lists->approaval_status[1] != 'pending'): ?>
									    <?php echo e($expense_lists->approaval_date[1]??''); ?>

									    <?php endif; ?>
									    
									    </td>
									
										<td><?php echo e($expense_lists->modifieddate??''); ?></td>

							<td>



	<?php echo e($expense_lists->status); ?>

								
						
 






							</td>

							<td>

								<a href="<?php echo e(URL::to('view_expenses')); ?>/<?php echo e($expense_lists->id); ?>"><i class="mdi mdi-eye font-blue"

									data-toggle="tooltip" title="Active"></i></a>

									<?php if($expense_lists->status =='saved'): ?>

									<a href="<?php echo e(URL::to('edit_expenses')); ?>/<?php echo e($expense_lists->id); ?>"><i class="mdi mdi-pen text-warning"

										data-toggle="tooltip"

										title="Edit"></i></a>

										<?php endif; ?>


                                         <?php if($expense_lists->status =='saved'): ?>
										<a onclick="return confirm('Are you sure you want to delete this?');" href="<?php echo e(URL::to('delete_expenses')); ?>/<?php echo e($expense_lists->id); ?>">       

											<i class="mdi mdi-delete text-danger" data-toggle="modal"

											data-target="#deletemp" title="Delete"></i>

										</a>

										<?php endif; ?>

									</td>

								</tr>



								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                       
                       
                       
                       
                       
                       

						<?php $__currentLoopData = $expense_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>

							<td><?php echo e($i++); ?></td>

							<!-- <td>

								<div class="custom-control custom-checkbox">

									<input class="custom-control-input" type="checkbox" name="checkall" id="remember" value="<?php echo e($expense_lists->id); ?>">

									<label class="custom-control-label" for="customControlInline remember">

									</label>

								</div>

							</td> -->

							<td><?php echo e($expense_lists->userfullname); ?></td>

							<td>

								<?php echo e($expense_lists->expense_name); ?>


							</td>

							<td><?php echo e($expense_lists->project_name??''); ?></td>

							<td>

								<?php echo e(date('d-M-Y',strtotime($expense_lists->createddate))); ?>


							</td>

							<td>

								<?php echo e(date('d-M-Y',strtotime($expense_lists->expense_date))); ?>


							</td>

							<td>

	<?php if($role ==1 || $role == 11): ?>

     <?php if(!empty($expense_lists->approaval_status) && ($expense_lists->approaval_status[1] =='approved')): ?>
							
	<span id="r_amount_<?php echo e($expense_lists->id); ?>"><?php echo e($expense_lists->reimbursed_ammount??''); ?></span>
                             

<i class="mdi mdi-pen text-warning" id="edit_icon_<?php echo e($expense_lists->id); ?>" onclick="show_input('<?php echo e($expense_lists->id); ?>')"  ></i>

	  
<span style="display:none" id="editText_<?php echo e($expense_lists->id); ?>">

	<input type="text" class="form-control inline-block" id="r_amt_<?php echo e($expense_lists->id); ?>" style="width: auto;">

	<i onclick="update_r_amt('<?php echo e($expense_lists->id); ?>')" class="btn btn-primary mdi mdi-check"></i>

	<i onclick="close_r_amt('<?php echo e($expense_lists->id); ?>')" class="btn btn-danger mdi mdi-window-close"></i>

</span>

<?php else: ?>

<?php echo e($expense_lists->reimbursed_ammount??''); ?>


<?php endif; ?>

							
							<?php else: ?>
							
								<?php echo e($expense_lists->reimbursed_ammount??''); ?>






							



							<?php endif; ?>

	

							</td>

							<td><?php echo e($expense_lists->expense_amount??''); ?></td>

							<td class="text_ellipses">

								

								<?php if(!empty($expense_lists->reciept)): ?>

								<ul class="p-0">

								<?php $__currentLoopData = $expense_lists->reciept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<li>

								<a title="<?php echo e($files->receipt_name); ?>" data-toggle="tooltip" download href="<?php echo e(URL::to('/public/uploads/expenses_receipts')); ?>/<?php echo e($files->receipt_filename??''); ?>"><?php echo e($files->receipt_name); ?></a>

							     </li>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</ul>

								<?php endif; ?>

                                

							</td>
							
								<td>
								     <?php if(!empty($expense_lists->approaval_date)  && $expense_lists->approaval_status[0] != 'pending'): ?>
								    <?php echo e($expense_lists->approaval_date[0]??''); ?>

								    <?php endif; ?>
								    </td>
								
									<td>
									     <?php if(!empty($expense_lists->approaval_date) && $expense_lists->approaval_status[1] != 'pending'): ?>
									    <?php echo e($expense_lists->approaval_date[1]??''); ?>

									    <?php endif; ?>
									    
									    </td>
									
										<td><?php echo e($expense_lists->modifieddate??''); ?></td>

							<td>

							<?php if($role ==1 || $role == 11 ): ?>

							<?php if(!empty($expense_lists->approaval_status) && ($expense_lists->approaval_status[1] =='approved')): ?>
							
								<select class="form-control" id="status" onchange="update_status('<?php echo e($expense_lists->id); ?>',this.value)">

<option value="reimbursed"  <?php if($expense_lists->status == 'reimbursed'): ?>  selected <?php endif; ?>>Reimbursed</option>

<option value="approved"  <?php if($expense_lists->status == 'approved'): ?>  selected <?php endif; ?>>Approved</option>

<option value="rejected"  <?php if($expense_lists->status == 'rejected'): ?>  selected <?php endif; ?>>Rejected</option>

</select>

						<?php else: ?>

						<?php echo e($expense_lists->status); ?>




						<?php endif; ?>

						

							<?php else: ?>


	<?php echo e($expense_lists->status); ?>

								
						
 




							<?php endif; ?>


							</td>

							<td>

								<a href="<?php echo e(URL::to('view_expenses')); ?>/<?php echo e($expense_lists->id); ?>"><i class="mdi mdi-eye font-blue"

									data-toggle="tooltip" title="Active"></i></a>

									<?php if($expense_lists->status =='saved'): ?>

									<a href="<?php echo e(URL::to('edit_expenses')); ?>/<?php echo e($expense_lists->id); ?>"><i class="mdi mdi-pen text-warning"

										data-toggle="tooltip"

										title="Edit"></i></a>

										<?php endif; ?>


                                         <?php if($expense_lists->status =='saved'): ?>
										<a onclick="return confirm('Are you sure you want to delete this?');" href="<?php echo e(URL::to('delete_expenses')); ?>/<?php echo e($expense_lists->id); ?>">       

											<i class="mdi mdi-delete text-danger" data-toggle="modal"

											data-target="#deletemp" title="Delete"></i>

										</a>

										<?php endif; ?>

									</td>

								</tr>



								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</tbody>

						</table>
</div>
					</div>



				</div>

			</div>

			<!-- end col -->

		</div>

		<!-- end row -->

	</div>

	<!-- container-fluid -->

</div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('extra_js'); ?>



<script>$(function () {

	$("#form-horizontal").steps({

		headerTag: "h3",

		bodyTag: "fieldset",

		transitionEffect: "slide"

	});

});

// $(document).ready(function(){

//   $(".editable").on("click", function(){

//     alert("The paragraph was clicked.");

//   });

// });

function show_input(exp_id){



	var amt = $('#r_amount_'+exp_id).text();

	

    $('r_amt_'+exp_id).val(amt);

	$('#editText_'+exp_id).show();

	$('#r_amount_'+exp_id).hide();

	$('#edit_icon_'+exp_id).hide();



}



function close_r_amt(exp_id){



	$('#r_amount_'+exp_id).show();

	$('#editText_'+exp_id).hide();

      $('#edit_icon_'+exp_id).show();

}



function update_r_amt(expenses_id){







	var r_amount = $('#r_amt_'+expenses_id).val();



	var _token = "<?php echo e(csrf_token()); ?>";

	$.ajax({

		url: '/update_r_amt',

		type: "post",

		data: {"_token": _token,"expenses_id":expenses_id,"r_amount":r_amount},

		dataType: 'JSON',



		success: function (data) {



			if(data.status == 200){



				$('#editText_'+expenses_id).hide();

				$('#r_amount_'+expenses_id).show();

				$('#r_amount_'+expenses_id).text(r_amount);

                 $('#edit_icon_'+expenses_id).show();



				alertify.success(data.msg); 



			}else{

				alertify.success(data.msg); 

			}



		}

	});

}







function get_project(user_id){





	var _token = "<?php echo e(csrf_token()); ?>";

	$.ajax({

		url: '/get_user_project',

		type: "post",

		data: {"_token": _token,"user_id":user_id},

		dataType: 'JSON',



		success: function (data) {



			$('#project').html(data.project);



		}

	});



}



function update_status(exp_id,status){



	





	            if(status == 2){

					

                 $('#edit_icon_'+exp_id).hide();

				

                }else{

                 $('#edit_icon_'+exp_id).show();	

                }

              





	var _token = "<?php echo e(csrf_token()); ?>";
	
	 $('#loadingDiv').show();

	$.ajax({

		url: '/update_status_expeses',

		type: "post",

		data: {"_token": _token,"exp_id":exp_id,"status":status},

		dataType: 'JSON',



		success: function (data) {
		    
		     $('#loadingDiv').hide();



			if(data.status == 200){











				alertify.success(data.msg); 



			}else{

				alertify.success(data.msg); 

			}



		}

	});



}



</script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>