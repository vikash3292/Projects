<?php $__env->startSection('content'); ?>

<div class="content p-0">
	<div class="container-fluid">
		<div class="page-title-box">
			<div class="row align-items-center bredcrum-style">
				<div class="col-sm-6">
					<h4 class="page-title">Audit List</h4>
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="#">GRC</a></li>
						<li class="breadcrumb-item active"><a href="<?php echo e(URL::to('/audit')); ?>">Audit List</a>
						</li>
					</ol>
				</div>
				<div class="col-sm-6">
					<div class="float-right d-none d-md-block">
						<div class="dropdown">
							<a href="<?php echo e(URL::to('/add-audit')); ?>">
								<button
								class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
								type="button">
							Add New Audit</button>
						    </a>
					    </div>
				    </div>
			    </div>
		    </div>
	    </div>
	    <div class="row">
			<div class="col-12">
				<div class="card m-t-20">
					<div class="card-body">
						<div class="row">
							<div class="col-sm-12">
								<table id="datatable" class="table table-bordered dt-responsive nowrap"
					style="border-collapse: collapse; border-spacing: 0; width: 100%;">
									<thead>
										<tr>
											<th>S.No</th>
											<th>Audit Checklist</th>
											<th>Main Person Responsible</th>
											<th>Audit Status</th>
											<th>QMS Observations</th>
											<th>Compilance Status by HOD/Coordinator</th>
											<th>Management Remarks</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
                                       <?php ($i =1); ?>
										<?php $__currentLoopData = $audit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                       <tr>
											<td><?php echo e($i++); ?></td>
											<td><?php echo e($audits->check_list == 1?'Pending' : 'Complete'); ?></td>
											<td><?php echo e($audits->userfullname); ?></td>
											<td><?php echo e($audits->aduit_status == 1?'Pending':'Complete'); ?></td>
											<td><?php echo e($audits->qms); ?></td>
											<td><?php echo e($audits->mng_remark); ?></td>

									    <td><?php echo e($audits->compaine_status == 1?'Pending':'Complete'); ?></td>
											
											<td>
												<i class="mdi mdi-eye" data-toggle="tooltip" title="View" data-toggle="modal" data-target="#viewaudit"></i>
                                               
                                               <a href="<?php echo e(URL::to('edit-audit')); ?>/<?php echo e($audits->id); ?>">

                                                <i class="mdi mdi-pen text-warning" data-toggle="modal" data-target="#editaudit" title="Edit"></i></a>

                                                <a href="<?php echo e(URL::to('delete-audit')); ?>/<?php echo e($audits->id); ?>">
                                                <i class="mdi mdi-delete text-danger" data-toggle="modal" data-target="#deletemp" title="Delete"></i>

                                            </a>
                                            </td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>