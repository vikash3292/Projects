  <?php $__env->startSection('extra_css'); ?>
  <style>
table.requistion_table ul{
   list-style:unset;
}
.width30{
   width: 30%;
}
.width2{
   width:2%;
}
</style>
<?php $__env->stopSection(); ?>
    

   <?php $__env->startSection('content'); ?>

            

         <!-- Start content -->

         <div class="content p-0">

            <div class="container-fluid">

               <div class="page-title-box">

                  <div class="row align-items-center bredcrum-style">

                     <div class="col-sm-6 col-6">

                        <h3 class="page-title">Requisition New Request</h3>

                        <ol class="breadcrumb">

                           <li class="breadcrumb-item"><a href="index.html">GRC</a></li>

                           <li class="breadcrumb-item active"><a href="new_request.html">Requisition New Request</a>

                           </li>

                        </ol>

                     </div>

                  </div>

               </div>

               <!-- end row -->

               <div class="row">

                  <div class="col-12">

                     <div class="card m-t-20">

                        <div class="card-body">

                       <!--     <div class="row">

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="empcode" class="col-lg-4 col-form-label">Requisition for

                                       Position/Designation</label>

                                    <div class="col-lg-8">

                                       <input id="designation" maxlength="60" type="text" class="form-control">

                                       <div id="designation_error"></div>

                                    </div>

                                 </div>

                              </div>

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="empid" class="col-lg-4 col-form-label">Department</label>

                                    <div class="col-lg-8">

                                       <input id="department" maxlength="60" type="text" class="form-control">

                                        <div id="department_error"></div>

                                    </div>

                                 </div>

                              </div>

                           </div>

                           <div class="row">

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="prifix" class="col-lg-4 col-form-label">Date of Requisition</label>

                                    <div class="col-lg-8">

                                       <input id="requistion" type="date" class="form-control">

                                        <div id="requistion_error"></div>

                                    </div>

                                 </div>

                              </div>

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="firstname" class="col-lg-4 col-form-label">Sanctioned Post "Experienced

                                       OR Fresher"</label>

                                    <div class="col-lg-8">

                                       <select class="form-control" id="sanction">

                                      <option>Select option</option>

                                          <option>Experienced</option>

                                          <option>Fresher</option>

                                       </select>

                                          <div id="sanction_error"></div>

                                    </div>

                                 </div>

                              </div>

                           </div>

                           <div class="row">

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="role" class="col-lg-4 col-form-label">Required Experience</label>

                                    <div class="col-lg-8">

                                       <input id="exp" type="text" maxlength="10" class="form-control">

                                        <div id="exp_error"></div>

                                    </div>

                                 </div>

                              </div>

                           </div> -->
                      <!--      <div class="row m-t-20">

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="cid" class="col-lg-4 col-form-label">Deadline By HR</label>

                                    <div class="col-lg-8">

                                       <input id="deadline" type="date" class="form-control">

                                        <div id="deadline_error"></div>

                                    </div>

                                 </div>

                              </div>

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="empcat" class="col-lg-4 col-form-label">Actual Date of Closure</label>

                                    <div class="col-lg-8">

                                      <input id="actualdate" type="date" class="form-control">

                                        <div id="actualdate_error"></div>

                                    </div>

                                 </div>

                              </div>

                           </div>

                           <div class="row">

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="crdno" class="col-lg-4 col-form-label">Remarks by Recruiter</label>

                                    <div class="col-lg-8">

                                       <input id="remark" type="text" maxlength="500" class="form-control">

                                       <div id="remark_error"></div>

                                    </div>

                                 </div>

                              </div>

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="busunit" class="col-lg-4 col-form-label">Remarks by Director</label>

                                    <div class="col-lg-8">

                                     <textarea id="remark_director" class="form-control" maxlength="500"></textarea>

                                    </div>

                                 </div>

                              </div>

                           </div>

                           <div class="row">

                              <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="dep" class="col-lg-4 col-form-label">Remark By MS[Management

                                       Secretariat]</label>

                                    <div class="col-lg-8">

                                       <textarea id="remark_management" maxlength="500" class="form-control"></textarea>

                                    </div>

                                 </div>

                              </div>

                           </div>

                            <div class="col-md-6">

                                 <div class="form-group row">

                                    <label for="firstname" class="col-lg-4 col-form-label">Status</label>

                                    <div class="col-lg-8">

                                       <select class="form-control" id="status">

                                      <option>Select option</option>

                                          <option value="1">Active</option>

                                          <option value="1">inActive</option>

                                       </select>

                                          <div id="status_error"></div>

                                    </div>

                                 </div>

                              </div> -->

                         <!--   <div class="col-sm-12">

                              <button id="addreqruitment" class="btn btn-primary float-right">Save</button>

                           </div> -->
                              <div class="col-sm-12">
                                 <table border="0" width="100%">
                                    <tr>
                                       <td class="padding-5 width30"><strong>Number Of Position</strong></td>  
                                       <td class="padding-5 text-center width2">:</td>
                                       <td class="text-center padding-5"><input type="number" class="form-control m-0"></td>
                                    </tr>
                                    <tr>
                                       <td class="padding-5 width30"><strong>Job Title</strong></td>
                                       <td class="padding-5 text-center width2">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                    </tr>
                                    <tr>
                                       <td class="padding-5 width30"><strong>Department</strong></td>
                                       <td class="padding-5 text-center width2">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                    </tr>
                                 </table>
                              </div>
                                <div class="col-sm-12 m-t-20">
                                 <table border="0" width="100%" class="requistion_table">
                                    <tr class="bg-primary">
                                       <td class="padding-5" colspan="2"><strong>KRA's</strong></td>  
                                    </tr>
                                    <tr>
                                       <td class="padding-5 width30">Role Objective</td>
                                       <td class="padding-5">
                                          <input type="text" class="form-control m-0">
                                       </td>
                                    </tr>
                                    <tr>
                                       <td class="padding-5 width30">Responsibilities</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                    </tr>
                                 </table>
                              </div>
                                <div class="col-sm-12 m-t-20">
                                 <table border="0" width="100%" class="requistion_table">
                                    <tr class="bg-primary">
                                       <td class="padding-5" colspan="2"><strong>Key Skill/Abilities</strong></td>  
                                    </tr>
                                    <tr>
                                       <td class="padding-5 width30">Skills</td>
                                       <td class="padding-5">
                                          <input type="text" class="form-control m-0">
                                       </td>
                                    </tr>
                                    <tr>
                                       <td class="padding-5 width30">Experience</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                    </tr>
                                 </table>
                              </div>
                              <div class="col-sm-12 m-t-20">
                                 <table border="0" width="100%" class="requistion_table">
                                    <tr class="bg-primary">
                                       <td class="padding-5 width30" colspan="2"><strong>Experience Required</strong></td>  
                                    </tr>
                                    <tr>
                                       <td class="padding-5">&nbsp;</td>
                                       <td class="padding-5">&nbsp;</td>
                                    </tr>
                                     <tr>
                                       <td class="padding-5">&nbsp;</td>
                                       <td class="padding-5">&nbsp;</td>
                                    </tr>
                                 </table>
                              </div>
                                <div class="col-sm-12 m-t-20">
                                 <table border="0" width="100%" class="requistion_table">
                                    <tr class="bg-primary">
                                       <td class="padding-5" colspan="6"><strong>Other Details</strong></td>  
                                    </tr>
                                    <tr>
                                       <td class="padding-5 width30"><strong>Qualification</strong></td>
                                       <td class="padding-5 width2 text-center">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                       <td class="padding-5"><strong>Gender</strong></td>
                                       <td class="padding-5 width2 text-center">:</td>
                                       <td class="padding-5">
                                          <select class="form-control m-0">
                                             <option>Male</option> 
                                             <option>Female</option>  
                                          </select>
                                    </td>
                                    </tr>
                                      <tr>
                                       <td class="padding-5 width30"><strong>Job Location</strong></td>
                                       <td class="padding-5 width2 text-center">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                       <td class="padding-5"><strong>Reporting To</strong></td>
                                       <td class="width2 text-center">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                    </tr>
                                      <tr>
                                       <td class="padding-5 width30"><strong>Interviewers</strong></td>
                                       <td class="padding-5 width2 text-center">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                       <td class="padding-5"><strong>Tentative DOJ</strong></td>
                                       <td class="text-center width2">:</td>
                                       <td class="padding-5"><input type="date" class="form-control m-0"></td>
                                    </tr>
                                 </table>
                              </div>
                                   <div class="col-sm-12 m-t-20">
                                 <table border="0" width="100%" class="requistion_table">
                                    <tr>
                                       <td class="padding-5 width30"><strong>Proposed Salary</strong></td>
                                       <td class="padding-5 width2 text-center">:</td>
                                       <td class="padding-5"><input type="number" class="form-control m-0"></td>
                                       <td class="padding-5 width30">&nbsp;</td>
                                       <td class="padding-5 width2">&nbsp;</td>
                                       <td class="padding-5">&nbsp;</td>
                                    </tr>
                                      <tr>
                                       <td class="padding-5 width30"><strong>Requested By</strong></td>
                                       <td class="width2 text-center padding-5">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                       <td class="padding-5"><strong>Signature</strong></td>
                                       <td class="width2 text-center">:</td>
                                       <td class="padding-5"><input type="text" class="form-control m-0"></td>
                                    </tr>
                                 </table>
                              </div>
                        </div>

                     </div>

                  </div>

                  <!-- end col -->

               </div>

               <!-- end row -->

            </div>

            <!-- container-fluid -->

         </div>

           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>