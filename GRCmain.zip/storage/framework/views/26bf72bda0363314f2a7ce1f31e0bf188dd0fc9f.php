    
   <?php $__env->startSection('content'); ?>
                 <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h3 class="page-title">Lead View</h3>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                           <li class="breadcrumb-item active"><a href="lead_view.html">Lead View</a></li>
                        </ol>
                     </div>
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <div class="width-float">
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="empcode" class="col-lg-4 col-form-label">Lead Owner</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->owner); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="empid" class="col-lg-4 col-form-label">Phone</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->phone); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="prifix" class="col-lg-4 col-form-label">Mobile</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->mobile); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="firstname" class="col-lg-4 col-form-label">Salutation</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->prefix); ?>.</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">First Name</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->fname); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Last Name</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->lname); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="cid" class="col-lg-4 col-form-label">Company</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->company); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="mode" class="col-lg-4 col-form-label">Fax</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->fax); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Title</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->title); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Email</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->email); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Lead Source</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->sourse); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Website</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->website); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Industry</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->industry); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Lead Status</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->lead_status); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Annual Revenue</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->annual_revenue); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Rating</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">
                                             <?php for($i = 0; $i < $lead->rating; $i++): ?>
                                             <i class="fa fa-star font-green"></i>
                                             <?php endfor; ?>
                                          </label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">No of
                                          Employees</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->no_of_emp); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Product Interest</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->product_interest); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Project Type</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->product_type); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Estimated
                                          Order Value</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->order_val); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12">
                                    <div class="col-sm-12">
                                       <h5 class="font-18">Proposed Site Address</h5>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Country</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->country); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">State</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->state); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">City</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->city); ?></label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Street</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->street); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Zip Code</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"><?php echo e($lead->zipcode); ?></label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
         <!-- content -->
           <?php $__env->stopSection(); ?>

           <?php $__env->startSection('extra_js'); ?>



           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>