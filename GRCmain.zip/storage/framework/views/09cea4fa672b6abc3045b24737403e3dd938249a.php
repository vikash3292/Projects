 
   <?php $__env->startSection('content'); ?>
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6 col-6">
                                <h4 class="page-title">All Employees</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="employees.html">All Employees</a></li>
                                </ol>
                            </div>
                              
                            <div class="col-sm-6 col-6 state_dist">
                                        <?php if(PermissionHelper::frontendPermission('add-users')): ?>
                                        <a href="<?php echo e(URL::to('/add-employees')); ?>">
                                           <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                            type="button">
                                            Add New Employee</button>
                                    </a>

                                       <?php endif; ?>
                                        <button class="btn btn-primary advance_setting">Import User <i class="fa fa-angle-right"></i></button>

                                <form method="post" class="state_dist_wrapper" action="<?php echo e(URL::to('uploadusercsv')); ?>" enctype='multipart/form-data'>

                                       

                                        <div class="">

                                            <div class="close_popup">

                                                <img src="../public/assets/images/close_icon.png" alt="" title="">

                                            </div>

                                            <div class="row">

                                                <div class="col-xs-12 col-sm-12">

                                                    <div class="form-group">

                                                      <input type="file" required="" name="upload_users"  class="form-control" style="padding:3px;"  />

                                                       <?php echo e(csrf_field()); ?>


                                                    </div>

                                                </div>

                                                <div class="col-xs-12 col-sm-12">

                                                    <div class="form-group">

                                                      <input type="submit" name="upload" value="Upload" class="btn btn-primary float-right">

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </form>
                              <?php if(PermissionHelper::frontendPermission('import-user-csv')): ?>
                                    
                                     <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->

                       

                    <div class="row">
                            <div class="col-12">
                                 <?php if(Session::has('message')): ?>
                     <p class="alert alert-primary"><?php echo e(Session::get('message')); ?></p>
                              <?php endif; ?>
                                <div class="card m-t-20">
                                    <div class="card-body">
                                        <div class="table-responsive mb-0" data-pattern="priority-columns">
                                    <table id="datatable" class="table appraisal_form_fill">
                                       <thead>
                                       <tr>          <th>S.No</th>
                                                    <th>Name</th>
                                                    <th>Employee ID</th>
                                                    <th>Contact No.</th>
                                                    <th>Email ID</th>
                                                    <th>Department</th>
                                                    <th>Date of Joining</th>
                                                    <th>Action</th>
                                                </tr>
                                       </thead>
                                       <tbody>
                                       <tr >  
                                              <?php ($i = 1); ?>
                                                    <?php $__currentLoopData = $listData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <td><?php echo e($i++); ?>

                                                        
                                                    </td>
                                                    <td><?php echo e($result->userfullname); ?>

                                                        
                                                    </td>
                                                    <td><?php echo e($result->employeeId); ?></td>
                                                    <td><?php echo e($result->workphone); ?></td>
                                                    <td>
                                                        <?php echo e($result->emailaddress); ?>

                                                    </td>
                                                    <td><?php echo e($result->deptname); ?></td>
                                                   

                                                    <td><?php echo e(date('d-m-Y',strtotime($result->usercreateddate))); ?></td>
                                                    <td>

                                                          <?php if(PermissionHelper::frontendPermission('view-users')): ?>
                                                        <a href="<?php echo e(url('/edit/myprofile')); ?>/<?php echo e($result->id); ?>"><i class="mdi mdi-eye" data-toggle="tooltip" title="View"></i></a>
                                                          <?php endif; ?>


                                                          <?php if(PermissionHelper::frontendPermission('edit-users')): ?>
                                                           <a href="<?php echo e(URL::to('emp/edit')); ?>/<?php echo e($result->id); ?>">
                                                        <i class="mdi mdi-pen text-warning" data-toggle="modal" data-target="#editemp" title="Edit"></i></a>
                                                          <?php endif; ?>

                                                          <?php if(PermissionHelper::frontendPermission('delete-users')): ?>
                                                        <a onclick="return confirm('Are you sure you want to delete?');" href="<?php echo e(URL::to('delete/')); ?>/<?php echo e($result->id); ?>">
                                                        <i class="mdi mdi-delete text-danger" data-toggle="modal" data-target="#deletemp" title="Delete"></i></a>

                                                        <?php endif; ?>

                                                         <?php if(PermissionHelper::frontendPermission('status-users')): ?>

                                                        <div class="togglebutton custom-control custom-switch inline-block" <?php if($result->isactive ==1): ?> title="Active" <?php else: ?> title="InActive" <?php endif; ?> >
                                                        <input type="checkbox" onclick="changestatus('<?php echo e($result->isactive); ?>','<?php echo e($result->id); ?>','main_users')" <?php if($result->isactive ==1): ?> checked <?php else: ?> notchecked <?php endif; ?> class="custom-control-input"
                                                            id="customSwitches<?php echo e($result->id); ?>">
                                                        <label class="custom-control-label" for="customSwitches<?php echo e($result->id); ?>">
                                                        </label>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                                               <?php if(count($listData) == 0): ?>

                                               <td colspan="8">No Record Found</td>

                                               <?php endif; ?>
                                       </tbody>
                                    </table>
                                 </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end col -->
                        </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>