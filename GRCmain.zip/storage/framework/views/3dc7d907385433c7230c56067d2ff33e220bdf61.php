



                                         <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-12">
                                        <div class="card one_to_form m-t-10">

                                           <div class="card-body">

                                               <div class="row">
                                               <div class="col-sm-12">

                                               <?php if($forms->type ==1): ?>
                                               Job

                                               <?php elseif($forms->type ==2): ?>

                                               Customer / Client

                                               <?php elseif($forms->type ==3): ?>

                                               Communication

                                               <?php elseif($forms->type ==4): ?>

                                               Interpersonal

                                               <?php endif; ?>

                                               <div>

                                               <div class="col-sm-12">

                                               <?php echo e($forms->desc); ?>


                                               <div>

                                               <div class="col-sm-12">

                                                   <p><?php echo e($forms->question); ?>


                                                     <?php if($forms->required =='on'): ?>

                                                   	<span class="text-danger p-l-5">*</span>

                                                   	<?php endif; ?>

                                                    <a href="<?php echo e(URL::to('edit-question')); ?>/<?php echo e($forms->id); ?>" ><i class="mdi mdi-pencil text-warning float-right cursorpointer" ></i></a>

                                                   

                                                   </p>

                                               </div>



                                               <?php if($forms->category == 1): ?>



                                                      <div class="col-sm-12">



                                                      	 <input type="text"  class="form-control"  >

                                                   

                                                                    

                                                                </div>





                                               <?php elseif($forms->category == 2): ?>



                                                 <div class="col-sm-12">

                                                       <ul class="p-0 mb-0">

                                                       	<?php $__currentLoopData = json_decode($forms->ans); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                           <li>

                                                            <input type="radio" id="male"  value="<?php echo e($option); ?>" >

                                                            <label for="male"><?php echo e($option); ?></label>

                                                           </li>

                                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                          <!--  <li>

                                                            <input type="radio" id="female" name="answer[]" value="female">

                                                            <label for="male">Female</label>

                                                           </li>

                                                           <li>

                                                            <input type="radio" id="other" name="answer[]" value="other">

                                                            <label for="male">Other</label>

                                                           </li> -->

                                                       </ul>

                                                    </div>



                                               <?php elseif($forms->category == 3): ?>



                                                <div class="col-sm-12">

                                                                    <select class="form-control"  >

                                                                    <option value>Select option</option>

                                                                    	<?php $__currentLoopData = json_decode($forms->ans); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <option><?php echo e($option); ?></option>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                        

                                                                    </select>

                                                                </div>



                                               <?php elseif($forms->category == 4): ?>



                                                <div class="col-sm-12">

                                                  <ul class="p-0 m-b-0">

                                                  	<?php $__currentLoopData = json_decode($forms->ans); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                      <li>

                                                        <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" value="<?php echo e($option); ?>"  id="customControlInline">

                                                             <label class="custom-control-label" for="customControlInline"><?php echo e($option); ?></label>

                                                        </div>

                                                      </li>

                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                     <!--  <li>

                                                        <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">

                                                             <label class="custom-control-label" for="customControlInline">Option 2</label>

                                                        </div>

                                                      </li>

                                                      <li> -->

                                                       <!--  <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">

                                                             <label class="custom-control-label" for="customControlInline">Option 3</label>

                                                        </div>

                                                      </li> -->

                                                  </ul>

                                               </div>



                                               <?php endif; ?>







                                              





                                               </div>

                                               </div>

                                               </div>
</div>


                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


