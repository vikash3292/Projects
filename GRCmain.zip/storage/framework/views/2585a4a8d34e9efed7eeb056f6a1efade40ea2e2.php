   <?php $__env->startSection('content'); ?>
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h3 class="page-title">Apply Leave</h3>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="employees.html">Apply Leave</a></li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <form method="post" id="myleave">
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div class="row align-items-center justify-content-center m-b-20">
                                        <div class="col-4 justify-div">
                                            <div class="form-group row m-0">
                                                <label for="empcode" class="col-lg-4 col-form-label p-l-0">Leave
                                                    Type</label>
                                                <div class="col-lg-8 p-r-0">
                                                    <select class="form-control" name="leavemode" id="leavemode">
                                                        <option>Casual Leave</option>
                                                        <option>Planned Leave</option>
                                                        <option>Restricted Leave</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div id="calendar"></div>
                                            <div style="clear:both"></div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="table-responsive">
                                                <table class="table mb-0 fixed_header" id="appendDate" name="appendDate">
                                                    <thead>
                                                        <tr>
                                                            <th>Date</th>
                                                            
                                                            <th>Leave Type</th>
                                                            <th>Leave Timing</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>

                                     <?php
                                    $user_id = Auth::guard('main_users')->user()->id;
                                     $totalleave = DB::table('total_leave_list')->where('user_id',$user_id)->first();                         
                                    ?>
                                    <div class="row m-t-20">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Leave Days</label>
                                                <div class="col-lg-8">
                                                    <input id="leavedays" name="leavedays" type="text" value="<?php echo e($totalleave->    used_leave??0); ?>" readonly
                                                        class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                     $manager = DB::table('main_users')->where('emprole',3)->get();

                                        ?>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Approving
                                                    Manager</label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="manager" name="manager" required>
                                                        <option value="">Select</option>
                                                        <?php $__currentLoopData = $manager; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $managers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($managers->id); ?>"><?php echo e($managers->userfullname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Available Leaves(In
                                                    Month)</label>
                                                <div class="col-lg-8">
                                                    <input id="leaveinmonth" value="<?php echo e($totalleave-> month_leave??0); ?>" name="leaveinmonth" type="text"  value="16.5" readonly
                                                        class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                         <?php
                                     $hr = DB::table('main_users')->where('emprole',4)->get();

                                        ?>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Approving
                                                    HR</label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="hr" name="hr" required>
                                                        <option value="">Select</option>
                                                        <?php $__currentLoopData = $hr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($hrs->id); ?>"><?php echo e($hrs->userfullname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Total Available
                                                    Leave(In Year)</label>
                                                <div class="col-lg-8">
                                                    <input id="leaveinyear" value="<?php echo e($totalleave->total_year_leave??0); ?>" name="leaveinyear" type="text" value="18" readonly
                                                        class="form-control">
                                                </div>
                                            </div>
                                        </div>


                                         <?php
                                     $admin = DB::table('main_users')->where('emprole',7)->get();

                                        ?>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label" required="">Approving
                                                    Admin</label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="admin" name="admin" required>
                                                        <option value="">Select</option>
                                                       <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($admins->id); ?>"><?php echo e($admins->userfullname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                               
                                     $commnet = DB::table('main_commnet_list')->where('status',1)->get();                         
                                    ?>
                                    <div class="row">
                                            <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Unpaid Leave</label>
                                                <div class="col-lg-8">
                                                <input id="Unpaid" value="<?php echo e($totalleave->unpaid_leave??0); ?>" name="Unpaid" type="text" readonly
                                                        class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                         <?php
                                     $Director = DB::table('main_users')->where('emprole',1)->get();

                                        ?>
                                         <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Approving
                                                Director</label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" disabled="" required id="Director" name="Director" required="">
                                                        <option value="">Select</option>
                                                        <?php $__currentLoopData = $Director; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Directors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($Directors->id); ?>"><?php echo e($Directors->userfullname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                 
                                        </div>
                                        <div class="row">
                                          <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">Comment By
                                                    Applicant</label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" id="select_commnet" name="select_commnet" required="">
                                                        <option value="">Select</option>
                                                        <?php $__currentLoopData = $commnet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commnets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option><?php echo e($commnets->commnet); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                        <option>Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                             <div class="col-md-6" id="commnettext">
                                           
                                        </div>
                                    </div>

                                        <div class="col-md-12">
                                            <button class="btn btn-primary float-right">Apply</button>
                                        </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    </form>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->

          
         <?php $__env->stopSection(); ?>

         <?php $__env->startSection('extra_js'); ?>

<script type="text/javascript">

         
  var count = 1;
  var leavecount = 1;
  $(document).on('click', '.fc-day-number', function () {
    var a = $(this).attr("data-date");
    if(a){

 var _token = "<?php echo e(csrf_token()); ?>";

$.ajax({
 url: '/checkdate',
 type: "post",
 data: {"_token": _token,"selectedDate":a},
 dataType: 'JSON',
  
 success: function (data) {
   console.log(data);

   if(data.status ==200){

    countval = count++;
    var leavecount1 = leavecount++;

    //    var leaveDate = new Array();
    //       $("input[name^='leaveDate']").each(function() {
    //           leaveDate.push($(this).val());
    //       });

    //       console.log(leaveDate);

    // for (var i=0; i < leaveDate.length; i++) {
    //     if (leaveDate[i] === $(this).attr("data-date")) {
    //        alert('Aleady Added Date');
    //        return false;
    //     }
    // }

    var leavetype = '<select name="leavetype" data-count="' + leavecount1 + '" class="form-control leavecalcute" required><option value="">Select</option><option value="0.5">Half Day</option><option value="1.0">Full Day</option> <option value="1.0">Comp Off</option></select> ';
    var leavetime = '<select id="leavetime' + leavecount1 + '" name="leavetime" class="form-control" required><option value="">Select</option><option>First Half</option><option>Second Half</option></select>';
    var action = '<i data-del="' + leavecount1 + '" class="mdi mdi-close text-danger delete-row"></i>';
    var appendDate = "<tr><td><input type='hidden' id='leave_" + (countval) + "' name='leaveDate'/>" + a + "</td><td>" + leavetype + "</td><td>" + leavetime + "</td><td class='text-center'>" + action + "</td></tr>"

    $("table#appendDate tbody").append(appendDate);

    $('#leave_' + countval).val(a);
    if (countval > 3) {
        var result = confirm("Are You Sure Take Leave More then 3 Take Permission to Director");
        if (result) {
            $('#Director').removeAttr('disabled');
        }
     
    }

     
   }else{

    alert(data.msg);

   }
   
 }
});

    }
   
  });


  // end get time from calender and append in table


  // delete row of table
  $("table#appendDate tbody").on("click", ".delete-row", function () {
    var del = $(this).data('del');

    if (del > 4) {

      $('#Director').removeAttr('disabled');

    } else {

      $('#Director').attr('disabled', 'disabled');

    }
    $(this).parent().parent().remove();
  });
  // end delete row of table


         </script>

         <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>