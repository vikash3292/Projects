    
   <?php $__env->startSection('content'); ?>
                   
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Recruitment Tracker</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Leave</a></li>
                                    <li class="breadcrumb-item active"><a href="leaveapprove.html">Recruitment
                                            Tracker</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                     <?php if(PermissionHelper::frontendPermission('add-recruitment')): ?>
                                    <a href="<?php echo e(URL::to('/addnewrequest')); ?>" class="btn btn-primary float-right">New Request</a>
                                    <?php endif; ?>
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap text-center"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>
                                                    Designation
                                                </th>
                                                <th>Department</th>
                                                <th>Date of Requisition</th>
                                                <th>Sanctioned Post</th>
                                                <th>Requisition Given By</th>
                                                <!-- <th>Deadline by Requisitioner (If any)</th> -->
                                                <!-- <th>Deadline By HR</th> -->
                                                <th>Action</th>
                                                <!-- <th>HR Recruiter Assigned</th>
                                                <th>Required Experience</th>
                                                <th>Actual Date of Closure</th>
                                                <th>Remarks by Recruiter</th>
                                                <th>Remarks by Director</th>
                                                <th>Remark By MS[Management
                                                    Secretariat]</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php ($i= 1); ?>
                                          <?php $__currentLoopData = $reqruiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reqruiments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>

                                                <td>
                                                   <?php echo e($reqruiments->designation); ?>

                                                </td>
                                                <td> <?php echo e($reqruiments->department); ?></td>
                                                <td><?php echo e($reqruiments->requisition_date); ?></td>
                                                <td><?php echo e($reqruiments->experience); ?></td>
                                                <td><?php echo e($reqruiments->userfullname); ?></td>
                                                <td>
                                                <?php if(PermissionHelper::frontendPermission('view-recruitment')): ?>
                                                    <i class="fa fa-eye font-blue m-r-5" title="View"
                                                        data-toggle="modal" data-target="#recruitmentview<?php echo e($reqruiments->id); ?>"></i>
                                                        <?php endif; ?>
                                                </td>
                                            </tr>


                                                            <div id="recruitmentview<?php echo e($reqruiments->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Recruitment Tracker View</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body p-0">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Requisition for
                                            Position/Designation</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"> <?php echo e($reqruiments->designation); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empid" class="col-lg-8 col-form-label">Department</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($reqruiments->department); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Date of Requisition</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($reqruiments->requisition_date); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Sanctioned Post
                                            "Experienced OR Fresher"</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($reqruiments->sanctioned); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Requisition Given
                                            By</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($reqruiments->userfullname); ?></label>
                                        </div>
                                    </div>
                                </div>
                              <!--   <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Deadline by Requisitioner
                                            (If any)</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label">No</label>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Deadline By HR</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label"><?php echo e($reqruiments->deadline_date); ?></label>
                                        </div>
                                    </div>
                                </div>
                          <!--       <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">HR Recruiter
                                            Assigned</label>
                                        <div class="col-lg-4 col-form-label">
                                            <label class="myprofile_label">Dummy</label>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Required Experience</label>
                                        <div class="col-lg-4 col-form-label p-l-4">
                                            <label class="myprofile_label">
                                                <?php echo e($reqruiments->experience); ?> yr
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-4 col-form-label">Actual Date of
                                            Closure</label>
                                        <div class="col-lg-8 col-form-label p-l-4">
                                            <label class="myprofile_label">
                                               <?php echo e($reqruiments->actual_date); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Remarks by
                                            Recruiter</label>
                                        <div class="col-lg-4 col-form-label p-l-4">
                                            <label class="myprofile_label">
                                                 <?php echo e($reqruiments->remark); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Remarks by Director</label>
                                        <div class="col-lg-4 col-form-label p-l-4">
                                            <label class="myprofile_label">
                                                  <?php echo e($reqruiments->remark_director); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Remark By MS[Management
                                            Secretariat]</label>
                                        <div class="col-lg-4 col-form-label p-l-4">
                                            <label class="myprofile_label">
                                                 <?php echo e($reqruiments->remark_mang); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                                   <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row m-0">
                                        <label for="empcode" class="col-lg-8 col-form-label">Status</label>
                                        <div class="col-lg-4 col-form-label p-l-4">
                                            <label class="myprofile_label">
                                                 <?php if($reqruiments->status ==1): ?>

                                                 <div style="color:green">Active</div>

                                                 <?php else: ?>

                                                  <div style="color:red">InActive</div>

                                                 <?php endif; ?>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary waves-effect" data-dismiss="modal">Back</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <!--   <tr>
                                                <td>2</td>

                                                <td>
                                                    Sales Force Developer
                                                </td>
                                                <td>IT</td>
                                                <td>13/12/2019</td>
                                                <td>Fresher</td>
                                                <td>Avni</td>
                                                <td>
                                                    <i class="fa fa-eye font-blue m-r-5" title="View"
                                                        data-toggle="modal" data-target="#recruitmentview"></i>
                                                </td>
                                            </tr> -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->


   
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>