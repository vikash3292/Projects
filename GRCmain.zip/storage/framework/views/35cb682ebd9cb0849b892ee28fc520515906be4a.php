
   <!-- Begin page -->
   <div id="wrapper">
      <!-- Top Bar Start -->
      <div class="topbar">
         <!-- LOGO -->
         <div class="topbar-left">
            <a href="index.html" class="logo">
               <span>
                  <img src="assets/images/logo.png" alt="" height="55">
               </span>
               <i><img src="assets/images/logo.png" alt="" height="40"></i>
            </a>
         </div>
         <nav class="navbar-custom">
            <div class="width-float">
               <ul class="navbar-right list-inline float-right mb-0">
                  <!-- notification -->
                  <li class="dropdown notification-list list-inline-item">
                     <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#"
                        role="button" aria-haspopup="false" aria-expanded="false"><i class="mdi mdi-bell noti-icon"></i>
                        <span class="badge badge-pill badge-danger noti-icon-badge">0</span></a>
                     <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg">
                        <!-- item-->
                        <h6 class="dropdown-item-text">Notifications (0)</h6>
                        <div class="slimscroll notification-item-list">

                        </div>
                        <!-- All-->
                        <!-- <a href="javascript:void(0);" class="dropdown-item text-center text-primary">View all <i class="fi-arrow-right"></i></a> -->
                     </div>
                  </li>
                  <li class="dropdown notification-list list-inline-item">
                     <a href="#" class="nav-link dropdown-toggle arrow-none waves-effect text-right" style="position: relative;
                     top: -5px;">
                        <p class="m-0">Nisha Upreti</p>
                        <p class="m-0">Admin</p>
                     </a>
                  </li>
                  <li class="dropdown notification-list list-inline-item">
                     <div class="dropdown notification-list nav-pro-img">
                        <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user" data-toggle="dropdown"
                           href="#" role="button" aria-haspopup="false" aria-expanded="false"><img
                              src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle"></a>
                        <div class="dropdown-menu dropdown-menu-right profile-dropdown">
						
					           	<?php 
                              

                             if(Auth::guard('main_users')->check()){

                             $id =  Auth::guard('main_users')->user()->id;
                              $name =  Auth::guard('main_users')->user()->userfullname;
                             
                             }else{

                              $id = '';
                               $profileimg = URL::to('assets/images/profile.png');

                             }

                           
										
						           	?>
                           <a class="dropdown-item" href="<?php echo e(url('/emp/edit/'.$id.'?profile='.$name)); ?>"><i class="mdi mdi-account-circle m-r-5"></i>Profile</a>
                           <div class="dropdown-divider"></div>
                           
                           <a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();"><i
                                 class="mdi mdi-power text-danger"></i></i>
                            <?php echo e(__('Logout')); ?>

                           </a>

                        <form id="logout-forma" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        </div>
                     </div>
                  </li>
               </ul>
               <span class="grcerp">GRC ERP</span>
               <ul class="list-inline menu-left mb-0">
                  <li class="float-left"><button class="button-menu-mobile open-left waves-effect"><i
                           class="mdi mdi-menu"></i></button></li>

               </ul>
            </div>
            <!-- <div class="width-float sub-menu b-t" id="topbar-menu">
               <ul class="navbar-left list-inline float-left mb-0 m-l-20">
               
                  <li class="dropdown notification-list list-inline-item mm-active">
                     <a>HR</a>
                  </li>
                  <li class="dropdown notification-list list-inline-item">
                     <a>BD</a>
                  </li>
                  <li class="dropdown notification-list list-inline-item">
                     <a>PM</a>
                  </li>
                  <li class="dropdown notification-list list-inline-item">
                     <a>Account</a>
                  </li>
                  <li class="dropdown notification-list list-inline-item">
                     <a>TT</a>
                  </li>
                  <li class="dropdown notification-list list-inline-item">
                     <a>Quality</a>
                  </li>
               </ul>
            </div> -->
         </nav>
      </div>