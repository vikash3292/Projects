    
   <?php $__env->startSection('content'); ?>
       
         <!-- Start content -->
         <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h4 class="page-title">Vacancy List</h4>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                           <li class="breadcrumb-item active"><a href="vacancy_list.html">Vacancy List</a></li>
                        </ol>
                     </div>
                  </div>
               </div>
               <!-- end row -->
               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body">
                             <?php if(PermissionHelper::frontendPermission('add-new-vacancy')): ?>
                 
                           <button class="btn btn-primary float-right" data-toggle="modal"
                              data-target="#add_vacancy">Add New Vacancy</button>
                              <?php endif; ?>
                           <table id="datatable" class="table table-bordered dt-responsive nowrap"
                              style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                              <thead>
                                 <tr>
                                    <th>S.No</th>
                                    <th>Position/Designation</th>
                                    <th>Department</th>
                                    <th>Sanctioned Post</th>
                                    <th>Year of Experience</th>
                                    <th>Deadline By HR</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <?php ($i = 1); ?>
                                 <?php $__currentLoopData = $hiring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hirings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td>
                                       <?php echo e($hirings->designation); ?>

                                    </td>
                                    <td> <?php echo e($hirings->department); ?></td>
                                    <td><?php echo e($hirings->sanctioned_post); ?></td>
                                    <td><?php echo e($hirings->exp); ?></td>
                                    <td>
                                      <?php echo e($hirings->dead_line); ?>

                                    </td>
                                 </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
         <!-- content -->


      <div id="add_vacancy" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
      aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title mt-0" id="myModalLabel">Add New Vacancy</h5>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
               <div class="form-group row">
                  <label for="example-text-input" class="col-sm-4 col-form-label">Position/Designation</label>
                  <div class="col-sm-8">
                     <input class="form-control" id="designation" type="text" maxlength="60" id="example-text-input" require>
                  </div>
               </div>
               <div class="form-group row">
                  <label for="example-text-input" class="col-sm-4 col-form-label">Department</label>
                  <div class="col-sm-8">
                     <input class="form-control" id="department" type="text" maxlength="60" id="example-text-input" require>
                  </div>
               </div>
               <div class="form-group row">
                  <label for="example-text-input" class="col-sm-4 col-form-label">Sanctioned Post</label>
                  <div class="col-sm-8">
                     <input class="form-control" id="sancpost" type="text" id="example-text-input">
                  </div>
               </div>
               <div class="form-group row">
                  <label for="example-text-input" class="col-sm-4 col-form-label">Year of Experience</label>
                  <div class="col-sm-8">
                     <input class="form-control" id="exp" onkeypress="preventNonNumericalInput(event)" maxlength="10" type="text" id="example-text-input" require>
                  </div>
               </div>
               <div class="form-group row">
                  <label for="example-text-input" class="col-sm-4 col-form-label">Deadline By HR</label>
                  <div class="col-sm-8">
                     <input type="date" id="deadline" class="form-control" type="email" id="example-text-input" require>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button id="vacancyadd" type="button" class="btn btn-primary waves-effect">Save</button>
               <button type="button" class="btn btn-secondary waves-effect waves-light"
                  data-dismiss="modal">Cancel</button>
            </div>
         </div>
         <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
   </div>
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>