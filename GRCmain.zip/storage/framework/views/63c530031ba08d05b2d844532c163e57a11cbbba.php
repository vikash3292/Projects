   <?php $__env->startSection('content'); ?>
   
   
    <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add Opportunity</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>"><?php echo e($mainsetting->site_title); ?></a></li>
                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Add
                                            Opportunity</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <a href="javascript: history.go(-1)" class="btn btn-primary float-right">Back to List</a>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <form method="post" id="opp_form">
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empcode" class="col-lg-4 col-form-label">Opportunity Owner
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                <input type="text" placeholder="<?php echo e(Auth::guard('main_users')->user()->userfullname); ?>" disabled
                                                        class="form-control"> </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="opp_id" value="<?php echo e($edit_opp->id); ?>">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label">Amount <span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" value="<?php echo e($edit_opp->amount??''); ?>"   name="opp_amount"> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="prifix" class="col-lg-4 col-form-label">Expected Revenue
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" value="<?php echo e($edit_opp->exp_revance??''); ?>"  name="opp_exp_revenue"> </div>
                                            </div>
                                        </div>
                                        <!-- <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="firstname" class="col-lg-4 col-form-label">Opportunity
                                                    Name<span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" value="<?php echo e($edit_opp->opp_name??''); ?>" class="form-control"   name="opp_name"> </div>
                                            </div>
                                        </div> -->
                                    </div>

                                    <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="firstname" class="col-lg-4 col-form-label">Organization 
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    
                                    <?php 
                                                
                                                $getAccount = DB::table('main_lead_list')->where('owner',$userid)->where('lead_status',5)->get();
                                                ?>

                                                <select class="form-control" name="ac_name" id="ac_name">

                                                                        <?php $__currentLoopData = $getAccount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getAccounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                           
                                                                           <option value="<?php echo e($getAccounts->id); ?>"  <?php if($edit_opp->account_id ==$getAccounts->id ): ?> selected   <?php endif; ?>><?php echo e($getAccounts->company); ?></option>

                                                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                          
                                                                       </select> </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="logo" class="col-lg-4 col-form-label">Close Date<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="date" value="<?php echo e($edit_opp->close_date??''); ?>" class="form-control"   name="opp_close_date"> </div>
                                            </div>
                                        </div>

                                        

                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="email" class="col-lg-4 col-form-label">Product Interest
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <select class="form-control" name="opp_product_inst">
                                                        <option <?php if($edit_opp->project_intrest =='EIA' ): ?> selected   <?php endif; ?>>EIA</option>
                                                        <option <?php if($edit_opp->project_intrest =='CTE' ): ?> selected   <?php endif; ?>>CTE</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <!--     <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="cid" class="col-lg-4 col-form-label">Organization
                                                    Name <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" value="<?php echo e($edit_opp->org_name??''); ?>"  name="opp_org_name"  class="form-control"> </div>
                                            </div>
                                        </div>
                                    
                                    </div> -->
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="col-sm-12">
                                                <h5 class="font-18 h5after"><span>Address Information</span></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Country<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                               
     
      <select class="form-control" id="country" name="country">
         <option value="">Select Country</option>
         <?php $__currentLoopData = $Country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($Country->id); ?>" <?php if(!empty($edit_opp)): ?>  <?php if($Country->id == $edit_opp->opp_country): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($Country->country); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </select>
      <div id="country_error"></div> </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">State<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                <?php



      
    ?>
     
      <select class="form-control" id="state" name="state">
         <option value="">Select State</option>

          <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($states->id); ?>" <?php if(!empty($edit_opp)): ?>  <?php if($states->id == $edit_opp->opp_state): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($states->name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
      </select>
     <div id="state_error"></div> </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">City<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                <?php


      
    ?>
                                                <select class="form-control" id="city" name="city">
                                                <option value="">Select City</option>

                                                 <?php $__currentLoopData = $alm_cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alm_citiess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($alm_citiess->id); ?>" <?php if(!empty($edit_opp)): ?>  <?php if($alm_citiess->id == $edit_opp->opp_city): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($alm_citiess->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                               
                                             </select>
                                             <div id="city_error"></div>
                                                    
                                                     </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Street<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" value="<?php echo e($edit_opp->opp_street??''); ?>" class="form-control"   name="opp_street" > </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Zip Code<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" value="<?php echo e($edit_opp->opp_zip??''); ?>" class="form-control"   name="opp_zip" > </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary float-right">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>

            </form>
   
            <?php $__env->startSection('extra_js'); ?>

<script language="javascript" type="text/javascript">

                    $("form#opp_form").submit(function(e) {

 
            e.preventDefault();
            
           

    //       var last_name = $('#last_name').val();
    //        var first_name = $('#first_name').val();
    //         var mobile = $('#mobile').val();
      
    //      if(first_name ==''){
    //      $('#first_name_error').text('First Name is Required').attr('style','color:red');
    //      $('#first_name_error').show();
    //       error = 0;
    //           return false;

    //   }else{$('#first_name_error').hide();  error = 1;}
      
    //   if(last_name ==''){
    //      $('#last_name_error').text('Last Name is Required').attr('style','color:red');
    //      $('#last_name_error').show();
    //       error = 0;
    //           return false;

    //   }else{$('#last_name_error').hide();  error = 1;}
      
    //   if(mobile ==''){
    //      $('#mobile_error').text('Mobile is Required').attr('style','color:red');
    //      $('#mobile_error').show();
    //       error = 0;
    //           return false;

    //   }else{$('#mobile_error').hide();  error = 1;}

      

   var token = "<?php echo e(csrf_token()); ?>"; 


  $.ajax({
        url: '/insert-opp',
        headers: {'X-CSRF-TOKEN': token}, 
        type: "post",
        data:$(this).serialize(),

           beforeSend: function() {    
       
        $('#loadingDiv').show();
        },
    
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
             
             swal("Good job!", "Added Successfully", "success");

            base_url = $('#base_url').val();
 
          var editurl =   base_url+'/opportunity/';


   
         window.location = editurl;

          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");
               location.reload();

          }else{

             $('#loadingDiv').hide();
            
             swal("Good job!", "You clicked the button!", "error");

          }
          
        }
      });

       
           });

           </script>

           <?php $__env->stopSection(); ?>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>