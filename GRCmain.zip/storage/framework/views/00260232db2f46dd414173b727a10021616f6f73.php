                                 <?php $__currentLoopData = $newuserlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newuserlists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                        <div class="col-sm-6 append_div cursorpointer">
                                                            <div class="card m-b-10 float-left width100 box-shadow">
                                                                <div class="media p-l-5 p-r-5 p-t-5">
                                                                    
                                                                    
                                                                   <?php if(!empty($newuserlists->profileimg)): ?>
                            <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/')); ?>/<?php echo e($newuserlists->profileimg); ?>" alt="Generic placeholder image" height="40">
                              <?php elseif($newuserlists->prefix == 1): ?>
                              
                               <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/male.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php elseif($newuserlists->prefix == 2 || $newuserlists->prefix == 3): ?>
                              
                                <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/female.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php else: ?>
                              
                              <img class="d-flex mr-3 rounded-circle"
                              src="<?php echo e(URL::to('public/uploads/human.png')); ?>" alt="Generic placeholder image" height="40">
                              
                              <?php endif; ?>
                              
                              
                                                                 <input type="hidden" class="user_id" value="<?php echo e($newuserlists->id); ?>">   
                                                                        
                                                                        
                                                                    <div class="media-body">
                                                                        <h6 class="mt-0 mb-0 font-16 text-info"><?php echo e($newuserlists->userfullname); ?>

                                                                            </h6>
                                                                        <p class="m-0 font-12"><?php echo e($newuserlists->employeeId); ?></p>
                                                                       
                                                                    </div>
                                                                </div>
                                                                <div class="mainhilight">
                                                                    <span class="font-500"><?php echo e($newuserlists->jobtitlename); ?></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                  
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>