   <?php $__env->startSection('content'); ?>
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Leaves to Approve</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Leave</a></li>
                                    <li class="breadcrumb-item active"><a href="leaveapprove.html">Leaves to Approve</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap text-center"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>
                                                    Employee
                                                </th>
                                                <th>Leave Type</th>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>No. of Days</th>
                                                <th>Approver Status</th>
                                                <th>Leave Status</th>
                                          <?php if(PermissionHelper::frontendPermission('update-leave-to-approval')): ?>
                                                <th>Action</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $leavelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leavelists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td>
                                                       <?php echo e(ucwords($leavelists->userfullname)); ?>

                                                    </div>
                                                </td>
                                                <td>  <?php echo e($leavelists->leave_mode); ?></td>
                                                <td>  <?php echo e($leavelists->leaveDate); ?></td>
                                                <td>  <?php echo e($leavelists->leaveDate); ?></td>
                                                <td>1</td>
                                                <td>
                                                <?php ($useridshowid = array_filter(explode(',',$leavelists->show_user_id))); ?>
                                                    
                                                    <?php if($leavelists->manager ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                    <?php elseif($leavelists->manager ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>
                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->hr ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                      <?php elseif($leavelists->hr ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>
                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->admin ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                        <?php elseif($leavelists->admin ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>

                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->director ==1 && count($useridshowid) > 5): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                           <?php elseif($leavelists->director ==0 && count($useridshowid) > 5): ?> 

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="pending"></i>
                                                      <?php elseif(count($useridshowid) > 5): ?> 

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                   <!--  <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Pending"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                    <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i> -->
                                                </td>
                                              
                                                
                                                <?php if(count($useridshowid) > 5): ?>
                                               

                                                <?php if($leavelists->manager ==1 && $leavelists->hr ==1 && $leavelists->admin ==1 && $leavelists->director == 1): ?>

                                             
                                                <td class="approve-bg">
                                                    Approved
                                                </td>
                                                <?php elseif($leavelists->manager == 2 || $leavelists->hr ==2 || $leavelists->admin ==2 || $leavelists->director ==2): ?>
 
                                                <td class="reject-bg">
                                                    Rejected 
                                                </td>

                                                <?php else: ?>

                                           
                                                 <td class="pending-bg">
                                                    Pending
                                                </td>

                                                <?php endif; ?>

                                                <?php else: ?>

                                                <?php if($leavelists->manager ==1 && $leavelists->hr ==1 && $leavelists->admin ==1 ): ?>

                                             
                                                <td class="approve-bg">
                                                    Approved
                                                </td>
                                                <?php elseif($leavelists->manager == 2 || $leavelists->hr ==2 || $leavelists->admin ==2 ): ?>
 
                                                <td class="reject-bg">
                                                    Rejected 
                                                </td>

                                                <?php else: ?>

                                           
                                                 <td class="pending-bg">
                                                    Pending
                                                </td>

                                                <?php endif; ?>

                                                <?php endif; ?>

                                       <?php if(PermissionHelper::frontendPermission('update-leave-to-approval')): ?>

                                                <td class="font-blue cursorpointer" data-toggle="modal" data-target="#leaveapprove<?php echo e($leavelists->id); ?>">
                                                    Approve/Reject</td>

                                                    <?php endif; ?>
                                            </tr>

<!-- leave approve -->

    <div id="leaveapprove<?php echo e($leavelists->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
       <div class="modal-content">
          <div class="modal-header">
             <h5 class="modal-title mt-0" id="myModalLabel">Approve Leave</h5>
             <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <form id="aproveModel" method="post">
          <div class="modal-body p-0">
             <div class="row">
                 <div class="col-md-2">
                    Date
                 </div>
                  <div class="col-md-2">
                    Leave Day Type
                 </div>
                  <div class="col-md-2">
                    Leave Timing
                 </div>
                  <div class="col-md-2">
                    Approver Status
                 </div>
                  <div class="col-md-2">
                    My Action
                 </div>
                  <div class="col-md-2">
                    Final Status
                 </div>
             </div>

                  <in>


               <div class="row">
                  <div class="col-md-2">
                   <?php echo e(date('d-M-Y',strtotime($leavelists->leaveDate))); ?>

                 </div>
                  <div class="col-md-2">
                   <?php if($leavelists->leave_type == 1.0): ?>

                   Full day

                   <?php else: ?>

                    Half Day

                   <?php endif; ?>
                 </div>
                  <div class="col-md-2">
                    <?php echo e($leavelists->leave_timing??'Fullday'); ?>

                 </div>
                  <div class="col-md-2">
                    <?php if($leavelists->manager ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                    <?php elseif($leavelists->manager ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Rejected"></i>
                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->hr ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                      <?php elseif($leavelists->hr ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Rejected"></i>
                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->admin ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>
                                                        <?php elseif($leavelists->admin ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Rejected"></i>

                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                                                       <?php if($leavelists->director ==1): ?>
                                                        <i class="mdi mdi-checkbox-blank-circle approved"
                                                        title="Approved"></i>

                                                           <?php elseif($leavelists->director ==0): ?>

                                                       <i class="mdi mdi-checkbox-blank-circle pending"
                                                        title="Rejected"></i>
                                                      <?php else: ?>

                                                       <i class="mdi mdi-checkbox-blank-circle rejected"
                                                        title="Rejected"></i>
                                                      
                                                      <?php endif; ?>  
                 </div>
                  <div class="col-md-2">
                    <select class="form-control" id="status" name="status" required="">
                       <option value="">Selet status</option>
                                                 <option>Approve</option>
                                                 <option>Reject</option>
                                             </select>
                 </div>
                 <input type="hidden" id="leaveid" name="leaveid" value="<?php echo e($leavelists->id); ?>">
                 <input type="hidden" id="user_id" name="user_id" value="<?php echo e($leavelists->user_id); ?>">
                  <input type="hidden" id="leavecount" name="leavecount" value="<?php echo e($leavelists->leave_type); ?>">
                  <div class="col-md-2">
                     <?php if($leavelists->manager == 1 && $leavelists->hr == 1 && $leavelists->admin == 1): ?>
                    <div class="approved-bg">Approved</div>

                    <?php elseif($leavelists->manager == 2 || $leavelists->hr == 2 || $leavelists->admin == 2): ?>
                     

                        <div class="rejected-bg">Rejected</div>

                    <?php else: ?>

                     <div class="pending-bg">Pending</div>

                   
                    <?php endif; ?>
                 </div>
                 </div>
           
                <div class="col-md-12">
                        <div class="row">
                                <div class="col-md-6">
                                   <div class="form-group row m-0">
                                      <label for="empcode" class="col-lg-8 col-form-label">Available Leaves in <?php echo e($getleavecount->drtDate); ?></label>
                                      <div class="col-lg-4 col-form-label">
                                         <label class="myprofile_label">
                                           <?php if($leavelists->total_year_leave > 0): ?>

                                           <?php if($leavelists->total_year_leave > $leavelists->used_leave ): ?>
                                           <?php echo e($leavelists->total_year_leave - $leavelists->used_leave); ?>


                                           <?php else: ?>

                                             0.00

                                           <?php endif; ?>

                                           <?php else: ?>
                                           <?php echo e($leavelists->total_year_leave); ?>


                                           <?php endif; ?>
                                          </label>
                                      </div>
                                   </div>
                                </div>
                                <div class="col-md-6">
                                   <div class="form-group row m-0">
                                      <label for="empid" class="col-lg-8 col-form-label">Available Leaves in Year</label>
                                      <div class="col-lg-4 col-form-label">
                                         <label class="myprofile_label"><?php echo e($leavelists->total_year_leave); ?></label>
                                      </div>
                                   </div>
                                </div>
                             </div>
                              <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0">
                                          <label for="empcode" class="col-lg-8 col-form-label">Used Leaves</label>
                                          <div class="col-lg-4 col-form-label">
                                             <label class="myprofile_label"><?php echo e($leavelists->used_leave); ?></label>
                                          </div>
                                       </div>
                                    </div>

                                    <?php if(Auth::guard('main_users')->check() && Auth::guard('main_users')->user()->emprole == 3): ?>

                                    <div class="col-md-6">
                                       <div class="form-group row m-0">
                                          <label for="empcode" class="col-lg-8 col-form-label">Reason</label>
                                          <div class="col-lg-4 col-form-label">
                                            <textarea id="reason" name="reason" class="form-control" required></textarea>
                                          </div>
                                       </div>
                                    </div>
                                    <?php endif; ?>
                                 </div>
                                 
                             <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0">
                                          <label for="empcode" class="col-lg-8 col-form-label">Unpaid Leaves</label>
                                          <div class="col-lg-4 col-form-label">
                                             <label class="myprofile_label"><?php echo e($leavelists->unpaid_leave); ?></label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group row m-0">
                                              <label for="empcode" class="col-lg-4 col-form-label">Comment By Applicant</label>
                                              <div class="col-lg-8 col-form-label">
                                                 <label class="myprofile_label">
                                                       <?php echo e($leavelists->comment); ?>

                                                 </label>
                                              </div>
                                           </div>
                                        </div>
                                     </div>
                </div>
             </div>
            <div class="modal-footer">
             <button type="submit" class="btn btn-primary float-right">Save</button>
             <button type="button" class="btn btn-primary waves-effect" data-dismiss="modal">Cancel</button>
          </div>
              </form>
          </div>
        
       </div>
       <!-- /.modal-content -->
    </div>
 
    <!-- /.modal-dialog -->
 </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php if(count($leavelist) == 0): ?>
                                            <tr><td colspan="9">No Recoud Found</td></tr>

                                            <?php endif; ?>

                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->


    
          
         <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>