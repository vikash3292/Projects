@extends('layouts.superadmin_layout')
@section('extra_css')
<style type="text/css">
    .custom-control-label::after{
        top: 0.12rem;
    }
     .custom-control-label::before{
        top: 0.12rem;
    }
    .modal-header .close{
    position: absolute;
    right: -3px;
    top: 2px;
    background: #fff;
    border-radius: 50%;
     padding: 0; 
    height: 20px;
    width: 20px;
    line-height: 20px;
}
</style>
@stop
@section('content')
<div class="content p-0">

    <div class="container-fluid">

        <div class="page-title-box">

            <div class="row align-items-center bredcrum-style">

                <div class="col-sm-6 col-6">

                    <h3 class="page-title">Requisition List</h3>

                    <ol class="breadcrumb">

                        <li class="breadcrumb-item"><a href="index.html">GRC</a></li>

                        <li class="breadcrumb-item active"><a href="bill_master.html">Requisition List</a>

                        </li>

                    </ol>

                </div>

            </div>

        </div>

        <div class="row">

            <div class="col-12">

                <div class="card m-t-20">

                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <button class="btn btn-primary float-right" data-toggle="modal"
                                    data-target="#addrequisition">Add Requisition</button>
                                <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Name</th>
                                            <th>Designation</th>
                                            <th>Place to be Visit</th>
                                            <th>Particulars</th>
                                            <th>Mode of Payment</th>
                                            <th>Amount</th>
                                            <th>PDF</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><i class="fa fa-download"></i></td>
                                            <td>
                                                <i title="View" class="mdi mdi-eye text-info" data-toggle="modal"
                                                    data-target="#viewrequisition"></i>
                                                <i title="Edit" class="mdi mdi-pencil text-warning" data-toggle="modal"
                                                    data-target="#addrequisition"></i>
                                                   <a  onclick="return confirm('Are you sure you want to delete this ?');" href=""> 
                                                <i title="Delete" class="mdi mdi-delete text-danger"></i>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
     <!-- 
              add new requisition form -->
    <div id="addrequisition" class="modal fade" role="dialog">

        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header bg-gray float-none p-0">
                   <h5 class="m-0 text-center width100 font-16">
                    <p class="m-0">GRASS ROOTS RESEARCH & CREATION INDIA (P) LTD</p>
                    <p class="m-0">ADVANCE REQUISITION FORM</p>
                </h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form id="vendor_form">
                <div class="modal-body  modal-height">
                    <div class="border">
                        <div class="col-sm-12 p-0">
                            <table width="100%" border="1" style="border-color: #ededed;font-size: 13px;">
                                <tbody>
                                    <tr>
                                        <td class="padding-5 font-500">
                                           Name
                                        </td class="padding-5">
                                        <td>
                                             <input type="text" class="form-control m-0" id="name"> 
                                        </td>
                                        <td class="padding-5 font-500">
                                            Designation
                                        </td>
                                        <td class="padding-5">
                                             <input type="text" class="form-control m-0" id="designation"> 
                                        </td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5 font-500">
                                           Section
                                        </td>
                                        <td>
                                             <input type="text" class="form-control m-0" id="name"> 
                                        </td>
                                        <td class="padding-5 font-500">
                                            Place to be Visit
                                        </td>
                                        <td class="padding-5">
                                             <input type="text" class="form-control m-0" id="designation"> 
                                        </td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5 font-500">
                                           Journey Start Date & Time
                                        </td>
                                        <td>
                                             <input type="text" class="form-control m-0" id="name"> 
                                        </td>
                                        <td class="padding-5 font-500">
                                            Journey End Date & Time
                                        </td>
                                        <td class="padding-5 font-500">
                                             <input type="text" class="form-control m-0" id="designation"> 
                                        </td>
                                    </tr>
                                         <tr>
                                        <td class="padding-5 font-500">
                                           Project Name
                                        </td>
                                        <td>
                                             <input type="text" class="form-control m-0" id="name"> 
                                        </td>
                                        <td class="padding-5 font-500">
                                            Project Code
                                        </td>
                                        <td class="padding-5">
                                             <input type="text" class="form-control m-0" id="designation"> 
                                        </td>
                                    </tr>
                                             <tr>
                                        <td class="padding-5 font-500">
                                           Project Sector
                                        </td>
                                        <td class="padding-5">
                                             <input type="text" class="form-control m-0" id="name"> 
                                        </td>
                                        <td class="padding-5 font-500">
                                            A/C Number(If Other than Salary A/C)
                                        </td>
                                        <td class="padding-5">
                                             <input type="text" class="form-control m-0" id="designation"> 
                                        </td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5 font-500">
                                           Priority
                                        </td>
                                        <td class="padding-5">
                                            <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="normal" checked value="priority" name="priority" class="custom-control-input checkval">
                                                    <label class="custom-control-label" for="normal">Normal</label></div>
                                                     <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="urgent"  value="priority" name="priority" class="custom-control-input checkval">
                                                    <label class="custom-control-label" for="urgent">Urgent</label></div>
                                        </td>
                                        <td class="padding-5 font-500">
                                            Mode of Payment
                                        </td>
                                        <td class="padding-5">
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="cash" value="payment" checked name="payment" class="custom-control-input checkval">
                                                    <label class="custom-control-label" for="cash">Cash In Person</label></div>
                                                     <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="modeofpayment" value="payment" name="payment" class="custom-control-input checkval">
                                                    <label class="custom-control-label" for="modeofpayment">Deposite in A/C</label></div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="padding-5 font-500">Detail of the Tour</td>
                                        <td colspan="3" class="padding-5">
                                            <textarea class="form-control" rows="3"></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" class="padding-5">
                                                 <table id="datatable1" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;font-size: 13px">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>PARTICULARS</th>
                                            <th>AMOUNT</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><input type="text" class="form-control m-0"></td>
                                            <td></td>
                                        </tr>
                                          <tr>
                                            <td>2</td>
                                            <td><input type="text" class="form-control m-0"></td>
                                            <td></td>
                                        </tr>
                                           <tr>
                                            <td>3</td>
                                            <td><input type="text" class="form-control m-0"></td>
                                            <td></td>
                                        </tr>
                                           <tr>
                                            <td>4</td>
                                            <td><input type="text" class="form-control m-0"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                            <td><input type="text" class="form-control m-0"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" class="text-right font-600">TOTAL</td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                                        </td>
                                    </tr>
                                      <tr>
                                        <td class="padding-5 font-500">CLAIMANT</td>
                                        <td class="font-500 padding-5">HOD/COORDINATOR</td>
                                          <td class="font-500 padding-5">ACCOUNTS MANAGER</td>
                                        <td class="font-500 padding-5">PRESIDENT</td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5">
                                            <input type="text" class="form-control m-0">
                                        </td>
                                        <td class="padding-5">
                                            <input type="text" class="form-control m-0">
                                        </td>
                                          <td class="padding-5">
                                              <input type="text" class="form-control m-0">
                                          </td>
                                        <td class="padding-5">
                                            <input type="text" class="form-control m-0">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-sm-12 m-t-10 text-center">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <button  type="reset" class="btn btn-default" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </form>
                

            </div>
        </div>
    </div>
    <!-- view requisition form -->
   <div id="viewrequisition" class="modal fade" role="dialog">

        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header bg-gray float-none p-0">
                   <h5 class="m-0 text-center width100 font-16">
                        <p class="m-0">GRASS ROOTS RESEARCH & CREATION INDIA (P) LTD</p>
                        <p class="m-0">ADVANCE REQUISITION FORM</p>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form id="vendor_form">
                <div class="modal-body modal-height">
                    <div class="border">
                        <div class="col-sm-12 p-0">
                            <table width="100%" border="1" style="border-color: #ededed;font-size: 13px;">
                                <tbody>
                                    <tr>
                                        <td class="padding-5 font-500">
                                           Name
                                        </td>
                                        <td class="padding-5">
                                             dummy 
                                        </td>
                                        <td class="padding-5 font-500">
                                            Designation
                                        </td>
                                        <td class="padding-5">
                                             dummy 
                                        </td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5 font-500">
                                           Section
                                        </td>
                                        <td class="padding-5">
                                             dummy 
                                        </td>
                                        <td class="padding-5 font-500">
                                            Place to be Visit
                                        </td>
                                        <td class="padding-5">
                                             dummy 
                                        </td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5 font-500">
                                           Journey Start Date & Time
                                        </td>
                                        <td class="padding-5">
                                             dummy 
                                        </td>
                                        <td class="padding-5 font-500">
                                            Journey End Date & Time
                                        </td>
                                        <td class="padding-5">
                                             dummy 
                                        </td>
                                    </tr>
                                         <tr>
                                        <td class="padding-5 font-500">
                                           Project Name
                                        </td>
                                        <td class="padding-5">
                                             dummy
                                        </td>
                                        <td class="padding-5 font-500">
                                            Project Code
                                        </td>
                                        <td class="padding-5">
                                             dummy
                                        </td>
                                    </tr>
                                             <tr>
                                        <td class="padding-5 font-500">
                                           Project Sector
                                        </td>
                                        <td class="padding-5">
                                             dummy
                                        </td>
                                        <td class="padding-5 font-500">
                                            A/C Number(If Other than Salary A/C)
                                        </td>
                                        <td class="padding-5">
                                            dummy
                                        </td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5 font-500">
                                           Priority
                                        </td>
                                        <td class="padding-5">
                                            Normal
                                        </td>
                                        <td class="padding-5 font-500">
                                            Mode of Payment
                                        </td>
                                        <td class="padding-5">
                                             Cash In Person
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="padding-5 font-500">Detail of the Tour</td>
                                        <td colspan="3" class="padding-5">
                                            dummy dummy
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" class="padding-5">
                                                 <table id="datatable1" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;font-size: 13px">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>PARTICULARS</th>
                                            <th>AMOUNT</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                          <tr>
                                            <td>1</td>
                                            <td>dummy</td>
                                            <td>10,000</td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td class="text-right font-600">TOTAL</td>
                                            <td>10,1000</td>
                                        </tr>
                                    </tbody>
                                </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="padding-5 font-500">CLAIMANT</td>
                                        <td class="font-500 padding-5">HOD/COORDINATOR</td>
                                          <td class="font-500 padding-5">ACCOUNTS MANAGER</td>
                                        <td class="font-500 padding-5">PRESIDENT</td>
                                    </tr>
                                     <tr>
                                        <td class="padding-5">dummy</td>
                                        <td class="padding-5">Umang Mathur</td>
                                        <td class="padding-5">Arun Mishra</td>
                                        <td class="padding-5">Atul Singal</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-sm-12 m-t-10 text-center">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <button  type="reset" class="btn btn-default" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </form>
                

            </div>
        </div>
    </div>
      @stop
  @section('extra_js')
    <script type="text/javascript">
        $("#datatable1").DataTable();
    </script>
  @stop