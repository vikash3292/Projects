@extends('layouts.superadmin_layout')

@section('content')

     <div class="content p-0">

            <div class="container-fluid">

            <div class="page-title-box">

<div class="row align-items-center bredcrum-style">

<div class="col-sm-6">

<h3 class="page-title">One-to-One Form</h3>

<ol class="breadcrumb">

<li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>

<li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Edit Question</a></li>

</ol>

</div>

<div class="col-sm-6 text-right">

<a class="btn btn-primary" href="javascript: history.go(-1)">Back</a>

</div>

</div>

</div>
<form id="quertion_from">
 <div class="row">
     <div class="col-sm-12">
      <div class="card one_to_form_top m-t-10" style="width:700px">
                   
                            </div>
                            </div>
                            <div class="col-sm-12">
                     <div class="card one_to_form m-t-10" style="width:700px">
                        <div class="card-body">
                            <div class="row m-b-10">
                            <div class="col-sm-8">
                                <input type="text" class="form-control" placeholder="Untitled Question" id="question" name="question" value="{{$edit->question}}" required=""  maxlenght="60"/>
                            </div>
                            <div class="col-sm-4">
                                <select class="form-control" id="category" name="category" onchange="question_value(this.value)">
                                    <option value="1" @if($edit->category == 1)  selected @endif>Input Box</option>
                                    <option value="2" @if($edit->category == 2)  selected @endif>radio</option>
                                    <option value="3" @if($edit->category == 3)  selected @endif>Dropdown</option>
                                    <option value="4" @if($edit->category == 4)  selected @endif>Checkbox</option>
                                </select>
                            </div>
                            </div>
                            <input type="hidden" name="question_id" value="{{$edit->id}}">
                             <div class="row " id="multiplechoice">
                             <div class="col-sm-12 m-b-10">


                                    <div class="row append_data">
     

                                      @if($edit->category == 2)

                                     @foreach(json_decode($edit->ans) as $k => $option)



                                     @if($k == 0)
                                     <div class="col-1 p-10 text-center"><input type="radio" id="male" name="gender" value="male" disabled></div>
                                     <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                     <div class="col-1 p-10"><span onclick="add_row('{{$edit->category}}')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>
                                 

                                         @else
                                        <div class="col-sm-12"> 
                                         <div class="row">  
                                         <div class="col-sm-1 p-10 text-center"><input type="radio" id="male" name="gender" value="male" disabled></div>
                                         <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                         <div class="col-1  p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>
                                        </div>
                                         @endif
                                     
                                     @endforeach

                                      @elseif($edit->category == 3)

                                      @foreach(json_decode($edit->ans) as $k => $option)

                                      @if($k == 0)
                                      <div class="col-1 p-10 text-center"><i class="fa fa-circle"></i></div>
                                     <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                      

                                         <div class="col-1 p-10 text-center"><span onclick="add_row('{{$edit->category}}')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>
                                 

                                         @else
                                             <div class="col-sm-12">
                                         <div class="row">
                                             <div class="col-1 p-10 text-center"><i class="fa fa-circle"></i></div>
                                              <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                    
                                         <div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>
                                        </div>
                                         @endif


                                      @endforeach


                                      @elseif($edit->category == 4)

                                      @foreach(json_decode($edit->ans) as $k => $option)

                                      @if($k == 0)
                                      <div class="col-1 p-10 text-center"><input type="checkbox" id="male" name="gender" value="male" disabled></div>
                                     <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                      

                                         <div class="col-1 p-10 text-center"><span onclick="add_row('{{$edit->category}}')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>
                                 

                                         @else
<div class="col-sm-12">
                                         <div class="row"> 
                                           <div class="col-1 p-10 text-center"><input type="checkbox" id="male" name="gender" value="male" disabled></div>
                                         <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                    
                                         <div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>
</div>
                                         @endif


                                       @endforeach

                                      @endif

                                

                                    </div>


                            </div>
                             <div class="col-sm-12">
                                    <div class="row">
       

                            </div>
                            </div>
                        </div>
                        <input type="hidden" name="form_id" value="{{$edit->form_id}}">
                            <div class="col-sm-12 oneformfooter m-t-10 p-0">
                                <div class="alignment">
                                    <div class="iewQuestionFooterFooterRight">
                                        <div>
                                            
                                            <div class="togglebutton custom-control custom-switch inline-block" title="Active">
                                                        <input type="checkbox" checked="" name="required_field" id="required_field" class="custom-control-input" id="required">
                                                        <label class="custom-control-label" for="customSwitches156">Required
                                                        </label>
                                                                                                            </div>
                                        </div>
                                        <div class="formfooterseprate">
                                            
                                        </div>
                                       <!--  <div>
                                            <i class="fa fa-trash font-18"></i>
                                        </div> -->
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-primary" value="submit">
                            </div>
                            </div>
                            </div>
                            </div>
                            </div>
                        </form>
            </div>
    </div>
@endsection
 @section('extra_js')

  <script type="text/javascript">
 

function question_value(qval){
    var html_data = '';
    if(qval == 2){

     html_data += '<div class="col-1 p-10 text-center"><input type="radio" id="male" name="gender" value="male" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1  p-10 text-center"><span onclick="add_row('+qval+')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>';
  
   }else if(qval == 3){

    html_data += '<div class="col-1 p-10 text-center"><i class="fa fa-circle"></i></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 text-center p-10"><span onclick="add_row('+qval+')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>';


   }else if(qval == 4){

    html_data += '<div class="col-1 p-10 text-center"><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 text-center p-10"><span onclick="add_row('+qval+')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>';


   }
    

    $('.append_data').html(html_data);

}
 
 function add_row(inpu_val){

   

     html_data = '';

     if(inpu_val == 2){

        html_data += '<div class="col-sm-12"><div class="row"><div class="col-sm-1 p-10 text-center"><input type="radio" id="male" name="gender" value="male" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 text-center p-10"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>';
    

     }else if(inpu_val == 3){

        html_data += '<div class="col-sm-12"><div class="row"><div class="col-sm-1 p-10 text-center"><i class="fa fa-circle"></i></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 text-center p-10"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>';
    

     }else if(inpu_val == 4){

        html_data += '<div class="col-sm-12"><div class="row"><div class="col-sm-1 p-10 text-center"><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 text-center p-10"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>';
    

     }
     

    $('.append_data').append(html_data);

 }

 function remove_field(input){

     console.log(input);

    $(input).parent().parent().remove();
 }

//  $('.append_data').on("click",".remove_field", function(e){ //user click on remove text
//         e.preventDefault(); $(this).parent('div').remove(); 
//     });
 




  $("form#quertion_from").submit(function(e) {

 
            e.preventDefault();

            $('#loadingDiv').show();

   var token = "{{csrf_token()}}"; 


  $.ajax({
        url: '/insert_question',
        headers: {'X-CSRF-TOKEN': token}, 
        type: "post",
        data:$(this).serialize(),
        
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
             alertify.success(data.msg);
             window.location = "{{URL::to('/one-to-one-form')}}/{{$edit->form_id}}";

       

             //swal("Good job!", "Added Successfully", "success");

            //location.reload();

          }else if(data.status ==202){

              $('#loadingDiv').hide();
              alertify.success(data.msg);
           // swal("Good job!", "User alert Exist", "success");
            //location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
              alertify.success(data.msg);
           // swal("Good job!", "Successfully Updated", "success");
               //location.reload();

          }else{

             $('#loadingDiv').hide();
             alertify.error(data.msg);
            // swal("Good job!", "You clicked the button!", "error");

          }
          
        }
      });

            

          });




</script>


 @stop