@extends('layouts.superadmin_layout')

@section('content')





<div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">KRA Master</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="index.html">Kloudrac</a></li>

                                    <li class="breadcrumb-item active"><a href="users.html">KRA Master</a></li>

                                </ol>

                            </div>

                            <div class="col-sm-6 text-right">

                            

                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <!-- end row -->

                    <div class="row">

                        <div class="col-12">

                            <div class="card m-t-20">

                                <div class="card-body">

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"

                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                                        <thead>

                                            <tr>

                                                <th>S.No</th>

                                                <th>KRA Name</th>

                                                <th>Designation</th>

                                                <th width="20%">Employee Status</th>

                                                <th width="20%">Manager Status</th>

                                                <th width="10%">Action</th>

                                            </tr>

                                        </thead>

                                        <tbody>

                                         @php($i = 1)

                                       





                                        @foreach($form as $forms)

                                            <tr>

                                            <td>{{$i++}}</td>

                                                <td>{{$forms->name}}</td>

                                                <td>{{$forms->positionname}}</td>

                                               

                                                <td>{{($forms->user_fill == 0)?'No Entry':'Filled'}}</td>

                                                <td>{{($forms->manager_fill == 0)?'No Entry':'Filled'}}</td>

                                                <td>

                                                <a href="{{URL::to('view-emp-kra')}}/{{$forms->id}}/{{$forms->kra_assign_id}}">

                                                   <i class="mdi mdi-eye font-blue"></i>

                                                   </a>

                                                </td>

                                            </tr>



                                            @endforeach

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

            <!-- content -->

        

    <div id="addkra" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"

                style="display: none; padding-right: 5px;" aria-modal="true">

                <div class="modal-dialog modal-lg">

                    <div class="modal-content">

                        <div class="modal-header">

                            <h5 class="modal-title mt-0" id="myModalLabel">KRA</h5>

                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

                        </div>

                        <div class="modal-body">

                            <div class="row">

                                <div class="col-sm-12">

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Name

                                                    <span class="text-danger">*</span></label>

                                                <div class="col-lg-8 col-form-label">

                                                    <input type="text" class="form-control" id="assets_name">

                                                    <div id="assets_name_error"></div>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0" id="fillsubtask">

                                                <label for="empid" class="col-lg-4 col-form-label">Designation<span

                                                        class="text-danger">*</span></label>

                                                <div class="col-lg-8 col-form-label">

                                                    <input type="text" class="form-control">

                                                    <div id="assets_type_error"></div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="modal-footer">

                            <div class="row">

                                <div class="col-sm-12">

                                    <button class="btn btn-primary add_assets">Save</button>

                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>



@stop