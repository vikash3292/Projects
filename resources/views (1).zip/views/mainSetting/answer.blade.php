@extends('layouts.superadmin_layout')

@section('content')



 <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">Form</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>

                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Form</a></li>

                                </ol>

                            </div>

                            <div class="col-sm-6">

                               

                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <form id="question_form">

                    <div class="row">

                        <div class="col-sm-12 m-t-20">

                         <div class="card one_to_form_top m-t-10" style="width:700px">

                                           <div class="card-body">

                                                   <div class="row m-b-10">

                                               <div class="col-sm-12 m-b-10">

                                                   <h3>{{$view->form_name}}</h3>

                                                       </div>

                                             

                                               </div>

                                               </div>

                                               </div>

                                               </div>





                                               <div class="col-sm-12 m-t-20">





                                         @foreach($form as $key => $forms)

                                        <div class="card one_to_form m-t-10 m-b-20" style="width:700px">

                                           <div class="card-body">

                                               <div class="row">

                                               <div class="col-sm-12">

                                                   <p class="cursorpointer">{{$forms->question}}

                                                     

                                                        </p>

                                               </div>



                                              <div class="col-sm-12">

                                               <ul class="p-0 mb-0">



                                               @foreach(json_decode($forms->ans) as $option)

                                                           <li>

                                                            <label for="male">{{$option}}</label>

                                                           </li>



                                                           @endforeach

                                                          

                                                       </ul>

</div>

                                            </div>

                                               </div>

                                               </div>



                                               @endforeach







                                               <!-- <div class="card one_to_form m-t-10 m-b-20">

                                                <div class="card-body">

                                                    <div class="row m-b-10">

                                                    <div class="col-sm-12">

                                                        <p>Question 2</p>

                                                    </div>

                                                    <div class="col-sm-12">

                                                       <ul class="p-0 m-b-0">

                                                           <li>

                                                            <input type="radio" id="male" name="gender" value="male">

                                                            <label for="male">Male</label>

                                                           </li>

                                                           <li>

                                                            <input type="radio" id="female" name="gender" value="female">

                                                            <label for="male">Female</label>

                                                           </li>

                                                           <li>

                                                            <input type="radio" id="other" name="gender" value="other">

                                                            <label for="male">Other</label>

                                                           </li>

                                                       </ul>

                                                    </div>

                                                    </div>

                                                    </div>

                                                    </div>

                                                    <div class="card one_to_form m-t-10 m-b-20">

                                                        <div class="card-body">

                                                            <div class="row m-b-10">

                                                                <div class="col-sm-12">

                                                                    <p>Question 3</p>

                                                                </div>

                                                                <div class="col-sm-12">

                                                                    <select class="form-control">

                                                                        <option>Option 1</option>

                                                                        <option>Option 2</option>

                                                                        <option>Option 3</option>

                                                                    </select>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                            

                                               </div>

                                               </div>

                                           </form>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

            





@stop



 @section('extra_js')



  <script type="text/javascript">

 





  $("form#question_form").submit(function(e) {



 

            e.preventDefault();







   var token = "{{csrf_token()}}"; 





  $.ajax({

        url: '/answer_question',

        headers: {'X-CSRF-TOKEN': token}, 

        type: "post",

        data:$(this).serialize(),

        

        success: function (data) {

        //console.log(data.city); // this is good

    

          if(data.status ==200){

             $('#loadingDiv').hide();

         

             

             swal("Good job!", "Added Successfully", "success");



             $('#question_form')[0].reset();



            //location.reload();



          }else if(data.status ==202){



              $('#loadingDiv').hide();

            swal("Good job!", "User alert Exist", "success");

            //location.reload();



              }else if(data.status ==203){



              $('#loadingDiv').hide();

            swal("Good job!", "Successfully Updated", "success");

               location.reload();



          }else{



             $('#loadingDiv').hide();

            

             swal("Good job!", "You clicked the button!", "error");



          }

          

        }

      });



            



          });









</script>





 @stop