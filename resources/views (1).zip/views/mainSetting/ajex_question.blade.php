



                                         @foreach($form as $key => $forms)
                                    <div class="col-sm-12">
                                        <div class="card one_to_form m-t-10">

                                           <div class="card-body">

                                               <div class="row">

                                               <div class="col-sm-12">

                                                   <p>{{$forms->question}}

                                                     @if($forms->required =='on')

                                                   	<span class="text-danger p-l-5">*</span>

                                                   	@endif

                                                    <a href="{{URL::to('edit-form')}}/{{$forms->id}}" ><i class="mdi mdi-pencil text-warning float-right cursorpointer" ></i></a>

                                                     <input type="hidden" name="question[]" value="{{$forms->question}}">

                                                   </p>

                                               </div>



                                               @if($forms->category == 1)



                                                      <div class="col-sm-12">



                                                      	 <input type="text" name="answer[{{$key}}][]" class="form-control"  @if($forms->required =='on') required  @endif>

                                                   

                                                                    

                                                                </div>





                                               @elseif($forms->category == 2)



                                                 <div class="col-sm-12">

                                                       <ul class="p-0 mb-0">

                                                       	@foreach(json_decode($forms->ans) as $option)

                                                           <li>

                                                            <input type="radio" id="male" name="answer[{{$key}}][]" value="{{$option}}" @if($forms->required =='on') required  @endif>

                                                            <label for="male">{{$option}}</label>

                                                           </li>

                                                           @endforeach

                                                          <!--  <li>

                                                            <input type="radio" id="female" name="answer[]" value="female">

                                                            <label for="male">Female</label>

                                                           </li>

                                                           <li>

                                                            <input type="radio" id="other" name="answer[]" value="other">

                                                            <label for="male">Other</label>

                                                           </li> -->

                                                       </ul>

                                                    </div>



                                               @elseif($forms->category == 3)



                                                <div class="col-sm-12">

                                                                    <select class="form-control" name="answer[{{$key}}][]" @if($forms->required =='on') required  @endif>

                                                                    <option value>Select option</option>

                                                                    	@foreach(json_decode($forms->ans) as $option)

                                                                        <option>{{$option}}</option>

                                                                        @endforeach

                                                                        

                                                                    </select>

                                                                </div>



                                               @elseif($forms->category == 4)



                                                <div class="col-sm-12">

                                                  <ul class="p-0 m-b-0">

                                                  	@foreach(json_decode($forms->ans) as $option)

                                                      <li>

                                                        <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" value="{{$option}}" name="answer[{{$key}}][]" id="customControlInline" @if($forms->required =='on') required  @endif>

                                                             <label class="custom-control-label" for="customControlInline">{{$option}}</label>

                                                        </div>

                                                      </li>

                                                      @endforeach

                                                     <!--  <li>

                                                        <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">

                                                             <label class="custom-control-label" for="customControlInline">Option 2</label>

                                                        </div>

                                                      </li>

                                                      <li> -->

                                                       <!--  <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">

                                                             <label class="custom-control-label" for="customControlInline">Option 3</label>

                                                        </div>

                                                      </li> -->

                                                  </ul>

                                               </div>



                                               @endif







                                              





                                               </div>

                                               </div>

                                               </div>
</div>


                                               @endforeach


