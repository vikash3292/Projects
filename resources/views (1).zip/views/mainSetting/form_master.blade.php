@extends('layouts.superadmin_layout')

@section('content')


<?php
$year = date('Y');
?>

 <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">Form List</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
                                      

                                </ol>

                            </div>

                            <div class="col-sm-6 text-right">
                                <button class="btn btn-primary" onclick="add_from()">Add Form</button>
                                <button class="btn btn-primary" data-toggle="modal" data-target="#sendform">Send</button>
                            </div>

                        </div>

                    </div>



                    @if(Session::has('msg'))

<p class="alert alert-danger">{{ Session::get('msg') }}</p>

@endif

                    <!-- end row -->

                    <!-- end row -->

                    <div class="row">

                        <div class="col-12">

                            <div class="card m-t-20">

                                <div class="card-body">

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"

                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                                        <thead>

                                            <tr>

                                                <th>Form Name</th>

                                                <th>Year </th>
                                                <th>Month </th>
                                                <th title="Active/Inactive" data-toggle="tooltip">Status</th>

                                                <th>Actions</th>

                                            </tr>

                                        </thead>

                                        <tbody>

 
                                       @foreach($form as $forms)
                                            <tr>
                                                <td class="text_ellipses">{{$forms->form_name}}</td>
                                                <td>
                                                
                                                
                                               
                                                {{$forms->year}}
                                                
                                                
                                                </td>
                                                  <td>
                                                
                                                
                                               
                                                {{$forms->month}}
                                                
                                                
                                                </td>
                                                <td class="active-text">
                                                  

                                           
                                 <div class="secondrycheck togglebutton custom-control custom-switch inline-block" @if($forms->status ==1) title="Active" @else title="InActive" @endif >
                                                        <input type="checkbox" onclick="change_hide_status('{{$forms->status}}','{{$forms->id}}')" @if($forms->status ==1) checked @else notchecked @endif class="custom-control-input"
                                                            id="customSwitches{{$forms->id}}">
                                                        <label class="custom-control-label" for="customSwitches{{$forms->id}}">
                                                        </label>

                                 

                                                </td>
                                                <td>
<!-- 
                                                	         <a href="{{URL::to('one-to-one-form')}}/{{$forms->id}}">
             
                                                   <i class="mdi mdi-eye font-blue"></i>

                                                   </a> -->
                                                    
  <a href="javascript:void(0)" onclick="edit_from('{{$forms->form_name}}','{{$forms->year}}','{{$forms->month}}','{{$forms->id}}')">
                                                	  
                                                       <i class="mdi mdi-pen text-warning" data-toggle="tooltip" title="Edit"></i> 

                                                   </a>
                                                
                                                   
                                                 <!--   <a onclick="return confirm('Are you sure you want to delete this?');" href="{{URL::to('delete-form')}}/{{$forms->id}}">
                                                   <i class="mdi mdi-delete text-danger" data-toggle="tooltip" title="Delete"></i>
                                               </a> -->
                                                </td>
                                            </tr>
                                            @endforeach


                                        	
                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

  <div id="addform" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                style="display: none; padding-right: 5px;" aria-modal="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title mt-0" id="myModalLabel">Add Form</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Form Name
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" id="form_name" maxlength="60">
                                                    <div id="form_name_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label">Year<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <select class="form-control" id="year">
                                                        <option value="">select Option</option>
                                                     @for($i=date('Y')-1;$i <= date('Y'); $i++ )


   
                      <option @if(!empty($year))  @if($year == $i) selected    @endif @endif>{{$i}}</option>
      



                      @endfor

                                                    </select>
                                                    <div id="year_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label p-r-0">Month<span
                                                        class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                     <select class="form-control"  id="month">
                                                      
                        <option value="">Select Month</option>







                        <option   >January</option>







                        <option  >February</option>







                        <option  >March</option>







                        <option  >April</option>







                        <option  >May</option>







                        <option  >June</option>







                        <option  >July</option>







                        <option  >August</option>







                        <option     >September</option>







                        <option   >October</option>







                        <option   >November</option>







                        <option   >December</option>




                                                    </select>
                                                    <div id="month_error"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="form_id">
                        <div class="modal-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <button onclick="save_form()" id="save_form" class="btn btn-primary add_assets">Save</button>
                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<div id="sendform" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                style="display: none; padding-right: 5px;" aria-modal="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title mt-0" id="myModalLabel">Send Form</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <form id="send_one_from_user">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Select Form
                                                    <span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                   <select class="form-control" id="form_id" name="form_id" required="">
                                                    <option value="">select Option</option>
                                                      @foreach($form as $forms)
                                                      @if($forms->status==1)
                                                       <option value="{{$forms->id}}">{{$forms->form_name}}</option>
                                                       @endif
                                                       @endforeach
                                                   </select>
                                                  
                                                </div>
                                            </div>
                                        </div>
                                        <?php

                                       $user = DB::table('main_users')->where('isactive',1)->get();
                                        ?>
                                        <div class="col-md-6 p-l-0">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label p-r-0">Select Employee<span class="text-danger">*</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                   <select class="form-control multiselect-ui" multiple="multiple" name="user_id[]" required="">
                                                    @foreach($user as $users)
                                                       <option value="{{$users->id}}">{{$users->userfullname}}</option>
                                                       @endforeach
                                                   </select>
                                                    <span id="form_id_error"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <button  type="submit" id="save_form" class="btn btn-primary add_assets">Send</button>
                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>

                      </form>
                    </div>
                </div>
            </div>
            @stop



            @section('extra_js')



<script>



function add_from(){

      $('#myModalLabel').text('Add Form');
     $('#form_id').val('');
     var name = $('#form_name').val('');
     var name = $('#year').val('');
     var name = $('#month').val('');
$('#addform').modal('show')

}


function edit_from(form,year,month,id){

    $('#myModalLabel').text('Edit Form');
     $('#form_id').val(id);
     var name = $('#form_name').val(form);
  

$("#year > option").each(function() {
                              if(this.value == year){
                                 $('#year').val(year).attr("selected"); 
                              }
                         
                           });

$("#month > option").each(function() {
                              if(this.value == month){
                                 $('#month').val(month).attr("selected"); 
                              }
                         
                           });

    $('#addform').modal('show')

}


function save_form(){


var form_name = $('#form_name').val();
var year = $('#year').val();
var form_id = $('#form_id').val();
var month = $('#month').val();


if(form_name.replace(/\s/g,'') ==''){
         $('#form_name_error').text('Form Name is Required').attr('style','color:red');
         $('#form_name_error').show();
           error = 0;
              return false;
      }else{$('#form_name_error').hide();  error = 1;}

            if(year ==''){
         $('#year_error').text('Year is Required').attr('style','color:red');
         $('#year_error').show();
           error = 0;
              return false;
      }else{$('#year_error').hide();  error = 1;}

      if(month ==''){
         $('#month_error').text('Month is Required').attr('style','color:red');
         $('#month_error').show();
           error = 0;
              return false;
      }else{$('#designation_error').hide();  error = 1;}


      var _token = "{{csrf_token()}}";
      $('#save_form').attr('disabled','disabled');

$.ajax({
    url: '/save_form',
    type: "post",
    data: {"_token": _token,"form_name":form_name,"year":year,"form_id" : form_id,"month":month},
   // dataType: 'JSON',
      beforeSend: function() {
    // setting a timeout
    $('#loadingDiv').show();
},
    success: function (data) {
      //console.log(data); // this is good

      $('#save_form').removeAttr('disabled','disabled');

       // return false;
      if(data.status ==200){
         $('#loadingDiv').hide();
     
         alertify.success(data.msg);
        
          location.reload();

         

      }else if(data.status ==202){

          $('#loadingDiv').hide();
          alertify.success(data.msg);
        location.reload();

          }else if(data.status ==203){

          $('#loadingDiv').hide();
          alertify.success(data.msg);


      }else{

         $('#loadingDiv').hide();
         alertify.error(data.msg);
         

      }
      
    }
  });

}



function change_hide_status(menustaus,menuid){

  

  var _token = "{{csrf_token()}}";



   $.ajax({

       url: '/question_form',

       type: "post",

       data: {"_token": _token,"menuid":menuid,"menustaus":menustaus},

       dataType: 'JSON',

         beforeSend: function() {

       // setting a timeout

       $('#loadingDiv').show();

   },

       success: function (data) {

         //console.log(data); // this is good



          // return false;

         if(data.status ==200){

            $('#loadingDiv').hide();

        
            location.reload();
            

           // swal("Good job!", data.msg, "success");

            alertify.success(data.msg);

            



         }else if(data.status ==202){



             $('#loadingDiv').hide();

             alertify.success(data.msg);

          // swal("Good job!",  data.msg, "success");

          // location.reload();



             }else if(data.status ==203){



             $('#loadingDiv').hide();

           //swal("Good job!",  data.msg, "success");

           alertify.success(data.msg);





         }else{



            $('#loadingDiv').hide();

           

           // swal("Good job!",  data.msg, "error");

            alertify.error(data.msg);



         }

         

       }

     });

}




  $("form#send_one_from_user").submit(function(e) {

 
            e.preventDefault();

            $('#loadingDiv').show();

   var token = "{{csrf_token()}}"; 


  $.ajax({
        url: '/send_one_form',
        headers: {'X-CSRF-TOKEN': token}, 
        type: "post",
        data:$(this).serialize(),
        
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
      
         alertify.success(data.msg);

         ;

            location.reload();

          }else if(data.status ==202){

              $('#loadingDiv').hide();
              alertify.success(data.msg);
           // swal("Good job!", "User alert Exist", "success");
            //location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
              alertify.success(data.msg);
           // swal("Good job!", "Successfully Updated", "success");
               //location.reload();

          }else{

             $('#loadingDiv').hide();
             alertify.error(data.msg);
            // swal("Good job!", "You clicked the button!", "error");

          }
          
        }
      });

            

          });








</script>
<script type="text/javascript">
$(function() {
    $('.multiselect-ui').multiselect({
        includeSelectAllOption: true
    });
});
</script>


@stop