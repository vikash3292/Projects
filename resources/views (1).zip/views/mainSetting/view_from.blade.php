@extends('layouts.superadmin_layout')

@section('content')



 <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">Form</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>

                                    <li class="breadcrumb-item active">Form</li>

                                </ol>

                            </div>

                            <div class="col-sm-6">

                               

                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <form id="question_form">

                    <div class="row">

                        <div class="col-sm-12 m-t-20">

                         <div class="card one_to_form_top m-t-10" style="width:700px">

                                           <div class="card-body">

                                                   <div class="row m-b-10">

                                               <div class="col-sm-12 m-b-10">

                                                   <h3>{{$title->form_name}}</h3>

                                                   <input type="hidden" name="title" value="{{$title->form_name}}">
                                                   <input type="hidden" name="form_id" value="{{$title->id}}">
                                                   <input type="hidden" name="assign_id" value="{{$assign_id}}">

                                                   

                                               </div>

                                           

                                               </div>

                                               </div>

                                               </div>

                                               </div>


                                               


                                               <div class="col-sm-12 m-t-20">





                                         @foreach($form as $key => $forms)

                                        <div class="card one_to_form m-t-10 m-b-20" style="width:700px">

                                           <div class="card-body">

                                               <div class="row m-b-10">

                                               <div class="col-sm-12">

                                                   <p>{{$forms->question}}

                                                     @if($forms->required =='on')

                                                   	<span class="text-danger p-l-5">*</span>

                                                   	@endif

                                                     <input type="hidden" name="question[]" value="{{$forms->question}}">

                                                   </p>

                                               </div>



                                               @if($forms->category == 1)



                                                      <div class="col-sm-12">



                                                      	 <input type="text" name="answer[{{$key}}][]" class="form-control"  @if($forms->required =='on') required  @endif>

                                                   

                                                                    

                                                                </div>





                                               @elseif($forms->category == 2)



                                                 <div class="col-sm-12">

                                                       <ul class="p-0 m-b-0">

                                                       	@foreach(json_decode($forms->ans) as $option)

                                                           <li>

                                                            <input type="radio" id="male" name="answer[{{$key}}][]" value="{{$option}}" @if($forms->required =='on') required  @endif>

                                                            <label for="male">{{$option}}</label>

                                                           </li>

                                                           @endforeach

                                                          <!--  <li>

                                                            <input type="radio" id="female" name="answer[]" value="female">

                                                            <label for="male">Female</label>

                                                           </li>

                                                           <li>

                                                            <input type="radio" id="other" name="answer[]" value="other">

                                                            <label for="male">Other</label>

                                                           </li> -->

                                                       </ul>

                                                    </div>



                                               @elseif($forms->category == 3)



                                                <div class="col-sm-12">

                                                                    <select class="form-control" name="answer[{{$key}}][]" @if($forms->required =='on') required  @endif>

                                                                    <option value>Select option</option>

                                                                    	@foreach(json_decode($forms->ans) as $option)

                                                                        <option>{{$option}}</option>

                                                                        @endforeach

                                                                        

                                                                    </select>

                                                                </div>



                                               @elseif($forms->category == 4)



                                                <div class="col-sm-12">

                                                  <ul class="p-0 m-b-0">

                                                  	@foreach(json_decode($forms->ans) as $k => $option)

                                                      <li>

                                                        <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" value="{{$option}}" name="answer[{{$key}}][]" id="customControlInline_{{$k}}" @if($forms->required =='on') required  @endif>

                                                             <label class="custom-control-label" for="customControlInline_{{$k}}">{{$option}}</label>

                                                        </div>

                                                      </li>

                                                      @endforeach

                                                     <!--  <li>

                                                        <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">

                                                             <label class="custom-control-label" for="customControlInline">Option 2</label>

                                                        </div>

                                                      </li>

                                                      <li> -->

                                                       <!--  <div class="custom-control custom-checkbox">

                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">

                                                             <label class="custom-control-label" for="customControlInline">Option 3</label>

                                                        </div>

                                                      </li> -->

                                                  </ul>

                                               </div>



                                               @endif







                                              





                                               </div>

                                               </div>

                                               </div>



                                               @endforeach







                                               <!-- <div class="card one_to_form m-t-10 m-b-20">

                                                <div class="card-body">

                                                    <div class="row m-b-10">

                                                    <div class="col-sm-12">

                                                        <p>Question 2</p>

                                                    </div>

                                                    <div class="col-sm-12">

                                                       <ul class="p-0 m-b-0">

                                                           <li>

                                                            <input type="radio" id="male" name="gender" value="male">

                                                            <label for="male">Male</label>

                                                           </li>

                                                           <li>

                                                            <input type="radio" id="female" name="gender" value="female">

                                                            <label for="male">Female</label>

                                                           </li>

                                                           <li>

                                                            <input type="radio" id="other" name="gender" value="other">

                                                            <label for="male">Other</label>

                                                           </li>

                                                       </ul>

                                                    </div>

                                                    </div>

                                                    </div>

                                                    </div>

                                                    <div class="card one_to_form m-t-10 m-b-20">

                                                        <div class="card-body">

                                                            <div class="row m-b-10">

                                                                <div class="col-sm-12">

                                                                    <p>Question 3</p>

                                                                </div>

                                                                <div class="col-sm-12">

                                                                    <select class="form-control">

                                                                        <option>Option 1</option>

                                                                        <option>Option 2</option>

                                                                        <option>Option 3</option>

                                                                    </select>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                                -->    
                                                <div class="m-t-10 m-b-20" style="margin:0 auto;width:700px">

                                                       <input type="submit" class="btn btn-primary" value="submit">

                                                    </div>

                                               </div>

                                               </div>

                                           </form>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

            





@stop



 @section('extra_js')



  <script type="text/javascript">

 

$(function(){

    var requiredCheckboxes = $(':checkbox[required]');

    requiredCheckboxes.change(function(){

        if(requiredCheckboxes.is(':checked')) {
            requiredCheckboxes.removeAttr('required');
        }

        else {
            requiredCheckboxes.attr('required', 'required');
        }
    });

});



  $("form#question_form").submit(function(e) {



 

            e.preventDefault();




   var token = "{{csrf_token()}}"; 





  $.ajax({

        url: '/answer_question',

        headers: {'X-CSRF-TOKEN': token}, 

        type: "post",

        data:$(this).serialize(),

        

        success: function (data) {

        //console.log(data.city); // this is good

    

          if(data.status ==200){

             $('#loadingDiv').hide();

         

             

             swal("Good job!", "Added Successfully", "success");



             $('#question_form')[0].reset();

            window.location = "{{URL::to('user-form')}}";

            //location.reload();



          }else if(data.status ==202){



              $('#loadingDiv').hide();

            swal("Good job!", "User alert Exist", "success");

            //location.reload();



              }else if(data.status ==203){



              $('#loadingDiv').hide();

            swal("Good job!", "Successfully Updated", "success");

               location.reload();



          }else{



             $('#loadingDiv').hide();

            

             swal("Good job!", "You clicked the button!", "error");



          }

          

        }

      });



            



          });






</script>





 @stop