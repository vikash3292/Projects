

@extends('layouts.superadmin_layout')

@section('content')





<div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">KRA Detail</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>

                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">KRA Detail</a>

                                    </li>

                                </ol>

                            </div>

                            <div class="col-sm-6">

                                <div class="float-right">

                                      @if($existtkra > 0)

                                    <a href="{{URL::to('export-kra-user')}}/{{$kra_id}}/{{$assign_id}}" class="btn btn-primary">CSV Download</a>

                                    @endif

                                    

                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <!-- end row -->

                    <form id="user_fill_kra_form">

                    <div class="row">

                        <div class="col-12">

                            <div class="card m-t-20">

                                <div class="card-body">

                                    <div class="col-sm-12 p-0">



                                              <table class="table" border="1">
                                            <thead>
                                                <tr>
                                                    <td colspan="4">
                                                       <h5 class="text-center"> Key Responsibility Areas</h5>
                                                    </td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th>Name</label></th>
                                                    <td><input type="text"  disabled class="form-control" value="{{$kra->name}}"></td>
                                                    <th>Emp ID</th>
                                                    <td><input type="text" class="form-control" name="emp_id" @if(!empty($info->emp_id))  disabled value="{{$info->emp_id}}" @endif required="" /></td>
                                                </tr>
                                                 <tr>
                                                    <th>Designation</th>
                                                    <td> <input type="text"  disabled class="form-control" value="{{$kra->positionname}}"></td>
                                                    <th>DOJ</th>
                                                    <td><input type="date" class="form-control" name="doj" id="doj" @if(!empty($info->doj))  disabled value="{{$info->doj}}" @endif required=""/></td>
                                                </tr>
                                                 <tr>
                                                    <th>Projects done in this Period</th>
                                                    <td><input type="text" class="form-control" name="p_period" @if(!empty($info->p_period))  disabled value="{{$info->p_period}}" @endif required=""/></td>
                                                    <th>Period</th>
                                                    <td>
                                                        <input type="date" class="form-control" name="s_period" @if(!empty($info->s_period))  disabled value="{{$info->s_period}}" @endif required=""/>
                                                        <input type="date" class="form-control" name="e_period" @if(!empty($info->e_period))  disabled value="{{$info->e_period}}" @endif required=""/>
                                                    </td>
                                                </tr>
                                                 <tr>
                                                    <th>Status</th>
                                                    <td>
                                                         <select class="form-control" disabled>

                                                            <option>{{$kra->status}}</option>
                                                       </select>
                                                    </td>
                                                    <th></th>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>


                                    </div>

                                    <hr>

                                    

                                    <div class="col-sm-12 m-t-20">

                                        <h4 class="h4after">Task

                                            @if($user_fill == 0)



                                            <button type="submit" value="2" class="btn btn-primary float-right">Save & Submit</button>

                                      



                                          

                                           @elseif($manager_fill == 0 && $role == 3)



                                            <button type="submit" value="2" class="btn btn-primary float-right">Save & Submit</button>

                                      



                                            @endif

                                                        <!-- <button type="submit"  value="1" class="btn btn-primary float-right m-r-5">Save</button> -->

                                        </h4>

                                    </div>

                                    <div class="col-sm-12 m-t-20 table-responsive">

                                    

                                        <table id="datatable2" class="table nowrap" border="1"
                                            style="border-collapse: collapse; border-spacing: 0; width: 100%;white-space: break-spaces;">

                                            <thead>

                                                <tr style="background-color: #ededed;">

                                                    <th  style="width:40%">Tasks</th>

                                                    <th>Contribution %</th>

                                                    <th>Measurment</th>

                                                    <th>Target</th>

                                                    <th>Actual</th>

                                                 

                                                    <th>Manager's Feedback(%)</th>

                                                  

                                                   

                                                    <th>Remarks</th>



                                                  

                                                    <th>Manager's Remark</th>

                                                   

                                                   

                                                </tr>

                                            </thead>

                                            <tbody>



                                            <input type="hidden" name="kra_id" value="{{$kra_id}}">

                                            <input type="hidden" name="existtkra" value="{{$existtkra}}">

                                            <input type="hidden" name="assign_id" value="{{$assign_id}}">

                                           

                                                 @php($total_contbution = 0)
                                           @php($total_target = 0)
                                                  @php($total_actual = 0)
                                           @php($total_manager = 0)

                                            @foreach($view_task as $f => $view_tasks)


                                              <?php

                                             $total_contbution +=$view_tasks->con_sum;
                                               $total_target +=$view_tasks->target;
                                               $total_actual += $view_tasks->actual_sum??0;
                                               $total_manager += $view_tasks->manager_sum??0;

                                             ?>



                                            @if($existtkra > 0)

                                       

                                            <input type="hidden" name="task_id[{{$f}}]" value="{{$view_tasks->id}}">



                                            @endif



<tr style="background-color: #d2d1f6;">

        <td style="width:40%">{{$view_tasks->task}} <input type="hidden" name="task[{{$f}}]" value="{{$view_tasks->task}}"></td>

        <td>{{$view_tasks->con_sum}}%</td>

        <td>{{$view_tasks->measurment}} <input type="hidden" name="measurment[{{$f}}]" value="{{$view_tasks->measurment}}"></td>

        <td>{{$view_tasks->target}} %<input type="hidden" name="target[{{$f}}]" value="{{$view_tasks->target}}"></td>

        <td>



        {{$view_tasks->actual_sum??''}}%

        

     

        </td>



      

        <td>



{{$view_tasks->manager_sum??''}}%





</td>







<td>

        

        <input type="text" class="form-controll" name="user_remark[{{$f}}]"  @if(!empty($view_tasks->actual_remark)) disabled value="{{$view_tasks->actual_remark}}"   @endif  required>

        

        

        </td>



     

       

        <td>

        

        <input type="text" class="form-controll" name="manager_remark[{{$f}}]"    @if($userid != $mng) disabled  @endif @if(!empty($view_tasks->manager_remark)) disabled value="{{$view_tasks->manager_remark}}"   @endif required>

        

        

        </td>

      

        

    </tr>



    @foreach($view_tasks->sub_task as $l => $sub_task)


 


                             @if($existtkra > 0)

                                       

                             <input type="hidden" name="sub_task_id[{{$f}}][{{$l}}]" value="{{$sub_task->id}}"></td>



                                       @endif



   

    <tr>

    <td>{{$sub_task->sub_task}} <input type="hidden" name="sub_task[{{$f}}][{{$l}}]" value="{{$sub_task->sub_task}}"></td>

  <td>{{$sub_task->contribution}} %<input type="hidden" name="contribution[{{$f}}][{{$l}}]" value="{{$sub_task->contribution}}"></td>

        <td>{{$sub_task->measurement}} <input type="hidden" name="sub_measurement[{{$f}}][{{$l}}]" value="{{$sub_task->measurement}}"></td>

        <td>{{$sub_task->target}}%  <input type="hidden" name="sub_target[{{$f}}][{{$l}}]" value="{{$sub_task->target}}"></td>

        <td>

        

      



      <select class="form-controll" name="user_actual[{{$f}}][{{$l}}]"  @if($existtkra > 0) disabled  @endif  >

     @for($i = 0; $i <= $sub_task->contribution; $i++)

      <option value="{{$i}}" @if((int)$sub_task->actual == $i)  selected  @endif  >{{$i}}%</option>



      @endfor



      </select>

        

        

    

        

        </td>



       

       

        <td>



        <select class="form-controll" name="manager_actual[{{$f}}][{{$l}}]"  @if($userid != $mng) disabled  @endif  @if(!empty($sub_task->manager))  disabled    @endif>



        @for($i = 0; $i <= $sub_task->contribution; $i++)

      <option  value="{{$i}}"  @if((int)$sub_task->manager == $i)  selected  @endif  >{{$i}}%</option>



      @endfor



    



</select>

  

        </td>

       

        

        <td></td>

    </tr>



   



    @endforeach



    @endforeach

   

 
       <tr style="background-color: #ededed;">

                                                    <td> Total </td>

                                                    <td>{{$total_contbution??0}}%</td>

                                                    <td></td>

                                                    <td>{{$total_target??0}}%</td>

                                                    <td>{{$total_actual??0.00}}%</td>

                                                    <td>{{$total_manager??0.00}}%</td>

                                                    <td></td>
                                                     <td></td>

                                                </tr>
                                                

                                            </tbody>

                                        </table>

                                        

                                    </div>



                                  
                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

              </form>


            <!-- content -->

            

            <div id="addtask" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"

                style="display: none; padding-right: 5px;" aria-modal="true">

                <div class="modal-dialog modal-lg">

                    <div class="modal-content">

                        <div class="modal-header">

                            <h5 class="modal-title mt-0" id="myModalLabel">Add Sub Task</h5>

                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

                        </div>

                        <div class="modal-body">

                            <div class="row">

                                <div class="col-sm-12">

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Task Name

                                                    <span class="text-danger">*</span></label>

                                                <div class="col-lg-8 col-form-label">

                                                    <input type="text" class="form-control" id="assets_name">

                                                    <div id="assets_name_error"></div>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Measurment<span

                                                        class="text-danger">*</span></label>

                                                <div class="col-lg-8 col-form-label">

                                                    <input type="text" class="form-control">

                                                    <div id="assets_type_error"></div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-sm-12">

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label p-r-0">Target<span

                                                        class="text-danger">*</span></label>

                                                <div class="col-lg-8 col-form-label">

                                                    <input type="text" class="form-control">

                                                    <div id="assets_type_error"></div>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-sm-6 text-right" style="padding-right: 30px;padding-top: 10px;">

                                            <button class="btn btn-primary" data-toggle="collapse" data-target="#addsubtask" class="font-blue p-10">Add Sub Task</button>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-sm-12">

                                <div class="row">

                                    <div class="col-sm-12">

                                      

                                        <div class="col-sm-12">

                                        <div class="collapse" id="addsubtask">

                                            <div class="card-body m-t-10" style="border:1px solid #ededed;">

                                                <div class="col-sm-12 p-0">

                                                    <div class="row">

                                                        <div class="col-md-6">

                                                            <div class="form-group row m-0">

                                                                <label for="empid" class="col-lg-4 col-form-label p-r-0">Add Sub Task<span

                                                                        class="text-danger">*</span></label>

                                                                <div class="col-lg-8 col-form-label">

                                                                    <input type="text" class="form-control">

                                                                    <div id="assets_type_error"></div>

                                                                </div>

                                                            </div>

                                                        </div>

                                                        <div class="col-md-6">

                                                            <div class="form-group row m-0">

                                                                <label for="empid" class="col-lg-4 col-form-label">Contribution<span

                                                                        class="text-danger">*</span></label>

                                                                <div class="col-lg-8 col-form-label">

                                                                    <input type="text" class="form-control">

                                                                    <div id="assets_type_error"></div>

                                                                </div>

                                                            </div>

                                                        </div>

                                                   

                                                    </div>

                                                </div>

                                            </div>

                                          </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                            </div>

                            <div class="row">

                                <div class="col-sm-12">

                                    <div class="row">

                                      

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="modal-footer">

                            <div class="row">

                                <div class="col-sm-12">

                                    <button class="btn btn-primary add_assets">Save</button>

                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <div id="edittask" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"

            style="display: none; padding-right: 5px;" aria-modal="true">

            <div class="modal-dialog modal-lg">

                <div class="modal-content">

                    <div class="modal-header">

                        <h5 class="modal-title mt-0" id="myModalLabel">Edit Task</h5>

                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

                    </div>

                    <div class="modal-body">

                        <div class="row">

                            <div class="col-sm-12">

                                <div class="row">

                                    <div class="col-md-6">

                                        <div class="form-group row m-0">

                                            <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Task Name

                                                <span class="text-danger">*</span></label>

                                            <div class="col-lg-8 col-form-label">

                                                <input type="text" class="form-control" id="assets_name">

                                                <div id="assets_name_error"></div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="col-md-6">

                                        <div class="form-group row m-0" id="fillsubtask">

                                            <label for="empid" class="col-lg-4 col-form-label">Designation<span

                                                    class="text-danger">*</span></label>

                                            <div class="col-lg-8 col-form-label">

                                                <input type="text" class="form-control">

                                                <div id="assets_type_error"></div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="col-md-6">

                                        <div class="form-group row m-0" id="fillsubtask">

                                            <label for="empid" class="col-lg-4 col-form-label">Status<span

                                                    class="text-danger">*</span></label>

                                            <div class="col-lg-8 col-form-label">

                                                <select class="form-control">

                                                <option>Activated</option>

                                                <optoin>Deactivated</optoin>

                                                </select>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>  

                    </div>

                    <div class="modal-footer">

                        <div class="row">

                            <div class="col-sm-12">

                                <button class="btn btn-primary add_assets">Save</button>

                                <button class="btn btn-default" data-dismiss="modal">Cancel</button>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        </div>



        @stop





        

@section('extra_js')







<script>









$("form#user_fill_kra_form").submit(function(e) {

e.preventDefault();

doj = $('#doj').val();




                  var today = new Date();
                  var dd = String(today.getDate()).padStart(2, '0');
                  var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                  var yyyy = today.getFullYear();

                  today = yyyy + '-' + mm + '-' + dd;

                  var d1 = Date.parse(today);
                  var d2 = Date.parse(doj);
                  if (d1 < d2) {
                      alert ("Please Select Valid Date");
                      return false;
                  }



$('#loadingDiv').show();



var token = "{{csrf_token()}}"; 





$.ajax({

url: '/insert_kra',

headers: {'X-CSRF-TOKEN': token}, 

type: "post",

data:$(this).serialize(),



success: function (data) {

//console.log(data.city); // this is good



if(data.status ==200){

 $('#loadingDiv').hide();







alertify.success(data.msg);



 //swal("Good job!", "Added Successfully", "success");



history.back();



}else if(data.status ==202){



  $('#loadingDiv').hide();

  alertify.success(data.msg);

// swal("Good job!", "User alert Exist", "success");

//location.reload();



  }else if(data.status ==203){



  $('#loadingDiv').hide();

  alertify.success(data.msg);

// swal("Good job!", "Successfully Updated", "success");

   //location.reload();



}else{



 $('#loadingDiv').hide();

 alertify.error(data.msg);

// swal("Good job!", "You clicked the button!", "error");



}



}

});







});









$(function () {



	$("#form-horizontal").steps({



		headerTag: "h3",



		bodyTag: "fieldset",



		transitionEffect: "slide"



	});



});



  $(document).ready(function(){
        $('#datatable2').DataTable( {
                order: [],
                columnDefs: [ { orderable: false, targets: [0,1,2,3,4,5,6] } ],
                "scrollX": true,
                "paging": false
             } );     
  });

</script>











@stop