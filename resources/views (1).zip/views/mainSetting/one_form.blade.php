@extends('layouts.superadmin_layout')
@section('content')
     <div class="content p-0">
            <div class="container-fluid">
            <div class="page-title-box">
<div class="row align-items-center bredcrum-style">
<div class="col-sm-6">
<h3 class="page-title">One-to-One Form</h3>
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
<li class="breadcrumb-item active"><a href="javascript: history.go(-1)">One-to-One Form</a></li>
</ol>
</div>
<div class="col-sm-6 text-right">
<a href="javascript:history.go(-1)" class="btn btn-primary" id="backLink">Back</a>
</div>
</div>
</div>
<div class="row">
    <div class="col-sm-6">
        <form id="quertion_from">
 <div class="row">
     <div class="col-sm-12">
      <div class="card one_to_form_top m-t-10">
                        <div class="card-body">
                                <div class="row m-b-10">
                                    <div class="col-sm-12">
                                    <h5 class="m-t-0">Form Name</h5>
                                </div>
                            <div class="col-sm-12 m-b-10">
                                <input type="text" class="form-control fomt-20" placeholder="Untitled Form" name="title" readonly="" value="{{$form->form_name}}" id="title" required="" maxlenght="60" />
                            </div>
                            <div class="col-sm-12">
                                  <textarea class="form-control" placeholder="Description" id="desc" name="desc" @if(!empty($get_desc->desc)) readonly=""  @endif maxlenght="250">{{$get_desc->desc??''}}</textarea>
                            </div>
                            </div>
                            </div>
                            </div>
                            </div>
                            <div class="col-sm-12">
                     <div class="card one_to_form m-t-10">
                        <div class="card-body">
                            <div class="row m-b-10">
                                <div class="col-sm-12">
                                    <h5 class="m-t-0">Add Questions</h5>
                                </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" placeholder="Untitled Question" id="question" name="question" required=""  maxlenght="60"/>
                            </div>
                            <input type="hidden" name="form_id" id="form_id" value="{{$form_id}}">
                            <div class="col-sm-4">
                                <select class="form-control" id="category" name="category" onchange="question_value(this.value)">
                                    <option value="1">Input Box</option>
                                    <option value="2">radio</option>
                                    <option value="3">Dropdown</option>
                                    <option value="4">Checkbox</option>
                                </select>
                            </div>
                            </div>
                            
                             <div class="row " id="multiplechoice">
                             <div class="col-sm-12 m-b-10">


                                    <div class="row append_data">
     



                                

                                    </div>


                            </div>
                             <div class="col-sm-12">
                                    <div class="row">
       

                            </div>
                            </div>
                        </div>
                            <div class="col-sm-12 oneformfooter m-t-10 p-0">
                                <div class="alignment">
                                    <div class="iewQuestionFooterFooterRight">
                                        <div>
                                            <div class="togglebutton custom-control custom-switch inline-block" title="Active">
                                                        <input type="checkbox" checked="" name="required_field" id="required_field" class="custom-control-input" id="required">
                                                        <label class="custom-control-label" for="customSwitches156">Required
                                                        </label>
                                                                                                            </div>
                                        </div>
                                       <!--  <div class="formfooterseprate">
                                            
                                        </div> -->
                                       <!--  <div>
                                            <i class="fa fa-trash font-18"></i>
                                        </div> -->
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Submit">
                            </div>
                            </div>
                            </div>
                            </div>
                            </div>
                            </form>
                            </div>
                        
                        <div class="col-sm-6">
                                <div class="row view_question_form">
                                   
                        </div>
                        </div>
                        </div>
            </div>
    </div>
      <div id="editquestion" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                style="display: none; padding-right: 5px;" aria-modal="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title mt-0" id="myModalLabel">Add Sub Task</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="row edit_question">
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
@endsection
 @section('extra_js')

  <script type="text/javascript">

   var form_id = '{{$form_id}}';


   fetch_form();

    function fetch_form(){


    var _token = "{{csrf_token()}}";
    

$.ajax({
    url: '/fetch_all_question',
    type: "post",
    data: {"_token": _token,"form_id":form_id},
   // dataType: 'JSON',
//       beforeSend: function() {
//     // setting a timeout
//     $('#loadingDiv').show();
// },
    success: function (data) {
      //console.log(data); // this is good
      $('#loadingDiv').hide();
    $('.view_question_form').html(data);
          
    }
  });


    }
 

function question_value(qval){
    var html_data = '';
    if(qval == 2){

     html_data += '<div class="col-1 p-10 text-center"><input type="radio" id="male" name="gender" value="male" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 p-10 text-center"><span onclick="add_row('+qval+')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>';
  
   }else if(qval == 3){

    html_data += '<div class="col-1 p-10 text-center"><i class="fa fa-circle"></i></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 p-10 text-center"><span onclick="add_row('+qval+')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>';


   }else if(qval == 4){

    html_data += '<div class="col-1 p-10 text-center"><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div>';
     html_data += '<div class="col-1 p-10 text-center"><span onclick="add_row('+qval+')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>';


   }
    
    console.log(html_data);

    $('.append_data').html(html_data);

}
 
 function add_row(inpu_val){

   

     html_data = '';

     if(inpu_val == 2){

        html_data += '<div class="col-12"><div class="row m-t-10"><div class="col-1 p-10 text-center"><input type="radio" id="male" name="gender" value="male" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div><div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>';
     // html_data += '<div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20 p-10"></i></a></div>';
    

     }else if(inpu_val == 3){

        html_data += '<div class="col-12"><div class="row m-t-10"><div class="col-1 p-10 text-center"><i class="fa fa-circle"></i></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div><div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>';
     // html_data += '<div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20 p-10"></i></a></div>';
    

     }else if(inpu_val == 4){

        html_data += '<div class="col-12"><div class="row m-t-10"><div class="col-1 p-10 text-center"><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" disabled></div><div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60"></div><div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div></div>';
     // html_data += '<div class="col-1 p-10 text-center"><a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a></div></div>';
    

     }
     

    $('.append_data').append(html_data);

 }

 function remove_field(input){

     console.log(input);

    $(input).parent().parent().remove();
 }

//  $('.append_data').on("click",".remove_field", function(e){ //user click on remove text
//         e.preventDefault(); $(this).parent('div').remove(); 
//     });
 




  $("form#quertion_from").submit(function(e) {

 
            e.preventDefault();

           

    var  title = $('#title').val();
    var  question = $('#question').val();
    

    if(title.replace(/\s/g,'') ==''){
        alert('Please Enter Form name');
        return false;
    }

        if(question.replace(/\s/g,'') ==''){
        alert('Please Enter Question');
        return false;
    }


     $('#loadingDiv').show();

   var token = "{{csrf_token()}}"; 


  $.ajax({
        url: '/insert_question',
        headers: {'X-CSRF-TOKEN': token}, 
        type: "post",
        data:$(this).serialize(),
        
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
            $('#title').attr('readonly','readonly');
             $('#desc').attr('readonly','readonly');

             $('#question').val('');
             $('#category option[value="1"]').attr("selected", "selected");
             question_value(1);
              fetch_form();

         alertify.success(data.msg);

             //swal("Good job!", "Added Successfully", "success");

            //location.reload();

          }else if(data.status ==202){

              $('#loadingDiv').hide();
              alertify.success(data.msg);
           // swal("Good job!", "User alert Exist", "success");
            //location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
              alertify.success(data.msg);
           // swal("Good job!", "Successfully Updated", "success");
               //location.reload();

          }else{

             $('#loadingDiv').hide();
             alertify.error(data.msg);
            // swal("Good job!", "You clicked the button!", "error");

          }
          
        }
      });

            

          });





</script>


 @stop