@extends('layouts.superadmin_layout')

@section('content')



 <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">User Form</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>

                                 

                                </ol>

                            </div>

                            

                        </div>

                    </div>



                    @if(Session::has('msg'))

<p class="alert alert-danger">{{ Session::get('msg') }}</p>

@endif

                    <!-- end row -->

                    <!-- end row -->

                    <div class="row">

                        <div class="col-12">

                            <div class="card m-t-20">

                                <div class="card-body">

                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"

                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                                        <thead>

                                            <tr>

                                                <th>Form Name</th>

                                                <th>Year</th>

                                                <th>Month</th>

                                                 <th>Status</th>

                                                <th>Actions</th>

                                            </tr>

                                        </thead>

                                        <tbody>



                                        	@foreach($form as $forms)

                                            <tr>

                                                <td>{{$forms->form_name}}</td>

                                                <td>

                                                

                                                

                                              

                                                {{$forms->year}}

                                                

                                                

                                                </td>

                                                 <td>

                                                

                                                

                                              

                                                {{$forms->month}}

                                                

                                                

                                                </td>

                                                <td class="active-text">

                                                  



                                           

                                               @if($forms->view > 0)



                                                Filled



                                               @else

                                                 

                                               No Entry



                                               @endif



                                 



                                                </td>

                                                <td>



                                                @if($forms->view > 0)



                                               <a  href="{{URL::to('view-form')}}/{{$forms->id}}/{{$forms->assign_id}}">

                                                       <i class="fa fa-eye" aria-hidden="true"></i>

                                                </a>



@else

  

<a  href="{{URL::to('view-form')}}/{{$forms->id}}/{{$forms->assign_id}}">

                                                       <i class="fa fa-eye" aria-hidden="true"></i>

                                                </a>



@endif





                                                	



                                                	  

                                                   

                                                   

                                                </td>

                                            </tr>

                                            @endforeach

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>



            @stop



            @section('extra_js')



<script>





function change_hide_status(menustaus,menuid){

  

  var _token = "{{csrf_token()}}";



   $.ajax({

       url: '/question_form',

       type: "post",

       data: {"_token": _token,"menuid":menuid,"menustaus":menustaus},

       dataType: 'JSON',

         beforeSend: function() {

       // setting a timeout

       $('#loadingDiv').show();

   },

       success: function (data) {

         //console.log(data); // this is good



          // return false;

         if(data.status ==200){

            $('#loadingDiv').hide();

        

            

           // swal("Good job!", data.msg, "success");

            alertify.success(data.msg);

            



         }else if(data.status ==202){



             $('#loadingDiv').hide();

             alertify.success(data.msg);

          // swal("Good job!",  data.msg, "success");

          // location.reload();



             }else if(data.status ==203){



             $('#loadingDiv').hide();

           //swal("Good job!",  data.msg, "success");

           alertify.success(data.msg);





         }else{



            $('#loadingDiv').hide();

           

           // swal("Good job!",  data.msg, "error");

            alertify.error(data.msg);



         }

         

       }

     });

}









</script>



@stop