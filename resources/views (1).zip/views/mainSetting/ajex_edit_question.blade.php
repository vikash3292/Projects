<form id="quertion_from">

 <div class="row">

     <div class="col-sm-12">

      <div class="card one_to_form_top m-t-10">

                   

                            </div>

                            </div>

                            <div class="col-sm-12">

                     <div class="card one_to_form m-t-10">

                        <div class="card-body">

                            <div class="row m-b-10">

                            <div class="col-sm-8">

                                <input type="text" class="form-control" placeholder="Untitled Question" id="question" name="question" value="{{$edit->question}}" required=""  maxlenght="60"/>

                            </div>

                            <div class="col-sm-4">

                                <select class="form-control" id="category" name="category" onchange="question_value(this.value)">

                                    <option value="1" @if($edit->category == 1)  selected @endif>Input Box</option>

                                    <option value="2" @if($edit->category == 2)  selected @endif>radio</option>

                                    <option value="3" @if($edit->category == 3)  selected @endif>Dropdown</option>

                                    <option value="4" @if($edit->category == 4)  selected @endif>Checkbox</option>

                                </select>

                            </div>

                            </div>

                            <input type="hidden" name="question_id" value="{{$edit->id}}">

                             <div class="row " id="multiplechoice">
                             <div class="col-sm-12 m-b-10">
                                    <div class="row append_data">
                                      @if($edit->category == 2)
                                     @foreach(json_decode($edit->ans) as $k => $option)
                                     @if($k == 0)
                                     <div class="col-1 text-center p-10"><input type="radio" id="male" name="gender" value="male" disabled></div>
                                     <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}">
                                     </div>
                                         <div class="col-1 p-10 text-center">
                                          <span onclick="add_row('{{$edit->category}}')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span>
                                        </div>
                                         @else
                                          <div class="col-1 text-center p-10">
                                           <input type="radio" id="male" name="gender" value="male" disabled>
                                         </div>
                                           <div class="col-10">
                                            <input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}">
                                          </div>                                    
                                       <div class="col-1 p-10 text-center">
                                          <a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a>
                                         </div>
                                       </div>
                                         @endif
                                     @endforeach
                                      @elseif($edit->category == 3)
                                      @foreach(json_decode($edit->ans) as $k => $option)
                                      @if($k == 0)
                                        <div class="col-1 text-center p-10">
                                        <i class="fa fa-circle font-20"></i>
                                      </div>
                                     <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                         <div class="col-1 text-center p-10">
                                          <span onclick="add_row('{{$edit->category}}')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span>
                                         </div>
                                         @else
                                          <div class="col-1 text-center p-10"><i class="fa fa-circle font-20"></i></div>
                                          <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                         <div class="col-1 p-10 text-center">
                                          <a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a>
                                         </div>
                                     </div>
                                         @endif
                                      @endforeach
                                      @elseif($edit->category == 4)
                                      @foreach(json_decode($edit->ans) as $k => $option)
                                      @if($k == 0)
                                      <div class="col-1 text-center p-10">
                                         <input type="checkbox" id="male" name="gender" value="male" disabled>
                                      </div>
                                     <div class="col-10">
                                     
                                      <input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}">
                                    </div>
                                                                        <div class="col-1 p-10 text-center"><span onclick="add_row('{{$edit->category}}')"><i class="fa fa-plus-circle font-20" aria-hidden="true"></i></span></div>

                                 



                                         @else


<div class="col-12">
                                         <div class="row m-t-10"> 
                                        <div class="col-1 text-center p-10">
                                         <input type="checkbox" id="male" name="gender" value="male" disabled>
                                      </div>
                                          <div class="col-10"><input type="text" name="answer[]" class="form-control display-inline" width="100%" required maxlenght="60" value="{{$option}}"></div>
                                         <div class="col-1 p-10 text-center">
                                          <a href="javascript:void(0)" onclick="remove_field(this)"><i class="fa fa-times font-20"></i></a>
                                        </div>
                                      </div>
                                      </div>
                                    </div>



                                         @endif





                                       @endforeach



                                      @endif


 <div class="col-sm-12 oneformfooter m-t-10">

                                <div class="alignment">

                                    <div class="iewQuestionFooterFooterRight">

                                        <div>

                                            <div class="togglebutton custom-control custom-switch inline-block" title="Active">

                                                        <input type="checkbox" checked="" name="required_field" id="required_field" class="custom-control-input" id="required">

                                                        <label class="custom-control-label" for="customSwitches156">Required

                                                        </label>

                                                                                                            </div>

                                        </div>

                                      <!--   <div class="formfooterseprate">

                                            

                                        </div> -->

                                       <!--  <div>

                                            <i class="fa fa-trash font-18"></i>

                                        </div> -->

                                    </div>

                                </div>

                                <input type="submit" class="btn btn-primary" value="submit">

                            </div>
                                



                                    </div>





                            </div>

                             <div class="col-sm-12">

                                    <div class="row">

       



                            </div>

                            </div>

                        </div>

                           

                            </div>

                            </div>

                            </div>

                            </div>

                        </form>

