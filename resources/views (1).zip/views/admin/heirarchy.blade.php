@extends('layouts.superadmin_layout')



@section('extra_css')



<style>
  figure{
            margin: 20px 0 1rem;
            overflow: auto;
        }
        .tree,
        .tree ul,
        .tree li {
            list-style: none;
            margin: 0;
            padding: 0;
            position: relative;
        }

        .tree {
            width: 100%;
            margin: 0 0 1em;
            text-align: center;
        }
        .tree,
        .tree ul {
            display: table;
        }

        .tree ul {
            width: 100%;
        }

        .tree li {
            display: table-cell;
            padding: .5em 0;
            vertical-align: top;
        }

        /* _________ */
        .tree li:before {
            outline: solid 1px #666;
            content: "";
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
        }

        .tree li:first-child:before {
            left: 50%;
        }

        .tree li:last-child:before {
            right: 50%;
        }

        .tree code,
        .tree span {
            border: solid .1em #666;
            border-radius: .2em;
            display: inline-block;
            margin: 0 .2em .5em;
            padding: .2em .5em;
            position: relative;
        }

        .tree div {
            display: inline;
            border: solid .1em #666;
            border-radius: .2em;
            display: inline-block;
            margin: 37px .2em .5em;
            padding: 15px 10px 5px 10px;
            position: relative;
        }
        .tree img{
            position: absolute;
            top: -35px;
            left: 50%;
            transform: translate(-50%, 0);
            border: 2px solid #666;
            border-radius: 50%;
            background-color: #fff;
        }
        .tree p{
            margin: 0;
        }

        /* If the tree represents DOM structure */
        .tree code {
            font-family: monaco, Consolas, 'Lucida Console', monospace;
        }

        /* | */
        .tree ul:before,
        .tree code:before,
        .tree span:before,
        .tree div:before {
            outline: solid 1px #666;
            content: "";
            height: .5em;
            left: 50%;
            position: absolute;
        }

        .tree ul:before {
            top: -8px;
        }

        .tree code:before,
        .tree span:before,
        .tree div:before {
            top: -43px;
        }

        /* The root node doesn't connect upwards */
        .tree>li {
            margin-top: 0;
        }

        .tree>li:before,
        .tree>li:after,
        .tree>li>code:before,
        .tree>li>span:before {
            outline: none;
        }
    </style>



@stop



@section('content')



  <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">Employee Heirarchy</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="index.html">Employee</a></li>

                                    <li class="breadcrumb-item active"><a href="#">Employee Heirarchy</a>

                                    </li>

                                </ol>

                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <!-- end row -->

                    <div class="row">

                        <div class="col-12">

                            <div class="card m-t-20">

                                <div class="card-body">
                                    <figure>

                                        <figcaption><h4 class="m-0">Users Heirarchy</h4></figcaption>



                                        @if(!empty($users))



                                        <ul class="tree">



                                        @foreach($users as $userss)

                                          <li>
 <div>
                                                        <img src="{{$userss['profile']}}" height="50" width="50">
                                                        <p><b>{{$userss['userfullname']}}</b></p>
                                                        <p>{{$userss['role']}}</p>
                                                    </div>

                                          @if(!empty($userss['sub']))

                                            <ul>

                                            @foreach($userss['sub'] as $sub_users)

                                              <li>
 <div>
                                                        <img src="{{$sub_users['profile']}}" height="50" width="50">
                                                        <p><b>{{$sub_users['userfullname']}}</b></p>
                                                        <p>{{$sub_users['role']}}</p>
                                                    </div>

                                              @if(!empty($sub_users['sub']))

                                                <ul>

                                                @foreach($sub_users['sub'] as $sub_sub_users)

                                                  

                                                  <li>
 <div>
                                                        <img src="{{$sub_sub_users['profile']}}" height="50" width="50">
                                                        <p><b>{{$sub_sub_users['userfullname']}}</b></p>
                                                        <p>{{$sub_sub_users['role']}}</p>
                                                    </div>

                                                  @if(!empty($sub_sub_users['sub']))

                                                    <ul>

                                                      @foreach($sub_sub_users['sub'] as $sub_sub_sub_user)

                                                      <li>
 <div>
                                                        <img src="{{$sub_sub_sub_user['profile']}}" height="50" width="50">
                                                        <p><b>{{$sub_sub_sub_user['userfullname']}}</b></p>
                                                        <p>{{$sub_sub_sub_user['role']}}</p>
                                                    </div>

                                                      @if(!empty($sub_sub_sub_user['sub']))

                                                        <ul>

                                                        @foreach($sub_sub_sub_user['sub'] as $sub_sub_sub_sub_users)

                                                          <li>
 <div>
                                                        <img src="{{$sub_sub_sub_sub_users['profile']}}" height="50" width="50">
                                                        <p><b>{{$sub_sub_sub_sub_users['userfullname']}}</b></p>
                                                        <p>{{$sub_sub_sub_sub_users['role']}}</p>
                                                    </div>
                                                    </li>

                                                          @endforeach

                                                        </ul>

                                                        @endif

                                                      </li>

                                                      @endforeach

                                                    </ul>

                                                    @endif

                                                  </li>

                                                  @endforeach

                                                  

                                                 

                                                </ul>

                                                @endif

                                              </li>

                                              @endforeach

                                            </ul>

                                            @endif

                                            

                                          </li>

                                          @endforeach

                                        </ul>

                                        @endif

                                      </figure>

                                     
                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>



            @stop