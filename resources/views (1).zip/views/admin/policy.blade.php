@extends('layouts.superadmin_layout')
   @section('content')
 <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Company Policy</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Policy List</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right d-none d-md-block">
                                      @if(PermissionHelper::frontendPermission('add-policy'))
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#add_policy">
                                        Add Policy</button>
                                        @endif
                                        
                                </div>
                            </div>
                        </div>
                    </div>

                    @if(Session::has('message'))
<p class="alert alert-info">{{ Session::get('message') }}</p>
@endif
                     <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body table-responsive">
 <table id="datatable" class="datatable table appraisal_form_fill">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Policy Name</th>
                                                <th class="text_ellipses">Description</th>
                                                <th class="text_ellipses">Upload File</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @php($i = 1)
                                        @foreach($policy as $policys)
                                            <tr>
                                                <td>
                                                    {{$i++}}
                                                </td>
                                                <td>{{$policys->title}}</td>
                                                <td class="text_ellipses">{!!$policys->desc!!}</td>
                                                <td class="text_ellipses">
                                                @if(!empty($policys->files))
                                                <ul class="p-0">
                                                 @foreach(explode(',',$policys->files)  as $files)
                                                 <li>
                                                 <a href="{{URL::to('public')}}/{{$files}}" data-toggle="tooltip" title="{{str_replace('/uploads/attach/files/','',$files)}}"> {{str_replace('/uploads/attach/files/','',$files)}}</a>
                                                    </li> 
                                                 @endforeach

                                                 </ul>

                                                @endif
                                                
                                                
                                                </td>
                                                <td>
                                                	 <a href="{{URL::to('view-policy')}}/{{$policys->id}}"><i class="mdi mdi-eye text-info"></i></a>
                                                     @if(PermissionHelper::frontendPermission('edit-policy'))
                                                   <i  onclick="get_policy_data('{{$policys->id}}')" class="mdi mdi-pen text-warning"></i>
                                                   @endif
                                                     @if(PermissionHelper::frontendPermission('delete-policy'))
                                                    <a  onclick="return confirm('Are you sure you want to delete ?');" href="{{URL::to('delete-policy')}}/{{$policys->id}}"> <i class="fa fa-trash" aria-hidden="true"></i></a>
                                                @endif
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                                </div>
                            </div>






  <div id="add_policy" class="modal fade" role="dialog">
	<div class="modal-dialog modal-lg">

		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title mt-0 policy_text">Add Policy</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group row">
							<label for="empid" class="col-lg-4 col-form-label">
								Policy Name <span class="text-danger">*</span></label>
								<div class="col-lg-8">
									<input type="text" class="form-control" id="policy_name">
                                    <span id="policy_name_error"></span>
								</div>
							</div>
						</div>
                        <input type="hidden" id="policy_id">
							<div class="col-md-6">
								<div class="form-group row">
									<label for="empid" class="col-lg-4 col-form-label">
										File Upload </label>
										<div class="col-lg-8">
											<input type="file" id="files" multiple class="form-control p-0">
                                            <span id="files_error"></span>
										</div>
									</div>
								</div>
						<div class="col-md-12">
							<div class="form-group row">
								<label for="empid" class="col-lg-12 col-form-label">
									Description <span class="text-danger">*</span></label>
									<div class="col-lg-12">
										<textarea  id="desc" name="desc" class="form-control"></textarea>
                                        <span id="desc_error"></span>
									</div>
								</div>
							</div>
						

							</div>
						</div>
						<div class="modal-footer text-right">
							<button onclick="save_policy()"  class="btn btn-primary">Save</button>
							
						</div>
					</div>
				</div>

                            @stop

                            @section('extra_js') 


  <script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>


                            <script>


function get_policy_data(policy_id){


var _token = "{{csrf_token()}}";

$.ajax({
    url: '/get_policy',
    type: "post",
    data: { "_token": _token,"policy_id":policy_id},
    dataType: 'JSON',

    success: function (data) {
      //  console.log(data.allclient); // this is good

       $('.policy_text').text('Edit');
       $('#policy_name').val(data.policy.title);
       $('#policy_id').val(data.policy.id);
       CKEDITOR.instances.desc.setData( data.policy.desc);
     $('#add_policy').modal('show');


    }
});

}
  

function save_policy(){

error = 1;

var files = $('#files').val();

var policy_name = $('#policy_name').val();
var policy_id = $('#policy_id').val();


var desc = CKEDITOR.instances.desc.getData();

          if(policy_name ==''){
         $('#policy_name_error').text('Policy is Required').attr('style','color:red');
         $('#policy_name_error').show();
           error = 0;
              return false;
      }else{$('#policy_name_error').hide();  error = 1;}

      if(desc ==''){
         $('#desc_error').text('DESC is Required').attr('style','color:red');
         $('#desc_error').show();
           error = 0;
              return false;
      }else{$('#desc_error').hide();  error = 1;}


// var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
//   if(!allowedExtensions.exec(profile)){
//       $('#profile_error').text('Valid Image').attr('style','color:red');
//        $('#profile_error').show();
//          error = 0;
//       fileInput.value = '';
//       return false;
//   }





formData  =  new FormData();
//var files = $('#files')[0].files[0];

console.log( $('input[type=file]')[0].files);


var files =$('input[type=file]')[0].files;
console.log(files.length);

for(var i=0;i<files.length;i++){
    formData.append("images[]", files[i], files[i]['name']);

}

formData.append("policy_name", policy_name);
formData.append("desc", desc);
formData.append("policy_id", policy_id);

error =1;


  if(error ==1){

      $('#loadingDiv').show();

       var token = "{{csrf_token()}}";




  $.ajax({
  url: '/save_policy',
  headers: {'X-CSRF-TOKEN': token},                          
  type: "POST",
  cache: false,
  dataType:'json',
  processData: false,
  contentType: false,
  data:formData,
  success:function(data){

    if(data.status ==200){
      alertify.success(data.msg); 
       $('#loadingDiv').hide(); 
       location.reload();
     

   }
 }
  });

  }


}





// get_files();

// function get_files() {



//     var _token = "{{csrf_token()}}";

//     $.ajax({
//         url: '/all_form',
//         type: "post",
//         data: { "_token": _token },
//         dataType: 'JSON',

//         success: function (data) {
//           //  console.log(data.allclient); // this is good
//           $('table.show_all_files tbody').html(data.all_files);


//         }
//     });
// }

//  function delete_file(element,file_id) {



//     var _token = "{{csrf_token()}}";

//     $.ajax({
//         url: '/delete_form',
//         type: "post",
//         data: { "_token": _token, "file_id": file_id },
//         dataType: 'JSON',

//         success: function (data) {
//           //  console.log(data.allclient); // this is good
//           //$('table.show_all_files tbody').html(data.all_files);
//           $(element).parent().parent().remove();
//            alertify.success(data.msg);
//              get_files();


//         }
//     });
// }

</script>





         <script>
   CKEDITOR.replace( 'desc' );
                 </script>

                            @stop