@extends('layouts.superadmin_layout')

   @section('content')

<div class="content p-0">

            <div class="container-fluid">

               <div class="page-title-box">

                  <div class="row align-items-center bredcrum-style">

                     <div class="col-sm-6 col-6">

                        <h3 class="page-title">Policy View</h3>

                        <ol class="breadcrumb">

                           <li class="breadcrumb-item"><a href="index.html">GRC</a></li>

                           <li class="breadcrumb-item active"><a href="">Policy View</a></li>

                        </ol>

                     </div>

                     <div class="col-sm-6 col-6">

                        <div class="float-right d-md-block">

                           <div class="dropdown">
                                    <a href="javascript: history.go(-1)"  class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light">Back</a>

                           </div>

                        </div>

                     </div>

                  </div>

               </div>

               <!-- end row -->

               <div class="row">

                  <div class="col-12">

                     <div class="card m-t-20">

                        <div class="card-body">

                           <div class="width-float">

                              <div class="row">

                                 <div class="col-md-6">

                                    <div class="form-group row m-0">

                                       <label for="empcode" class="col-lg-4 col-form-label">Policy Name</label>

                                       <div class="col-lg-8 col-form-label">

                                          <label class="myprofile_label">{{$viewpolicy->title}}</label>

                                       </div>

                                    </div>

                                 </div>

                                 <div class="col-md-6">

                                    <div class="form-group row m-0">

                                       <label for="empid" class="col-lg-4 col-form-label">Description</label>

                                       <div class="col-lg-8 col-form-label">

                                          <label class="myprofile_label">{!!$viewpolicy->desc!!}</label>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                              <div class="row">

                                 <div class="col-md-6">

                                    <div class="form-group row m-0">

                                       <label for="prifix" class="col-lg-4 col-form-label">Uploaded File</label>

                                       <div class="col-lg-8 col-form-label">



                                            @if(!empty($viewpolicy->files))

                                            <ul class="p-0">

                                                 @foreach(explode(',',$viewpolicy->files)  as $files)

                                                 <li>

                                                 <a href="{{URL::to('public')}}/{{$files}}">   {{str_replace('/uploads/attach/files/','',$files)}} </a>

                                                   </li>

                                                 @endforeach

</ul>

                                                @endif

                                       

                                       </div>

                                    </div>

                                 </div>

                              </div>

                           </div>

                        </div>

                     </div>

                  </div>

                  <!-- end col -->

               </div>

               <!-- end row -->

            </div>

            <!-- container-fluid -->

         </div>



         @stop