
@extends('layouts.dashboard_layout')
 @section('extra_css')
    <style>
              body{
                  font-family-sans-serif: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
              }
              .card{
                    box-shadow: 0 0 13px 0 rgba(48, 48, 211, 0.44);
              }
              .form-control{
                  /* height:calc(1.5em + .75rem + 10px); */
                  display: block;
    width: 100%;
    height: calc(1.5em + 1.5rem + 2px);
    padding: .75rem 1.25rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #8492a6;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #8492a6;
    border-radius: .25rem;
    box-shadow: inset 0 1px 1px rgba(31,45,61,.075);
    transition: all .2s ease;
              }
            
            .primary-color{
                color: #2974b6;
            }
            .wrapper-page a {
    color: #2974b6;
}
            .toggleBtnfilled {
    /* border: 1px solid #2974b6; */
    background: #2974b6;
    color: #fff !important;
    /* padding: 10px 20px;
    border-radius: 0px; */
    width: 100%;
    display: block;
    text-align: center;
    border: 1px solid transparent !important;
    padding: .75rem 1.75rem !important;
    font-size: 1rem !important;
    line-height: 1.5 !important;
    border-radius: .25rem !important;
}
.account-card .account-card-content {
    padding: 20px;
}


            .login-block{
    background: #DE6262;  /* fallback for old browsers */
background: -webkit-linear-gradient(to bottom, #FFB88C, #DE6262);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to bottom, #FFB88C, #DE6262); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
float:left;
width:100%;
padding : 50px 0;
}
.banner-sec{background:url(https://static.pexels.com/photos/33972/pexels-photo.jpg)  no-repeat left bottom; background-size:cover; min-height:500px; border-radius: 0 10px 10px 0; padding:0;}
.container{background:#fff; border-radius: 10px; box-shadow:15px 20px 0px rgba(0,0,0,0.1);}
.carousel-inner{border-radius:0 10px 10px 0;}
.carousel-caption{text-align:left; left:5%;}
.login-sec{padding: 50px 30px; position:relative;}
.login-sec .copy-text{position:absolute; width:80%; bottom:20px; font-size:13px; text-align:center;}
.login-sec .copy-text i{color:#FEB58A;}
.login-sec .copy-text a{color:#E36262;}
.login-sec h2{margin-bottom:30px; font-weight:800; font-size:30px; color: #DE6262;}
.login-sec h2:after{content:" "; width:100px; height:5px; background:#FEB58A; display:block; margin-top:20px; border-radius:3px; margin-left:auto;margin-right:auto}
.btn-login{background: #DE6262; color:#fff; font-weight:600;}
.banner-text{width:70%; position:absolute; bottom:40px; padding-left:20px;}
.banner-text h2{color:#fff; font-weight:600;}
.banner-text h2:after{content:" "; width:100px; height:5px; background:#FFF; display:block; margin-top:20px; border-radius:3px;}
.banner-text p{color:#fff;}
.wrapper-page a:hover{
      color: #2974b6;
}
.form-control:focus{
      border-color: #2974b6;
}
.field-icon{
      margin-top: -31px;
}
        </style>
  @stop
@section('content')
 <div class="card">
            <div class="row">
                <div class="col-sm-6">
                    <div class="wrapper-page">
                        <div class="card overflow-hidden account-card mx-3">
                              <div class="account-card-content">
                                  <div class="text-center">
                                      <img src=" {{URL::to('public/assets/images/kloudrac_new_logo-1.png')}}" height="45px" width="50px">
                                  </div>
                                    <div class="text-center position-relative mb-4">
                                                      <h3 style="font-size: 1.75rem;font-weight:500;margin-top: 20px;">Kloudrac HRMS</h3>
                                    </div>
                                   <form method="POST" class="form-horizontal m-t-30 col-sm-12" action="{{URL::to('sendlink')}}" aria-label="{{ __('Reset Password') }}">
                        @csrf

                        <div class="form-group">
                        <div class="row">
                              <div class="col-1 p-r-0">
                                    <i class="mdi mdi-email-mark-as-unread font-20"></i>
                              </div>
                              <div class="col-11">
                        <input type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"  name="email" value="{{ old('email') }}" maxlength="60" required placeholder="Registered Email Id">
                        @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                        </div>
                          @if(Session::has('message'))
                     <div class="col-12">
                        <p class="alert alert-info m-t-10">{{ Session::get('message') }}</p>
                     </div>
                   @endif
                     </div>
                  </div>

                        <div class="form-group m-t-10 mb-0 row">
                            <div class="col-12 m-t-20 text-center">
                                <button type="submit" class="btn toggleBtnfilled">
                                    {{ __('Reset Password') }}
                                </button>
                            </div>
                        </div>
                    </form>
                              </div>
                        </div>
                  </div>
                </div>
                <div class="col-md-6 banner-sec d-none d-sm-block d-xl-block d-md-block">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                         <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1" class=""></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                          </ol>
                    <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
              <img class="d-block img-fluid" src="{{URL::to('public/assets/images/1.png')}}" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid" src="{{URL::to('public/assets/images/2.png')}}" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid" src="{{URL::to('public/assets/images/3.png')}}" alt="First slide">
          </div>
                    </div>     
                    
                </div>
            </div>
            </div>
        </div>
<!--   <span class="logo_css">
          <a href="http://hrms.projectdemoonline.com"><h6><img src="{{URL::to('public/assets/images/hrms_logo.png')}}" alt="" height="40">KLOUDRAC HRMS</h6></a>
    </span>
 <div class="formWrapper">
        <div class="signUpWrapper">
         <div class="welcome-Box">
            <div class="text-center position-relative">
               <h5 class="font-30 m-b-20" style="margin-top:60px">CRM + HRMS</h5>
               <p>Enter Email to Reset Password </p>
            </div>
         </div>
          <div class="CreateAccount-Box">
                
                <div class="account-card-content row">
                <div class="text-center position-relative col-sm-12">
                        <h4 class="font-30 m-b-5">{{ __('Forgot Password') }}</h4>
                </div>
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" class="form-horizontal m-t-30 col-sm-12" action="{{URL::to('sendlink')}}" aria-label="{{ __('Reset Password') }}">
                        @csrf

                        <div class="form-group">
                        <div class="row">
                              <div class="col-1 p-r-0">
                                    <i class="mdi mdi-email-mark-as-unread font-20"></i>
                              </div>
                              <div class="col-11">
                        <input type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"  name="email" value="{{ old('email') }}" maxlength="60" required placeholder="Registered Email Id">
                        @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                        </div>
                          @if(Session::has('message'))
                     <div class="col-12">
                        <p class="alert alert-info m-t-10">{{ Session::get('message') }}</p>
                     </div>
                   @endif
                     </div>
                  </div>

                        <div class="form-group m-t-10 mb-0 row">
                            <div class="col-12 m-t-20 text-center">
                                <button type="submit" class="btn toggleBtnfilled">
                                    {{ __('Reset Password') }}
                                </button>
                            </div>
                        </div>
                    </form>
              
        </div>
               </div>
 </div> -->
 
<!--          <div class="col-sm-6">-->
<!--               <div class="wrapper-page wrapper-page-margin">-->
<!--                  <div class="overflow-hidden account-card mx-3">-->
<!--                     <div class="account-card-content">-->
<!--                        <div class="text-center position-relative">-->
<!--                           <h1 class="m-b-30">{{$mainsetting->site_title}}</h1>-->
<!--                           <p class="m-b-30">-->
<!--                              {{$mainsetting->site_desc}}-->
<!--                           </p>-->
<!--                        </div>-->
<!--                        <div class="text-left">-->
<!--                           <a href="{{URL::to('/')}}" class="logo">-->
<!--                           <img src="{{URL::to('/public')}}{{$mainsetting->company_logo}}" height="100" alt="logo">-->
<!--                           </a>-->
<!--                        </div>-->
<!--                     </div>-->
<!--                  </div>-->
<!--               </div>-->
<!--            </div>-->
<!--        <div class="col-md-6">-->
<!--            <div class="wrapper-page">-->
<!--                <div class="card overflow-hidden account-card mx-3">-->
<!--                  @if(Session::has('message'))-->
<!--                     <p class="alert alert-info">{{ Session::get('message') }}</p>-->
<!--                   @endif-->
<!--                <div class="account-card-content">-->
<!--                <div class="text-center position-relative">-->
<!--                        <h4 class="font-30 m-b-5">{{ __('Forgot Password') }}</h4>-->
<!--                </div>-->
<!--                    @if (session('status'))-->
<!--                        <div class="alert alert-success" role="alert">-->
<!--                            {{ session('status') }}-->
<!--                        </div>-->
<!--                    @endif-->

<!--                    <form method="POST" class="form-horizontal m-t-30" action="{{URL::to('sendlink')}}" aria-label="{{ __('Reset Password') }}">-->
<!--                        @csrf-->

<!--                        <div class="form-group">-->
<!--                        <div class="row">-->
<!--                              <div class="col-1 p-r-0">-->
<!--                                    <i class="mdi mdi-email-mark-as-unread font-20"></i>-->
<!--                              </div>-->
<!--                              <div class="col-11">-->
<!--                        <input type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"  name="email" value="{{ old('email') }}" maxlength="60" required placeholder="Registered Email Id">-->
<!--                        @if ($errors->has('email'))-->
<!--                                    <span class="invalid-feedback" role="alert">-->
<!--                                        <strong>{{ $errors->first('email') }}</strong>-->
<!--                                    </span>-->
<!--                                @endif-->
<!--                        </div>-->
<!--                     </div>-->
<!--                  </div>-->

<!--                        <div class="form-group m-t-10 mb-0 row">-->
<!--                            <div class="col-12 m-t-20">-->
<!--                                <button type="submit" class="btn btn-primary loginbtn">-->
<!--                                    {{ __('Send Password Reset Link') }}-->
<!--                                </button>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                    </form>-->
              
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<!--</div>-->
<script>
    // confirm password
function cnf_psd() {
    debugger
  var c = document.getElementById("cpassword");
  var d = document.getElementById("cnf_eye");
  if (c.type == "password") {
    c.type = "text";
    d.className = 'fa fa-eye-slash field-icon';
  } else {
    c.type = "password";
    d.className = 'fa fa-eye field-icon';
  }
}
</script>
@endsection
