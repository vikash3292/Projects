@extends('layouts.dashboard_layout')
  @section('extra_css')


        <style>
              body{
                  font-family-sans-serif: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
              }
              .card{
                    box-shadow: 0 0 13px 0 rgba(48, 48, 211, 0.44);
              }
              .form-control{
                  /* height:calc(1.5em + .75rem + 10px); */
                  display: block;
    width: 100%;
    height: calc(1.5em + 1.5rem + 2px);
    padding: .75rem 1.25rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #8492a6;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #8492a6;
    border-radius: .25rem;
    box-shadow: inset 0 1px 1px rgba(31,45,61,.075);
    transition: all .2s ease;
              }
            
            .primary-color{
                color: #2974b6;
            }
            .wrapper-page a {
    color: #2974b6;
}
            .toggleBtnfilled {
    /* border: 1px solid #2974b6; */
    background: #2974b6;
    color: #fff !important;
    /* padding: 10px 20px;
    border-radius: 0px; */
    width: 100%;
    display: block;
    text-align: center;
    border: 1px solid transparent !important;
    padding: .75rem 1.75rem !important;
    font-size: 1rem !important;
    line-height: 1.5 !important;
    border-radius: .25rem !important;
}
.account-card .account-card-content {
    padding: 20px;
}


            .login-block{
    background: #DE6262;  /* fallback for old browsers */
background: -webkit-linear-gradient(to bottom, #FFB88C, #DE6262);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to bottom, #FFB88C, #DE6262); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
float:left;
width:100%;
padding : 50px 0;
}
.banner-sec{background:url(https://static.pexels.com/photos/33972/pexels-photo.jpg)  no-repeat left bottom; background-size:cover; min-height:500px; border-radius: 0 10px 10px 0; padding:0;}
.container{background:#fff; border-radius: 10px; box-shadow:15px 20px 0px rgba(0,0,0,0.1);}
.carousel-inner{border-radius:0 10px 10px 0;}
.carousel-caption{text-align:left; left:5%;}
.login-sec{padding: 50px 30px; position:relative;}
.login-sec .copy-text{position:absolute; width:80%; bottom:20px; font-size:13px; text-align:center;}
.login-sec .copy-text i{color:#FEB58A;}
.login-sec .copy-text a{color:#E36262;}
.login-sec h2{margin-bottom:30px; font-weight:800; font-size:30px; color: #DE6262;}
.login-sec h2:after{content:" "; width:100px; height:5px; background:#FEB58A; display:block; margin-top:20px; border-radius:3px; margin-left:auto;margin-right:auto}
.btn-login{background: #DE6262; color:#fff; font-weight:600;}
.banner-text{width:70%; position:absolute; bottom:40px; padding-left:20px;}
.banner-text h2{color:#fff; font-weight:600;}
.banner-text h2:after{content:" "; width:100px; height:5px; background:#FFF; display:block; margin-top:20px; border-radius:3px;}
.banner-text p{color:#fff;}
.wrapper-page a:hover{
      color: #2974b6;
}
.form-control:focus{
      border-color: #2974b6;
}
.field-icon{
      margin-top: -31px;
}
        </style>
  
  @stop
@section('content')
         <div class="card">
            <div class="row">
                <div class="col-sm-6">
                    <div class="wrapper-page">
                        <div class="card overflow-hidden account-card mx-3">
                              <div class="account-card-content">
                                  <div class="text-center">
                                      <img src=" {{URL::to('public/assets/images/kloudrac_new_logo-1.png')}}" height="45px" width="50px">
                                  </div>
                                    <div class="text-center position-relative mb-4">
                                                      <h3 style="font-size: 1.75rem;font-weight:500;margin-top: 20px;">Kloudrac HRMS</h3>
                                    </div>
                                    <form class="form-horizontal m-t-20 width100" id="login_form" method="POST"
                  aria-label="{{ __('Login') }}" aria-label="Login">
                                        
                                           @csrf
                                          <div class="form-group">
                                                <div class="row">
                                                      <div class="col-12">
                                                            <label>Email</label>
                                                      </div>
                                                      <div class="col-12">
                                                            <input id="emaildata" type="text" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email"  maxlength="60" 
                              autofocus="" placeholder="Enter valid Email Or EmployeeId" required @if(!empty(Auth::guard('main_users')->user())) value="{{Auth::guard('main_users')->user()->emailaddress}}"  @endif>
                               <span id="email_error" style="margin-left:100px;color:red" /></span>
                                 @if ($errors->has('email'))
                              <span class="invalid-feedback" role="alert">
                              <strong>{{ $errors->first('email') }}</strong>
                              </span>
                              @endif
                           <div id="email_error"></div>
                                                      </div>
                                                </div>
                                          </div>
                                          <div class="form-group">
                                                <div class="row">
                                                      <div class="col-12">
                                                            <label>Password</label>
                                                      </div>
                                                      <div class="col-12">
                                                            <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password"   maxlength="60"
                              placeholder="Enter password" required  @if(!empty(Auth::guard('main_users')->user())) value="{{Auth::guard('main_users')->user()->password}}"  @endif>
                              
                              <span id="password_error" style="margin-left:100px;color:red" /></span>
                              @if ($errors->has('password'))
                              <span class="invalid-feedback" role="alert">
                              <strong>{{ $errors->first('password') }}</strong>
                              </span>
                              @endif
                                                            <span  onclick="login_psd()" toggle="#password-field"
                                                                  class="fa fa-eye field-icon toggle-password"></span>
                                                      </div>
                                                </div>
                                          </div>
                                          <div class="form-group row m-t-20">
                                                <div class="col-sm-6">
                                                      <div class="custom-control custom-checkbox"><input
                                                                  type="checkbox" class="custom-control-input"
                                                                  id="customControlInline" name="remember_me" @if(!empty(Auth::guard('main_users')->user())) checked  @endif> <label
                                                                  class="custom-control-label"
                                                                  for="customControlInline">Remember me</label>
                                                      </div>
                                                </div>
                                                <div class="col-sm-6">
                                                      <a href="{{URL::to('forget')}}"><i class="mdi mdi-lock"></i> Forgot
                                                            your password?</a>
                                                </div>
                                                 <div class="col-sm-6">
                                                 <div class="g-recaptcha" data-sitekey="6LdWfrIZAAAAAF60EgeN-krQYpAayLnJcKersS4G"></div>
                                                 <span id="captcha" style="margin-left:100px;color:red" /></span>
                                                 </div>
                                          </div>
                                           @if(Session::has('message'))
                              <div class="alert alert-primary alert-dismissible">
                         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        {{ Session::get('message') }}
                       </div>
                          
                          
                            @endif
                                          <div class="form-group m-t-10 mb-0 row">
                                                <div class="col-12 m-t-20">
                                                      <button type="button" id="login" onclick="get_action()" class="toggleBtnfilled startTransition">{{ __('Login') }}</button>
                                                </div>
                                          </div>
                                    </form>
                              </div>
                        </div>
                  </div>
                </div>
                <div class="col-md-6 banner-sec d-none d-sm-block d-xl-block d-md-block">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                         <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1" class=""></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                          </ol>
                    <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
              <img class="d-block img-fluid" src="{{URL::to('public/assets/images/1.png')}}" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid" src="{{URL::to('public/assets/images/2.png')}}" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block img-fluid" src="{{URL::to('public/assets/images/3.png')}}" alt="First slide">
          </div>
                    </div>	   
                    
                </div>
            </div>
            </div>
        </div>
  @endsection
   
  
@section('extra_js')




 <script>
 
 
 
 function get_action() 
{
    
    // var email = $('#emaildata').val();
    // var password = $('#password').val(); 
    
    // if(email == ''){
        
    //     $('#email_error').html('Email & User ID is Required').show();
    //     return false;
        
    // }else{
        
    //     $('#email_error').hide();
    //     return true;
        
    // }
    
    // if(password == ''){
        
    //      $('#password_error').html('password is Required').show();
    //     return false;
        
    // }else{
        
    //     $('#password_error').hide();
    //     return true;
        
    // }
    
    var v = grecaptcha.getResponse();
    if(v.length == 0)
    {
        document.getElementById('captcha').innerHTML="You can't leave Captcha Code empty";
        return false;
    }
    else
    {
        //document.getElementById('captcha').innerHTML="Captcha completed";
        
        $('#login_form').submit();
        return true; 
    }
}
 
 
      $(document).ready(function () {
         $("#signup").click(function () {
            $(".loginfWrapper").css({ "display": "flex", "transition": "all 2s linear" });
            $(".signUpWrapper").css("display", "none");
         });
         $("#signin").click(function () {
            $(".loginfWrapper").css("display", "none");
            $(".signUpWrapper").css({ "display": "flex", "transition": "all 2s linear" });
         });
      })
      
      
      
       $(".startTransition").on("click", function () {

            if ($(".signUpWrapper").is(":visible")) {
               $(".signUpWrapper").transition({ x: '-100%', opacity: 0.1 }, function () { $(".signUpWrapper").hide(); });
               $(".loginfWrapper").css({ x: '100%' });
               $(".loginfWrapper").show().transition({ x: '0%', opacity: 1.0 });
               return;
            }

            $(".loginfWrapper").transition({ x: '-100%', opacity: 0.1 }, function () { $(".loginfWrapper").hide(); });
            $(".signUpWrapper").css({ x: '100%' });
            $(".signUpWrapper").show().transition({ x: '0%', opacity: 1.0 });

         });
      //login show password
function login_psd() {
  var e = document.getElementById("password");
  var f = document.getElementById("login_eye");
  if (e.type == "password") {
    e.type = "text";
    f.className = 'fa fa-eye-slash field-icon';
  } else {
    e.type = "password";
    f.className = 'fa fa-eye field-icon';
  }
}
   </script>

@stop