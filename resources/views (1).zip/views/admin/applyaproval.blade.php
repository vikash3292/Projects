

@extends('layouts.superadmin_layout')
   @section('content')
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Leaves to Approve</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Leaves to Approve</a>
                                    </li>
                                </ol>
                            </div>
                            <?php
                            $userlist = DB::table('main_users')->whereNull('extension')->orderBy('userfullname','ASC')->get();
                            ?>
                            <div class="col-sm-6 state_dist">
                                @if($role == 1 || $role == 4 || $role == 11)
                                <button class="btn btn-primary advance_setting">User Export <i class="fa fa-angle-right"></i></button>
                                @endif
                                <form method="post" class="state_dist_wrapper" action="{{URL::to('export_leave')}}" enctype="multipart/form-data">
                                    @csrf
<div class="">
<div class="close_popup">
<img src="../public/assets/images/close_icon.png" alt="" title="">
</div>
<div class="row">
<div class="col-sm-12">
<label for="empid" class="float-left col-form-label">Select
Employee <span class="text-danger">*</span></label>
</div>
<div class="col-sm-12">
<select class="form-control" name="user_id" required="">
<option value="">Select option</option>
@foreach($userlist as $userlists)
<option value="{{$userlists->id}}">{{$userlists->userfullname}}</option>
@endforeach

</select>
</div>
<div class="col-sm-12">
<label for="empid" class="float-left col-form-label">Select
Status <span class="text-danger">*</span></label>
</div>
<div class="col-sm-12">
<select class="form-control" name="status" required="">
<option value="Approved">Approved</option>
<option value="Rejected">Rejected</option>
</select>
</div>

<div class="col-xs-12 col-sm-12">
<div class="form-group m-t-10">
<input type="submit" name="upload" value="Export" class="btn btn-primary float-right">
</div>
</div>
</div>
</div>
</form>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap text-center"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>
                                                    Employee
                                                </th>
                                                <th>Leave Type</th>
                                                <th>Date</th>
                                                <th>Day</th>
                                                
                                                
                                                <th>Leave Status</th>
                                                <th>Action</th>
                                        
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php($i = 1)
                                            @foreach($leavelist as $leavelists)
                                            <tr>
                                                <td>{{$i++}}</td>
                                                <td>
                                                       {{ucwords($leavelists->userfullname)}}
                                                    </div>
                                                </td>
                                                
                                                   <?php
                    
                    if($leavelists->leavetypeid ==1){
                        $title = 'CL';
                       
                    }else if($leavelists->leavetypeid ==2){
                         $title = 'RH';
                        
                    }else if($leavelists->leavetypeid ==5){
                          $title = 'MyLeave';
                         
                    }else if($leavelists->leavetypeid ==4){
                        
                         $title = 'Maternity Leave';
                      
                        
                    }
                    
                    ?>
                                                <td>  {{$title}}</td>
                                                <td>  {{$leavelists->from_date}}</td>
                                                 <td>  {{$leavelists->appliedleavescount}}</td>
                                               
                                    
                                              
                                                <td class="bg-success text-white">

                                               <?php if($leavelists->leavestatus == 'Cancel'){?>

                                                    Canceled

                                                  <?php }else{ ?>

                                                     {{$leavelists->leavestatus}}

                                                  <?php } ?>
                                                   
                                                </td>
                                            

                                                <td >

                                                    <?php
                                                    $currentdate = date('Y-m-d');

                                                    $leavedate = date('Y-m-d',(strtotime ( '-1 day' , strtotime ( $leavelists->from_date) ) ));
                                                    if($currentdate <=  $leavedate && $leavelists->leavestatus != 'Cancel'){
                                                     
                                                    ?>
                                                   <a   href="javascript:void(0)" onclick="cancel_leave('{{$leavelists->id}}')"> Cancel</a>
                                                   <?php } ?>
                                                </td>

                                    
 </div>

                                            @endforeach

                                           <?php 

            $arrUser = [];
       $findunderUser = DB::table('main_users')->where('reporting_manager',$userid)->where('isactive',1)->select('id')->get();
       
       
       foreach($findunderUser as $key => $findunderUsers) {
         $arrUser[] =  $findunderUsers->id;
       }

      

      $leavelist = DB::table('main_leaverequest')->join('main_users','main_leaverequest.user_id','=','main_users.id');
       $leavelist->whereIn('main_users.id',$arrUser);
     $leavelist =  $leavelist->where('main_leaverequest.isactive',1)->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y'))"), "=", date('Y'))->orderBy('main_leaverequest.id','DESC')->select('main_leaverequest.*','main_users.userfullname')->get();
      
                                           ?>

                                  @foreach($leavelist as $leavelists)
                                            <tr>
                                                <td>{{$i++}}</td>
                                                <td>
                                                       {{ucwords($leavelists->userfullname)}}
                                                    </div>
                                                </td>
                                                
                                                   <?php
                    
                    if($leavelists->leavetypeid ==1){
                        $title = 'CL';
                       
                    }else if($leavelists->leavetypeid ==2){
                         $title = 'RH';
                        
                    }else if($leavelists->leavetypeid ==5){
                          $title = 'MyLeave';
                         
                    }else if($leavelists->leavetypeid ==4){
                        
                         $title = 'Maternity Leave';
                      
                        
                    }
                    
                    ?>
                                                <td>  {{$title}}</td>
                                                <td>  {{$leavelists->from_date}}</td>
                                               
                                                <td>  {{$leavelists->appliedleavescount}}</td>
                                               
                                    
                                              
                                                <td class="bg-success text-white">
                                                      <?php if($leavelists->leavestatus == 'Cancel'){?>

                                                    Canceled

                                                  <?php }else{ ?>

                                                     {{$leavelists->leavestatus}}

                                                  <?php } ?>
                                                </td>
                                            
                       <td >
                                                   <?php
                                                    $currentdate = date('Y-m-d');

                                                    $leavedate = date("Y-m-d", strtotime("last day of this month"));
                                                    
                                                    if(strtotime($currentdate) <=  strtotime($leavedate)  &&  $currentdate < $leavelists->from_date && $leavelists->leavestatus != 'Cancel'){
                                                      
                                                    ?>
                                                   <a  href="javascript:void(0)" onclick="cancel_leave('{{$leavelists->id}}')"> Cancel</a>
                                                   <?php } ?>
                                                </td>
                                               

                                    
 </div>

                                            @endforeach

                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->


    
          
         @stop

         @section('extra_js')

         <script type="text/javascript">
           function cancel_leave(leave_id)  {

    var result = confirm("Are you sure you want to Cancel this leave?");
if (result) {
    //Logic to delete the item

       $('#loadingDiv').show();

 var _token = "{{csrf_token()}}";

$.ajax({
     url: '/cancel_leave',
     type: "post",
     data: {"_token": _token,"leave_id":leave_id},
     dataType: 'JSON',
      
     success: function (data) {


   
       if(data.status ==200){
          $('#loadingDiv').hide();

       
        swal("Good job!", data.msg, "success");
         location.reload();
          
     
       }else if(data.status ==202){

           $('#loadingDiv').hide();
         swal("Good job!", "User alert Exist", "success");
         location.reload();

           }else if(data.status ==203){

           $('#loadingDiv').hide();
         swal("Good job!", "Successfully Updated", "success");


       }else{

          $('#loadingDiv').hide();
         
          swal("Good job!", "You clicked the button!", "error");

       }
       
     }
   });

}

           }



    
$(".advance_setting").on("click", function(){
            $(".state_dist_wrapper").addClass("state_dis_cls");
        });
        $(".close_popup").on("click", function(){
           $(".state_dist_wrapper").removeClass("state_dis_cls"); 
        });
         </script>

         @stop