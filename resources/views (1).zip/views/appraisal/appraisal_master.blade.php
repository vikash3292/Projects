



@extends('layouts.superadmin_layout')



@section('content')











<div class="content p-0">



                <div class="container-fluid">



                    <div class="page-title-box">



                        <div class="row align-items-center bredcrum-style">



                            <div class="col-sm-6">



                                <h4 class="page-title">Appraisal Master</h4>



                                <ol class="breadcrumb">



                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>



                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Appraisal Master</a></li>



                                </ol>



                            </div>



                            <div class="col-sm-6 text-right">



                              <button class="btn btn-primary" onclick="add_kra()">Add Appraisal</button>

                               <button class="btn btn-primary" data-toggle="modal" data-target="#sendform">Send</button>



                            </div>



                        </div>



                    </div>



                    <!-- end row -->



                    <!-- end row -->



                    <div class="row">



                        <div class="col-12">



                            <div class="card m-t-20">



                                <div class="card-body">



                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"



                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">



                                        <thead>



                                            <tr>



                                                <th>Name</th>



                                                <th>Designation</th>



                                                <th width="20%">Status</th>



                                                <th width="10%">Action</th>



                                            </tr>



                                        </thead>



                                        <tbody>







                                        @foreach($list as $lists)



                                            <tr>



                                               



                                                <td>{{$lists->name}}</td>



                                                <td>{{$lists->positionname}}</td>



                                                <td>{{$lists->status}}</td>



                                                <td>







                                               







                                                  <a href="{{URL::to('appraisal-question')}}/{{$lists->id}}">



             



                                                   <i class="mdi mdi-eye font-blue"></i>







                                                   </a>



       <a href="javascript:void(0)" onclick="getedit('{{$lists->name}}','{{$lists->designation}}','{{$lists->id}}','{{$lists->status}}')">







                                                   <i class="mdi mdi-pencil text-warning"></i>







                                                   </a>










<!-- 
                                                    <a onclick="return confirm('Are you sure you want to delete this ?');" href="{{URL::to('delete-kra')}}/{{$lists->id}}">



                                                   <i class="mdi mdi-delete text-danger"></i>

                                                 </a>
 -->


                                                </td>



                                            </tr>







                                            @endforeach



                                        </tbody>



                                    </table>



                                </div>



                            </div>



                        </div>



                        <!-- end col -->



                    </div>



                    <!-- end row -->



                </div>



                <!-- container-fluid -->



            </div>











            <div id="addkra" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"



                style="display: none; padding-right: 5px;" aria-modal="true">



                <div class="modal-dialog modal-lg">



                    <div class="modal-content">



                        <div class="modal-header">



                            <h5 class="modal-title mt-0" id="myModalLabel">Appraisal</h5>



                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>



                        </div>



                        <div class="modal-body">



                            <div class="row">



                                <div class="col-sm-12">



                                    <div class="row">



                                        <div class="col-md-6">



                                            <div class="form-group row m-0">



                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Name



                                                    <span class="text-danger">*</span></label>



                                                <div class="col-lg-8 col-form-label">



                                                    <input type="text" class="form-control" id="name">



                                                    <div id="name_error"></div>



                                                </div>



                                            </div>



                                        </div>







                                        <input type="hidden" id="kra_id">



                                        <input type="hidden" id="status">



                                        <?php



                                        



                                        $posi = DB::table('main_positions')->where('isactive',1)->get();



                                        ?>



                                        <div class="col-md-6">



                                            <div class="form-group row m-0" id="fillsubtask">



                                                <label for="empid" class="col-lg-4 col-form-label">Designation<span



                                                        class="text-danger">*</span></label>



                                                <div class="col-lg-8 col-form-label">



                                                <select class="form-control" id="designation">







<option value="">Select option</option>



@foreach($posi as $posis)



<option value="{{$posis->id}}">{{$posis->positionname}}</option>



@endforeach



                                                </select>



                                                  



                                                    <div id="designation_error"></div>



                                                </div>



                                            </div>



                                        </div>



                                    </div>



                                </div>



                            </div>



                        </div>



                        <div class="modal-footer">



                            <div class="row">



                                <div class="col-sm-12">



                                    <button onclick="save_kra()" id="save_kra" class="btn btn-primary add_assets">Save</button>



                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>



                                </div>



                            </div>



                        </div>



                    </div>



                </div>



            </div>





<div id="sendform" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"

                style="display: none; padding-right: 5px;" aria-modal="true">

                <div class="modal-dialog modal-lg">

                    <div class="modal-content">

                        <div class="modal-header">

                            <h5 class="modal-title mt-0" id="myModalLabel">Send Form</h5>

                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

                        </div>

                        <form id="send_kra_user">

                        <div class="modal-body">

                            <div class="row">

                                <div class="col-sm-12">

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empcode" class="col-lg-4 p-r-0 col-form-label">Select Form

                                                    <span class="text-danger">*</span></label>

                                                <div class="col-lg-8 col-form-label">

                                                   <select class="form-control" id="form_id" name="kra_id" required="">

                                                    <option value="">select Option</option>

                                                     @foreach($list as $lists)
                                                     @if($lists->status == 'Active')

                                                       <option value="{{$lists->id}}">{{$lists->name}}</option>
                                                       @endif

                                                       @endforeach

                                                   </select>

                                                  

                                                </div>

                                            </div>

                                        </div>

                                      <?php 

                                      

                                      $user_list = DB::table('main_users')->where('isactive',1)->orderBy('userfullname','ASC')->get();

                                      ?>

                                        <div class="col-md-6 p-l-0">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label p-r-0">Select Employee<span class="text-danger">*</span></label>

                                                <div class="col-lg-8 col-form-label">

                                                   <select class="form-control multiselect-ui" multiple="multiple" name="user_id[]" required="">

                                                   @foreach($user_list as $user)



<option value="{{$user->id}}">{{$user->userfullname}}</option>



@endforeach



                                                   </select>

                                                    <span id="form_id_error"></span>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        

                        <div class="modal-footer">

                            <div class="row">

                                <div class="col-sm-12">

                                    <button  type="submit" id="save_form" class="btn btn-primary add_assets">Send</button>

                                    <button class="btn btn-default" data-dismiss="modal">Cancel</button>

                                </div>

                            </div>

                        </div>



                      </form>

                    </div>

                </div>

            </div>





            @stop







 



@section('extra_js')







<script>







function add_kra(){







    $('#myModalLabel').text('Add Appraisal');



     $('#kra_id').val('');



     var name = $('#name').val('');



     var name = $('#status').val('');



var designation = $('#designation').val('');







$('#addkra').modal('show')







}











function getedit(name,desig,id,status){







    $('#myModalLabel').text('Edit Appraisal');



     $('#kra_id').val(id);



     var name = $('#name').val(name);



     var name = $('#status').val(status);



var designation = $('#designation').val();







$("#designation > option").each(function() {



                              if(this.value == desig){



                                 $('#designation').val(desig).attr("selected"); 



                              }



                         



                           });







    $('#addkra').modal('show')







}











function save_kra(){











var name = $('#name').val();



var designation = $('#designation').val();



var kra_id = $('#kra_id').val();



var status = $('#status').val();







if(name.replace(/\s/g,'') ==''){



         $('#name_error').text('Name is Required').attr('style','color:red');



         $('#name_error').show();



           error = 0;



              return false;



      }else{$('#name_error').hide();  error = 1;}







      if(designation.replace(/\s/g,'') ==''){



         $('#designation_error').text('Designation is Required').attr('style','color:red');



         $('#designation_error').show();



           error = 0;



              return false;



      }else{$('#designation_error').hide();  error = 1;}











      var _token = "{{csrf_token()}}";



      $('#save_kra').attr('disabled','disabled');







$.ajax({



    url: '/save_appraisal',



    type: "post",



    data: {"_token": _token,"name":name,"designation":designation,"kra_id" : kra_id,"status":status},



   // dataType: 'JSON',



      beforeSend: function() {



    // setting a timeout



    $('#loadingDiv').show();



},



    success: function (data) {



      //console.log(data); // this is good







      $('#save_kra').removeAttr('disabled','disabled');







       // return false;



      if(data.status ==200){



         $('#loadingDiv').hide();



     



         alertify.success(data.msg);



        



          location.reload();







         







      }else if(data.status ==202){







          $('#loadingDiv').hide();



          alertify.success(data.msg);



        location.reload();







          }else if(data.status ==203){







          $('#loadingDiv').hide();



          alertify.success(data.msg);











      }else{







         $('#loadingDiv').hide();



         alertify.error(data.msg);



         







      }



      



    }



  });







}







  $("form#send_kra_user").submit(function(e) {



 

            e.preventDefault();



            $('#loadingDiv').show();



   var token = "{{csrf_token()}}"; 





  $.ajax({

        url: '/send_appraisal',

        headers: {'X-CSRF-TOKEN': token}, 

        type: "post",

        data:$(this).serialize(),

        

        success: function (data) {

        //console.log(data.city); // this is good

    

          if(data.status ==200){

             $('#loadingDiv').hide();

         

      

         alertify.success(data.msg);



         ;



            location.reload();



          }else if(data.status ==202){



              $('#loadingDiv').hide();

              alertify.success(data.msg);

           // swal("Good job!", "User alert Exist", "success");

            //location.reload();



              }else if(data.status ==203){



              $('#loadingDiv').hide();

              alertify.success(data.msg);

           // swal("Good job!", "Successfully Updated", "success");

               //location.reload();



          }else{



             $('#loadingDiv').hide();

             alertify.error(data.msg);

            // swal("Good job!", "You clicked the button!", "error");



          }

          

        }

      });



            



          });



















</script>



<script type="text/javascript">
$(function() {
    $('.multiselect-ui').multiselect({
        includeSelectAllOption: true
    });
});
</script>







            @stop