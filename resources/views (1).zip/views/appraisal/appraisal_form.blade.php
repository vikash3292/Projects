@extends('layouts.superadmin_layout')

   @section('content')

  

          



   <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6">

                                <h4 class="page-title">Appraisal Form</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="index.html">Kloudrac</a></li>

                                    <li class="breadcrumb-item active"><a href="">Appraisal Form</a>

                                    </li>

                                </ol>

                            </div>

                            <div class="col-sm-6 text-right">
                            	<a href="javascript: history.go(-1)" class="btn btn-primary">Back</a>
                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <!-- end row -->

                    <div class="row">

                        <div class="col-12">

                            <div class="appraisal_card">

                                <div class="card_div">

                                    <form class="form-inline" id="appraisal_from_user">

                                    <div class="col-sm-12 p-0">

                                        <h4 class="text-center"><u>Annual Employee Evaluation</u></h4>

                                        <p class="text-center font-500 font-18 mb-0">Kloudrac Softwares Pvt Ltd</p>

                                        <p class="text-center font-500 font-18 mb-0">C-44, Sec-65</p>

                                        <p class="text-center font-500 font-18 mb-0">Noida, Uttar Pradesh-201307</p>

                                        <p class="text-center font-500 font-18 mb-0">Date: {{$assign->state_date}}</p>

                                        <input type="hidden" name="form_id" value="{{$form_id}}">

                                        <input type="hidden" name="assign_id" value="{{$assign_id}}">

                                    </div>

                                    <div class="col-sm-12 m-t-20">

                                        <div class="row form-group">

                                            <div class="col-sm-2 text-left">

                                                <label for="email">Employee Name :  </label>

                                            </div>

                                            <div class="col-sm-3">

                                                <input type="text" maxlength="60" class="form-control width100" name="emp_name" @if(!empty($edit)) disabled value="{{$edit->emp_name}}"  @endif required id="name">

                                            </div>

                                        </div>

                                        <div class="row form-group m-t-10">

                                            <div class="col-sm-2 text-left">

                                                <label for="email">Evaluation Period :  </label>

                                            </div>

                                            <div class="col-sm-3">

                                                <input type="date" class="form-control width100" id="s_date"  name="s_date" @if(!empty($edit)) disabled value="{{$edit->s_date}}"  @endif required>

                                            </div>

                                            <div class="col-sm-1">

                                                <label for="email">To  </label>

                                            </div>

                                            <div class="col-sm-3">

                                                <input type="date" class="form-control width100" id="e_date"  name="e_date" @if(!empty($edit)) disabled value="{{$edit->e_date}}"  @endif required>

                                            </div>

                                        </div>

                                        <div class="row form-group m-t-10">

                                            <div class="col-sm-2 text-left">

                                                <label for="email">Review Date :  </label>

                                            </div>

                                            <div class="col-sm-3">

          <input type="date" width="100%" class="form-control width100" id="review_date" name="review_date" @if($userid != $mng) disabled @endif @if(!empty($edit->review_date)) disabled value="{{$edit->review_date}}"  @endif required>

                                            </div>

                                        </div>

                                        <div class="row form-group m-t-10">

                                            <div class="col-sm-2 text-left">

                                                <label for="email">Supervisor’s Name:   </label>

                                            </div>

                                            <div class="col-sm-3">

                                                <input type="text" maxlength="60" class="form-control width100" name="mng_name" @if(!empty($edit)) disabled value="{{$edit->mng_name}}"  @endif required>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <h4>Job Performance</h4>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <table class="table" border="1">

                                            <thead class="theadbg">

                                                <tr>

                                                    <th>Functional Area</th>

                                                    <th>Description</th>

                                                    <th>Employee Rating</th>

                                                    <th>Manager Rating</th>

                                                </tr>

                                            </thead>

                                            <tbody>


                                              @php($i = 0)
                                              @foreach($question as $key => $forms)

                                              @if($forms->type == 1)



                                                <tr>

                                                    <td>{{$forms->question}}   <input type="hidden" value="{{$forms->question}}" name="job_question[]" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

                                                    <td width="40%">{{$forms->desc}}   <input type="hidden" value="{{$forms->desc}}" name="job_desc[]" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

                                                    <td>



 



                                                    @if($forms->category == 1)



<div class="col-sm-12">



     <input type="text" name="job_answer[]" class="form-control"  @if($forms->required =='on') required  @endif>



              

          </div>








@elseif($forms->category == 3)



<div class="col-sm-12">

              <select class="form-control" name="job_answer[]" @if(!empty($edit->job_emp_rating))  disabled  @endif @if($forms->required =='on') required  @endif>

              <option value>Select option</option>

                  @foreach(json_decode($forms->ans) as $kn => $option)


         <option  @if(!empty($edit->job_emp_rating))  @if($option == json_decode($edit->job_emp_rating)[$i]) selected  @endif  @endif>{{$option}}</option>

                  @endforeach

                  

              </select>

          </div>



@endif



                                                    </td>

                                                    <td>







                                                    @if($forms->category == 1)



<div class="col-sm-12">



     <input type="text" name="mng_job_answer[]" maxlength="60" class="form-control" @if($userid != $mng) disabled @endif @if($forms->required =='on') required  @endif>



              

          </div>






@elseif($forms->category == 3)



<div class="col-sm-12">

              <select class="form-control" name="mng_job_answer[]" @if(!empty($edit->job_mng_rating)) disabled  @endif  @if($userid != $mng) disabled @endif @if($forms->required =='on') required  @endif>

              <option value>Select option</option>

                  @foreach(json_decode($forms->ans) as $km => $option)

                  <option  @if(!empty($edit->job_mng_rating))  @if(($option == json_decode($edit->job_mng_rating)[$i])) selected  @endif  @endif>{{$option}}</option>

                  @endforeach

                  

              </select>

          </div>



@endif



                                                   

                                                    </td>

                                                </tr>
                                                 @php($i++)

                                                @endif

                                                @endforeach

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Employee's Self-Observation

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" @if(!empty($edit)) disabled @if($edit->job_emp_stre_obs) value="{{$edit->job_emp_stre_obs}}"  @endif  @endif name="emp_stre" class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" @if(!empty($edit)) disabled @if($edit->job_emp_weak_obs) value="{{$edit->job_emp_weak_obs}}"  @endif  @endif name="emp_weak" class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Observations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" name="mng_stre" @if(!empty($edit->job_mng_stre_obs)) disabled @if($edit->job_mng_stre_obs) value="{{$edit->job_mng_stre_obs}}"  @endif  @endif  @if($userid != $mng) disabled @endif class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" name="mng_weak" @if(!empty($edit->job_mng_weak_obs)) disabled @if($edit->job_mng_weak_obs) value="{{$edit->job_mng_stre_obs}}"  @endif  @endif  @if($userid != $mng) disabled @endif   class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Recommendations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td colspan="4">

                                                        <input type="text" maxlength="60" @if(!empty($edit->job_mng_recommendation)) disblaed @if($edit->job_mng_recommendation) value="{{$edit->job_mng_recommendation}}"  @endif  @endif  @if($userid != $mng) disabled @endif  name="mng_recommendation"   class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                            </tbody>

                                        </table>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <h4>  Customer/Client Relations :</h4>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <table class="table" border="1">

                                            <thead class="theadbg">

                                                <tr>

                                                    <th>Functional Area</th>

                                                    <th>Description</th>

                                                    <th>Employee Rating</th>

                                                    <th>Manager Rating</th>

                                                </tr>

                                            </thead>

                                            <tbody>
                                            @php($j = 0)

                                            @foreach($question as $key => $forms)

                                            @if($forms->type == 2)



<tr>

    <td>{{$forms->question}} <input type="hidden" name="cust_question[]" value="{{$forms->question}}" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

    <td width="40%">{{$forms->desc}} <input type="hidden" name="cust_desc[]" value="{{$forms->desc}}" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

    <td>







    @if($forms->category == 1)



<div class="col-sm-12">



<input type="text" maxlength="60" name="cust_answer[]" class="form-control"  @if($forms->required =='on') required  @endif>





</div>








@elseif($forms->category == 3)



<div class="col-sm-12">

<select class="form-control" name="cust_answer[]" @if(!empty($edit->cust_emp_rating)) disabled    @endif @if($forms->required =='on') required  @endif>

<option value>Select option</option>

@foreach(json_decode($forms->ans) as $kn => $option)

<option  @if(!empty($edit->cust_emp_rating))  @if(($option == json_decode($edit->cust_emp_rating)[$j])) selected  @endif  @endif>{{$option}}</option>

@endforeach



</select>

</div>




@endif



    </td>

    <td>







    @if($forms->category == 1)



<div class="col-sm-12">



<input type="text" maxlength="60" name="mng_cust_answer[]"  @if($userid != $mng) disabled @endif class="form-control"  @if($forms->required =='on') required  @endif>





</div>





@elseif($forms->category == 3)



<div class="col-sm-12">

<select class="form-control" name="mng_cust_answer[]"  @if(!empty($edit->cust_mng_rating)) disabled  @endif  @if($userid != $mng) disabled @endif @if($forms->required =='on') required  @endif>

<option value>Select option</option>

@foreach(json_decode($forms->ans) as $km => $option)

<option @if(!empty($edit->cust_mng_rating))  @if(($option == json_decode($edit->cust_mng_rating)[$j])) selected  @endif  @endif>{{$option}}</option>

@endforeach



</select>

</div>







@endif



   

    </td>

</tr>

   @php($j++)

@endif

@endforeach

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Employee's Self-Observation

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" name="cust_emp_stre" @if(!empty($edit)) disabled @if($edit->cust_emp_stre_obs) value="{{$edit->cust_emp_stre_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" @if(!empty($edit)) disabled @if($edit->cust_emp_weak_obs) value="{{$edit->cust_emp_weak_obs}}"  @endif  @endif  name="cust_emp_weak" class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Observations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" @if(!empty($edit->job_mng_stre_obs)) disabled @if($edit->job_mng_stre_obs) value="{{$edit->cust_mng_stre_obs}}"  @endif  @endif  @if($userid != $mng) disabled @endif name="cust_mng_stre" class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" @if(!empty($edit->cust_mng_weak_obs)) disabled @if($edit->cust_mng_weak_obs) value="{{$edit->cust_mng_weak_obs}}"  @endif  @endif  @if($userid != $mng) disabled @endif name="cust_mng_weak" class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Recommendations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td colspan="4">

                                                        <input type="text" maxlength="60" @if(!empty($edit->cust_mng_recommendation)) disabled @if($edit->cust_mng_recommendation) value="{{$edit->cust_mng_recommendation}}"  @endif  @endif @if($userid != $mng) disabled @endif name="cust_mng_recommendation" class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                            </tbody>

                                        </table>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <h4>Communication Skills:</h4>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <table class="table" border="1">

                                            <thead class="theadbg">

                                                <tr>

                                                    <th>Functional Area</th>

                                                    <th>Description</th>

                                                    <th>Employee Rating</th>

                                                    <th>Manager Rating</th>

                                                </tr>

                                            </thead>

                                            <tbody>

                                               


                                               @php($k = 0)
                                            @foreach($question as $key => $forms)

                                            @if($forms->type == 3)



<tr>

    <td>{{$forms->question}}<input type="hidden" value="{{$forms->question}}" name="comm_question[]" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

    <td width="40%">{{$forms->desc}}<input type="hidden"  value="{{$forms->desc}}" name="comm_desc[]" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

    <td>







    @if($forms->category == 1)



<div class="col-sm-12">



<input type="text" name="comm_answer[]" maxlength="60" class="form-control"  @if($forms->required =='on') required  @endif>





</div>





@elseif($forms->category == 3)



<div class="col-sm-12">

<select class="form-control" name="comm_answer[]" @if(!empty($edit->comm_emp_rating)) disabled   @endif @if($forms->required =='on') required  @endif>

<option value>Select option</option>

@foreach(json_decode($forms->ans) as $jh => $option)

<option @if(!empty($edit->comm_emp_rating))  @if(($option == json_decode($edit->comm_emp_rating)[$k])) selected  @endif  @endif>{{$option}}</option>

@endforeach



</select>

</div>




@endif



    </td>

    <td>







    @if($forms->category == 1)



<div class="col-sm-12">



<input type="text" maxlength="60" name="mng_comm_answer[]"  @if($userid != $mng) disabled @endif class="form-control"  @if($forms->required =='on') required  @endif>





</div>





@elseif($forms->category == 3)



<div class="col-sm-12">

<select class="form-control" name="mng_comm_answer[]" @if(!empty($edit->comm_mng_rating)) disabled   @endif  @if($userid != $mng) disabled @endif @if($forms->required =='on') required  @endif>

<option value>Select option</option>

@foreach(json_decode($forms->ans) as $ki => $option)

<option @if(!empty($edit->comm_mng_rating))  @if(($option==json_decode($edit->comm_mng_rating)[$k])) selected  @endif  @endif>{{$option}}</option>

@endforeach



</select>

</div>



@endif



   

    </td>

</tr>

 @php($k++)

@endif

@endforeach

                                                    <th colspan="4" class="bg_gray">

                                                        Employee's Self-Observation

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" name="comm_emp_stre"  @if(!empty($edit)) disabled @if($edit->comm_emp_stre_obs) value="{{$edit->comm_emp_stre_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" name="comm_emp_weak" @if(!empty($edit)) disabled @if($edit->comm_emp_weak_obs) value="{{$edit->comm_emp_weak_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Observations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60"  @if($userid != $mng) disabled @endif name="comm_mng_stre" @if(!empty($edit->comm_mng_stre_obs)) disabled @if($edit->comm_mng_stre_obs) value="{{$edit->comm_mng_stre_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60"  @if($userid != $mng) disabled @endif  name="comm_mng_weak" @if(!empty($edit->comm_mng_weak_obs)) disabled @if($edit->comm_mng_weak_obs) value="{{$edit->comm_mng_weak_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Recommendations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td colspan="4">

                                                        <input type="text" maxlength="60"  @if($userid != $mng) disabled @endif name="comm_mng_recommendation" @if(!empty($edit->comm_mng_recommendation)) disabled @if($edit->comm_mng_recommendation) value="{{$edit->comm_mng_recommendation}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                            </tbody>

                                        </table>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <h4>Interpersonal Skills:</h4>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <table class="table" border="1">

                                            <thead class="theadbg">

                                                <tr>

                                                    <th>Functional Area</th>

                                                    <th>Description</th>

                                                    <th>Employee Rating</th>

                                                    <th>Manager Rating</th>

                                                </tr>

                                            </thead>

                                            <tbody>

                                               @php($l = 0)

                                            @foreach($question as $key => $forms)

                                            @if($forms->type == 4)



<tr>

    <td>{{$forms->question}} <input type="hidden" value="{{$forms->question}}" name="inter_question[]" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

    <td width="40%">{{$forms->desc}} <input type="hidden" value="{{$forms->desc}}" name="inter_desc[]" class="form-control"  @if($forms->required =='on') required  @endif>

</td>

    <td>







    @if($forms->category == 1)



<div class="col-sm-12">



<input type="text" maxlength="60" name="inter_answer[]" class="form-control"  @if($forms->required =='on') required  @endif>





</div>




@elseif($forms->category == 3)



<div class="col-sm-12">

<select class="form-control" name="inter_answer[]" @if(!empty($edit->inter_emp_rating)) disabled   @endif @if($forms->required =='on') required  @endif>

<option value>Select option</option>

@foreach(json_decode($forms->ans) as $kn => $option)

<option @if(!empty($edit->inter_emp_rating))  @if(($option == json_decode($edit->inter_emp_rating)[$l])) selected  @endif  @endif>{{$option}}</option>

@endforeach



</select>

</div>



@endif



    </td>

    <td>







    @if($forms->category == 1)



<div class="col-sm-12">



<input type="text" maxlength="60" name="mng_inter_answer[]"  @if($userid != $mng) disabled @endif class="form-control"  @if($forms->required =='on') required  @endif>





</div>






@elseif($forms->category == 3)



<div class="col-sm-12">

<select class="form-control" name="mng_inter_answer[]" @if(!empty($edit->inter_mng_rating))  disabled @endif  @if($userid != $mng) disabled @endif @if($forms->required =='on') required  @endif>

<option value>Select option</option>

@foreach(json_decode($forms->ans) as $kg => $option)

<option  @if(!empty($edit->inter_mng_rating))  @if(($option == json_decode($edit->inter_mng_rating)[$l])) selected  @endif  @endif>{{$option}}</option>

@endforeach



</select>

</div>



@endif



   

    </td>

</tr>

 @php($l++)

@endif

@endforeach

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Employee's Self-Observation

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" name="inter_emp_stre" @if(!empty($edit)) disabled @if($edit->inter_emp_stre_obs) value="{{$edit->inter_emp_stre_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text" maxlength="60" name="inter_emp_weak" @if(!empty($edit)) disabled @if($edit->inter_emp_weak_obs) value="{{$edit->inter_emp_weak_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Observations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td>Strengths</td>

                                                    <td colspan="3">

                                                        <input type="text"  maxlength="60" @if($userid != $mng) disabled @endif name="inter_mng_stre" @if(!empty($edit->inter_mng_stre_obs)) disabled @if($edit->inter_mng_stre_obs) value="{{$edit->inter_mng_stre_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <td>Weaknesses</td>

                                                    <td colspan="3">

                                                        <input type="text"  maxlength="60" @if($userid != $mng) disabled @endif name="inter_mng_weak" @if(!empty($edit->inter_mng_weak_obs)) disabled @if($edit->inter_mng_weak_obs) value="{{$edit->inter_mng_weak_obs}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                                <tr>

                                                    <th colspan="4" class="bg_gray">

                                                        Manager’s Recommendations

                                                    </th>

                                                </tr>   

                                                <tr>

                                                    <td colspan="4">

                                                        <input type="text"  maxlength="60" @if($userid != $mng) disabled @endif name="inter_mng_recommendation" @if(!empty($edit->inter_mng_recommendation)) disabled @if($edit->inter_mng_recommendation) value="{{$edit->inter_mng_recommendation}}"  @endif  @endif  class="form-control width100" required/>

                                                    </td>

                                                </tr>

                                            </tbody>

                                        </table>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <h4 class="text-center">Signature</h4>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <p class="text-center">Please print and sign once all sections are completed.  The Supervisor will file both electronic and printed copies with the HR Department.</p>

                                        <p class="text-center">I am signing this form to indicate that I have received it and completed my portion.  My signature does not necessarily indicate that I agree with the contents.</p>

                                    </div>

                                    <div class="col-sm-12 m-t-10">

                                        <div class="row">

                                            <div class="col-sm-6">

                                                <p class="text-center"><input type="text" maxlength="60" name="sign" @if(!empty($edit)) disabled @if($edit->emp_sign) value="{{$edit->emp_sign}}"  @endif  @endif required class="form-control input_bb"/></p>

                                                <p class="text-center">Employee’s Signature</p>

                                            </div>

                                            <div class="col-sm-6">

                                            <p class="text-center"><input type="text" maxlength="60" name="mng_sign"  @if(!empty($edit->mng_sign)) disabled @if($edit->mng_sign) value="{{$edit->mng_sign}}"  @endif  @endif required  @if($userid != $mng) disabled @endif class="form-control input_bb"/></p>

                                                <p class="text-center">Supervisor’s Signature</p>

                                            </div>

                                        </div>

                                    </div>





                                    @if(empty($edit->created_by))



                                    <div class="row">

                                    <div class="col-sm-6">



                                    <button type="submit" class="form-control btn btn-primary">Submit</button>

                                    </div>



                                    </div>

                                  @elseif(empty($edit->updated_by) && ($role == 3))

                                    <div class="row">

                                    <div class="col-sm-6">



                                    <button type="submit" class="form-control btn btn-primary">Submit</button>

                                    </div>



                                    </div>



                                    @endif





                                </form>

                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

            

         @stop



         @section('extra_js')



<script>







$("form#appraisal_from_user").submit(function(e) {



 

e.preventDefault();

s_date = $('#s_date').val();
e_date = $('#e_date').val();
review_date = $('#review_date').val();



var today = new Date();
                  var dd = String(today.getDate()).padStart(2, '0');
                  var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                  var yyyy = today.getFullYear();

                  today = yyyy + '-' + mm + '-' + dd;

                  var d1 = Date.parse(today);
                  var d2 = Date.parse(s_date);
                  if (d1 < d2) {
                      alert ("Please Select Valid Date");
                      return false;
                  }

                   if (Date.parse(today) < Date.parse(e_date)) {
                      alert ("Please Select Valid Date");
                      return false;
                  }
                   
                  //  if (Date.parse(today) < Date.parse(review_date)) {
                  //     alert ("Please Select Valid Date");
                  //     return false;
                  // }

                   if (Date.parse(e_date) < Date.parse(s_date)) {
                      alert ("Please Select Valid Date");
                      return false;
                  }





// var  title = $('#title').val();

// var  question = $('#question').val();





// if(title.replace(/\s/g,'') ==''){

// alert('Please Enter Title');

// return false;

// }



// if(question.replace(/\s/g,'') ==''){

// alert('Please Enter Question');

// return false;

// }





$('#loadingDiv').show();



var token = "{{csrf_token()}}"; 





$.ajax({

url: '/insert_appraisal_form',

headers: {'X-CSRF-TOKEN': token}, 

type: "post",

data:$(this).serialize(),



success: function (data) {

//console.log(data.city); // this is good



if(data.status ==200){

 $('#loadingDiv').hide();



alertify.success(data.msg);

history.back();

 //swal("Good job!", "Added Successfully", "success");


}else if(data.status ==202){



  $('#loadingDiv').hide();

  alertify.success(data.msg);

// swal("Good job!", "User alert Exist", "success");

location.reload();



  }else if(data.status ==203){



  $('#loadingDiv').hide();

  alertify.success(data.msg);

// swal("Good job!", "Successfully Updated", "success");

   //location.reload();



}else{



 $('#loadingDiv').hide();

 alertify.error(data.msg);

// swal("Good job!", "You clicked the button!", "error");



}



}

});







});











</script>



@stop