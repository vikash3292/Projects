                                         @foreach($form as $key => $forms)

                                    <div class="col-sm-12">

                                        <div class="card one_to_form m-t-10">



                                           <div class="card-body">
                                               <div class="col-sm-12">



                                               @if($forms->type ==1)

                                              <h6> Job</h6>



                                               @elseif($forms->type ==2)



                                               <h6>Customer / Client</h6>



                                               @elseif($forms->type ==3)



                                               <h6>Communication</h6>



                                               @elseif($forms->type ==4)



                                               <h6>Interpersonal</h6>



                                               @endif



                                               <div>



                                               <div class="col-sm-12 p-0">
                                               		{{$forms->desc}}
											   </div>
                                               <div class="col-sm-12 p-0">
												<div class="row">
                                               <div class="col-sm-12">
                                                   <p class="font-500">{{$forms->question}}
                                                     @if($forms->required =='on')
                                                   	<span class="text-danger p-l-5">*</span>
                                                   	@endif
                                                    <a href="{{URL::to('edit-question')}}/{{$forms->id}}" ><i class="mdi mdi-pencil text-warning float-right cursorpointer" ></i></a>
                                                   </p>
                                               </div>
                                               @if($forms->category == 1)
                                                      <div class="col-sm-12">
                                                      	 <input type="text"  class="form-control"  >
                                                                </div>
                                               @elseif($forms->category == 2)
                                                 <div class="col-sm-12">
                                                       <ul class="p-0 mb-0">
                                                       	@foreach(json_decode($forms->ans) as $option)
                                                           <li>
                                                            <input type="radio" id="male"  value="{{$option}}" >
                                                            <label for="male">{{$option}}</label>
                                                           </li>
                                                           @endforeach
                                                          <!--  <li>



                                                            <input type="radio" id="female" name="answer[]" value="female">



                                                            <label for="male">Female</label>



                                                           </li>



                                                           <li>



                                                            <input type="radio" id="other" name="answer[]" value="other">



                                                            <label for="male">Other</label>



                                                           </li> -->



                                                       </ul>



                                                    </div>







                                               @elseif($forms->category == 3)







                                                <div class="col-sm-12">



                                                                    <select class="form-control"  >



                                                                    <option value>Select option</option>



                                                                    	@foreach(json_decode($forms->ans) as $option)



                                                                        <option>{{$option}}</option>



                                                                        @endforeach



                                                                        



                                                                    </select>



                                                                </div>







                                               @elseif($forms->category == 4)







                                                <div class="col-sm-12">



                                                  <ul class="p-0 m-b-0">



                                                  	@foreach(json_decode($forms->ans) as $option)



                                                      <li>



                                                        <div class="custom-control custom-checkbox">



                                                            <input type="checkbox" class="custom-control-input" value="{{$option}}"  id="customControlInline">



                                                             <label class="custom-control-label" for="customControlInline">{{$option}}</label>



                                                        </div>



                                                      </li>



                                                      @endforeach



                                                     <!--  <li>



                                                        <div class="custom-control custom-checkbox">



                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">



                                                             <label class="custom-control-label" for="customControlInline">Option 2</label>



                                                        </div>



                                                      </li>



                                                      <li> -->



                                                       <!--  <div class="custom-control custom-checkbox">



                                                            <input type="checkbox" class="custom-control-input" name="answer[]" id="customControlInline">



                                                             <label class="custom-control-label" for="customControlInline">Option 3</label>



                                                        </div>



                                                      </li> -->



                                                  </ul>



                                               </div>







                                               @endif















                                              











                                               </div>

</div>

                                               </div>



                                               </div>

</div>


</div>
</div>


                                               @endforeach





