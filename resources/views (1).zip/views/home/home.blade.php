@extends('layouts.dashboard_layout')
  @section('extra_css')
   <style>
      <?php
      
      $imgurl = URL::to('public/assets/images/bodyBG.png');
      
     ?>
      body {
         background-image: url('{{$imgurl}}');
         background-repeat: no-repeat;
         background-size: cover;
      }

      * {
         padding: 0;
         margin: 0;

      }

      .signUpWrapper {

         display: flex;
         width: 100%;
      }

      .formWrapper {
         width: 60%;
         /* background: #fff; */
         box-sizing: border-box;
         box-shadow: 2px 1px 28px #6967675c;
         border-radius: 5px;
         display: flex;
         height: 60vh;
         position: absolute;
         left: 50%;
         top: 50%;
         transform: translate(-50%, -50%);
         -ms-transform: translate(-50%, -50%);
         /* for IE 9 */
         -webkit-transform: translate(-50%, -50%);
         /* for Safari */

         /* optional size in px or %: */
         /* width: 100px;
         height: 100px; */
      }

      .welcome-Box {
         width: 40%;
         transition: all .5s;
         /* height: 100vh; */
         background: #0989eb70;
         /* align-items: stretch; */
         flex: 1;
         align-items: center;
         padding: 70px;
         color: #fff;
      }

      .welcome-Box.bgsecendry {
         background: #2974b6a1;
      }

      .CreateAccount-Box {
         width: 60%;
         display: flex;
         padding: 70px;
         align-items: center;
         transition: all .5s;
         background: #fff;
      }


      .loginfWrapper {
         display: none;
         float: left;
         width: 100%;
      }

      .ccc {
         transform: translateX(187%);
         right: 0;
         z-index: 1;
         transition: all .5s;
      }

      .bb {
         transform: translateX(-51%);
         transition: all .5s;
      }

      .footer-login {
         position: fixed;
         border-top: 2px solid #5fe384;
         width: 100%;
         bottom: 0;
         text-align: center !important;
         padding: 19px 30px 20px;
         background-color: #f1f2f5;
         font-family: Sarabun, sans-serif;
      }

      .toggleBtn {
         border: 1px solid #fff;
         background: transparent;
         color: #fff;
         padding: 10px 20px;
         border-radius: 20px;
      }

      .toggleBtnfilled {
         border: 1px solid #2974b6;
         background: #2974b6;
         color: #fff;
         padding: 10px 20px;
         border-radius: 20px;
      }

      @media (max-width:576px) {
         .formWrapper {
            width: 80%;
         }

         .welcome-Box {
            padding: 10px;
         }

         .CreateAccount-Box {
            padding: 10px;
         }
      }

      .footer-login {
         border-top: 2px solid #41a1d6 !important;
      }
   </style>
  
  @stop
@section('content')
   <div class="formWrapper">
      <span style="position: absolute;padding: 5px;">
         <img src="assets/images/kloudrac_new_logo-1.png" alt="" height="40">
      </span>
      <div class="signUpWrapper">

         <div class="welcome-Box">
            <div class="text-center position-relative">
               <h5 class="font-30 m-b-20">Hello,</h5>
               <p>Enter your Personal details and start journey with us </p>
            </div>
            <div class="h text-center">
               <button type="button" class="toggleBtn" id="signup">Sign Up</button>
            </div>
         </div>
         <div class="CreateAccount-Box">
            <div class="row">
               <div class="col-12 text-center position-relative">
                  <h5 class="font-30 m-b-20">Sign In to Kloudrac</h5>
               </div>
               <form class="form-horizontal m-t-20 width100" method="POST"
                  action="http://grcerp.projectdemoonline.com/admin" aria-label="Login">
                  <input type="hidden" name="_token" value="ENGeZUpxU8ZnCLjQ4IzCs6WW3x5xpOu7uMf6I5gn">
                  <div class="form-group">
                     <div class="row">
                        <div class="col-1 p-r-0">
                           <i class="mdi mdi-account-circle font-20"></i>
                        </div>
                        <div class="col-11">
                           <input id="emaildata" type="email" class="form-control " name="email" maxlength="60" value=""
                              autofocus="" placeholder="Enter valid Email">
                           <div id="email_error"></div>
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                        <div class="col-1 p-r-0">
                           <i class="mdi mdi-lock font-20"></i>
                        </div>
                        <div class="col-11">
                           <input id="password" type="password" class="form-control" name="password" maxlength="60"
                              placeholder="Enter password">
                           <span toggle="#password-field" onclick="login_psd()"
                              class="fa fa-eye field-icon toggle-password"></span>
                           <div id="password_error"></div>
                        </div>

                     </div>
                  </div>
                  <div class="col-12">
                     <div class="form-group row m-t-20">
                        <div class="col-md-6">
                           <div class="custom-control custom-checkbox">
                              <input class="custom-control-input" type="checkbox" name="remember" id="remember">
                              <label class="custom-control-label" for="customControlInline remember"> Remember
                                 Me</label>
                           </div>
                        </div>
                        <div class="col-sm-6">
                           <a href="http://grcerp.projectdemoonline.com/forget"><i class="mdi mdi-lock"></i> Forgot Your
                              Password?</a>
                        </div>
                     </div>
                  </div>
                  <div class="form-group m-t-10 mb-0 row">
                     <div class="col-12 m-t-20 text-center">
                        <button type="button" class="toggleBtnfilled">Sign In</button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>

      <div class="loginfWrapper">
         <div class="CreateAccount-Box">
            <div class="row">
               <div class="col-12 text-center position-relative">
                  <h5 class="font-30 m-b-20">Create Account</h5>
               </div>
               <form class="form-horizontal m-t-20 width100" method="POST"
                  action="http://grcerp.projectdemoonline.com/admin" aria-label="Login">
                  <input type="hidden" name="_token" value="ENGeZUpxU8ZnCLjQ4IzCs6WW3x5xpOu7uMf6I5gn">
                  <div class="form-group">
                     <div class="row">
                        <div class="col-1 p-r-0">
                           <i class="mdi mdi-account-circle font-20"></i>
                        </div>
                        <div class="col-11">
                           <input id="emaildata" type="text" class="form-control " name="uname" maxlength="60" value=""
                              autofocus="" placeholder="Enter Username">
                           <!-- <div id="email_error"></div> -->
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                        <div class="col-1 p-r-0">
                           <i class="mdi mdi-gmail font-20"></i>
                        </div>
                        <div class="col-11">
                           <input id="emaildata" type="email" class="form-control " name="email" maxlength="60" value=""
                              autofocus="" placeholder="Enter valid Email">
                           <div id="email_error"></div>
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                        <div class="col-1 p-r-0">
                           <i class="mdi mdi-lock font-20"></i>
                        </div>
                        <div class="col-11">
                           <input id="password" type="password" class="form-control" name="password" maxlength="60"
                              placeholder="Enter password">
                           <span toggle="#password-field" onclick="login_psd()"
                              class="fa fa-eye field-icon toggle-password"></span>
                           <div id="password_error"></div>
                        </div>

                     </div>
                  </div>
                  <div class="form-group m-t-10 mb-0 row">
                     <div class="col-12 m-t-20 text-center">
                        <button type="button" class="toggleBtnfilled">Sign Up</button>
                     </div>
                  </div>
               </form>
            </div>

         </div>
         <div class="welcome-Box bgsecendry">
            <div class="h text-center">
               <h4>Welcome Back!</h4>
               <p>To Keep Connected with us please login with your personal Info</p>
               <button type="button" class="toggleBtn" id="signin">Sign In</button>
            </div>
         </div>
      </div>

   </div>
  @endsection
   
  
@section('extra_js')

 <script>
      $(document).ready(function () {
         $("#signup").click(function () {
            $(".loginfWrapper").css({ "display": "flex", "transition": "all 2s linear" });
            $(".signUpWrapper").css("display", "none");
         });
         $("#signin").click(function () {
            $(".loginfWrapper").css("display", "none");
            $(".signUpWrapper").css({ "display": "flex", "transition": "all 2s linear" });
         });
      })
   </script>

@stop