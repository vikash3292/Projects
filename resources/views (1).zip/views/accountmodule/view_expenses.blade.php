@extends('layouts.superadmin_layout')

@section('content')



  <div class="content p-0">

                <div class="container-fluid">

                    <div class="page-title-box">

                        <div class="row align-items-center bredcrum-style">

                            <div class="col-sm-6 col-6">

                                <h4 class="page-title">Expenses View</h4>

                                <ol class="breadcrumb">

                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>

                                  

                                </ol>

                            </div>

                            <div class="col-sm-6 text-right col-6">

                                <a href="javascript: history.go(-1)" class="btn btn-primary">Back</a>

                              <!--   <button class="btn btn-primary"><i class="fa fa-download"></i> Download</button>
 -->
                            </div>

                        </div>

                    </div>

                    <!-- end row -->

                    <!-- end row -->

                    <div class="row">

                        <div class="col-12">

                            <div class="card m-t-20">

                                <div class="card-body">

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empcode" class="col-lg-4 col-form-label">Employee Name

                                                    <span class="text-danger"></span>

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->userfullname??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empcode" class="col-lg-4 col-form-label">Expense Name

                                                    <span class="text-danger"></span>

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->expense_name??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Project</label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->project_name??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empcode" class="col-lg-4 col-form-label">Category

                                                    <span class="text-danger"></span>

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->cat_name??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Expense Date</label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->expense_date??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Reimbursable

                                                    <span class="text-danger"></span>

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">



                                                        @if($expense_view->is_reimbursable==1)

                                                            Yes

                                                        @else

                                                           No

                                                        @endif

                                                    </label>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Reimbursable Amount

                                                    <span class="text-danger"></span>

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->reimbursed_ammount??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Amount

                                                    <span class="text-danger">*</span>

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->expense_amount??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                     

                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Select

                                                    Advance</label>

                                                    <div class="col-lg-8 col-form-label">

                                                        <label class="myprofile_label">

                                                        @if($expense_view->is_from_advance==1)

                                                            No Advance

                                                        @else

                                                            Advance

                                                        @endif</label>

                                                    </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Add To Trip</label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->trip??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Description

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">{{$expense_view->desc??''}}</label>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Uploaded

                                                    Receipt</label>

                                                    <div class="col-lg-8 col-form-label">

                                                    @if(!empty($expense_view->reciept))

<ul style="padding:0">

@foreach($expense_view->reciept as $files)

<li>

<a download href="{{URL::to('/public/uploads/expenses_receipts')}}/{{$files->receipt_filename??''}}">{{$files->receipt_name}}</a>

 </li>

@endforeach

</ul>

@endif

                                                        

                                                    </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Status

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label"> {{ucwords($expense_view->status)}}</label>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        
                                        
                                              <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Accountant Status

                                                </label>

                                                <div class="col-lg-8 col-form-label">




                                                    <label class="myprofile_label"> 
                                                    
                                                    
                                                     @if(!empty($expense_view->approaval_status))
                                                    {{ucwords($expense_view->approaval_status[1])??''}}
                                                    @endif
                                                    </label>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        
                                              <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Manager Status

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">
                                                        
                                                          @if(!empty($expense_view->approaval_status))
                                                         {{ucwords($expense_view->approaval_status[0])??''}}
                                                          @endif
                                                         </label>

                                                </div>

                                            </div>

                                        </div>
                                        
                                             <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Accountant Approval Date

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">
                                                        
                                                          @if(!empty($expense_view->approaval_status) && $expense_view->approaval_status[1] != 'pending')
                                                         {{ucwords($expense_view->approaval_date[1])??''}}
                                                          @endif
                                                         </label>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        
                                                                                      <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Manager Approval Date

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">
                                                        
                                                          @if(!empty($expense_view->approaval_status) && $expense_view->approaval_status[0] != 'pending')
                                                         {{ucwords($expense_view->approaval_date[0])??''}}
                                                          @endif
                                                         </label>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        
                                          @if(!empty($expense_view->certification))
                                         <div class="col-md-6">

                                            <div class="form-group row m-0">

                                                <label for="empid" class="col-lg-4 col-form-label">Part of CTC

                                                </label>

                                                <div class="col-lg-8 col-form-label">

                                                    <label class="myprofile_label">
                                                        
                                                         {{ucwords($expense_view->certification)}}
                                                         </label>

                                                </div>

                                            </div>

                                        </div>
                                        @endif
                                        

                                    </div>
                                    
                                    <div class="row">

							<div class="col-sm-12 text-right">
                                  @if($role == 3 && !empty($expense_view->approaval_status) && $expense_view->approaval_status[0] =='pending')
                                                   
                                                
								   <a href="javascript:void(0)" onclick="approve_expense('{{$expense_view->id}}',1)" class="btn btn-primary">Approved</a>
								
								    @endif
								    
								    
								     @if($role == 11 && !empty($expense_view->approaval_status) && $expense_view->approaval_status[1] =='pending')
                                                   
                                                
								   <a href="javascript:void(0)" onclick="approve_expense('{{$expense_view->id}}',1)" class="btn btn-primary">Approved</a>
								
								    @endif
 @if($role == 3 && !empty($expense_view->approaval_status) && $expense_view->approaval_status[0] =='pending')
                                                   
                                                
                                   <a href="javascript:void(0)" onclick="approve_expense('{{$expense_view->id}}',2)" class="btn btn-danger">Reject</a>
                                
                                    @endif
                                    
                                    
                                     @if($role == 11 && !empty($expense_view->approaval_status) && $expense_view->approaval_status[1] =='pending')
                                                   
                                                
                                   <a href="javascript:void(0)" onclick="approve_expense('{{$expense_view->id}}',2)" class="btn btn-danger">Reject</a>
                                
                                    @endif

							</div>

</div>
							


                                    <div class="row">

                                        <div class="col-sm-12">

                                            <h4 class="p-lr-20">TimeLine</h4>

                                        </div>

                                    </div>

                                    <div id="cd-timeline">

                                        <ul class="timeline list-unstyled">



                                            @foreach($expense_timeline as $k => $expense_timelines)



                                            @if($k%2==0)

                                            @php($class='timeline-list')

                                            @else

                                            @php($class='timeline-list  right clearfix')

                                            @endif

                                           <li class="{{$class}}">

                                              <div class="cd-timeline-content bg-light p-10">

                                                 <h5 class="mt-0 mb-2">{{ucwords($expense_timelines->userfullname)}}</h5>

                                                 <p class="mb-2">{{$expense_timelines->msg}}</p>

                                                 <p class="mb-0"></p>

                                                 <div class="date bg-primary">

                                                    <h5 class="mt-0 mb-0">{{date('d',strtotime($expense_timelines->created_at))}}</h5>

                                                    <p class="mb-0 text-white-50">{{date('M',strtotime($expense_timelines->created_at))}}</p>

                                                 </div>

                                              </div>

                                           </li>

                                           @endforeach

                                          <!--  <li class="timeline-list right clearfix">

                                              <div class="cd-timeline-content bg-light p-10">

                                                 <h5 class="mt-0 mb-2">Himanshu Pawar</h5>

                                                 <p>Reimbursable</p>

                                                 <button type="button" class="btn btn-primary btn-rounded waves-effect waves-light m-t-5">See more detail</button>

                                                 <div class="date bg-primary">

                                                    <h5 class="mt-0 mb-0">23</h5>

                                                    <p class="mb-0 text-white-50">Jan</p>

                                                 </div>

                                              </div>

                                           </li>

                                           <li class="timeline-list">

                                              <div class="cd-timeline-content bg-light p-10">

                                                 <h5 class="mt-0 mb-2">Nisha Upreti</h5>

                                                 <p>Reimburse</p>

                                                 <img src="assets/images/small/img-1.jpg" alt="" class="rounded mr-1" width="120"> <img src="assets/images/small/img-2.jpg" alt="" class="rounded" width="120">

                                                 <div class="date bg-primary">

                                                    <h5 class="mt-0 mb-0">24</h5>

                                                    <p class="mb-0 text-white-50">Jan</p>

                                                 </div>

                                              </div>

                                           </li>

                                           <li class="timeline-list right clearfix">

                                              <div class="cd-timeline-content bg-light p-10">

                                                 <h5 class="mt-0 mb-2">Timeline Event Four</h5>

                                                 <p class="mb-2">It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental</p>

                                                 <p class="mb-0">languages are members of the same family. Their separate existence is a myth... <a href="#" class="text-primary">Read More</a></p>

                                                 <div class="date bg-primary">

                                                    <h5 class="mt-0 mb-0">25</h5>

                                                    <p class="mb-0 text-white-50">Jan</p>

                                                 </div>

                                              </div>

                                           </li> -->

                                        </ul>

                                     </div>

                                </div>

                            </div>

                        </div>

                        <!-- end col -->

                    </div>

                    <!-- end row -->

                </div>

                <!-- container-fluid -->

            </div>

            



@stop

@section('extra_js')

<script>

function approve_expense(exp_id,status){
    
    
          $('#loadingDiv').show();
            var _token = "{{csrf_token()}}";

        $.ajax({
            url: '/expense_approval_indivial',
            type: "post",
            data: { "_token": _token, "exp_id": exp_id, "status": status },
            dataType: 'JSON',

            success: function (data) {
                //console.log(data.city); // this is good

                if (data.status == 200) {
                    $('#loadingDiv').hide();
                    

                    alertify.success(data.msg);

                      window.location.href = "{{URL::to('/expense')}}";


                } else {

                    $('#loadingDiv').hide();


                    alertify.error(data.msg);
                    
                     window.location.href = "{{URL::to('/expense')}}";

                }

            }
        });
}

</script>

@stop