  
@extends('layouts.superadmin_layout')
@section('content')
<?php
$year = date('Y');
?>
  <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Timesheet Unlock</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Timesheet Unlock</a></li>
                                </ol>
                            </div>
                            <div class="col-sm-6 text-right">
                               <i class="fa fa-cog font-20" data-toggle="modal" data-target="#timesheetsetting" title="Setting"></i>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                           <label for="year" class="col-lg-4 col-form-label">Year</label>
                                           <div class="col-lg-8">
                                              <select class="form-control" name="year" id="year" required=""  onchange="get_month(this.value)">
                                                 @for($i=date('Y')-1;$i <= date('Y'); $i++ )


   
                      <option @if(!empty($year))  @if($year == $i) selected    @endif @endif>{{$i}}</option>
      



                      @endfor



                                              </select>
                                           </div>
                                        </div>
                                     </div>
                                     <div class="col-md-4">
                                        <div class="form-group row">
                                           <label for="year" class="col-lg-4 col-form-label">Month</label>
                                           <div class="col-lg-8">
                                            <select class="form-control" name="month" id="month"  onchange="get_week()" required="">







                        <option value="">Select Month</option>




                     @for($i =1;$i <= (int)date('m');$i ++)


                        <option value="{{$i}}"   @if((int)date('m') == $i) selected    @endif >{{$i}}</option>

                        @endfor








                      </select>




                                           </div>
                                        </div>
                                     </div>
                                     <div class="col-md-4">
                                        <div class="form-group row">
                                           <label for="year" class="col-lg-4 col-form-label">Week</label>
                                           <div class="col-lg-8">
                                 <select class="form-control" name="week" id="week"  onchange="getweekandmonthtimesheet(this.value)">







                      <option value="">Select Week</option>





                                             @if(!empty($totalweek))



                                              @for($i =1; $i <=$totalweek; $i++)

                               <option value="{{$i}}"  @if(!empty($week)) @if($i == $week) selected    @endif  @endif>{{$i}}</option>



                                              @endfor



                                             @endif





                    </select>


                                           </div>
                                        </div>
                                     </div>
                                    </div>
                                    <div class="row">
                                        <!-- <div class="col-sm-12">
                                            <label class="datatable_search">Search:<input type="search" id="myInput" class="form-control form-control-sm"  onkeyup="myFunction()" placeholder="" aria-controls="datatable"></label>
                                        </div> -->
                                        <div class="col-sm-12 m-t-20">
                                            <table id="datatable" class="lock_timesheet table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Name</th>
                                                <th>Actual Hr</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                          <!--                   <tr>
                                                <td>1</td>
                                                <td>Nisha Upreti</td>
                                                <td>KSPL1165</td>
                                                <td>45 hr</td>
                                                <td>45 hr</td>
                                                <td>Lock</td>
                                                <td><i class="mdi mdi-lock-outline text-danger font-20"></i></td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Ujjval Shrivastava</td>
                                                <td>KSPL1175</td>
                                                <td>45 hr</td>
                                                <td>45 hr</td>
                                                <td>Unlocked</td>
                                                <td><i class="mdi mdi-lock-open-outline text-primary font-20"></i></td>
                                            </tr> -->
                                        </tbody>
                                    </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                               </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>



 <div id="timesheetsetting" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
           <div class="modal-content">
              <div class="modal-header">
                 <h5 class="modal-title mt-0" id="myModalLabel">Settings</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
              </div>
              <div class="modal-body">
                    <div class="form-group row">
                       <label for="example-text-input" class="col-sm-4 col-form-label">Automatic Lock Day</label>
                       <div class="col-sm-8">
                             <select class="form-control" id="lock_day">
                                <option value="">Select Option</option>
                                <option @if($setting->day == 'Sun') selected @endif>Sun</option>
                                <option @if($setting->day == 'Mon') selected @endif>Mon</option>
                                <option @if($setting->day == 'Tue') selected @endif>Tue</option>
                                <option @if($setting->day == 'Web') selected @endif>Web</option>
                                <option @if($setting->day == 'Thu') selected @endif>Thu</option>
                                <option @if($setting->day == 'Fri') selected @endif>Fri</option>
                                <option @if($setting->day == 'Sat') selected @endif>Sat</option>
                             </select>
                             <span id="lock_day_error"> </span>                
                                    </div>
                    </div>
                    <div class="form-group row">
                          <label for="example-text-input" class="col-sm-4 col-form-label">Unlock Duration</label>
                          <div class="col-sm-8">
                                <select class="form-control" id="lock_hour">
                                      <option value="">Select</option>
                                      <option value="1" @if($setting->hour == 1) selected @endif>1 hour</option>
                                      <option value="2" @if($setting->hour == 2) selected @endif>2 hour</option>
                                      <option value="3" @if($setting->hour == 3) selected @endif>3  hour</option>
                                      <option value="4" @if($setting->hour == 4) selected @endif>4 hour</option>
                                      <option value="5" @if($setting->hour == 5) selected @endif>5 hour</option>
                                      <option value="6" @if($setting->hour == 6) selected @endif>6 hour</option>

                                   </select>       

                                    <span id="lock_hour_error"> </span>                      

                                                  </div>
                       </div>
              </div>
              <div class="modal-footer">
                 <button type="button" onclick="save_lock_setting()" id="save_lock_setting" class="btn btn-primary waves-effect">Save</button> 
                 <button type="button" class="btn btn-secondary waves-effect waves-light" data-dismiss="modal">Cancel</button>
              </div>
           </div>
           <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
     </div>


            @stop

             @section('extra_js')

  <script type="text/javascript">
  function myFunction() {
      debugger
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("datatable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
$('#datatable').dataTable( {
  "searching": false
} );





    function save_lock_setting(){

lock_day = $('#lock_day').val();
lock_hour = $('#lock_hour').val();

     if(lock_day ==''){
         $('#lock_day_error').text('Day is Required').attr('style','color:red');
         $('#lock_day_error').show();
           error = 0;
              return false;
      }else{$('#lock_day_error').hide();  error = 1;}


        if(lock_hour ==''){
         $('#lock_hour_error').text('Hour is Required').attr('style','color:red');
         $('#lock_hour_error').show();
           error = 0;
              return false;
      }else{$('#lock_hour_error').hide();  error = 1;}

   

   var _token = "{{csrf_token()}}";

  $.ajax({
        url: '/save_setting',
        type: "post",
        data: {"_token": _token,"lock_day":lock_day,"lock_hour":lock_hour},
        dataType: 'JSON',
         
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
             
             swal("Good job!", "Added Successfully", "success");

             $('#timesheetsetting').modal('hide');

          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", data.msg, "success");
             $('#timesheetsetting').modal('hide');
           

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");


          }else{

             $('#loadingDiv').hide();
            
             swal("Good job!", "You clicked the button!", "error");

          }
          
        }
      });
      }

  var year = $('#year').val();

var month = $('#month').val();

    get_week();

    var currentweekCount = '{{$currentweekCount}}';



 
function get_week(){









   var _token = "{{csrf_token()}}";



  $.ajax({

        url: '/get_week',

        type: "post",

        data: {"_token": _token,"year":year,"month":month},

        dataType: 'JSON',

         

        success: function (data) {

        //console.log(data.city); // this is good

       getweekandmonthtimesheet(currentweekCount);

        $('#week').html(data.week);

        
        $("#week > option").each(function() {
                              if(this.text == currentweekCount){
                                 $('#week').val(currentweekCount).attr("selected"); 
                              }
                         
                           });
          

        }

      });



}



var user = '{{$userid}}';
var type = 'all';




 getweekandmonthtimesheet(currentweekCount);

 function getweekandmonthtimesheet(week){

  var year = $('#year').val();

var month = $('#month').val();

var week = $('#week').val();
     


     $('#loadingDiv').show();
 
      var _token = "{{csrf_token()}}";

  $.ajax({
        url: '/unlock_week_timsheet',
        type: "post",
        data: {"_token": _token,"user":user,"year":year,"month":month,"week":week},
        dataType: 'JSON',
         
        success: function (data) {
        // this is good


     $('#loadingDiv').hide();
       
      $('#loadingDiv').hide();
        $('.lock_timesheet tbody').html(data.approvellist);
          
        }
      });
    
    
}


function empApproveTimesheet(useri_d,status_id,week,repoting_id,status,year,month){

  if(status == 1){

    var s = 'Unlocked';

  }else{

      var s = 'Locked';

  }

  var result = confirm("Are You Sure "+ s);
if (result) {
    //Logic to delete the item



      $('#loadingDiv').show();
      var _token = "{{csrf_token()}}";

  $.ajax({
        url: '/lock_status',
        type: "post",
        data: {"_token": _token,"useri_d":useri_d,"status_id":status_id,"week":week,"repoting_id":repoting_id,"status":status,'year':year,'month':month},
        dataType: 'JSON',
         
        success: function (data) {
        // this is good
        
          $('#loadingDiv').hide();
       
    if(data.status == 200){
        
     
          getweekandmonthtimesheet(week);
        
          alertify.success(data.msg);
        
        
    }
     
          
        }
      });

}
    
}


  var year = $('#year').val();

var month = $('#month').val();

var week = $('#week').val();

  current_year = "{{date('Y')}}";
          current_month = "{{date('m')}}";

		 function get_month(val){



		 	if(val == current_year){
		 		month = current_month;

		 	}else{

		 		month = 12;
		 	}

        year = '';
        for(i = 1; i<=month; i++ ){

        	

        	year +='<option value='+i+'>'+i+'</option>';
		 }
		 $('#month').html(year);
		  getweekandmonthtimesheet(week);
        }

</script>

@stop