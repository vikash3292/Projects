@extends('layouts.superadmin_layout')
   @section('content')

   <?php 
 
 $current_year = date('Y')-1;
   $preYear = (int) date('Y')-2;
   $currentYear = (int)date('Y');
  
   ?>
            
         <div class="content p-0">
                <div class="container-fluid">
                     @if (Session::has('message'))
         <div class="alert alert-{{Session::get('alert')}} alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button> 
            <strong>{{Session::get('message')}}</strong>
         </div>
         @endif
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Export Timssheet</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
                                    <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Export Timssheet
                                            </a></li>
                                </ol>
                                
                            </div>
                            

                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                 <form method="post" id="export_timesheet">
                                    <div class="row">
                                        <div class="col-md-6">
                                        <?php 
                                        $userdetils = DB::table('main_users')->where('isactive',1)->whereNull('extension')->get();
                                        ?>
                                            <div class="form-group row">
                                                <label for="empid" class="col-lg-4 col-form-label">Select
                                                    Employee <span class="text-danger">*</span></label>
                                                   <div class="col-lg-8">
                                                       <select class="form-control js-example-basic-single" name="user_id" onchange="get_project(this.value)" id="user_id" required>
                                                         
                                                         <option value=""> Select Option</option>
                                                           <option value="all"> All Employee</option>
                                                           @foreach($userdetils as $userlist)
                                                           
                                                         <option value="{{$userlist->id}}"  >{{ucwords($userlist->userfullname)}}</option>
                                                         
                                                           @endforeach


                                                       

                                                       
                                                    </select>
                                                    <div id="user_id_error"></div>
                                                       <!--<input type="text" name="emp_name" id="emp_name" class="form-control" value="{{$name??''}}" placeholder="Enter Employee Name" />-->
                                                       <!--<div id="empList">-->
                                                       <!-- <input id="userid" name="userid" type="hidden" value="{{$userid??0}}">-->
                                                       <!--</div>-->
                                                     
                                                      <!--{{ csrf_field() }}-->
                                                  <!--   <select class="form-control">
                                                  <!--      <option>Select</option>-->
                                                  <!--      <option>Nisha Upreti</option>-->
                                                  <!--      <option>Diksha Saini</option>-->
                                                  <!--      <option>Rajesh Yadav</option>-->
                                                  <!--      <option>RIshab</option>-->
                                                  <!--      <option>Pooja</option>-->
                                                  <!--      <option>Nitish</option>-->
                                                  <!--  </select> -->
                                                </div>
                                            </div>
                                        </div>
                                        
                                           <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">
                                                    Project </label>
                                                <div class="col-lg-8">
                                      
                                                  <select class="form-control" id="project" name="project" >

											<option value="">Select Project</option>
											</select>
                                                </div>
                                            </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">
                                                    From Date <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                      
                                                    <input type="date" class="form-control" id="from_date" name="from_date" required>
                                                    <div id="from_date_error"></div>
                                            
                                                </div>
                                            </div>
                                        </div>
                                        
                                         <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="empcode" class="col-lg-4 col-form-label">
                                                    To Date <span class="text-danger">*</span></label>
                                                <div class="col-lg-8">
                                      
                                                    <input type="date" class="form-control" id="to_date" name="to_date" required>
                                                    <div id="to_date_error"></div>
                                                
                                                </div>
                                            </div>
                                        </div>
                                        
                                           {{ csrf_field() }}
                                        <!--<div class="col-md-6">-->
                                        <!--    <div class="form-group row">-->
                                        <!--        <label for="empcode" class="col-lg-4 col-form-label">Select-->
                                        <!--            From Date <span class="text-danger">*</span></label>-->
                                        <!--        <div class="col-lg-8">-->
                                      
                                        <!--          <input type="date" class="form-control js-example-basic-single" id="form_date" name="form_date">-->
                                        <!--        </div>-->
                                        <!--    </div>-->
                                        <!--</div>-->
                                    </div>
                                    <div class="row">
                                        <!--<div class="col-md-6">-->
                                        <!--    <div class="form-group row">-->
                                        <!--        <label for="empcode" class="col-lg-4 col-form-label">To Date-->
                                        <!--            Year <span class="text-danger">*</span></label>-->
                                        <!--        <div class="col-lg-8">-->
                                         
                                                  
                                        <!--          <input type="date" class="form-control js-example-basic-single" id="to_date" name="to_date">-->
                                                
                                        <!--        </div>-->
                                        <!--    </div>-->
                                        <!--</div>-->
                                        <div class="col-sm-6">
                                            <button type="button" onclick="export_timesheet()" class="btn btn-primary float-right">Export</button>
                                        </div>
                                    </div>
                                   </form>
                                   
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>




           @stop

                 @section('extra_js')

  <script type="text/javascript">
  
  
  function export_timesheet(){
      
      var user_id = $('#user_id').val();
            var from_date = $('#from_date').val();
                  var to_date = $('#to_date').val();
      
       if(user_id ==''){
         $('#user_id_error').text('User is Required').attr('style','color:red');
         $('#user_id_error').show();
           error = 0;
              return false;
      }else{$('#user_id_error').hide();  error = 1;}
      
       if(from_date ==''){
         $('#from_date_error').text('Form Date is Required').attr('style','color:red');
         $('#from_date_error').show();
           error = 0;
              return false;
          }else if(today_date(from_date) == false){

          	$('#from_date_error').text('Form Date invalid').attr('style','color:red');
         $('#from_date_error').show();
           error = 0;
              return false;

      }else{$('#from_date_error').hide();  error = 1;}
      
       if(to_date ==''){
         $('#to_date_error').text('To Date is Required').attr('style','color:red');
         $('#to_date_error').show();
           error = 0;
              return false;
      }else if(today_date(to_date) == false){

      	$('#to_date_error').text('To Date invalid').attr('style','color:red');
         $('#to_date_error').show();
           error = 0;
              return false;


      }else{$('#to_date_error').hide();  error = 1;}
      
      
         var d1 = Date.parse(from_date);
         var d2 = Date.parse(to_date);
        if(d1 > d2){
        $('#to_date_error').text('Valid Date is Required').attr('style','color:red');
         $('#to_date_error').show();
           error = 0;
              return false;
      }else{$('#to_date_error').hide();  error = 1;}


      
      $('#export_timesheet').submit();
      
  }


  function today_date(date_val){

                  var today = new Date();
                  var dd = String(today.getDate()).padStart(2, '0');
                  var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                  var yyyy = today.getFullYear();

                  today = yyyy + '-' + mm + '-' + dd;

                  var d1 = Date.parse(today);
                  var d2 = Date.parse(date_val);
                  if (d1 < d2) {

                  	return false;
                     
                  }else{

                  	return true;

                  }


  }
  
  
  
function get_project(user_id){





	var _token = "{{csrf_token()}}";

	$.ajax({

		url: '/get_user_project',

		type: "post",

		data: {"_token": _token,"user_id":user_id},

		dataType: 'JSON',



		success: function (data) {



			$('#project').html(data.project);



		}

	});



}


                    
 $(document).ready(function(){

 $('#emp_name').keyup(function(){ 
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"/searchemp",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#empList').fadeIn();  
                    $('#empList').html(data);
          }
         });
        }
    });

    $(document).on('click', 'li', function(){  
        $('#emp_name').val($(this).text());  
        $('#empList').fadeOut();  
    });  

});

 $(".advance_setting").on("click", function(){
            $(".state_dist_wrapper").addClass("state_dis_cls");
        });
        $(".close_popup").on("click", function(){
           $(".state_dist_wrapper").removeClass("state_dis_cls"); 
        });
                 </script>


                 @stop