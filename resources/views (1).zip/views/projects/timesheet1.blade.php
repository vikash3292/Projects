

@extends('layouts.superadmin_layout')
@section('content')

 <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Timesheet</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="timesheet.html">Timesheet</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right">
                                <span class="font-600 m-r-10">Legend:</span>
                                <span class="span_hr bg-blank float-none">Leave</span>
                                <span class="span_hr bg-weekend float-none">Week Off</span>
                                <span class="span_hr bg-approx float-none">Estimate Hr</span>
                                <span class="span_hr bg-equalhr float-none">Actual Hr</span>
                                <span class="span_hr bg-free float-none">Free Hr</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <ul class="nav nav-tabs nav-tabs-custom" role="tablist">
                                                <li class="nav-item"><a class="nav-link active" data-toggle="tab"
                                                        href="#home1" role="tab"><span class="d-block d-sm-none"><i
                                                                class="fas fa-home"></i></span> <span
                                                            class="d-none d-sm-block">Timesheet</span></a></li>
                                                <li class="nav-item"><a class="nav-link" data-toggle="tab"
                                                        href="#timeallocation" role="tab"><span
                                                            class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                                        <span class="d-none d-sm-block">Timesheet Allocation</span></a>
                                                </li>
                                                <li class="nav-item"><a class="nav-link" data-toggle="tab"
                                                        href="#profile1" role="tab"><span class="d-block d-sm-none"><i
                                                                class="far fa-user"></i></span> <span
                                                            class="d-none d-sm-block">Employee Timesheet</span></a></li>
                                            </ul>
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active p-3" id="home1" role="tabpanel">
                                                    <div class="col-sm-12 p-0 m-t-20">
                                                        <div class="row">
                                                            <div class="col-sm-6 p-r-0">
                                                                <h6 class="m-0 bg-naviblue">Name</h6>
                                                            </div>
                                                            <div class="col-sm-6 p-l-0">
                                                                <h6 class="m-0 bg-naviblue text-center">Actual
                                                                    Hours
                                                                    in Week 1</h6>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-sm-6 p-r-0">
                                                                <h6 class="m-0 bg-light padding-5">
                                                                    <form role="search" class="app-search m-0"
                                                                        style="height: 0;">
                                                                        <div class="form-group mb-0">
                                                                            <input type="text" class="form-control m-0"
                                                                                placeholder="Search by Name..">
                                                                            <button type="submit" style="top:10px"><i
                                                                                    class="fa fa-search"></i></button>
                                                                        </div>
                                                                    </form>
                                                                </h6>
                                                            </div>
                                                            <div class="col-sm-6 p-l-0">
                                                                <h6
                                                                    class="m-0 text-center relative bg-light p-10 cursorpointer font-20">
                                                                    <i class="fa fa-calendar-alt m-r-5"
                                                                        id="datepicker"></i><input type="hidden"
                                                                        id="dp" />December
                                                                    <div class="tableabsolute">
                                                                        <table border="1">
                                                                            <thead>
                                                                                <tr>
                                                                                    <td colspan="3" class="form-group">
                                                                                        <select class="form-control">
                                                                                            <option>2019</option>
                                                                                            <option>2020</option>
                                                                                        </select>
                                                                                    </td>
                                                                                </tr>
                                                                            </thead>
                                                                            <tr>
                                                                                <td>Jan</td>
                                                                                <td>Feb</td>
                                                                                <td>Mar</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Apr</td>
                                                                                <td>May</td>
                                                                                <td>Jun</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Jul</td>
                                                                                <td>Aug</td>
                                                                                <td>Sep</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Oct</td>
                                                                                <td>Nov</td>
                                                                                <td>Dec</td>
                                                                            </tr>
                                                                        </table>
                                                                    </div>
                                                                </h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row m-t-20">
                                                        <div class="col-sm-12 btn-tab">
                                                            <ul class="nav nav-tabs small justify-content-end"
                                                                role="tablist">
                                                                <li class="nav-item"><a class="nav-link active"
                                                                        data-toggle="tab" href="#tab1" role="tab">Week
                                                                        1</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab2" role="tab">Week
                                                                        2</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab3" role="tab">Week
                                                                        3</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab4" role="tab">Week
                                                                        4</a></li>
                                                                <li class="nav-item"><a class="nav-link"
                                                                        data-toggle="tab" href="#tab5" role="tab">Week
                                                                        5</a></li>
                                                            </ul>
                                                            <div class="tab-content py-2">
                                                                <div class="tab-pane active" id="tab1" role="tabpanel">
                                                                    
                                                                    <div class="col-sm-12 p-0 timesheet">

                                                                        <ul class="bg-gray nav nav-tabs small justify-content-end"
                                                                            role="tablist">
                                                                            <li class="nav-item"><a
                                                                                    class="nav-link active"
                                                                                    data-toggle="tab" href="#tab1"
                                                                                    role="tab">Sun 27
                                                                                    Dec</a>
                                                                            </li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab2"
                                                                                    role="tab">Mon 28 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab3"
                                                                                    role="tab">Tue 29 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab4"
                                                                                    role="tab">Wed 30 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab5"
                                                                                    role="tab">Thurs 31 Dec</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab6"
                                                                                    role="tab">Fri 1 Jan</a></li>
                                                                            <li class="nav-item"><a class="nav-link"
                                                                                    data-toggle="tab" href="#tab7"
                                                                                    role="tab">Sat 2 Jan</a></li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="col-sm-12 p-0 treeview">
                                                                        <!-- <ul id="" class="evendiv">
                                                                            <li>
                                                                                <span class="caret">Nisha Upreti</span>
                                                                                <span class="float-right">
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-approx">9
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                </span> -->
                                                                        <ul class="evendiv">
                                                                            <li><span
                                                                                    class="caret p-level1-span">Salesforce</span>
                                                                                <span class="float-right">
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-approx">9
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-equalhr">8
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">6
                                                                                        hrs</span>
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                </span>
                                                                                <ul class="nested">
                                                                                    <li>
                                                                                        <span
                                                                                            class="caret p-level2-span">HSBC</span>
                                                                                        <span class="span_45hr">45
                                                                                            Hr</span>
                                                                                        <ul class="nested lastul">
                                                                                            <li>
                                                                                                <span>Design</span>
                                                                                                <div
                                                                                                    class="text-right float-right padding-5 inline-block">
                                                                                                    <span
                                                                                                        class="timespan">--
                                                                                                    </span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00">
                                                                                                    </span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan p-lr-0">
                                                                                                        <input
                                                                                                            type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                            placeholder="00:00"></span>
                                                                                                    <span
                                                                                                        class="timespan">--
                                                                                                    </span>
                                                                                                </div>

                                                                                            </li>
                                                                                        </ul>
                                                                                    </li>
                                                                            </li>
                                                                        </ul>
                                                                        <!-- </li>
                                                                        </ul> -->
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab2" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">Primary</h3>
                                                                            <p class="card-text">With supporting text
                                                                                below as a natural
                                                                                lead-in to additional content.</p>
                                                                            <a href="#"
                                                                                class="btn btn-outline-secondary">Outline</a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">Primary</h3>
                                                                            <p class="card-text">With supporting text
                                                                                below as a natural
                                                                                lead-in to additional content.</p>
                                                                            <a href="#"
                                                                                class="btn btn-outline-secondary">Outline</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab3" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">week3</h3>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab4" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">week4</h3>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab5" role="tabpanel">
                                                                    <div class="card border-primary mb-3">
                                                                        <div class="card-body">
                                                                            <h3 class="card-title">week5</h3>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-12 m-t-20">
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <label>Weekly Notes</label>
                                                                    </div>
                                                                    <div>
                                                                        <textarea class="form-control"
                                                                            rows="3"></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12 m-t-20">
                                                                    <div class="float-right">
                                                                        <button class="btn btn-primary">Save</button>
                                                                        <button class="btn btn-success">Save &
                                                                            Submit</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane p-3" id="timeallocation" role="tabpanel">
                                                    <div class="col-sm-12 p-0 m-t-20">
                                                        <div class="row">
                                                            <div class="col-sm-6 p-r-0">
                                                                <h6 class="m-0 bg-naviblue">Name</h6>
                                                            </div>
                                                            <div class="col-sm-6 p-l-0">
                                                                <h6 class="m-0 bg-naviblue text-center">Allocation Hours
                                                                    in Week {{$currentweekCount??1}}</h6>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-sm-6 p-r-0">
                                                                <h6 class="m-0 bg-light padding-5">
                                                                    <form role="search" class="app-search m-0"
                                                                        style="height: 0;">
                                                                        <div class="form-group mb-0">
                                                                            <input type="text" class="form-control m-0"
                                                                                placeholder="Search by Name..">
                                                                            <button type="submit" style="top:10px"><i
                                                                                    class="fa fa-search"></i></button>
                                                                        </div>
                                                                    </form>
                                                                </h6>
                                                            </div>
                                                              <?php
                                                                            
                                                                            $startDate = $daterange[0];
                                                                            $showDate = date('Y-m',strtotime($startDate));
                                                                            $showMonth = date('M',strtotime($startDate));
                                                                             $endtDate = $daterange[1];
                                                                             $startDay = date('d',strtotime($startDate));
                                                                            $endDay = date('d',strtotime($endtDate));
                                                                            //dd($showDate);
                                                                          
                                                                            ?>      
                                                            <div class="col-sm-6 p-l-0">
                                                                <h6
                                                                    class="m-0 text-center relative bg-light p-10 cursorpointer font-20">
                                                                    <i class="fa fa-calendar-alt m-r-5"
                                                                        id="datepicker"></i><input type="hidden"
                                                                        id="dp" />{{$showMonth}}
                                                                    <div class="tableabsolute">
                                                                        <table border="1">
                                                                            <thead>
                                                                                <tr>
                                                                                    <td colspan="3" class="form-group">
                                                                                        <select class="form-control">
                                                                                            <option>2019</option>
                                                                                            <option>2020</option>
                                                                                        </select>
                                                                                    </td>
                                                                                </tr>
                                                                            </thead>
                                                                            <tr>
                                                                                <td>Jan</td>
                                                                                <td>Feb</td>
                                                                                <td>Mar</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Apr</td>
                                                                                <td>May</td>
                                                                                <td>Jun</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Jul</td>
                                                                                <td>Aug</td>
                                                                                <td>Sep</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Oct</td>
                                                                                <td>Nov</td>
                                                                                <td>Dec</td>
                                                                            </tr>
                                                                        </table>
                                                                    </div>
                                                                </h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                    <div class="row m-t-20">
                                                        <div class="col-sm-12 btn-tab">
                                                            <ul class="nav nav-tabs small justify-content-end"
                                                                role="tablist">
                                                                
                                                                @for($i = 1;$i <= $currentweekCount;$i++)
                                                                 @if($i== $currentweekCount)
                                                                   <?php
                                                                   $ac ='active';
                                                                   ?>
                                                                 @else
                                                                 
                                                                  <?php
                                                                   $ac ='';
                                                                   ?>
                                                                 
                                                                 @endif
                                                                <li  class="nav-item"><a class="nav-link {{$ac}}"
                                                                    onclick="assignHour('{{date('Y-m')}}','{{$i}}','{{$totalweekCount}}','time')" href="javascript:void(0)">Week
                                                                        {{$i}}</a></li>
                                                                @endfor        
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab2" role="tab">Week-->
                                                                <!--        2</a></li>-->
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab3" role="tab">Week-->
                                                                <!--        3</a></li>-->
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab4" role="tab">Week-->
                                                                <!--        4</a></li>-->
                                                                <!--<li class="nav-item"><a class="nav-link"-->
                                                                <!--        data-toggle="tab" href="#timetab5" role="tab">Week-->
                                                                <!--        5</a></li>-->
                                                            </ul>
                                                            <div class="tab-content py-2">
                                                                
                                                                  @for($i = 1;$i <= $currentweekCount;$i++)
                                                                  
                                                                   @if($i== $currentweekCount)
                                                                   <?php
                                                                   $ac ='active';
                                                                   ?>
                                                                 @else
                                                                 
                                                                  <?php
                                                                   $ac ='';
                                                                   ?>
                                                                 
                                                                 @endif
                                                                 
                                                                       
                                                                            
                                                                              
                                                                   
                                                                            
                                                                         
                                                                
                                                                <div class=" {{$ac}}" id="timetab1" role="tabpanel">
                                                                    <div class="col-sm-12 p-0 timesheet">
                                                                 

                                                                        <ul class="bg-gray nav nav-tabs small justify-content-end"
                                                                            role="tablist">
                                                                            
                                                                            
                                                                             @for($i = (int) $startDay; $i < (int) $endDay; $i++)
                                                                            
                                                                            <li class="nav-item"> 
                                                                            <a class="nav-link">
                                                                                   {{date('D d M',strtotime($showDate.'-'.$i))}}
                                                                                   </a>
                                                                                    
                                                                            </li>
                                                                            @endfor 
                                                                       
                                                                   
                                                                        </ul>
                                                                    </div>
                                                                     @foreach($userproject as $key => $userprojects)
                                                                    <div class="col-sm-12 p-0 treeview">
                                                                        <ul id="" class="evendiv">
                                                                            
                                                                           
                                                                            
                                                                            <li>
                                                                                <span class="caret">{{ucwords($userprojects->userfullname??'')}}</span>
                                                                                <span class="float-right">
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                    <span class="span_hr bg-equalhr">0
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">0
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-approx">0
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-equalhr">0
                                                                                        hrs</span>
                                                                                    <span class="span_hr bg-free">0
                                                                                        hrs</span>
                                                                                    <span
                                                                                        class="span_hr bg-weekend">NA</span>
                                                                                </span>
                                                                                <ul class="nested">
                                                                                    @foreach($userprojects->catgory as $cat)
                                                                                    <li><span
                                                                                            class="caret p-level1-span">{{ucwords($cat->cat_name)}}</span>
                                                                                        <span class="span_45hr">0
                                                                                            Hr</span>
                                                                                        <ul class="nested">
                                                                                            
                                                                                            @foreach($cat->getproject as $projects)
                                                                                            <li>
                                                                                                <span
                                                                                                    class="caret p-level2-span">{{ucwords($projects->project_name)}}</span>
                                                                                                <span
                                                                                                    class="span_45hr">0
                                                                                                    Hr</span>
                                                                                                <ul
                                                                                                    class="nested lastul">
                                                                                                    
                                                                                                    @foreach($projects->gettask as $gettask)
                                                                                                    <li>
                                                                                                        <span>{{ucwords($gettask->task)}}</span>
                                                                                                        
                                                                                                        <input type="hidden" name="project_id[]" value="{{$gettask->project_id}}">
                                                                                                             <input type="hidden" name="task_id[]" value="{{$gettask->task_id}}">
                                                                                                              <input type="hidden" name="emp_id[]" value="{{$gettask->emp_id}}">
                                                                                                              <input type="hidden" name="project_task_id[]" value="{{$gettask->project_task_id}}">
                                                                                                        
                                                                                                        <div
                                                                                                        
                                                                                                            class="text-right float-right padding-5 inline-block">
                                                                                                            <span
                                                                                                                class="timespan">--
                                                                                                            </span>
                                                                                                            <span
                                                                                                                class="timespan p-lr-0">
                                                                                                                <input
                                                                                                                    type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                                    placeholder="00:00">
                                                                                                            </span>
                                                                                                            <span
                                                                                                                class="timespan p-lr-0">
                                                                                                                <input
                                                                                                                    type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                                    placeholder="00:00"></span>
                                                                                                            <span
                                                                                                                class="timespan p-lr-0">
                                                                                                                <input
                                                                                                                    type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                                    placeholder="00:00"></span>
                                                                                                            <span
                                                                                                                class="timespan p-lr-0">
                                                                                                                <input
                                                                                                                    type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                                    placeholder="00:00"></span>
                                                                                                            <span
                                                                                                                class="timespan p-lr-0">
                                                                                                                <input
                                                                                                                    type="text" onkeypress="preventNonNumericalInput(event)"
                                                                                                                    placeholder="00:00"></span>
                                                                                                            <span
                                                                                                                class="timespan">--
                                                                                                            </span>
                                                                                                        </div>
                                                                                                      
                                                                                                    </li>
                                                                                                    @endforeach
                                                                                                </ul>
                                                                                            </li>
                                                                                            @endforeach
                                                                                            
                                                                                            
                                                                                            
                                                                                    </li>
                                                                                    @endforeach
                                                                                    
                                                                                    
                                                                                </ul>
                                                                            </li>
                                                                            
                                                                            
                                                                          
                                                                            
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                      @endforeach
                                              
                                                
                                                
                                                                    <div class="mainhilight">
                                                                        <button class="btn btn-primary">Update</button>
                                                                      
                                                                    </div>
                                                                </div>
                                                                
                                                                 @endfor
                                                                
                                                                 <div class="tab-pane" id="timetab2" role="tabpanel">
                                                                    week2
                                                                    
                                                                </div>
                                                                   <div class="tab-pane" id="timetab3" role="tabpanel">
                                                                    week3
                                                                    
                                                                </div>
                                                                   <div class="tab-pane" id="timetab4" role="tabpanel">
                                                                    week4
                                                                    
                                                                </div>
                                                                   <div class="tab-pane" id="timetab5" role="tabpanel">
                                                                    week5
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
@stop

@section('extra_js')

<script>

function assignHour(yearMonth,currentweek,totalWeek,time){
    
    window.location.href = 'timesheet/'+yearMonth+'/'+currentweek+'/'+totalWeek+'/'+time;
    
}

</script>

@stop