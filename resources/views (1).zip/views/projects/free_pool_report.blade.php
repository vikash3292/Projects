







@extends('layouts.superadmin_layout')







@section('content')















<div class="content p-0">







	<div class="container-fluid">







		<div class="page-title-box">







			<div class="row align-items-center bredcrum-style">







				<div class="col-sm-6">







					<h4 class="page-title">All Free Pool Report</h4>







					<ol class="breadcrumb">







						<li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>







					</ol>







				</div>







				<div class="col-sm-6">







					<div class="float-right d-none d-md-block">







						<div class="dropdown">









					</div>







				</div>







			</div>







		</div>







	</div>







	<!-- end row -->







	<!-- end row -->







	<div class="row">







		<div class="col-12">







			<div class="card m-t-20">







				<div class="card-body">







					<form method="post">







						<div class="row">







							<div class="col-md-6">







								<div class="form-group row">







									<label for="empcode" class="col-lg-4 col-form-label">Select Year







										<span class="text-danger">*</span>







									</label>







									{{csrf_field()}}







									<div class="col-lg-8">







										<select class="form-control" name="year" id="year" required=""  onchange="get_week()" required="">







											<option value="">Select Year</option>







											@for($i=date('Y')-1;$i <= date('Y'); $i++ )







											<option @if(!empty($year))  @if($year == $i) selected    @endif @endif>{{$i}}</option>















											@endfor















										</select>























									</div>







								</div>















							</div>







							<div class="col-md-6">







									<div class="form-group row">







										<label for="empcode" class="col-lg-4 col-form-label">Select Month







											<span class="text-danger">*</span>







										</label>







										<div class="col-lg-8">







								<select class="form-control" name="month" id="month"  onchange="get_week()" required="">







												<option value="">Select Month</option>







												<option value="1" @if(!empty($month))  @if($month == 1) selected    @endif @endif>January</option>







												<option value="2" @if(!empty($month))  @if($month == 2) selected    @endif @endif>February</option>







												<option value="3" @if(!empty($month))  @if($month == 3) selected    @endif @endif>March</option>







												<option value="4" @if(!empty($month))  @if($month == 4) selected    @endif @endif>April</option>







												<option value="5" @if(!empty($month))  @if($month == 5) selected    @endif @endif>May</option>







												<option value="6" @if(!empty($month))  @if($month == 6) selected    @endif @endif>June</option>







												<option value="7" @if(!empty($month))  @if($month == 7) selected    @endif @endif>July</option>







												<option value="8" @if(!empty($month))  @if($month == 8) selected    @endif @endif>August</option>







												<option value="9" @if(!empty($month))  @if($month == 9) selected    @endif @endif>September</option>







												<option value="10" @if(!empty($month))  @if($month == 10) selected    @endif @endif>October</option>







												<option value="11" @if(!empty($month))  @if($month == 11) selected    @endif @endif>November</option>







												<option value="12" @if(!empty($month))  @if($month == 12) selected    @endif @endif>December</option>







											</select>







										</div>







									</div>







								</div>







							<div class="col-md-6">







								<div class="form-group row">







									<label for="empcode" class="col-lg-4 col-form-label">Select Week







										<span class="text-danger"></span>







									</label>











									<div class="col-lg-8">







										<select class="form-control" name="week" id="week" >







											<option value="">Select Week</option>





                                             @if(!empty($totalweek))



                                              @for($i =1; $i <=$totalweek; $i++)

                               <option value="{{$i}}"  @if(!empty($week)) @if($i == $week) selected    @endif  @endif>{{$i}}</option>



                                             	@endfor



                                             @endif





										</select>









									</div>







								</div>















							</div>







						</div>







						<div class="row">







							<div class="col-md-6">







								<div class="form-group row">







									<label for="empcode" class="col-lg-4 col-form-label">Employee Name







										<span class="text-danger">*</span>







									</label>







									<div class="col-lg-8">







										<select class="form-control multiselect-ui" multiple="multiple" name="user[]" id="user" required="">







											<option value="">Select Name</option>







											<option value="all" @if(!empty($user))  @if(in_array('all',$user)) selected    @endif @endif>All EMP</option>



                                            @if(!empty($userlist))



											@foreach($userlist as $userlists)







											<option value="{{$userlists->id}}" @if(!empty($user))  @if(in_array($userlists->id,$user)) selected    @endif @endif>{{$userlists->userfullname}}</option>







											@endforeach



											@endif















										</select>







									</div>







								</div>







							</div>







							



							<div class="col-md-6">







								<div class="form-group row">







									<label for="empcode" class="col-lg-4 col-form-label">Select Project







										<span class="text-danger">*</span>







									</label>







								







									<div class="col-lg-8">







										<select class="form-control" name="project" required="">







											<option value="">Select Project</option>







										@foreach($project_list as $project_lists)







											<option   value="{{$project_lists->id}}" @if(!empty($project))  @if($project_lists->id == $project) selected    @endif @endif>{{$project_lists->project_name}}</option>















											@endforeach















										</select>























									</div>







								</div>















							</div>











						</div>







						<div class="row">







							<div class="col-sm-6 text-center">







								<button type="submit" class="btn btn-primary">Search</button>







							</div>







					







						







<div class="col-sm-6">







	  <button type="submit" name="export" value="export" class="btn btn-primary">Export</button>







</div>







</div>















					</form>







					<hr>







					<!-- <button class="btn btn-primary float-right">Reimburse</button> -->







					<table id="datatable" class="table table-bordered dt-responsive nowrap"







					style="border-collapse: collapse; border-spacing: 0; width: 100%;">







					<thead>







						<tr>







							







						<th>S.N</th>



							<th>Employee Name</th>







							<th>Task Name</th>



							<th>Estimated hour</th>



							<th>Actual hour</th>







							







						</tr>







					</thead>







					<tbody>



                     @if(!empty($getuserproject))



                      @php($i = 1)



                     @foreach($getuserproject as $getuserprojects)



					 @foreach($getuserprojects->gettask as $task)



					<tr>



					 <td> {{$i++}}  </td>



					<td>{{$getuserprojects->userfullname}}</td>



					<td>{{$task->task}}</td>



					<td>{{$task->all_assign_hour_in_user_all}}</td>



					<td>{{$task->fool_hour_in_user_all}}</td>



					







					</tr>



					@endforeach



					@endforeach







					@endif











							</tbody>







						</table>







					</div>















				</div>







			</div>







			<!-- end col -->







		</div>







		<!-- end row -->







	</div>







	<!-- container-fluid -->







</div>















@stop















@section('extra_js')











<script type="text/javascript">

	

function get_week(){



var year = $('#year').val();

var month = $('#month').val();





   var _token = "{{csrf_token()}}";



  $.ajax({

        url: '/get_week',

        type: "post",

        data: {"_token": _token,"year":year,"month":month},

        dataType: 'JSON',

         

        success: function (data) {

        //console.log(data.city); // this is good

      

        $('#week').html(data.week);

        

          

        }

      });



}





</script>
<script type="text/javascript">
$(function() {
    $('.multiselect-ui').multiselect({
        includeSelectAllOption: true
    });
});

$('#datatable').dataTable(
{
"aoColumns": [{ "bSortable": false },{ "bSortable": false }]
} );


</script>
@stop