@extends('layouts.superadmin_layout')

<?php  //echo "<pre>"; print_r($classData); ?>
<!-- Content Wrapper. Contains page content -->
@section('extra_css')
<style>


.disabledTab{
    pointer-events: none;
}
</style>

@stop

@section('content')
      <!-- Start content -->
        <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h3 class="page-title">Project View</h3>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
                           <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Project View</a>
                           </li>
                            <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">{{$projectview->project_name}}</a>
                           </li>
                           
                           
                        </ol>
                     </div>
                     
                     
                   @if($current_user_id == $projectview->manager_id)
                      
                 
                     <div class="col-sm-6">
                        <div class="float-right d-md-block">
                           <div class="dropdown">
                              <a href="{{URL::to('/edit-project')}}/{{$projectview->id}}">
                                 <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Edit Project</button>
                              </a>
                           </div>
                        </div>
                     </div>
                      @elseif(PermissionHelper::frontendPermission('edit-project'))
                     
                        <div class="col-sm-6">
                        <div class="float-right d-md-block">
                           <div class="dropdown">
                            <a href="javascript: history.go(-1)" class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Back</a>
                            <!-- <a href="javascript: history.go(-1)">
                                 
                              </a> -->
                              <a href="{{URL::to('/edit-project')}}/{{$projectview->id}}">
                                 <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Edit Project</button>
                              </a>
                           </div>
                        </div>
                     </div>
                     
                     @endif
                
                     
                     
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body projectviewtab p-0">
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                            <li class="nav-item waves-effect waves-light"><a class="nav-link active"
                                                    data-toggle="tab" href="#home-1" role="tab">
                                                    <span class="d-sm-block">Details</span></a></li>
                                            <li class="nav-item waves-effect waves-light"><a class="nav-link"
                                                    data-toggle="tab" href="#profile-1" role="tab">
                                                    <span class="d-sm-block">Tasks</span></a></li>
                                            <li class="nav-item waves-effect waves-light"><a class="nav-link"
                                                    data-toggle="tab" href="#messages-1" role="tab">
                                                    <span class="d-sm-block">Resources</span></a></li>
                                        </ul>
                                        <!-- Tab panes -->
                                        <div class="tab-content">
                                            <div class="tab-pane active p-3" id="home-1" role="tabpanel">
                                               <div class="col-12">
                                    <h5 class="h5after"><span>Details</span></h5>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="empcode" class="col-lg-4 col-form-label">Project
                                             Name</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->project_name}}</label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="empid" class="col-lg-4 col-form-label">Client</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->client_name}}</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="prifix" class="col-lg-4 col-form-label">Description</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->description}}</label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="firstname" class="col-lg-4 col-form-label">Currency</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->currencyname}}</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="logo" class="col-lg-4 col-form-label">Status</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->project_status}}</label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="email" class="col-lg-4 col-form-label">Project Type</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->project_type}}</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="cid" class="col-lg-4 col-form-label">Start Date</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{date('d-M-Y',strtotime($projectview->start_date))}}</label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="mode" class="col-lg-4 col-form-label">End Date</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{date('d-M-Y',strtotime($projectview->end_date))}}</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Estimated Hours</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->estimated_hrs}}</label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Actual Hours</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{$projectview->actualhour}}</label>
                                          </div>
                                       </div>
                                    </div>
                                    
                                    
                                      <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Manager</label>
                                          <div class="col-lg-8 col-form-label">
                                             <label class="myprofile_label">{{ucwords($projectview->userfullname)}}</label>
                                          </div>
                                       </div>
                                    </div>
                                    <?php
                                    $stage  = DB::table('main_stage')->get();
                                    ?>
                                     @if($current_user_id == $projectview->manager_id)
                                    
                                    <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Stage</label>
                                          <div class="col-lg-8 col-form-label">
                                             <select class="form-control" id="stage">
                                                      
                                                        @foreach($stage as $stages)
                                                        <option value="{{$stages->id}}" @if($projectview->stage == $stages->id) selected @endif>{{$stages->stage_name}}</option>
                                                        @endforeach
                                                       
                                                                    </select>
                                          </div>
                                       </div>
                                    </div>
                                     @elseif(PermissionHelper::frontendPermission('edit-project'))
                                     
                                                  <div class="col-md-6">
                                       <div class="form-group row m-0 b-b-d">
                                          <label for="role" class="col-lg-4 col-form-label">Stage</label>
                                          <div class="col-lg-8 col-form-label">
                                             <select class="form-control" id="stage">
                                                       
                                                        @foreach($stage as $stages)
                                                        <option value="{{$stages->id}}" @if($projectview->stage == $stages->id) selected @endif>{{$stages->stage_name}}</option>
                                                        @endforeach
                                                       
                                                                    </select>
                                          </div>
                                       </div>
                                    </div>
                                     
                                     @endif
                                    
                                    
                                    
                                 </div>
                                            </div>
                                            <div class="tab-pane p-3" id="profile-1" role="tabpanel">
                                              <div class="col-12">
                                    <h5 class="h5after"><span>Tasks</span></h5>
                                 </div>
                                 <div class="col-sm-12 table-responsive">
                                    <table id="datatable" class="table table-bordered nowrap font-14"
                                       style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                       <thead>
                                          <tr>
                                             <th>S.No</th>
                                             <th>Name</th>
                                             <th>Estimated Hours</th>
                                             <th>Actual Hours</th>
                                             <th>Start Date</th>
                                             <th>End Date</th>
                                             <th>Status</th>
                                             <th>Created By</th>
                                             <th>Action</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                        
                                           @php($i = 1)
                                           @foreach($taskList as $taskLists)
                                           
                                           <?php
                               
        $taskAssign  = DB::table('tm_project_task_employees')->join('main_users','tm_project_task_employees.emp_id','=','main_users.id')->leftjoin('main_jobtitles','main_users.jobtitle_id','=','main_jobtitles.id')->join('tm_tasks','tm_project_task_employees.task_id','=','tm_tasks.id')->where('tm_project_task_employees.task_id',$taskLists->task_id)->where('tm_project_task_employees.project_id',$project_id)->select('tm_project_task_employees.*','main_users.userfullname','main_users.employeeId','main_users.prefix','main_users.profileimg','tm_tasks.task','main_jobtitles.jobtitlename')->get();
          // dd($taskAssign);                               
                                           
            	
        	     $all_seconds=0;
        	    $assignproject = DB::table('tm_emp_timesheets')->where('project_id',$project_id)->where('project_task_id',$taskLists->id)->get();
        	    if(isset($assignproject) && !empty($assignproject)){
        	        foreach($assignproject as $assignprojects){
        	        
        	         list($hour, $minute) = explode(':', $assignprojects->week_duration);
	                      $h = (int)$hour;
	                      $m  = (int)$minute;
	                        
	                     $all_seconds += $h * 3600;
                         $all_seconds += $m * 60;
        	        }
        	        
        	          $total_minutes = floor($all_seconds/60);
                    
                     $hours = floor($total_minutes / 60); 
                      $minutes = $total_minutes % 60;
                       
           
                  $week_hour =  sprintf('%02d:%02d', $hours, $minutes);
                  
        	        
        	        
        	        
        	    }
        	    
       
                                          
                                           ?>
                                          <tr>
                                             <td>
                                              {{$i++}}
                                             </td>
                                             <td class="text_ellipses" data-toggle="tooltip" title="{{$taskLists->task}}">{{$taskLists->task}}</td>
                                             <td>{{$taskLists->estimated_hrs}}</td>
                                             <td>{{$week_hour??'0'}}</td>
                                             <td>{{$taskLists->task_start_date}}</td>
                                             <td>{{$taskLists->task_end_date}}</td>
                                             <td>{{$taskLists->task_status}}</td>
                                             <td>{{$taskLists->userfullname}}</td>
                                             <td>
                                                <a href="project_view.html" data-toggle="modal" data-target="#viewtask{{$taskLists->id}}">
                                                   <i class="fa fa-eye font-blue"></i>
                                                </a>
                                             </td>
                                          </tr>
                                          
                                          
                                             <div id="viewtask{{$taskLists->id}}" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title mt-0" id="myModalLabel">View Task Resources</h5>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body modal-height">
               <div class="col-sm-12 p-0">
                  <div class="row">
                     <div class="col-sm-6">
                        <span class="font-500">Task:</span>
                        <span>{{$taskLists->task}}</span>
                     </div>
                     <div class="col-sm-6 float-right">
                        <span class="font-500">Estimated Hours:</span>
                        <span>{{$taskLists->estimated_hrs}}</span>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-sm-6">
                        <h5>
                           <span>Resources</span>
                        </h5>
                     </div>
                    <div class="col-sm-6 float-right">
                        <span class="float-right">
                           <form role="search" class="app-search float-right"
                                                                style="height: 0;">
                                                                <div class="form-group mb-0">
                                                                    <input type="text" class="form-control m-0"
                                                                        placeholder="Search..">
                                                                    <button type="submit" style="top:10px"><i
                                                                            class="fa fa-search"></i>
                                                                            </button>
                                                                            </div>
                                                            </form>
                        </span>
                     </div>
                  </div>
               </div>
               <div class="row m-t-10">
                   @foreach($taskAssign as $taskAssigns)
                  <div class="col-sm-3">
                     <div class="card m-b-10 float-left width100 box-shadow">
                        <div class="media p-l-5 p-r-5 p-t-5">
                            @if(!empty($taskAssigns->profileimg))
                            <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/')}}/{{$taskAssigns->profileimg}}" alt="Generic placeholder image" height="40">
                              @elseif($taskAssigns->prefix == 1)
                              
                               <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/uploads/male.png')}}" alt="Generic placeholder image" height="40">
                              
                              @elseif($taskAssigns->prefix == 2 || $taskAssigns->prefix == 3)
                              
                                <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/uploads/female.png')}}" alt="Generic placeholder image" height="40">
                              
                              @else
                              
                              <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/uploads/human.png')}}" alt="Generic placeholder image" height="40">
                              @endif
                              
                           <div class="media-body">
                              <h6 class="mt-0 mb-0 font-16 text-info">{{ucwords($taskAssigns->userfullname)}}</h6>
                              <p class="m-0 font-12">{{$taskAssigns->employeeId}}</p>
                              <p class="m-0 font-12">{{$taskLists->estimated_hrs}} Hrs</p>
                           </div>
                        </div>
                        <div class="mainhilight">
                           <span class="font-500">{{$taskAssigns->jobtitlename}}</span>
                        </div>
                     </div>
                  </div>
                  @endforeach
                  <!--<div class="col-sm-3">-->
                  <!--   <div class="card m-b-10 float-left width100 box-shadow">-->
                  <!--      <div class="media p-l-5 p-r-5 p-t-5"><img class="d-flex mr-3 rounded-circle"-->
                  <!--            src="assets/images/users/user-6.jpg" alt="Generic placeholder image" height="40">-->
                  <!--         <div class="media-body">-->
                  <!--            <h6 class="mt-0 mb-0 font-16 text-info">Nisha Upreti</h6>-->
                  <!--            <p class="m-0 font-12">KSPL1167</p>-->
                  <!--            <p class="m-0 font-12">2 Hrs</p>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--      <div class="mainhilight">-->
                  <!--         <span class="font-500">HTML Developer</span>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</div>-->
                  <!--<div class="col-sm-3">-->
                  <!--   <div class="card m-b-10 float-left width100 box-shadow">-->
                  <!--      <div class="media p-l-5 p-r-5 p-t-5"><img class="d-flex mr-3 rounded-circle"-->
                  <!--            src="assets/images/users/user-6.jpg" alt="Generic placeholder image" height="40">-->
                  <!--         <div class="media-body">-->
                  <!--            <h6 class="mt-0 mb-0 font-16 text-info">Nisha Upreti</h6>-->
                  <!--            <p class="m-0 font-12">KSPL1167</p>-->
                  <!--            <p class="m-0 font-12">2 Hrs</p>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--      <div class="mainhilight">-->
                  <!--         <span class="font-500">HTML Developer</span>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</div>-->
                  <!--<div class="col-sm-3">-->
                  <!--   <div class="card m-b-10 float-left width100 box-shadow">-->
                  <!--      <div class="media p-l-5 p-r-5 p-t-5"><img class="d-flex mr-3 rounded-circle"-->
                  <!--            src="assets/images/users/user-6.jpg" alt="Generic placeholder image" height="40">-->
                  <!--         <div class="media-body">-->
                  <!--            <h6 class="mt-0 mb-0 font-16 text-info">Nisha Upreti</h6>-->
                  <!--            <p class="m-0 font-12">KSPL1167</p>-->
                  <!--            <p class="m-0 font-12">2 Hrs</p>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--      <div class="mainhilight">-->
                  <!--         <span class="font-500">HTML Developer</span>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</div>-->
               </div>
            </div>
         </div>
      </div>
   </div>
                                          
                                          
                                          @endforeach
                                       </tbody>
                                    </table>
                                 </div>
                                            </div>
                                            <div class="tab-pane p-3" id="messages-1" role="tabpanel">
                                                 <div class="col-12">
                                    <h5 class="h5after"><span>Resources</span></h5>
                                 </div>
                                 
                               
                                 <div class="col-sm-12 table-responsive">
                                    <table id="datatable1" class="table table-bordered nowrap font-14"
                                       style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                       <thead>
                                          <tr>
                                             <th>S.No</th>
                                             <th>Name</th>
                                             <th>Role</th>
                                             <th>Billable Rate(INR)</th>
                                             <th>Cost Rate(INR)</th>
                                             <th>Action</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                           @php($i = 1)
                                           @foreach($userlist as $userlists)
                                           
                                           <?php
                                           
                                           $usreasigntask = DB::table('tm_project_task_employees')->leftjoin('main_users','tm_project_task_employees.emp_id','=','main_users.id')->leftjoin('main_jobtitles','main_users.jobtitle_id','=','main_jobtitles.id')->leftjoin('tm_project_tasks','tm_project_task_employees.task_id','=','tm_project_tasks.task_id')->leftjoin('tm_tasks','tm_project_task_employees.task_id','=','tm_tasks.id')->where('tm_project_task_employees.emp_id',$userlists->id)->where('tm_project_task_employees.project_id',$project_id)->select('tm_project_tasks.estimated_hrs','tm_project_tasks.id','tm_tasks.task','main_users.userfullname','main_users.id as userid','main_users.profileimg','main_users.prefix','main_users.employeeId','main_jobtitles.jobtitlename')->get();
                                         
                                           ?>
                                           
                                          <tr>
                                             <td>
                                                {{$i++}}
                                             </td>
                                             <td class="text_ellipses" data-toggle="tooltip" title="{{ucwords($userlists->userfullname)}}">{{ucwords($userlists->userfullname)}}</td>
                                             <td>{{$userlists->rolename}}</td>
                                             <td></td>
                                             <td></td>
                                             <td>
                                                <a href="project_view.html" data-toggle="modal"
                                                   data-target="#viewresource{{$userlists->id}}">
                                                   <i class="fa fa-eye font-blue"></i>
                                                </a>
                                             </td>
                                          </tr>
                                          <div id="viewresource{{$userlists->id}}" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
      aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title mt-0" id="myModalLabel">View Employee Task</h5>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body modal-height">
               <div class="row">
                  <div class="col-sm-12 m-b-10">
                     <span class="float-right">
                        <form role="search" class="app-search float-left width100" style="height: 0;">
                           <div class="form-group mb-0">
                              <input type="text" class="form-control m-0" placeholder="Search by Task..">
                              <button type="submit" style="top:10px"><i class="fa fa-search"></i></button></div>
                        </form>
                     </span>
                  </div>
                  <div class="col-sm-12">
                      
                      @foreach($usreasigntask as $usreasigntasks)
                      <?php
                      
                             
        	     $all_seconds=0;
        	    $assignproject = DB::table('tm_emp_timesheets')->where('emp_id',$usreasigntasks->userid)->where('project_id',$project_id)->where('project_task_id',$usreasigntasks->id)->get();
        	    if(isset($assignproject) && !empty($assignproject)){
        	        foreach($assignproject as $assignprojects){
        	        
        	         list($hour, $minute) = explode(':', $assignprojects->week_duration);
	                      $h = (int)$hour;
	                      $m  = (int)$minute;
	                        
	                     $all_seconds += $h * 3600;
                         $all_seconds += $m * 60;
        	        }
        	        
        	          $total_minutes = floor($all_seconds/60);
                    
                     $hours = floor($total_minutes / 60); 
                      $minutes = $total_minutes % 60;
                       
           
                   $week_hour =  sprintf('%02d:%02d', $hours, $minutes);

        	        
        	        
        	        
        	    }
        	    
        	
                      ?>
                     <div class="card m-b-10 float-left width100 box-shadow">

                        <div class="media padding-5">
                            
                             @if(!empty($usreasigntasks->profileimg))
                            <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/')}}/{{$usreasigntasks->profileimg}}" alt="Generic placeholder image" height="40">
                              @elseif($usreasigntasks->prefix == 1)
                              
                               <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/uploads/male.png')}}" alt="Generic placeholder image" height="40">
                              
                              @elseif($usreasigntasks->prefix == 2 || $usreasigntasks->prefix == 3)
                              
                                <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/uploads/female.png')}}" alt="Generic placeholder image" height="40">
                              
                              @else
                              
                              <img class="d-flex mr-3 rounded-circle"
                              src="{{URL::to('public/uploads/human.png')}}" alt="Generic placeholder image" height="40">
                              
                              @endif
                            
                         
                              
                           <div class="media-body col-sm-4">
                              <h6 class="mt-0 mb-0 font-16 text-info">{{ucwords($usreasigntasks->userfullname)}}</h6>
                              <p class="m-0 font-12">{{$usreasigntasks->employeeId}}</p>
                              <p class="m-0 font-12">{{$usreasigntasks->estimated_hrs}} Hrs</p>
                           </div>
                           <div class="media-body col-sm-8 text-center">
                              <div class="row">
                                 <div class="col-sm-4 div-right-b">
                                    <h6>Task</h6>
                                    <p class="m-b-5">{{$usreasigntasks->task}}</p>
                                 </div>
                                 <div class="col-sm-4 div-right-b">
                                    <h6>Estimated hours</h6>
                                    <p class="m-b-5">{{$usreasigntasks->estimated_hrs}}</p>
                                 </div>
                                 <div class="col-sm-4">
                                    <h6>Actual hours</h6>
                                    <p class="m-b-5">{{$week_hour??'00:00'}}</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="mainhilight col-sm-12">
                           <span class="font-500">{{$usreasigntasks->jobtitlename}}</span>
                        </div>
                     </div>
                     
                     @endforeach
                     @if(count($usreasigntask) == 0)
                     
                     <p>Task Not Assign</p>
                     @endif
                     
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
                                          
                                          @endforeach
                                       </tbody>
                                    </table>
                                 </div>
                                            </div>
                                        </div>

                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
         
         
     

         
         
@endsection

@section('extra_js')

<script>
	$(document).ready(function(){
		$("#datatable1").DataTable();
})	
var project_id = '{{$project_id}}';

$(document).on('change','#stage',function(){
    
    var stage = this.value;
   
 
   
   var _token = "{{csrf_token()}}";

  $.ajax({
        url: '/update_stage',
        type: "post",
        data: {"_token": _token,"project_id":project_id,"stage":stage},
        dataType: 'JSON',
         
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
             
             swal("Good job!", "Change Successfully", "success");

            location.reload();

          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");


          }else{

             $('#loadingDiv').hide();
            
             swal("Good job!", "Not change", "error");

          }
          
        }
      });

});
</script>

@stop