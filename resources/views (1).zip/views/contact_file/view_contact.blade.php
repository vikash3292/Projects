    @extends('layouts.superadmin_layout')
   @section('content')
                         <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h3 class="page-title">Contact View</h3>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="{{URL::to('/')}}">{{$mainsetting->site_title}}</a></li>
                           <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Contact View</a></li>
                        </ol>
                     </div>
                     <div class="col-sm-6">
                        <div class="float-right d-none d-md-block">
                           <div class="dropdown">
                              <a href="{{URL::to('edit-contact')}}/{{$viewcontact->id}}">
                                 <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Edit Contact</button>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <div class="row">
                              <div class="col-sm-6">
                                 <h5 class="m-0">
                                    <img src="assets/images/profile.png" height="100">
                                    <span title="Contact" data-toggle="tooltip">{{$viewcontact->salutation}} {{$viewcontact->first_name}} {{$viewcontact->last_name}}</span
                                       title="Contact" data-toggle="tooltip"></h5>
                              </div>
                              <div class="col-sm-6 text-right">
                                 <h6 class="text-success m-0"><span title="Account" data-toggle="tooltip">{{ucwords($viewcontact->account_name)}}</span title="Contact" data-toggle="tooltip"></h6>
                                 <p class="m-0"><span title="Title" data-toggle="tooltip">{{$viewcontact->title}}</span></p>
                                 <p class="m-0"><a href="#" title="Contact Owner" data-toggle="tooltip"><u
                                          class="text-info">{{$viewcontact->userfullname}}</u></a></p>
                                 <p class="m-0 text-info"><span title="Phone" data-toggle="tooltip">+91
                                       {{$viewcontact->mobile}}</span></p>
                                 <p class="m-0 text-info"><span title="Email"
                                       data-toggle="tooltip">{{$viewcontact->email}}</span></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-12">
                     <div class="card">
                        <div class="card-body">
                           <div class="width-float">
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="empcode" class="col-lg-4 col-form-label">Contact Owner</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->userfullname}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="empid" class="col-lg-4 col-form-label">Name</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->salutation}} {{$viewcontact->first_name}} {{$viewcontact->last_name}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="prifix" class="col-lg-4 col-form-label">Home Phone</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->phone}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="firstname" class="col-lg-4 col-form-label">Other Phone</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->other_phone}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Department</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->deportment}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Fax</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->fax}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Birth Date</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->dob}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Reports To</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->report_to}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Assistant</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->assistant}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Lead Source</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewbill->street??''}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Asst. Phone</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->assistant_phone}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Mailing Address</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewbill->street??''}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Other Address</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewshipp->street??''}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Languages</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->lang}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Level</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->level}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Created By</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">{{$viewcontact->userfullname}}, {{$viewcontact->created_at}}</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Last Modified By</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">
                                             {{$viewcontact->userfullname}}, {{$viewcontact->created_at}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-12">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Description</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label"> {{$viewcontact->desc}}</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
           @stop

           @section('extra_js')

<script language="javascript" type="text/javascript">

                    $("form#addcontact").submit(function(e) {

 
            e.preventDefault();
            
           

          var last_name = $('#last_name').val();
           var first_name = $('#first_name').val();
            var mobile = $('#mobile').val();
      
         if(first_name ==''){
         $('#first_name_error').text('First Name is Required').attr('style','color:red');
         $('#first_name_error').show();
          error = 0;
              return false;

      }else{$('#first_name_error').hide();  error = 1;}
      
      if(last_name ==''){
         $('#last_name_error').text('Last Name is Required').attr('style','color:red');
         $('#last_name_error').show();
          error = 0;
              return false;

      }else{$('#last_name_error').hide();  error = 1;}
      
      if(mobile ==''){
         $('#mobile_error').text('Mobile is Required').attr('style','color:red');
         $('#mobile_error').show();
          error = 0;
              return false;

      }else{$('#mobile_error').hide();  error = 1;}

      

   var token = "{{csrf_token()}}"; 


  $.ajax({
        url: '/insert-contact',
        headers: {'X-CSRF-TOKEN': token}, 
        type: "post",
        data:$(this).serialize(),

           beforeSend: function() {    
       
        $('#loadingDiv').show();
        },
    
        success: function (data) {
        //console.log(data.city); // this is good
    
          if(data.status ==200){
             $('#loadingDiv').hide();
         
             
             swal("Good job!", "Added Successfully", "success");

            base_url = $('#base_url').val();
 
          var editurl =   base_url+'/contact/';


   
         window.location = editurl;

          }else if(data.status ==202){

              $('#loadingDiv').hide();
            swal("Good job!", "User alert Exist", "success");
            location.reload();

              }else if(data.status ==203){

              $('#loadingDiv').hide();
            swal("Good job!", "Successfully Updated", "success");
               location.reload();

          }else{

             $('#loadingDiv').hide();
            
             swal("Good job!", "You clicked the button!", "error");

          }
          
        }
      });

       
           });

</script>

           @stop