  @extends('layouts.superadmin_layout')
@section('content')
  
 <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Organization List</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="{{URL::to('/view-org')}}">Organization List</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <div class="float-right d-none d-md-block">
                                    <div class="dropdown">
                                        <a href="{{URL::to('/add-org')}}">
                                            <button
                                                class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                                type="button">
                                                Add New Organization</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                  
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Organization Name</th>
                                                <th>Fav Icon</th>
                                                <th>Small Logo</th>
                                                <th>Large Logo</th>
                                                <th>Description</th>
                                                <th>No. of Users</th>
                                                <th>Term</th>
                                                <th>Modules</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $showmodule = [];
                                            ?>
                                          
                                            @foreach($vieworg as $key =>  $vieworgs)
                                            <?php
                                            
                                           $moduleid =  json_decode($vieworgs->module);
                                            
                                            $module = DB::table('site_menu')->whereIn('id',$moduleid)->get();
                                            foreach($module as $modules){
                                                
                                                $showmodule[$key][] = $modules->menu_title;
                                                
                                            }
                                            ?>
                                            <tr>
                                                <td>{{$key}}</td>
                                                <td>
                                                    {{$vieworgs->org_name}}
                                                </td>
                                                <td><img src="{{URL::to('public/')}}/{{$vieworgs->fav_icon}}" height="15"></td>
                                                <td><img src="{{URL::to('public/')}}/{{$vieworgs->small_logo}}" height="15"></td>
                                                <td>
                                                    <img src="{{URL::to('public/')}}/{{$vieworgs->large_logo}}" height="15">
                                                </td>
                                                <td class="text_ellipses">{{$vieworgs->org_desc}}</td>
                                                <td>{{$vieworgs->no_of_user}}</td>
                                                <td>{{$vieworgs->term}}yr</td>
                                                <td>
                                                    @if(isset($showmodule[$key]))
                                                    {{implode(', ',$showmodule[$key])}}
                                                    @endif
                                                    
                                                    </td>
                                                <td>
                                                    <a href="{{URL::to('/view-org')}}/{{$vieworgs->id}}"><i class="mdi mdi-eye font-blue"
                                                            data-toggle="tooltip" title="Active"></i></a>
                                                    <a href="{{URL::to('/edit-org')}}/{{$vieworgs->id}}"<i class="mdi mdi-pen text-warning"
                                                            data-toggle="modal" data-target="#editemp"
                                                            title="Edit"></i></a>
                                                    <i class="mdi mdi-delete text-danger" data-toggle="modal"
                                                        data-target="#deletemp" title="Delete"></i>
                                                </td>
                                            </tr>
                                            @endforeach
                                            <!--<tr>-->
                                            <!--    <td>2</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>3</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>4</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"> <i-->
                                            <!--                class="mdi mdi-pen text-warning" data-toggle="modal"-->
                                            <!--                data-target="#editemp" title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>5</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>6</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>7</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>8</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"> <i-->
                                            <!--                class="mdi mdi-pen text-warning" data-toggle="modal"-->
                                            <!--                data-target="#editemp" title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>9</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>10</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"> <i-->
                                            <!--                class="mdi mdi-pen text-warning" data-toggle="modal"-->
                                            <!--                data-target="#editemp" title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>11</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>12</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>13</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"> <i-->
                                            <!--                class="mdi mdi-pen text-warning" data-toggle="modal"-->
                                            <!--                data-target="#editemp" title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>14</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"> <i-->
                                            <!--                class="mdi mdi-pen text-warning" data-toggle="modal"-->
                                            <!--                data-target="#editemp" title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>15</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"><i class="mdi mdi-pen text-warning"-->
                                            <!--                data-toggle="modal" data-target="#editemp"-->
                                            <!--                title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>16</td>-->
                                            <!--    <td>-->
                                            <!--        Kloudrac-->
                                            <!--    </td>-->
                                            <!--    <td><img src="assets/images/logo-sm.png" height="15"></td>-->
                                            <!--    <td><img src="assets/images/login_img.png" height="15"></td>-->
                                            <!--    <td>-->
                                            <!--        <img src="assets/images/logo-dark.png" height="15">-->
                                            <!--    </td>-->
                                            <!--    <td class="text_ellipses">dummy dummy</td>-->
                                            <!--    <td>22</td>-->
                                            <!--    <td>1yr</td>-->
                                            <!--    <td>HR</td>-->
                                            <!--    <td>-->
                                            <!--        <a href="announcement_view.html"><i class="mdi mdi-eye font-blue"-->
                                            <!--                data-toggle="tooltip" title="Active"></i></a>-->
                                            <!--        <a href="edit_announcement.html"> <i-->
                                            <!--                class="mdi mdi-pen text-warning" data-toggle="modal"-->
                                            <!--                data-target="#editemp" title="Edit"></i></a>-->
                                            <!--        <i class="mdi mdi-delete text-danger" data-toggle="modal"-->
                                            <!--            data-target="#deletemp" title="Delete"></i>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
         @stop