  @extends('layouts.superadmin_layout')
@section('content')
  
<div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add Organization</h4>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{URL::to('/')}}">GRC</a></li>
                                    <li class="breadcrumb-item active"><a href="{{URL::to('/add-org')}}">Add Organization</a>
                                    </li>
                                </ol>
                            </div>
                            <div class="col-sm-6">
                                <a href="org_mngt.html" class="btn btn-primary float-right">Back to List</a>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            
                       
                            
                            @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
                            <div class="card m-t-20">
                                
                                <form method="post" enctype='multipart/form-data'>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empcode" class="col-lg-4 col-form-label">Organization
                                                    Name <span class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" name="orgname" value="{{ old('orgname') }}" maxlength="60" class="form-control">
                                              
                                                    </div>
                                            </div>
                                        </div>
                                         <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="firstname" class="col-lg-4 col-form-label">Official Name <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" name="offeialname" name="orgname" value="{{ old('offeialname') }}" maxlength="60" class="form-control"> 
                                               
                                                    </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label">Org Id <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" readonly value="{{$unique}}" class="form-control"> </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">License Count <span
                                                        class="text-danger"> *</span>
                                                </label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="number" name="licenseno" value="{{ old('licenseno') }}" maxlength="60" class="form-control"> 
                                                   
                                                    </div>
                                            </div>
                                        </div>
                                        
                                        
                                              <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Term <span
                                                        class="text-danger"> *</span>
                                                </label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="number" class="form-control" name="term" value="{{ old('term') }}" maxlength="60"> 
                                                    
                                                   </div>
                                            </div>
                                        </div>
                                        
                                         <div class="row">
                                 
                                    </div>
                                    </div>
                                    
                                     {!! csrf_field() !!}
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="prifix" class="col-lg-4 col-form-label">Email <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text"  name="orgemail" value="{{ old('orgemail') }}" class="form-control"> 
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="firstname" class="col-lg-4 col-form-label">GST No. 
                                              <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" name="gstno" value="{{ old('gstno') }}">
                                                      
                                               
                                                    </div>
                                            </div>
                                        </div>
                                        
                                             <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="firstname" class="col-lg-4 col-form-label">Total Emp 
                                                
                                              <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" name="totalemp" value="{{ old('totalemp') }}"> 
                                                     
                                                    </div>
                                            </div>
                                        </div>
                                        
                                            
                                              <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="firstname" class="col-lg-4 col-form-label">Customer Type
                                                
                                               <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control"  name="customertype" value="{{ old('customertype') }}"> 
                                                    
                                                    
                                                    </div>
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="logo" class="col-lg-4 col-form-label">PAN No.
                                                
                                             <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" name="pan_no" value="{{ old('pan_no') }}"> 
                                                       
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                           
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Fav Icon<span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="file" class="form-control" style="height: auto;" name="face_icon" value="{{ old('face_icon') }}">
                                                   
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Small Logo<span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    
                                                     <input type="file" class="form-control" style="height: auto;" name="small_icon" value="{{ old('face_icon') }}">
                                                    
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Large Logo<span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="file" class="form-control" style="height: auto;" name="large_icon" value="{{ old('large_icon') }}">
                                                  
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Modules<span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    
                                                    @foreach($modulelist as $modulelists)
                                                    
                                                    <div class="custom-control custom-checkbox m-r-5">
                                                        <input type="checkbox" value="{{$modulelists->id}}" name="module[]"  class="custom-control-input"
                                                            id="customControlInline">
                                                        <label class="custom-control-label p-2"
                                                            for="customControlInline">{{$modulelists->menu_title??''}}</label>
                                                    </div>
                                                    @endforeach
                                                    
                                                    
                                                    <!--<div class="custom-control custom-checkbox m-r-5">-->
                                                    <!--    <input type="checkbox" class="custom-control-input"-->
                                                    <!--        id="customControlInline">-->
                                                    <!--    <label class="custom-control-label p-2"-->
                                                    <!--        for="customControlInline">PM</label>-->
                                                    <!--</div>-->
                                                    <!--<div class="custom-control custom-checkbox m-r-5">-->
                                                    <!--    <input type="checkbox" class="custom-control-input"-->
                                                    <!--        id="customControlInline">-->
                                                    <!--    <label class="custom-control-label p-2"-->
                                                    <!--        for="customControlInline">BD</label>-->
                                                    <!--</div>-->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Description<span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <textarea rows="3" class="form-control" name="org_desc" >{{ old('org_desc') }}</textarea>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="col-sm-12">
                                                <h5 class="font-18 h5after"><span>Address Information</span></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Country <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <?php

                                       $Country = DB::table('main_countries')->where('isactive','=',1)->get();
                                             
                                           ?>
                                            
                                             <select class="form-control" name="country" id="country">
                                                <option value="">Select Country</option>
                                                @foreach($Country as $Country)
                                                <option value="{{$Country->id}}">{{$Country->country}}</option>
                                                @endforeach
                                               
                                             </select>
                                             
                                               
                                             
                                             </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">State <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                          <?php

                                       $state = DB::table('alm_states')->get();

                                             
                                           ?>
                                            
                                             <select class="form-control" name="state" id="state">
                                                <option value="">Select State</option>

                                                 @foreach($state as $states)
                                                <option value="{{$states->id}}" >{{$states->name}}</option>
                                                @endforeach
                                              
                                             </select> 
                                            
                                             </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">City <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                      <?php

                                       $alm_cities = DB::table('alm_cities')->get();
                                             
                                           ?>
                                                       <select class="form-control" name="city" id="city">
                                                <option value="">Select City</option>

                                                 @foreach($alm_cities as $alm_citiess)
                                                <option value="{{$alm_citiess->id}}" >{{$alm_citiess->name}}</option>
                                                @endforeach
                                              
                                               
                                             </select>
                                          
                                             
                                             
                                             </div>
                                            </div>
                                        </div>
                                               <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="empid" class="col-lg-4 col-form-label">Phone <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" name="phone" value="{{ old('phone') }}">
                                                 
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Street <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" name="strret" value="{{ old('strret') }}"> 
                                                  </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row m-0">
                                                <label for="role" class="col-lg-4 col-form-label">Zip Code 
                                                
                                              <span
                                                        class="text-danger"> *</span></label>
                                                <div class="col-lg-8 col-form-label">
                                                    <input type="text" class="form-control" name="zip_code" value="{{ old('zip_code') }}">
                                                    
                                                    
                                                     
                                                    </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-12">
                                        <button class="btn btn-primary float-right">Save</button>
                                    </div>
                                </div>
                                </form>
                                
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
         
         @stop