  @extends('superadmin_layout')
   @section('content')
   
    <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h3 class="page-title">Organization View</h3>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="javascript: history.go(-1)">GRC</a></li>
                           <li class="breadcrumb-item active"><a href="javascript: history.go(-1)">Organization View</a></li>
                        </ol>
                     </div>
                     <div class="col-sm-6">
                        <div class="float-right d-none d-md-block">
                           <div class="dropdown">
                              <a href="edit_org.html">
                                 <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Edit Organization</button>
                              </a>
                              <a href="user_mngt.html">
                                 <button class="btn btn-primary dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Manage User</button>
                              </a>
                              <a href="#">
                                 <button class="btn btn-danger dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Disable Login</button>
                              </a>
                              <a href="#">
                                 <button class="btn btn-info dropdown-toggle arrow-none waves-effect waves-light"
                                    type="button">
                                    Suspended</button>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <div class="width-float">
                              <div class="row">
                                 <div class="col-sm-12">
                                    <div class="col-sm-12">
                                       <h5 class="font-18 h5after"><span>Organization Detail</span></h5>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-6">
                                    <div class="row">
                                       <div class="col-md-12">
                                          <div class="form-group row m-0">
                                             <label for="empcode" class="col-lg-4 col-form-label">Organization
                                                ID</label>
                                             <div class="col-lg-8 col-form-label">
                                                <label class="myprofile_label">0098</label>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-md-12">
                                          <div class="form-group row m-0">
                                             <label for="empcode" class="col-lg-4 col-form-label">Organization
                                                Name</label>
                                             <div class="col-lg-8 col-form-label">
                                                <label class="myprofile_label">IT Solutions</label>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-md-12">
                                          <div class="form-group row m-0">
                                             <label for="empcode" class="col-lg-4 col-form-label">Organization
                                                ID</label>
                                             <div class="col-lg-8 col-form-label">
                                                <label class="myprofile_label">0098</label>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-md-12">
                                          <div class="form-group row m-0">
                                             <label for="empcode" class="col-lg-4 col-form-label">Organization
                                                Name</label>
                                             <div class="col-lg-8 col-form-label">
                                                <label class="myprofile_label">IT Solutions</label>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-sm-6">
                                    <div class="row">
                                       <div class="col-md-12">
                                          <div class="form-group row m-0">
                                             <label for="logo" class="col-lg-4 col-form-label">Fav Icon</label>
                                             <div class="col-lg-8 col-form-label">
                                                <img src="assets/images/favicon.ico" height="15">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-md-12">
                                          <div class="form-group row m-0">
                                             <label for="email" class="col-lg-4 col-form-label">Small Logo</label>
                                             <div class="col-lg-8 col-form-label">
                                                <img src="assets/images/logo-sm.png" height="40">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-md-12">
                                          <div class="form-group row m-0">
                                             <label for="logo" class="col-lg-4 col-form-label">Large Logo</label>
                                             <div class="col-lg-8 col-form-label">
                                                <img src="assets/images/favicon.ico" height="100">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12">
                                    <div class="col-sm-12">
                                       <h5 class="font-18 h5after"><span>Additional Detail</span></h5>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="empid" class="col-lg-4 col-form-label">Phone</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">9876543210</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="prifix" class="col-lg-4 col-form-label">Email</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">abc@gmail.com</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">PAN No.</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">AAACH4114R</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="firstname" class="col-lg-4 col-form-label">GST No.</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">2343</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">Term</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">1 yr</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-4 col-form-label">No. of Users</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">10</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12">
                                    <div class="col-sm-12">
                                       <h5 class="font-18 h5after"><span>Other Information</span></h5>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="logo" class="col-lg-4 col-form-label">Modules</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">HR</label>
                                       </div>
                                    </div>
                                 </div>

                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="cid" class="col-lg-4 col-form-label">Created Date</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">09-12-2019</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="mode" class="col-lg-4 col-form-label">Created Time</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">12:34 pm</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Last Modified By</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">Rishabh Dargan</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Last Modified Date</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">09-12-2019</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Last Modified Time</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">12:34 pm</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <div class="form-group row m-0">
                                       <label for="email" class="col-lg-2 col-form-label">Description</label>
                                       <div class="col-lg-10 col-form-label">
                                          <label class="myprofile_label">fdsfs gjuiyi kjhkjh reyiuyiw hkhfks jlkjlk
                                             rietuoewtu khkjhg bjtr ouo</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12">
                                    <div class="col-sm-12">
                                       <h5 class="font-18 h5after"><span>Address Information</span></h5>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Country</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">India</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">State</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">Delhi</label>
                                       </div>
                                    </div>
                                 </div>

                              </div>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">City</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">Delhi</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Street</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">New Friends Colony</label>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-group row m-0">
                                       <label for="role" class="col-lg-4 col-form-label">Zip Code</label>
                                       <div class="col-lg-8 col-form-label">
                                          <label class="myprofile_label">234565</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
   
   
   @stop