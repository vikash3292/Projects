    @extends('layouts.superadmin_layout')
   @section('content')
            
         <!-- Start content -->
         <div class="content p-0">
            <div class="container-fluid">
               <div class="page-title-box">
                  <div class="row align-items-center bredcrum-style">
                     <div class="col-sm-6">
                        <h3 class="page-title">Requisition New Request</h3>
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="index.html">GRC</a></li>
                           <li class="breadcrumb-item active"><a href="new_request.html">Requisition New Request</a>
                           </li>
                        </ol>
                     </div>
                  </div>
               </div>
               <!-- end row -->
               <div class="row">
                  <div class="col-12">
                     <div class="card m-t-20">
                        <div class="card-body">
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="empcode" class="col-lg-4 col-form-label">Requisition for
                                       Position/Designation</label>
                                    <div class="col-lg-8">
                                       <input id="designation" maxlength="60" type="text" class="form-control">
                                       <div id="designation_error"></div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="empid" class="col-lg-4 col-form-label">Department</label>
                                    <div class="col-lg-8">
                                       <input id="department" maxlength="60" type="text" class="form-control">
                                        <div id="department_error"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="prifix" class="col-lg-4 col-form-label">Date of Requisition</label>
                                    <div class="col-lg-8">
                                       <input id="requistion" type="date" class="form-control">
                                        <div id="requistion_error"></div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="firstname" class="col-lg-4 col-form-label">Sanctioned Post "Experienced
                                       OR Fresher"</label>
                                    <div class="col-lg-8">
                                       <select class="form-control" id="sanction">
                                      <option>Select option</option>
                                          <option>Experienced</option>
                                          <option>Fresher</option>
                                       </select>
                                          <div id="sanction_error"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="role" class="col-lg-4 col-form-label">Required Experience</label>
                                    <div class="col-lg-8">
                                       <input id="exp" type="text" maxlength="10" class="form-control">
                                        <div id="exp_error"></div>
                                    </div>
                                 </div>
                              </div>
                              <!-- <div class="col-sm-6">
                                 <button class="btn btn-primary float-right">Save</button>
                              </div> -->
                           </div>
                           <!-- <h5 class="b-b">HR</h5> -->
                           <div class="row m-t-20">
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="cid" class="col-lg-4 col-form-label">Deadline By HR</label>
                                    <div class="col-lg-8">
                                       <input id="deadline" type="date" class="form-control">
                                        <div id="deadline_error"></div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="empcat" class="col-lg-4 col-form-label">Actual Date of Closure</label>
                                    <div class="col-lg-8">
                                      <input id="actualdate" type="date" class="form-control">
                                        <div id="actualdate_error"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="crdno" class="col-lg-4 col-form-label">Remarks by Recruiter</label>
                                    <div class="col-lg-8">
                                       <input id="remark" type="text" maxlength="500" class="form-control">
                                       <div id="remark_error"></div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="busunit" class="col-lg-4 col-form-label">Remarks by Director</label>
                                    <div class="col-lg-8">
                                     <textarea id="remark_director" class="form-control" maxlength="500"></textarea>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="dep" class="col-lg-4 col-form-label">Remark By MS[Management
                                       Secretariat]</label>
                                    <div class="col-lg-8">
                                       <textarea id="remark_management" maxlength="500" class="form-control"></textarea>
                                    </div>
                                 </div>
                              </div>
                           </div>
                            <div class="col-md-6">
                                 <div class="form-group row">
                                    <label for="firstname" class="col-lg-4 col-form-label">Status</label>
                                    <div class="col-lg-8">
                                       <select class="form-control" id="status">
                                      <option>Select option</option>
                                          <option value="1">Active</option>
                                          <option value="1">inActive</option>
                                       </select>
                                          <div id="status_error"></div>
                                    </div>
                                 </div>
                              </div>
                           <div class="col-sm-12">
                              <button id="addreqruitment" class="btn btn-primary float-right">Save</button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end col -->
               </div>
               <!-- end row -->
            </div>
            <!-- container-fluid -->
         </div>
           @stop