<?php

namespace App\Http\Controllers;
namespace Illuminate\Support\Facades;
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;


//use Illuminate\Support\Facades\Auth;
use DB;
use Session;
//use Input;
use Mail;
use URL;
use Hash;
use Auth;
use Validator;
use App\Main_users;
use App\Mail\sendEmail;
use Carbon\Carbon;
use DateTime;
use DatePeriod;
use DateInterval;
use File;

use App\Http\Controllers\TimesheetController;


class MainusersController extends Controller
{
    //


   protected $_primary = 'id';
  protected $startDay = 21;
  protected $endDay = 20;
  protected $attEndDay = 20;
  protected $monthInterval = 1;

 //SUPER ADMIN LOGIN 
public function users_login(Request $request) {
        $email = $request->input('email');
        $password = $request->input('password');

         //dd($request->all());
         

    
            if($request->isMethod('post')) {


               $userId = Auth::guard('main_users')->user()??'';
          
           if(!empty($userId)){
           

              return redirect('dashboard');

          }
                
    $validator = Validator::make($request->all(), [
    
         'email' => 'required',
         'password' => 'required',
       
      
      ]);

      if($validator->fails()){
    
      return redirect()->back()->with('message', $validator->errors()->first());
      }
            
            $remember_me = $request->has('remember_me') ? true : false; 
            
            if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
    //user sent their email 
            if (Auth::guard('main_users')->attempt(['emailaddress' => $email, 'password' => $password,'isactive' => 1], $remember_me)){
              
              
               return redirect('dashboard');
               
            } else {
            return redirect()->back()->with('message', 'Invalid Email OR Password');;
        }
               
            } else {
    //they sent their username instead 
            if (Auth::guard('main_users')->attempt(['employeeId' => strtoupper($email), 'password' => $password,'isactive' => 1], $remember_me)){
               return redirect('dashboard');
            } else {
            return redirect()->back()->with('message', 'Invalid Email OR Password');;
        }
              }
            
            
            
    //    if (Auth::guard('main_users')->attempt(['emailaddress' => $email, 'password' => $password,'isactive' => 1])) {
          
    //      return redirect('dashboard');
      //  } else {
      //      return redirect()->back()->with('message', 'Invalid Email OR Password');;
      //  }
        } 
        else 
        {

 
            return view('admin.login');
           

        }    
}


public function dashboardview(){
    
     $Role = Auth::guard('main_users')->user()->emprole;
     $userid = Auth::guard('main_users')->user()->id;
    $date =  date("Y-m-d");
    
    $upcomingholydate = DB::table('main_holidaydates')->leftjoin('main_holidaygroups','main_holidaydates.groupid','=','main_holidaygroups.id')->whereDate('main_holidaydates.holidaydate','>=',$date)->where('main_holidaydates.isactive',1)->orderBy('main_holidaydates.holidaydate', 'asc')->select('main_holidaydates.*','main_holidaygroups.groupname')->limit(5)->get();
    
     $birthday = DB::table('grc_emppersonaldetails')->join('main_users','main_users.id','=','grc_emppersonaldetails.user_id')->where('main_users.isactive',1)->where(DB::raw("(DATE_FORMAT(grc_emppersonaldetails.dob,'%m-%d'))"), ">=", date('m-d'))->orderBy(DB::raw("DATE_FORMAT(grc_emppersonaldetails.dob,'%m')"), 'asc')->orderBy(DB::raw("DATE_FORMAT(grc_emppersonaldetails.dob,'%d')"), 'asc')->where('grc_emppersonaldetails.status',1)->select('main_users.userfullname','grc_emppersonaldetails.dob','main_users.profileimg','main_users.prefix','main_users.id as userid')->limit(5)->get();
  //  dd($birthday);

  $expense_approval = DB::table('expense_approval')->join('expenses','expenses.id','=','expense_approval.expense_id')->join('main_users','main_users.id','=','expenses.createdby')->where('expense_approval.approvel_user_id',$userid)->where('expense_approval.view',1)->where('expense_approval.status','pending')->orderBy('expenses.id','DESC')->select('expenses.*','expense_approval.status as aproval_status','expense_approval.id as approval_id','main_users.userfullname')->get();
    
      $policy = DB::table('policy_doc')->where('status',1)->orderBy('id','DESC')->get();
    
    
    $halfday = 0;
    $approve = 0;
     $attadance = DB::table('main_attendance')->leftjoin('main_attendance_temporarydata as tempAtt','main_attendance.empid','=','tempAtt.id')->where(DB::raw("(DATE_FORMAT(main_attendance.entry_date,'%m'))"), "=", date('m'))->whereIN('is_active',[2,3]);
     // $getattence =  $getAppravellist->whereIN('is_active',[2,3,4])->select('main_attendance_temporarydata.*','main_users.userfullname')->get();
       if($Role != 1){
        $attadance->where('main_attendance.user_id' , $userid);
    }
     
     $attadance = $attadance->get();
     foreach($attadance as $attadances){
         if($attadances->status == 'FTS'){
             $halfday +=1;
         }
         
       if($attadances->is_active == 3){
             $approve +=1;
         }
     }
    
    
    $leavecount = DB::table('main_leaverequest')->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y'))"), "=", date('Y'));
    if($Role != 1){
        $leavecount->where('user_id' , $userid);
    }
    $leavecount = $leavecount->get();
    $takenLeave = 0;
    $pending = 0;
    foreach($leavecount as $leavecounts){
          if($leavecounts->leavestatus =='Approved'){
             $takenLeave += $leavecounts->appliedleavescount; 
          }
           if($leavecounts->leavestatus =='Pending for approval' ){
             $pending += $leavecounts->appliedleavescount; 
          }
            
    }
    
   
    
    
     $userid = Auth::guard('main_users')->user()->id;

   $month = date('Y-m');


  $leavelist = DB::table('main_leaverequest')->leftJoin('main_users', 'main_users.id', '=', 'main_leaverequest.user_id')->where('main_leaverequest.leavestatus','Pending for approval')->where('main_leaverequest.rep_mang_id',$userid)

  ->select('main_leaverequest.*','main_users.userfullname')
  ->get();



$getleavecount = DB::table('main_leaverequest')->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), ">=", $month)->select(DB::raw('SUM(main_leaverequest.appliedleavescount) AS leaveCount'))->first();

if(isset($getleavecount)){

  $getleavecount->drtDate =date('M');

}
   // dd($getleavecount);
    
          $userid = Auth::guard('main_users')->user()->id;
       $role= Auth::guard('main_users')->user()->emprole;
      $getAppravellist = DB::table('main_attendance_temporarydata')->join('main_users','main_attendance_temporarydata.empid','=','main_users.id');
      if($role != 1){
        $getAppravellist ->where('main_attendance_temporarydata.reporting_to',$userid);

      }
      
     $getattence =  $getAppravellist->whereIN('is_active',[2])->select('main_attendance_temporarydata.*','main_users.userfullname')->get();



    
  $getleavetype = DB::table('main_employeeleavetypes')->where('isactive',1)->get();

$dashboardview = [];

$getleavecount = DB::table('main_leaverequest');
if($Role !=1){
$getleavecount->where('user_id',$userid);
}

$getleavecount = $getleavecount->where('leavestatus','Approved')->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y'))"), "=", date('Y'))->where('leavetypeid',1)->select(DB::raw('SUM(main_leaverequest.appliedleavescount) AS leaveCount'))->first();
$clvalue = $getleavetype[0]->id.'#'.$getleavetype[0]->numberofdays.'#'.$getleavetype[0]->leavecode;
$RHvalue = $getleavetype[1]->id.'#'.$getleavetype[1]->numberofdays.'#'.$getleavetype[1]->leavecode;
$dashboardview['totalCLleave'] = $getleavecount->leaveCount;
$ClAvailable = $this->avaliableleave($userid,$clvalue);
$RHAvailable = $this->avaliableleave($userid,$RHvalue);
$dashboardview['CL'] = $ClAvailable;
$dashboardview['RH'] = $RHAvailable;

 $pendingleave = DB::table('main_leaverequest')->leftJoin('main_users', 'main_users.id', '=', 'main_leaverequest.user_id')->where('main_leaverequest.leavestatus','Pending for approval');
if($Role !=1){
  $pendingleave->where('main_leaverequest.rep_mang_id',$userid);
}
$pendingleave = $pendingleave->select(DB::raw('SUM(main_leaverequest.appliedleavescount) AS leaveCount'))
  ->first();
  $dashboardview['pendingLeave'] = $pendingleave->leaveCount;


   // dd($getleavecount);

// MY Team


$totalunderUser = DB::table('main_users');
if($Role !=1){
$totalunderUser->where('reporting_manager',$userid);
}
$totalunderUser = $totalunderUser->count();
$dashboardview['TotalUnderUser'] = $totalunderUser;

$totalunderUserActive = DB::table('main_users');
if($Role !=1){
$totalunderUserActive->where('reporting_manager',$userid);
}
$totalunderUserActive = $totalunderUserActive->where('isactive',1)->count();
$dashboardview['TotalUnderUserActive'] = $totalunderUserActive;

// attdanceCount

$fts = $this->fts($userid);
$dashboardview['FTS'] = $fts;
    
      $attdandaceCorrection = DB::table('main_attendance_temporarydata');
      if($Role != 1){
        $attdandaceCorrection->where('main_attendance_temporarydata.reporting_to',$userid);

      }
      
     $attdandaceCorrection =  $attdandaceCorrection->whereIN('is_active',[2])->select(DB::raw('COUNT(*) AS leaveCorrection'))->first();
     $dashboardview['AttedanceCorrection'] = $attdandaceCorrection->leaveCorrection;
     $dashboardview['totalworkday'] = $this->totalworkingday();


     //project

     $underProject = DB::table('tm_projects')->where('project_status','in-progress')->where('is_active',1);
      if($Role != 1){
        $underProject->where('tm_projects.manager_id',$userid);
      }

      $underProject = $underProject->count();

      $tasknotfound = [];
$hideprojectlist = DB::table('tm_project_employees')->join('tm_projects','tm_project_employees.project_id','=','tm_projects.id')->join('main_users','tm_project_employees.emp_id','=','main_users.id')->where('tm_project_employees.emp_id',$userid)->where('tm_projects.project_status','in-progress')->select('tm_project_employees.*','main_users.userfullname','tm_projects.project_name')->get();
if(isset($hideprojectlist)){
foreach($hideprojectlist as $hideprojectlists){
$tasklist = DB::table('tm_project_task_employees')->leftjoin('tm_project_tasks','tm_project_task_employees.project_task_id','=','tm_project_tasks.id')->leftjoin('tm_tasks','tm_project_task_employees.task_id','=','tm_tasks.id')->where('tm_project_task_employees.project_id',$hideprojectlists->project_id)->where('tm_project_task_employees.is_active',1)->where('tm_project_task_employees.emp_id',$userid)->select('tm_project_tasks.*','tm_tasks.task')->first();
if(empty($tasklist)){
$tasknotfound[] = $hideprojectlists->project_id;
}
}
}
     
       $memberProject = DB::table('tm_project_employees')->join('tm_projects','tm_project_employees.project_id','tm_projects.id')->where('tm_projects.project_status','in-progress')->whereNotIn('tm_project_employees.project_id',$tasknotfound)->where('tm_projects.is_active',1);
 if($Role != 1){
         $memberProject->where('tm_project_employees.emp_id',$userid);
       }
     
      $memberProject = $memberProject->count();


           $TotalProject = DB::table('tm_project_employees')->join('tm_projects','tm_project_employees.project_id','tm_projects.id')->where('tm_projects.project_status','in-progress')->where('tm_projects.is_active',1);
 if($Role != 1){
         $TotalProject->where('tm_project_employees.emp_id',$userid);
       }
     
      $TotalProject = $TotalProject->count();

     
       $dashboardview['managerProject'] =  $underProject;
        $dashboardview['memberProject'] =  $memberProject;
        $dashboardview['TotalProject'] =  $TotalProject;


      $finddate = date('Y-m-d',strtotime('last sunday'));
      $currentweekcount  = (new TimesheetController)->weekOfMonth();
      $currentweekCountPassed =  (new TimesheetController)->weekOfMonth();
     $daterange =  (new TimesheetController)->x_week_range($finddate);
     list($firstDate,$lastDate) = $daterange;
     $findYear = date('Y',strtotime($finddate));
      $month = date('m',strtotime($finddate));
     $daterange1 =  (new TimesheetController)->createDateRangeArray($daterange[0] ,$daterange[1]) ;
      $daterange =  $daterange1;
      $alltotalhour = 0;

 $uderUser = [];
//$uderUser[] = $userid;
$usergetassign = DB::table('main_users');
$usergetassign->where('reporting_manager',$userid);
$usergetassign  =  $usergetassign->where('isactive',1)->select('id')->get();
foreach($usergetassign as $usergetassigns){
$uderUser[] = $usergetassigns->id;
}

$getuserproject = DB::table('tm_project_employees')->join('tm_projects','tm_project_employees.project_id','=','tm_projects.id')->join('main_users','tm_project_employees.emp_id','=','main_users.id');
if($role != 1 && $Role != 4){
 $getuserproject->whereIn('tm_project_employees.emp_id',$uderUser); 
}

$notassignrole=[];
$role = DB::table('main_roles')->where('hide',1)->where('isactive',1)->select('id')->get();
foreach($role as $roles){
  $notassignrole[] = $roles->id;
  }

$getuserproject = $getuserproject->where('main_users.isactive',1)->WhereNull('main_users.extension')->whereNotIn('main_users.emprole',$notassignrole)->groupBy('tm_project_employees.emp_id')->select('tm_project_employees.*','main_users.userfullname','tm_projects.project_name')->get();   



if(isset($getuserproject) && !empty($getuserproject)){
foreach($getuserproject as $getuserprojects){
$totaltaskhour = 0;
$total_mon = 0;
$total_tue = 0;
$total_wed = 0;
$total_thu = 0;
$total_fri = 0;


$leaveuser = DB::table('main_leaverequest')->where('user_id',$getuserprojects->emp_id)->where('leavestatus','Approved')->where('leaveday',1)->whereBetween('from_date', [$firstDate, $lastDate])->select('from_date')->get();
  $leaveList = [];
if(isset($leaveuser) && !empty($leaveuser) && count($leaveuser) > 0){
    
  foreach ($leaveuser as $key => $leaveusers) {
    
    $leaveList[] = date('D',strtotime($leaveusers->from_date)); 
  }
 
}

  $getuserprojects->leaveDate = $leaveList;

$urerhour = DB::table('tm_assign_emp_timesheets')->where('emp_id',$getuserprojects->emp_id)->where('ts_year',(int)$findYear)->where('ts_month',(int)$month)->where('ts_week',$currentweekCountPassed)->get();
foreach($urerhour as $urerhours)  {              
$time_arr =  array($urerhours->mon_duration??'00:00');
foreach ($time_arr as $time_val) {
$total_mon +=explode_time($time_val);
} 
$time_arr =  array($urerhours->tue_duration??'00:00');
foreach ($time_arr as $time_val) {
$total_tue +=explode_time($time_val);
} 
$time_arr =  array($urerhours->wed_duration??'00:00');
foreach ($time_arr as $time_val) {
$total_wed +=explode_time($time_val);
} 
$time_arr =  array($urerhours->thu_duration??'00:00');
foreach ($time_arr as $time_val) {
$total_thu +=explode_time($time_val);
} 
$time_arr =  array($urerhours->fri_duration??'00:00');
foreach ($time_arr as $time_val) {
$total_fri +=explode_time($time_val);
} 
$time_arr =  array($urerhours->week_duration??'00:00');
foreach ($time_arr as $time_val) {
$totaltaskhour +=explode_time($time_val);
}
}
//dd($total_fri);
$getuserprojects->userhour = second_to_hhmm($totaltaskhour??'00:00');
$getuserprojects->assign_hour_mon = second_to_hhmm($total_mon??'00:00');
$getuserprojects->assign_hour_tue = second_to_hhmm($total_tue??'00:00');
$getuserprojects->assign_hour_wed = second_to_hhmm($total_wed??'00:00');
$getuserprojects->assign_hour_thu = second_to_hhmm($total_thu??'00:00');
$getuserprojects->assign_hour_fri = second_to_hhmm($total_fri??'00:00');
//$getuserprojects->total_user_hour_emp_diff = second_to_hhmm($totaltaskhour - $usertotaltaskhour);


$getuserprojects->user_hour_mon_diff = second_to_hhmm( 32400 - (int)$total_mon);
$color_mon = 32400 - (int)$total_mon;
$getuserprojects->user_hour_mon_color = ($color_mon > 0)?(in_array('Mon',$getuserprojects->leaveDate)? 'bg-dark' : 'bg-green'):'bg-red';
$getuserprojects->user_hour_tue_diff = second_to_hhmm(32400 - (int)$total_tue);
$color_tue = 32400 - (int)$total_tue;
$getuserprojects->user_hour_tue_color = ($color_tue > 0)?(in_array('Tue',$getuserprojects->leaveDate)? 'bg-dark' : 'bg-green'):'bg-red';
$getuserprojects->user_hour_wed_diff = second_to_hhmm(32400 - (int)$total_wed );
$color_wed = 32400 - (int)$total_wed;
$getuserprojects->user_hour_wed_color = ($color_wed > 0)?(in_array('Wed',$getuserprojects->leaveDate)? 'bg-dark' : 'bg-green'):'bg-red';
$getuserprojects->user_hour_thu_diff = second_to_hhmm(32400 - (int)$total_thu);
$color_thu = 32400 - (int)$total_thu;
$getuserprojects->user_hour_thu_color = ($color_thu > 0)?(in_array('Thu',$getuserprojects->leaveDate)? 'bg-dark' : 'bg-green'):'bg-red';
$getuserprojects->user_hour_fri_diff = second_to_hhmm(32400 - (int)$total_fri);
$color_fri = 32400 - (int)$total_fri;
$getuserprojects->user_hour_fri_color = ($color_fri > 0)?(in_array('Fri',$getuserprojects->leaveDate)? 'bg-dark' : 'bg-green'):'bg-red';

}

}




    
    return view('admin.dashboard',['policy' => $policy,'expense_approval' =>  $expense_approval,'holyDay' => $upcomingholydate,'birthday' => $birthday,'takeleave' =>$takenLeave,'pending' =>$pending,'halfday' =>$halfday,'late' =>$approve ,'leavelist' =>$leavelist,'getleavecount' => $getleavecount,'approvalList' => $getattence,'dashboad' =>  $dashboardview,'daterange' => $daterange1,'userlist' => $getuserproject ]);

}



private function totalworkingday(){


                  $weekEnds = [];
                  $month = date('m');
                  $year = date('Y');
                  $d=cal_days_in_month(CAL_GREGORIAN,$month,$year);
                  $wkYear = ($month==12) ? ($year+1) : $year;
                  $wkMonth = ($month==12) ? '01' : ($month+1);

                  
                  $start = new DateTime($year.'-'.$month.'-01');
                  $interval = new DateInterval('P1D');
                 
                  $end = new DateTime($wkYear.'-'.$wkMonth.'-01');

                  $period = new DatePeriod($start,$interval,$end);
                
               // dd($period);
      
                  foreach ($period as $day){
                    if ($day->format('N') == 6 || $day->format('N') == 7){
                      $weekEnds[$day->format('Y-m-d')] = true;
                    }
                  }

                  $weekEnds  = count($weekEnds);

                   $newdate = date('Y-m', strtotime($year.'-'.$month.'+-1 months'));

       $attstatedate = $newdate.'-'.$this->startDay;
       $attenddate = $year.'-'. $month.'-'.$this->attEndDay;


                 $datetime1 = new DateTime($attstatedate);

                 $datetime2 = new DateTime($attenddate);

                 $difference = $datetime1->diff($datetime2);

                 $totalday  = $difference->d;

                 $weekendoff = $weekEnds;

                return $workingday = (int)$totalday - (int)$weekendoff;




}


private function fts($userid){

       $month = date('m');
       $newdate = date('Y-m', strtotime(date('Y-m').'+-1 months'));     
       $year = date('Y');


       $attstatedate = $newdate.'-'.$this->startDay;
       $attenddate = $year.'-'. $month.'-'.$this->attEndDay;

      return  $absent  = 1 * DB::table('main_attendance')->whereBetween('entry_date', [$attstatedate, $attenddate])->where('user_id',$userid)->where('status', '=', 'LWP')->count() + 0.5 * DB::table('main_attendance')->whereBetween('entry_date', [$attstatedate, $attenddate])->where('user_id',$userid)->where('status', '=', 'HL')->count() + 0.5 * DB::table('main_attendance')->whereBetween('entry_date', [$attstatedate, $attenddate])->where('user_id',$userid)->where('status', '=', 'FTCO')->count() + 0.5 * DB::table('main_attendance')->whereBetween('entry_date', [$attstatedate, $attenddate])->where('user_id',$userid)->where('status', '=', 'FTCI')->count()  + 0.5 * DB::table('main_attendance')->whereBetween('entry_date', [$attstatedate, $attenddate])->where('user_id',$userid)->where('status', '=', 'HPL')->count();
}


public function avaliableleave($userid,$leavetype){
    
  // dd($request->all());
    
    
    
    list($leaveid,$totalleaveall,$leavecode) = explode('#',$leavetype);
    $now = date('Y-m');
    $takenleave = 0;
    $totalleave = DB::table('main_employeeleaves')->where('user_id',$userid)->first();
    $userdetails = DB::table('main_users')->where('id',$userid)->first();


    if($leavecode == 'CL'){
        // $lessMonth = date('m');
         $lesscountmonthless = (int)date('m') - 1;
       
         $startDate = date('Y').'-01';
         $endDate = date('Y-m', strtotime(date('Y-m').'+-1 months'));
        
          $joinDate = date('Y',strtotime($userdetails->join_date));
          
          if((int)$joinDate >= (int)date('Y')){
                $joinmonth =(int) date('m',strtotime($userdetails->join_date));

                $lesscountmonthless =   (int)date('m') - $joinmonth;
                $lesscountmonthless  =  ($lesscountmonthless <= 0)?1:$lesscountmonthless;
                

          }else{

            $lesscountmonthless = (int)date('m') - 1;
            

          }
        
        $lessCountMonth = 0;
        for($i = 0;$i < (int)$lesscountmonthless; $i++){
            $lessCountMonth += 1.5;
        }
        
     
        
         $preleave = DB::table('main_leaverequest')->where('isactive',1)->where('leavestatus','Approved')->whereBetween(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), [$startDate, $endDate])->where('leavetypeid',(int)$leaveid)->where('user_id',$userid)->orderBy(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%m'))"), 'asc')->groupBy(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%m'))"))->select(DB::raw('SUM(main_leaverequest.appliedleavescount) as leaveCount'),DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%m'))"))->get();
         
          //$preMonthleaveAvail = 0;
           
          $preLeaveMonth = 0;
         if(count($preleave) > 0){
            foreach($preleave as $preleaves) {


             $preLeaveMonth +=$preleaves->leaveCount;
             $preMonthleaveAvail = $lessCountMonth - $preLeaveMonth;
                
         
                
            }

         
             
            
         }else{
             $preLeaveMonth = 0;
             
              $preMonthleaveAvail = $lessCountMonth - $preLeaveMonth;

               
         }
        

    $takenleave  =0;
    $takeleave = DB::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Rejected','Cancel'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), "=", $now)->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
  
    if(isset($takeleave) && !empty($takeleave)){
    foreach($takeleave as $takeleaves){
        
        $takenleave +=$takeleaves->appliedleavescount;
        
        
     
    }  
    }else{
        
        $takenleave = 0;
        
    }


     
     
     $Totalavaliableleave =   ($preMonthleaveAvail < 0)?0: $preMonthleaveAvail - $takenleave;



      if($Totalavaliableleave < 0){
       return 0;
      }else{

       return $Totalavaliableleave + 1.5  + caryforward($userid);

      }
        
    }elseif($leavecode == 'RH'){

       $takenleave = 0;
        
         $takeleave = Db::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Rejected','Cancel'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.createddate,'%Y'))"), "=", date('Y'))->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
 
    if(isset($takeleave) && !empty($takeleave)){
         foreach($takeleave as $takeleaves){
        $takenleave +=$takeleaves->appliedleavescount;
    }
        
    }else{
        
        $takenleave = 0;
        
    }
   
        
        
         return $totalleaveall - $takenleave;
    
    }elseif($leavecode == 'ML'){

      $takenleave = 0;
        
          $takeleave = Db::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Rejected','Rejected'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.createddate,'%Y'))"), "=", date('Y'))->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
 
    if(isset($takeleave) && !empty($takeleave)){
         foreach($takeleave as $takeleaves){
        $takenleave +=$takeleaves->appliedleavescount;
    }
        
    }else{
        
        $takenleave = 0;
        
    }
   
        
        
         return $totalleaveall - $takenleave;
        
    }elseif($leavecode == 'MyL'){
        
          $takeleave = Db::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Rejected','Rejected'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.createddate,'%Y'))"), "=", date('Y'))->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
 
    if(isset($takeleave) && !empty($takeleave)){
         foreach($takeleave as $takeleaves){
        $takenleave +=$takeleaves->appliedleavescount;
    }
        
    }else{
        
        $takenleave = 0;
        
    }
   
        
        
         return $totalleaveall - $takenleave;
        
    }
}



public function leave_status(Request $request){

       $userid = Auth::guard('main_users')->user()->id;
    
    $leave_id = json_decode($request->leave_id);
      $user_id = json_decode($request->user_id);
      
    
 
      
    if($request->status == 'Approve'){
        
        foreach($leave_id as $k => $leave_ids){
            
             $leave_details = DB::table('main_leaverequest')->where('id',$leave_ids)->first();
              $user_details = DB::table('main_users')->where('id',$user_id[$k])->first();
            
             if($leave_details->lwp > 0){
                 
                 $staus = ($leave_details->lwp == 1.0)?'LWP':'HPL';
                 
             }else if($leave_details->avail > 0){
                 
                 if($leave_details->leaveday == 1 && $leave_details->avail >= 0){
                        $staus = "L" ;   
                 }else if($leave_details->leaveday == 1 && $leave_details->avail >= 1.0){
                      $staus = "L"   ;
                 }else if($leave_details->leaveday == 2 && $leave_details->avail >= 0.5){
                      $staus = "HL"  ;
                 }else{
                      $staus = "HL"  ;
                 }
                 
                 
                 
             }else if($leave_details->leaveday == 1 && $leave_details->avail == 0){
                 
                $staus = 'L';
                 
             }else{
                 
                   $staus = 'HL';
                 
             }
            
             $user_details = DB::table('main_users')->where('id',$user_id[$k])->first();
             $t = preg_replace('/[^0-9]/i', '',$user_details->employeeId);
             $venc = (int)$t;
              // $leave_emp  = DB::table('main_employeeleaves')->where('user_id',$leave_details->user_id)->first();
                 DB::table('main_attendance')->where('user_id',$leave_details->user_id)->whereDate('entry_date',$leave_details->from_date)->delete();
              $addAttance = array(
                  'user_id' => $leave_details->user_id,
                  'empid' => $venc,
                  'reporting_to' => $user_details->reporting_manager,
                  'shift' => 'GS',
                  'intime'  => '00:00:00',
                  'outtime'  => '00:00:00',
                  'entry_date' => $leave_details->from_date, 
                  'status'  => $staus,
                 
                  );
                  
                  DB::table('main_attendance')->insert($addAttance);
             
              //DB::table('main_employeeleaves')->where('user_id',$leave_details->user_id)->update(['emp_leave_limit' => $leave_emp->emp_leave_limit -  $leave_details->appliedleavescount,'used_leaves' =>$leave_emp->used_leaves + $leave_details->appliedleavescount ]);

    $status = 1;

    
     if($leave_details->leavetypeid == 1){

        $leaveType = "CL";

     }else if($leave_details->leavetypeid == 2){

      $leaveType = "RH";

     }else{

      $leaveType = "My Leave";

     }

      DB::table('main_leaverequest')->where('id',$leave_ids)->update(['leavestatus' => 'Approved']);
      
        $leave_details = DB::table('main_leaverequest')->where('id',$leave_ids)->first();
    $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content =   templete_leave_confirmation($user_details->userfullname, date('d M Y', strtotime($leave_details->from_date)),1,$leaveType,$leave_details->leavestatus,$leave_details->reason);

  
  
    $userEmail  = sendMail($user_details->emailaddress,$subject,$from,$fromname,$content);

    DB::table('main_notification')->insert(['sender_id' =>$userid,'reciver_id' => $user_details->id,'msg' => 'Approved Leave for '. $leave_details->from_date,'status' => 1]);
     
        }
        
         return response()->json(['status' => 200, 'msg' => 'Successfully Approved']);
         

   }else{
       
          foreach($leave_id as $k => $leave_ids){
          
            $leave_details = DB::table('main_leaverequest')->where('id',$leave_ids)->first();
             $user_details = DB::table('main_users')->where('id',$user_id[$k])->first();
           
            // $total_leave_details = DB::table('total_leave_list')->where('user_id',$user_id[$k])->first(); 


     $status = 2;


 if($leave_details->leavetypeid == 1){

        $leaveType = "CL";

     }else if($leave_details->leavetypeid == 2){

      $leaveType = "RH";

     }else{

      $leaveType = "My Leave";

     }
 
     DB::table('main_leaverequest')->where('id',$leave_ids)->update(['leavestatus' => 'Rejected']);

        $leave_details = DB::table('main_leaverequest')->where('id',$leave_ids)->first();
     $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content =   templete_leave_confirmation($user_details->userfullname, date('d M Y', strtotime($leave_details->from_date)),1,$leaveType,$leave_details->leavestatus,$leave_details->reason);

    $userEmail  = sendMail($user_details->emailaddress,$subject,$from,$fromname,$content);

    DB::table('main_notification')->insert(['sender_id' =>$userid,'reciver_id' => $user_details->id,'msg' => 'Rejected Leave for '. $leave_details->from_date,'status' => 1]);
  
   }
   
    return response()->json(['status' => 200, 'msg' => 'Successfully Reject']);
   }
      
     
    
}


public function sendnotification(Request $request){
    
     $userid = Auth::guard('main_users')->user()->id;
    
    $addnoti = array(
        'sender_id' => $userid,
        'reciver_id' => $request->birthday_user_id,
        'msg' => $request->comment,
        'status' => 1,
        
        );
        
        $inst = DB::table('main_notification')->insert($addnoti);
        
        if($inst){
            
             return response()->json(['status' => 200, 'msg' => 'Send Wishes']);
        }else{
            
             return response()->json(['status' => 203, 'msg' => 'not send']);
            
        }
}

function shownotification(Request $request){
    
    $current_userid = $request->current_user_id;
    
     $role = Auth::guard('main_users')->user()->emprole;
    
    $getnotification = DB::table('main_notification')->leftjoin('main_users as sender','main_notification.sender_id','=','sender.id')->leftjoin('main_users as reciver','main_notification.reciver_id','=','reciver.id')->orderBy('main_notification.create_at', 'DESC')->select('main_notification.*','sender.userfullname as sender_user_name','reciver.userfullname as reciver_username','sender.profileimg','sender.prefix');
     if($role !=1){
        $getnotification->where('main_notification.reciver_id','=',$current_userid); 
     }
        $count =  $getnotification->count(); 
       
       $allnotidata = $getnotification->limit(10)->get();
       
    $html = '';
    
    foreach($allnotidata as $getnotifications){
        
       $cunt = date('d-M-Y h:i:s', strtotime($getnotifications->create_at));
       
                   
                 $html .=  ' <a href="javascript:void(0);" class="dropdown-item notify-item">
                              <div class="notify-icon bg-success">'; 
                              if(!empty($getnotifications->profileimg))
                              $html .=  '<img class="img-fluid thumb-sm1 rounded-circle mr-2" src="'.URL::to('public/').$getnotifications->profileimg.'">';
                              elseif($getnotifications->prefix == 1){
                                 $html .=  '<img class="img-fluid thumb-sm1 rounded-circle mr-2" src="'.URL::to('public/uploads/male.png').'">';
                              }elseif($getnotifications->prefix == 2 || $getnotifications->prefix ==3 ){
                                 $html .=  '<img class="img-fluid thumb-sm1 rounded-circle mr-2" src="'.URL::to('public/uploads/female.png').'">';
                              }else{
                              
                               $html .=  '<img class="img-fluid thumb-sm1 rounded-circle mr-2" src="#">';
                              
                              }
                              $html .= '</div>
                              <p class="notify-details">'.ucwords($getnotifications->sender_user_name).'<span class="text-muted">'. $getnotifications->msg .' - '.$cunt.'</span></p>
                           </a>';                             
                                                
        
        
     
    }
      

     
      
       return response()->json(['status' => 200, 'notifiction' => $html,'totalcount' =>$count]);

}


    public function employees(){

       $userid = Auth::guard('main_users')->user()->id;
       
       $role = Auth::guard('main_users')->user()->emprole;
       // dd($userid);

        

          $listData = Main_users::leftJoin('main_departments','main_users.department_id','=','main_departments.id')->where('main_users.emprole','!=',1);
          
          
          
          if($role !=1 && $role !=4){
              
             $listData->where('main_users.isactive',1) ;
          }
             
          
          
          $listData = $listData->where('main_users.id','!=', $userid)->orderBy('userfullname','asc')->select('main_users.*','main_departments.deptname','main_users.createddate as usercreateddate')->get();
            return view('admin.employees',compact('listData'));
    }

    public  function add_employees(Request $request){
      return view('admin.add_emp');
    }

   public function showLinkRequestForm(){

            return view('admin.forget');

    }

       public function sendResetLinkEmail(Request $request){


         date_default_timezone_set("Asia/Kolkata");
        

         $user = DB::table('main_users')->where('emailaddress', $request->email)->first();
        if ( !$user ) return redirect()->back()->with('message', 'Invalid Email');
          
      $arr  = [
            'email' => $request->email,
            'token' => str_random(60), //change 60 to any length you want
            'created_at' =>date('Y-m-d H:i:s'),
        ];

        //create a new token to be sent to the user. 
      // $dd = DB::table('password_resets')->insert($arr);

         DB::table('password_resets')->where('email', $request->email)->delete();
         
          $test_detailsId = DB::table('password_resets')->insert($arr);

        $tokenData = DB::table('password_resets')
        ->where('email', $request->email)->first();

       $token = $tokenData->token;
       $email = $request->email; // or $email = $tokenData->email;

   
        $to = $email;
        $subject = 'Reset password';
        $from = 'suitecrm14@gmail.com';
        $fromname = 'Not_To_Reply';
        $content = '';
        $content .='
   <!DOCTYPE html>
  <html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
    <title>GRC</title>
    <meta content="Admin Dashboard" name="description">
    <meta content="GRC" name="author">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <table class="body-wrap"
                    style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: #f6f6f6; margin: 0;"
                    bgcolor="#f6f6f6">
                    <tr
                        style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                        <td style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;"
                            valign="top"></td>
                        <td class="container" width="600"
                            style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;"
                            valign="top">
                            <div class="content"
                                style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; max-width: 600px; display: block; margin: 0 auto; padding: 20px;">
                                <table class="main" width="100%" cellpadding="0" cellspacing="0" itemprop="action"
                                    itemscope itemtype="http://schema.org/ConfirmAction"
                                    style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; border-radius: 3px; margin: 0; border: none;">
                                    <tr
                                        style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                        <td class="content-wrap"
                                            style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;padding: 30px;border: 3px solid #5fe384;border-radius: 7px; background-color: #fff;"
                                            valign="top">
                                            <meta itemprop="name" content="Confirm Email"
                                                style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                            <table width="100%" cellpadding="0" cellspacing="0"
                                                style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                <tr
                                                    style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                    <td class="content-block"
                                                        style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                                        valign="top">Please confirm your email address by
                                                        clicking the link below.</td>
                                                </tr>
                                                <tr
                                                    style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                    <td class="content-block"
                                                        style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                                        valign="top">We may need to send you critical
                                                        information about our service and it is important
                                                        that we have an accurate email address.</td>
                                                </tr>
                                                <tr
                                                    style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                    <td class="content-block" itemprop="handler" itemscope
                                                        itemtype="http://schema.org/HttpActionHandler"
                                                        style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                                        valign="top"><a href="'.URL::to('password/reset/'.$token).'" class="btn-primary" itemprop="url"
                                                            style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; font-weight: bold; text-align: center; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #5fe384; margin: 0; border-color: #5fe384; border-style: solid; border-width: 8px 16px;">Confirm
                                                            email address </a> 
                                                            <p style="color:red;margin-bottom: 5px;
    margin-top: 4px;
    font-size: 13px;">Link has been Expired After 2 hr</p>
                                                            </td>
                                                </tr>
                                                <tr
                                                    style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                    <td class="content-block"
                                                        style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                                        valign="top">
                                                        <b>kloudrac India</b>
                                                    </td>
                                                </tr>
                                                <tr
                                                    style="font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                                    <td class="content-block"
                                                        style="text-align: center;font-family: "Helvetica Neue",Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0;"
                                                        valign="top">© '.date('Y').' kloudrac</td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body>

</html>
       
        ';
       // $content .= 'Dear '.$user->userfullname.' Send Reset Password <a href="'.URL::to('password/reset/'.$token).'">Click Link</a> Link valid in 2 Hours'; 

        $sendEmail = sendMail($to,$subject,$from,$fromname,$content);

        
        if($sendEmail){

          return redirect('admin')->with('message', 'Link Has been send in your email');

        }else{

        return redirect('admin')->with('message', 'Link Has been send in your email');

        }



    }

        public function showResetForm($token)
     {
        
        
      if ( !$token ) return redirect('forget')->with('message', 'Link Expaired');
       
      // $hour  = date("Y-m-d H:i:s",strtotime('+5 hours', strtotime(date('Y-m-d H:i:s'))));
      
       
         $tokenData = DB::table('password_resets')
         ->where('token', $token)->where('created_at','>',Carbon::now()->subHours(2))->first();

         if ( !$tokenData ) return redirect('forget')->with('message', 'Link Expaired');; //redirect them anywhere you want if the token does not exist.
         return view('admin.changePassword',['token' =>$tokenData->token]);
     }



     public function resetform(Request $request)
     {
  

       $token = $request->token;

       $Validator =  Validator::make($request->all(), [
        'password' => 'min:6',
        'cpassword' => 'required_with:password|same:password|min:6'
      ]);

     if($Validator->fails()){

          return redirect('password/reset/'.$token)->with('message', $Validator->messages()->first());

       }
     
     $password = $request->password;
     $tokenData = DB::table('password_resets')->where('token', $token)->first();
  
 
   //  $user = User::where('email', $tokenData->email)->first();
      $user = DB::table('main_users')->where('emailaddress', $tokenData->email)->first();

     if ( !$user ) return redirect()->to('/'); //or wherever you want
       $pass  = Hash::make($password);
      $upated =  DB::table('main_users')->where('id',$user->id)->update(['password' => $pass]);
     //$user->password = Hash::make($password);
    // $user->update(); //or $user->save();
    
     //do we log the user directly or let them login and try their password for the first time ? if yes 

       if($upated){

       //  Auth::login($user);

        DB::table('password_resets')->where('email', $user->emailaddress)->delete();

          return redirect('admin')->with('message', 'Password has been changed successfully');

       }
  
 }
function heirarchy(){

  $items =  DB::table('main_users')->join('main_roles','main_roles.id','=','main_users.emprole')->where('main_users.isactive',1)->orderBy('main_users.emprole', 'ASC')->select('main_users.*','main_roles.rolename')->get();

  foreach ($items as $object) {
      $arrays[] =  (array) $object;
  }
  $users = $this->generateTree1($arrays, $parent_id = 0);
  

  return view('admin.heirarchy',['users' => $users]);

}


protected function generateTree1($items = array(), $parent_id = 0)
{
    $pages = array();
    for ($i = 0, $ni = count($items); $i < $ni; $i++) {
        if ($items[$i]['reporting_manager'] == $parent_id) {


            //$tree[] = '<input type="checkbox" value="'.$items[$i]['id'].'">';
            $page['id'] = $items[$i]['id'];
            $page['userfullname'] = $items[$i]['userfullname'];
            
            if(!empty($items[$i]['profileimg'])){
                $img = URL::to('/public/').$items[$i]['profileimg'];
            }elseif(!empty($items[$i]['prefix'] && $items[$i]['prefix'] ==1 )){
                $img  = URL::to('/public/uploads/male.png');
            }elseif(!empty($items[$i]['prefix'] && $items[$i]['prefix'] ==2 )){
                 $img  = URL::to('/public/uploads/female.png');
            }else{
                 $img  = URL::to('/public/uploads/human.png');
                
            }
            $page['profile'] = $img;
            $page['role'] = $items[$i]['rolename'];;
            $page['reporting_manager'] = $items[$i]['reporting_manager'];
            $page['sub'] = $this->generateTree1($items, $items[$i]['id']);
            $pages[] = $page;
        }
    }

    return $pages;
}



        protected function sendforgetlink($to, $subject, $from, $fromname, $content)
    {
        try {
            $mail = Mail::send([], [], function ($message) use ($to, $subject, $from, $fromname, $content) {

                $message->from($from, $fromname);
                $message->to($to);
                $message->subject($subject);
                $message->setBody($content, 'text/html'); // for HTML rich messages
            });

            if ($mail) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            throw new HttpException(500, $e->getMessage());
        }
    }




function policy(){
$policy = DB::table('policy_doc')->where('status',1)->orderBy('id','DESC')->get();

  return view('admin.policy',['policy' =>$policy ]);
}

function view_policy($id){

  $viewpolicy = DB::table('policy_doc')->where('id',$id)->first();

  return view('admin.policy_view',['viewpolicy' =>$viewpolicy ]);

}

function delete_policy($id){

 $getpolicy =  DB::table('policy_doc')->where('id',$id)->first();

 foreach(explode(',',$getpolicy->files)  as $filess){
  if(File::exists(public_path($filess))) {
    File::delete(public_path($filess));
}
 }
 DB::table('policy_doc')->where('id',$id)->delete();
 return redirect()->back()->with('message','Succesffully Deleted');

}

function get_policy(Request $request){

 $policy =  DB::table('policy_doc')->where('id',$request->policy_id)->first();

 return response()->json(['status' => 200, 'msg' => 'Successfully Added','policy' => $policy ]);



}

function save_policy(Request $request){
  $userid = Auth::guard('main_users')->user()->id;

  if($request->hasFile('images')) {

     $doc = [];     
    foreach($request->file('images') as $file){


     $name = str_replace(' ','_',$file->getClientOriginalName());

   //  $name = time().'.'.$original_name;

    $file->move(public_path().'/uploads/attach/files/', $name);

    $doc[] = '/uploads/attach/files/'. $name;


   }

   $policy['files'] = implode(',', $doc);

    }

    $policy['title'] = $request->policy_name;
    $policy['desc'] = $request->desc;
    $policy['created_by'] = $userid;
    $policy['updated_by'] = $userid;
    
   if(isset($request->policy_id)){
     
    $policy['updated_at'] = date('Y-m-d h:i:s');
    DB::table('policy_doc')->where('id',$request->policy_id)->update($policy);

    return response()->json(['status' => 200, 'msg' => 'Successfully updated']);

   }else{
    $policy['created_at'] = date('Y-m-d h:i:s');
    $policy['updated_at'] = date('Y-m-d h:i:s');
    DB::table('policy_doc')->insert($policy);

    return response()->json(['status' => 200, 'msg' => 'Successfully Added']);
   }
   

   


}





}
