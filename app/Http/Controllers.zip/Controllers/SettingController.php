<?php



namespace App\Http\Controllers;

namespace Illuminate\Support\Facades;

namespace App\Http\Controllers;



use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Input;





//use Illuminate\Support\Facades\Auth;

use DB;

use Session;

//use Input;

use Mail;

use URL;

use Hash;

use Auth;

use Validator;

use App\Main_users;

use App\Mail\sendEmail;

use Carbon\Carbon;
use Redirect;

use File;





class SettingController extends Controller

{



	public function file_manager(){

   $project_id = [];

    $user_id =  Auth::guard('main_users')->user()->id;

    $role =  Auth::guard('main_users')->user()->emprole;

    $get_Project = DB::table('tm_project_employees')->where('emp_id',$user_id)->get();

   foreach ($get_Project as $key => $get_Projects) {

    $project_id[] = $get_Projects->project_id;

   }





		$file_manager = DB::table('tm_folder');

     if($role !=1){

      $file_manager->whereIn('project_id',$project_id);

     }



   $file_manager =  $file_manager->get();



		return view('mainSetting.create_view_folder',['folder_list' => $file_manager]);

	}

    

    function create_folder(Request $request){





$user_id =  Auth::guard('main_users')->user()->id;



 $arr = array(



'folder_name' => $request->folder_name,

'created_by' => $user_id,

'create_at' => date('Y-m-d h:i:s'),



 );



 $inst = DB::table('tm_folder')->insert($arr);

 	return response()->json(['status' => 200, 'msg' => 'Successfully Added']);





}



public function rename_folder(Request $request){



$update = DB::table('tm_folder')->where('id',$request->folder_id)->update(['folder_name'=>$request->content]);

	return response()->json(['status' => 200, 'msg' => 'Successfully Rename']);

}



public  function view_file($folder_id){



	return view('mainSetting.view_files',['folder_id' => $folder_id]);

}



function all_files(Request $request){



$get_all_files = DB::table('tm_folder_uploads')->where('folder_id',$request->folder_id)->get();



$html = '';

$i = 1;

foreach ($get_all_files as $key => $value) {

$url = URL::to('/').$value->file_name;



$file_name = str_replace('/uploads/attach/files/', '', $value->file_name);



$html .=' <tr>

                                                    <td width="6%">'.$i++.'</td>

                                                    <td>'.$file_name.'</td>

                                                    <td width="6%">

                                                    <a href='.$url.' download>

                                                        <i class="mdi mdi-download text-blue"

                                                                data-toggle="tooltip"

                                                                title="Download"></i></a>

                                                       <a href="javascript:void(0)" onclick="delete_file(this,'.$value->id.')">         

                                                        <i class="mdi mdi-delete text-danger" data-toggle="tooltip" title="Delete"></i></a>

                                                    </td>

                                                </tr>';



}



return response()->json(['status' => 200, 'all_files' => $html]);

}





function forms(){



    return view('mainSetting.form');



}



public function all_forms(Request $request){



  $get_all_files = DB::table('tm_forms')->get();



$html = '';

$i = 1;

foreach ($get_all_files as $key => $value) {

$url = URL::to('public').'/'.$value->form_files;



$file_name = $value->form_name;



$html .=' <tr>

                                                    <td width="6%">'.$i++.'</td>

                                                    <td>'.$file_name.'</td>

                                                    <td width="6%">

                                                    <a href='.$url.' download>

                                                        <i class="mdi mdi-download text-blue"

                                                                data-toggle="tooltip"

                                                                title="Download"></i></a>

                                                       <a href="javascript:void(0)" onclick="delete_file(this,'.$value->id.')">         

                                                        <i class="mdi mdi-delete text-danger" data-toggle="tooltip" title="Delete"></i></a>

                                                    </td>

                                                </tr>';



}



return response()->json(['status' => 200, 'all_files' => $html]);



}



public function delete_files(Request $request){



	$del = DB::table('tm_folder_uploads')->where('id',$request->file_id);



   File::delete(public_path().$del->first()->file_name);



  $del->delete();





	return response()->json(['status' => 200, 'msg' => 'Successfully Deleted']);

}



function upload_file_folder_withoud_project(Request $request){







$user_id =  Auth::guard('main_users')->user()->id;



 $get_folder = DB::table('tm_folder')->where('id',$request->folder_id)->first();

 if(isset($get_folder->project_id) && !empty($get_folder->project_id)){

$project_id = $get_folder->project_id;

 }else{



$project_id = null;

 }



         if($request->hasFile('images')) {



          

           foreach($request->file('images') as $file){



           $original_name = $file->getClientOriginalExtension();



             $name = time().'.'.$original_name;



           $file->move(public_path().'/uploads/attach/files/', $name);



           $filename = '/uploads/attach/files/'. $name;



           $arr = array(





'project_id' => $project_id,

'folder_id' => $request->folder_id,

'file_name' => $filename,

'created_by' => $user_id,

'created_at' => date('Y-m-d h:i:d'),

           );



    $insert = DB::table('tm_folder_uploads')->insert($arr);



       }



        }



          return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);





}



function upload_file_form(Request $request){





$user_id =  Auth::guard('main_users')->user()->id;





         if($request->hasFile('images')) {



          

           foreach($request->file('images') as $file){



            $original_name = $file->getClientOriginalExtension();



            $name = time().'.'.$original_name;



           $file->move(public_path().'/uploads/attach/files/', $name);



           $filename = '/uploads/attach/files/'. $name;



           $arr = array(



'form_name' => $request->file_name,

'form_files' => $filename,

'created_by' => $user_id,

'created_at' => date('Y-m-d h:i:d'),

           );



    $insert = DB::table('tm_forms')->insert($arr);



       }



        }



          return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);





}





public function show_folder(Request $request){



     $project_id = [];

    $user_id =  Auth::guard('main_users')->user()->id;

    $role =  Auth::guard('main_users')->user()->emprole;

    $get_Project = DB::table('tm_project_employees')->where('emp_id',$user_id)->get();

   foreach ($get_Project as $key => $get_Projects) {

    $project_id[] = $get_Projects->project_id;

   }





    $folder = DB::table('tm_folder');

    



     if($request->type !='all'){



  $folder->join('tm_projects','tm_folder.project_id','=','tm_projects.id')->where('tm_projects.project_status','=',$request->type);

}



 if($role !=1){

      $folder->whereIn('tm_folder.project_id',$project_id);

     }



   $folder =  $folder->select('tm_folder.*')->get();



//   $folder = DB::table('tm_folder');



// if($request->type !='all'){



//   $folder->join('tm_projects','tm_folder.project_id','=','tm_projects.id')->where('tm_projects.project_status','=',$request->type);

// }



//   $folder = $folder->select('tm_folder.*')->get();



  $html = '';

  foreach ($folder as $key => $folder_lists) {

   $html .='  <div class="col text-center">



                          <span ondblclick="doubleclick(this,'.$folder_lists->id.')" ><i class="fa fa-folder-open font-100 text-warning"></i></span>



                            <span class="display-block"  onclick="listenForDoubleClick(this);" onblur="save_content(this,'.$folder_lists->id.')">'.$folder_lists->folder_name.'</span>



                                        </div>';

  }



   return response()->json(['status' => 200, 'show_folder' => $html]);









}





function delete_form(Request $request){



  

  $del = DB::table('tm_forms')->where('id',$request->file_id);



   File::delete(public_path().$del->first()->form_files);



  $del->delete();





  return response()->json(['status' => 200, 'msg' => 'Successfully Deleted']);



}



function letter_managment(){



  $latter_list = DB::table('latter_management')->get();



    return view('mainSetting.letter_managment',['latter_list' =>$latter_list]);

}



function add_letter(){



    return view('mainSetting.add_letter');

}

function edit_latter($id){



  $edit_latter = DB::table('latter_management')->where('id',$id)->first();



    return view('mainSetting.edit_latter',['edit_latter' => $edit_latter,'latter_id' => $id]);

}







function save_letter(Request $request){



   $user_id =  Auth::guard('main_users')->user()->id;



 $arr = array(

  'latter_name' => $request->letter_name,

  'latter_type' => $request->letter_type,

  'letter' => $request->letter,

  'is_active' => 1,

  'created_by' => $user_id,

  'updated_by' => $user_id,

  'created_at' => date('Y-m-d h:i:s'),

  'updated_at' => date('Y-m-d h:i:s'),



 );



 if(isset($request->latter_id)){



   DB::table('latter_management')->where('id',$request->latter_id)->update($arr);

  return response()->json(['status' => 200, 'msg' => 'successfully Updated']);





 }else{



   DB::table('latter_management')->insert($arr);

  return response()->json(['status' => 200, 'msg' => 'successfully Added']);





 }





}



function quility_master(){



  return view('mainSetting.qulity_master');

}





function checklist_master(){



          $check_list = DB::table('checklist_master')->join('main_departments','main_departments.id','=','checklist_master.deportment_id')->join('main_users','main_users.id','=','checklist_master.hod_user_id')->select('checklist_master.*','main_departments.deptname','main_users.userfullname')->get();

  

    return view('mainSetting.checklist_master',['check_list' => $check_list]);

}



function delete_checklist($id){

 DB::table('checklist_master')->where('id',$id)->delete();

  return redirect()->back();

}





function get_checklist(Request $request){





    $checklist  = DB::table('checklist_master')->where('id',$request->checklist_id)->first();

    return response()->json(['status' => 200, 'msg' => 'successfully Updated','checklist' =>  $checklist]);



}

function bill_master(){



  $bill = DB::table('tm_bill_master')->get();



  return view('mainSetting.bill_master',['bill' => $bill]);

}



function add_bill_master(Request $request){

   $user_id =  Auth::guard('main_users')->user()->id;



  $arr = array(

       'bill_name' => $request->billname,

        'desc' => $request->desc,

         'created_by' => $user_id ,

          'created_at' => date('Y-m-d h:i:s'),

      

    );



  if(isset($request->bill_id)){

   

     DB::table('tm_bill_master')->where('id',$request->bill_id)->update($arr);

    return response()->json(['status' => 200, 'msg' => 'successfully Updated']);



  }else{



    DB::table('tm_bill_master')->insert($arr);

    return response()->json(['status' => 200, 'msg' => 'successfully Added']);



  }



  



}



function delete_bill_master($id){

  DB::table('tm_bill_master')->where('id',$id)->delete();

  return redirect()->back();

}



function get_hod_list(Request $request){

  $hod_list = DB::table('main_users')->where('emprole',30)->where('department_id',$request->dept_id)->get();



  $html = '';

  $html .= '<option value=""> Select Option</option>';

  if(!empty($hod_list)){

  foreach ($hod_list as $key => $hod_lists) {

   $html .= '<option value="'.$hod_lists->id.'">'.$hod_lists->userfullname.'</option>';

 }

  }else{

    $html .= '<option value=""> No Result </option>';

  }





  return response()->json(['status' => 200, 'msg' => 'successfully Added','hod_list' => $html]);

}



function add_checklist_master(Request $request){

    $user_id =  Auth::guard('main_users')->user()->id;



 $arr = array(

  'check_list_name' => $request->checklist,

  'deportment_id' => $request->deportment,

  'hod_user_id' => $request->hod,

  'desc' => $request->desc,

  'created_by' => $user_id,

  'created_at' => date('Y-m-d h:i:s')



 );





if(isset($request->checklist_id)){





  DB::table('checklist_master')->where('id',$request->checklist_id)->update($arr);

  return response()->json(['status' => 200, 'msg' => 'successfully updated']);



}else{



  DB::table('checklist_master')->insert($arr);



  return response()->json(['status' => 200, 'msg' => 'successfully Added']);

}



}



function announcement(){





  $announcement_master = DB::table('announcement_master')->where('status',1)->get();



  return view('mainSetting.announcement',['list' => $announcement_master]);



}



function delete_annoucement_master($id){

  DB::table('announcement_master')->where('id',$id)->delete();

  return redirect()->back();

}



function add_ann_master(Request $request){



  $user_id =  Auth::guard('main_users')->user()->id;



  $array = array(

  'title' => $request->billname,

  'desc' => $request->desc,

  'created_by' => $user_id,

  'created_at' => date('Y-m-d h:i:s'),

  );



  if(isset($request->bill_id)){



    DB::table('announcement_master')->where('id',$request->bill_id)->update($array);

    return response()->json(['status' => 203, 'msg' => 'successfully update']);



  }else{



    

    DB::table('announcement_master')->insert($array);

    return response()->json(['status' => 200, 'msg' => 'successfully Added']);



  }





}



function one_to_one_form($id){

  $get_form = DB::table('one_form')->where('id',$id)->first();
  $get_desc= DB::table('one_to_one_form')->where('form_id',$id)->orderBy('id','desc')->first();


  return view('mainSetting.one_form',['form_id' => $id ,'form' => $get_form,'get_desc' => $get_desc]);

}





function insert_question(Request $request){




  $user_id =  Auth::guard('main_users')->user()->id;


  if(isset($request->question_id)){



    $q = array(

     
      'form_id' => $request->form_id,
      'question' => $this->RemoveSpecialChar($request->question),

      'category' => $request->category,

      'ans' => $this->RemoveSpecialChar(json_encode($request->answer)),

      'required' => $request->required_field,

      'created_by' => $user_id,

      'updated_by' => $user_id,

      'created_at' => date('Y-m-d h:i:s'),

      'updated_at' => date('Y-m-d h:i:s'),

      

        );



        DB::table('one_to_one_form')->where('id',$request->question_id)->update($q);

 return response()->json(['status' => 200, 'msg' => 'updated successfully']);





  }else{





    $q = array(

      'form_id' => $request->form_id,
      'title' => $request->title,

      'desc' => $request->desc,

      'question' => $request->question,

      'category' => $request->category,

      'ans' => json_encode($request->answer),

      'required' => $request->required_field,

      'created_by' => $user_id,

      'updated_by' => $user_id,

      'created_at' => date('Y-m-d h:i:s'),

      'updated_at' => date('Y-m-d h:i:s'),

      

        );



        DB::table('one_to_one_form')->insert($q);

 return response()->json(['status' => 200, 'msg' => 'successfully Added']);





  }







}



function answer_question(Request $request){



$user_id =  Auth::guard('main_users')->user()->id;





  foreach ($request->question as $key => $question) {



        $q = array(

'assign_id' => $request->assign_id,
'form_id'  => $request->form_id,
'title' => $request->title,

'desc' => $request->desc,

'question' => $question,



'ans' => json_encode($request->answer[$key]),



'created_by' => $user_id,

'updated_by' => $user_id,

'created_at' => date('Y-m-d h:i:s'),

'updated_at' => date('Y-m-d h:i:s'),



  );



        DB::table('one_to_one_form_user_answer')->insert($q);



   

  }





 return response()->json(['status' => 200, 'msg' => 'successfully Added']);





}









function delete_question_form($title){



    $form = DB::table('one_form')->where('id',$title)->delete();

    return redirect()->back()->with('msg','successfully Deleted');



}





function view_question_form($id,$assign_id){

    

   $form = DB::table('fill_user_form')->where('form_id',$id)->where('assign_id',$assign_id)->first();



   $title = DB::table('one_form')->where('id',$id)->first();

   

  return view('mainSetting.fill_user_one_form',['form' => $form,'form_id' => $id,'assign_id'=> $assign_id]);



}



function question_form(Request $request){



  if($request->menustaus == 1){



    $status = 0;



  }else{





    $status = 1;

  }

  DB::table('one_form')->update(['status' => 0 ]);

  DB::table('one_form')->where('id',$request->menuid)->update(['status' => $status ]);

  return response()->json(['status' => 200, 'msg' => 'successfully Added']);

  



}



function edit_form($id){



 $edit =  DB::table('one_to_one_form')->where('id',$id)->first();



  return view('mainSetting.edit_question',['edit' => $edit]);

}



function user_form(){



  $user_id =  Auth::guard('main_users')->user()->id;

 $current_date = date('Y-m-d');

  $from = DB::table('one_form_assign_user')->join('one_form','one_form_assign_user.form_id','=','one_form.id')
->where('one_form_assign_user.user_id',$user_id )
->where('one_form.status',1)
->whereDate('one_form_assign_user.state_date','<=', $current_date)
->whereDate('one_form_assign_user.end_date','>=', $current_date)
  ->select('one_form.*','one_form_assign_user.id as assign_id')->get();

   foreach($from as $froms){

    $froms->view = DB::table('fill_user_form')->where('assign_id',$froms->assign_id)->where('form_id',$froms->id)->count();

   }

 

  return view('mainSetting.user_from',['form' => $from]);



}



function view_user_form(){


  $user_id =  Auth::guard('main_users')->user()->id;
  $role =  Auth::guard('main_users')->user()->emprole;

  $notassignrole=[];
$user = DB::table('main_users')->where('reporting_manager',$user_id )->where('isactive',1)->select('id')->get();
foreach($user as $users){
  $notassignrole[] = $users->id;
  }



  $view = DB::table('one_form')->first();


  $user_view_form = [];
  $from = DB::table('one_form_assign_user')->join('one_form','one_form_assign_user.form_id','=','one_form.id')->join('main_users','one_form_assign_user.user_id','=','main_users.id');

  if($role != 1 && $role != 4 ){
  $from->whereIn('one_form_assign_user.user_id',$notassignrole);
}
  $from = $from->select('one_form.*','main_users.userfullname','main_users.id as user_id','one_form_assign_user.id as assign_id')->get();
  foreach ($from as $key => $froms) {
   $cunt = DB::table('fill_user_form')->where('form_id',$froms->id)->where('assign_id',$froms->assign_id)->count();
   if($cunt > 0){
     $user_view_form[] = $froms;

   }
  }



  return view('mainSetting.view_user_form',['view' => $view,'form' => $user_view_form]);





}



function answer($id,$user_id,$assign_id){



  $view = DB::table('one_form')->where('id',$id)->first();

  $from = DB::table('one_to_one_form_user_answer')->where('form_id',$id)->where('assign_id',$assign_id)->where('created_by',$user_id)->get();

  return view('mainSetting.answer',['view' => $view,'form' => $from]);



  return view('mainSetting.answer');



}


function fill_user_one_form(Request $request){

   $user_id =  Auth::guard('main_users')->user()->id;


  $manager = DB::table('main_users')->where('id',Auth::guard('main_users')->user()->reporting_manager)->where('isactive',1)->select('emailaddress')->first();

  $hr = DB::table('main_users')->where('emprole',4)->where('isactive',1)->orderBy('id','desc')->select('emailaddress')->first();


$sendemail = array(Auth::guard('main_users')->user()->emailaddress,$manager->emailaddress,$hr->emailaddress??'');

  

 if(DB::table('fill_user_form')->where('form_id',$request->form_id)->where('assign_id',$request->assign_id)->count() == 0){

    $arr = array(
    'emp_name' => $request->emp_name,
     'mng_name' => $request->mng_name,
      'ans1' => $request->ans1,
       'ans2' => json_encode($request->ans2),
        'ans3' => $request->ans3,
         'ans4' => $request->ans4,
          'ans5' => $request->ans5,
           'ans6' => $request->ans6,
           'ans7' => $request->ans7,
            'Inovation' => $request->inovation,
             'emp_feetback' => $request->emp_feetback,
              'emg_sign' => $request->emp_sign,
              'assign_id' => $request->assign_id,
              'form_id' => $request->form_id,
              'created_by' => $user_id,
              'created_at' => date('Y-m-d h:i:s'),


  );



   DB::table('fill_user_form')->insert($arr);

                 $subject = 'One To One Confimation';
               $from = 'suitecrm14@gmail.com';
               $fromname = 'Not_reply';

               $content =   intimation(Auth::guard('main_users')->user()->userfullname,'Submitted',date('Y-m-d'),'One To One Form');
    
               $userEmail  = MultiSendEmail($sendemail,$subject,$from,$fromname,$content);
             

    return response()->json(['status' => 200, 'msg' => 'successfully Added']);

 }else{

      $arr_mng = array(
    'mng_feetback' => $request->mng_feetback,
     'mng_sign' => $request->mng_sign,
      'updated_by' => $user_id,
     
        'updated_at' => date('Y-m-d h:i:s'),
        

  );



   DB::table('fill_user_form')->where('form_id',$request->form_id)->where('assign_id',$request->assign_id)->update($arr_mng);

    return response()->json(['status' => 200, 'msg' => 'successfully Added']);


 }



  

         

}

function save_form(Request $request){

  $user_id =  Auth::guard('main_users')->user()->id;

    if(!isset($request->form_id)){
  

       if(DB::table('one_form')->where('year',$request->year)->where('month',$request->month)->count() > 0){

         return response()->json(['status' => 205,'msg'=> 'Already Taken Month and Year']);

       }


  
       }     
        $q = array(

'form_name' => $request->form_name,

'year' => $request->year,

'month' => $request->month,

'created_by' => $user_id,


'created_at' => date('Y-m-d h:i:s'),



  );


if(isset($request->form_id)){

    DB::table('one_form')->where('id',$request->form_id)->update($q);

          return response()->json(['status' => 200, 'msg' => 'successfully Updated']);

}else{

    DB::table('one_form')->update(['status' => 0]);

    DB::table('one_form')->insert($q);

  

          return response()->json(['status' => 200, 'msg' => 'successfully Added']);

}


}

function form_master(){



  $form = DB::table('one_form')->get();

 
  return view('mainSetting.form_master',['form' => $form]);

}

function fetch_all_question(Request $request){

     $form = DB::table('one_to_one_form')->where('form_id',$request->form_id)->get();




  return view('mainSetting.ajex_question',['form' => $form]);



}

function edit_question(Request $request){

   $edit =  DB::table('one_to_one_form')->where('id',$request->question_id)->first();



  return view('mainSetting.ajex_edit_question',['edit' => $edit]);

}

function send_one_form(Request $request){

  $enddate = date('Y-m-d', strtotime('+7 days'));
  $user_id =  Auth::guard('main_users')->user()->id;

  foreach ($request->user_id as $key => $userid) {
 
  // if(DB::table('one_form_assign_user')->where('user_id',$userid)->where('form_id',$request->form_id)->count() >0){

  //      return response()->json(['status' => 205, 'msg' => 'Already Send']);

  // }

  $array = array(
   'user_id' => $userid,
   'form_id' => $request->form_id,
   'state_date' => date('Y-m-d'),
   'end_date' => $enddate,
   'created_by' => $user_id,
   'created_at' => date('Y-m-d h:i:s'),

  );


DB::table('one_form_assign_user')->insert($array);

}

   return response()->json(['status' => 200, 'msg' => 'successfully Send']);

  }





function kra_master(){

  $kra_form = DB::table('kra_master')->join('main_positions','kra_master.designation','=','main_positions.id')->select('kra_master.*','main_positions.positionname')->get();

  return view('mainSetting.kra_master',['list' => $kra_form]);
}

function save_kra(Request $request){

  $user_id =  Auth::guard('main_users')->user()->id;

 
  
     $arr['name' ] = $request->name;
     $arr['designation'] = $request->designation;
     $arr['created_by'] = $user_id;
     $arr['updated_by' ] = $user_id;
     $arr['created_at'] = date('Y-m-d H:i:s');
     $arr['updated_at'] = date('Y-m-d H:i:s');

    // DB::table('kra_master')->where('designation',$request->designation)->update(['status' =>'Inactive']);


 if(isset($request->kra_id)){

  $arr['status'] = $request->status;

  DB::table('kra_master')->where('id',$request->kra_id)->update($arr);
  return response()->json(['status' => 200, 'msg' => 'successfully updated']);


 }else{

 
  DB::table('kra_master')->insert($arr);
  return response()->json(['status' => 200, 'msg' => 'successfully Added']);


 }

 
}

function delete_kra($id){

  DB::table('kra_master')->where('id',$id)->delete();
  return redirect()->back();

}

function view_kra($id){


  $kra_form = DB::table('kra_master')->join('main_positions','kra_master.designation','=','main_positions.id')->where('kra_master.id',$id)->select('kra_master.*','main_positions.positionname')->first();
  $view_task = DB::table('kra_task')->where('kra_id',$id)->get();
  foreach($view_task as  $view_tasks){
    
    $view_tasks->sub_task = DB::table('kra_sub_task')->where('task_id',$view_tasks->id)->get();
    $view_tasks->con_sum = DB::table('kra_sub_task')->where('task_id',$view_tasks->id)->sum('contribution');

  }

  

  return view('mainSetting.view_kra',['list' => $kra_form,'view_task' => $view_task]);
}


function kra_task_add(Request $request){



  $user_id =  Auth::guard('main_users')->user()->id;

$task = json_decode($request->sub_task) ;

$contribution = json_decode($request->contribution) ;
$sub_target = json_decode($request->sub_target) ;
$sub_measurement = json_decode($request->sub_measurement) ;

  $arra = array(
'kra_id' => $request->kra_id,
'task' => $this->RemoveSpecialChar($request->task_name),
'measurment' => $this->RemoveSpecialChar($request->measurment),
'target' => $request->target,
'created_by' => $user_id,
'updated_by' => $user_id,
'created_at' =>  date('Y-m-d h:i:s'),
'updated_at' => date('Y-m-d h:i:s'),

    
  );

  $last_id = DB::table('kra_task')->insertGetId($arra);

  foreach($task as $k => $subtask){

    $subtask = array(
      'task_id' => $last_id,
      'sub_task' => $this->RemoveSpecialChar($subtask),
      'contribution' => $contribution[$k],
      'measurement' => $sub_measurement[$k],
      'target' => $sub_target[$k],
      'created_by' => $user_id,
  'updated_by' => $user_id,
  'created_at' =>  date('Y-m-d h:i:s'),
  'updated_at' => date('Y-m-d h:i:s'),
    );
  
    DB::table('kra_sub_task')->insert($subtask);

  }


  return response()->json(['status' => 200, 'msg' => 'successfully Added']);


}

function RemoveSpecialChar($str) { 
      
    // Using str_replace() function  
    // to replace the word  
    $res = str_replace( array( '\'', '"', 
    ',' , ';', '<', '>',',','&','*' ), ' ', $str); 
      
    // Returning the result  
    return $res; 
    } 

function kra_form(){

  $user_id =  Auth::guard('main_users')->user()->id;
  $position_id =  Auth::guard('main_users')->user()->position_id;
  $current_date = date('Y-m-d');
  //$kra_form = DB::table('kra_master')->join('main_positions','kra_master.designation','=','main_positions.id')->where('kra_master.designation',$position_id)->select('kra_master.*','main_positions.positionname')->get();
  
  $kra_form = DB::table('kra_assign_form_user')->join('kra_master','kra_assign_form_user.form_id','kra_master.id')->join('main_positions','kra_master.designation','=','main_positions.id')->where('kra_assign_form_user.user_id',$user_id)
->whereDate('kra_assign_form_user.state_date','<=',$current_date)
->whereDate('kra_assign_form_user.end_date','>=',$current_date)
  ->select('kra_master.*','main_positions.positionname','kra_assign_form_user.id as kra_assign_id')->get();
  foreach ($kra_form as $key => $kra_forms) {

     $kra_forms->user_fill = DB::table('kra_task_user')->where('assign_id',$kra_forms->kra_assign_id)->where('actual_remark','!=','')->count();
      $kra_forms->manager_fill = DB::table('kra_task_user')->where('assign_id',$kra_forms->kra_assign_id)->where('manager_remark','!=','')->count();
    

   
  }
 
  return view('mainSetting.user_kra_form',['form' => $kra_form]);
}


function view_emp_kra($id,$assign_id,$userid=null){

  $user_id =  Auth::guard('main_users')->user()->id;

  $exsitkra = DB::table("kra_task_user")
  ->select('*')
  ->where('kra_id',$id)
  ->whereRaw("find_in_set('".$user_id."',user_id)")
  ->count();
  
  $user_fill = DB::table('kra_task_user')->where('assign_id',$assign_id)->where('actual_remark','!=','')->count();
  $manager_fill = DB::table('kra_task_user')->where('assign_id',$assign_id)->where('manager_remark','!=','')->count();
   

if($exsitkra == 0){

  //$kra = DB::table('kra_master')->join('main_positions','kra_master.designation','=','main_positions.id')->where('kra_master.id',$id)->select('kra_master.*','main_positions.positionname')->first();
  $kra = DB::table('kra_assign_form_user')->join('kra_master','kra_assign_form_user.form_id','kra_master.id')->join('main_positions','kra_master.designation','=','main_positions.id')->where('kra_assign_form_user.user_id',$user_id)->select('kra_master.*','main_positions.positionname')->first();
  

  $view_task = DB::table('kra_task')->where('kra_id',$id)->get();
  
  foreach($view_task as  $view_tasks){
    
    $view_tasks->sub_task = DB::table('kra_sub_task')->where('task_id',$view_tasks->id)->get();
    $view_tasks->con_sum = DB::table('kra_sub_task')->where('task_id',$view_tasks->id)->sum('contribution');
    $view_tasks->actual_sum = DB::table('kra_sub_task')->where('task_id',$view_tasks->id)->sum('actual');
    $view_tasks->manager_sum = DB::table('kra_sub_task')->where('task_id',$view_tasks->id)->sum('manager');

  }


}else{

  $kra = DB::table('kra_assign_form_user')->join('kra_master','kra_assign_form_user.form_id','kra_master.id')->join('main_positions','kra_master.designation','=','main_positions.id')->where('kra_assign_form_user.user_id',$userid??$user_id)->select('kra_master.*','main_positions.positionname')->first();
  

  $view_task = DB::table('kra_task_user')->whereRaw("find_in_set('".$user_id."',user_id)");
  if(isset($userid)){
    $view_task->where('created_by',$userid);
  }

  $view_task = $view_task->where('kra_id',$id)->get();
 
  
  foreach($view_task as  $view_tasks){
    
    $view_tasks->sub_task = DB::table('kra_sub_task_user') ->whereRaw("find_in_set('".$user_id."',user_id)")->where('task_id',$view_tasks->id)->get();
    $view_tasks->con_sum = DB::table('kra_sub_task_user') ->whereRaw("find_in_set('".$user_id."',user_id)")->where('task_id',$view_tasks->id)->sum('contribution');
    $view_tasks->actual_sum = DB::table('kra_sub_task_user') ->whereRaw("find_in_set('".$user_id."',user_id)")->where('task_id',$view_tasks->id)->sum('actual');
    $view_tasks->manager_sum = DB::table('kra_sub_task_user') ->whereRaw("find_in_set('".$user_id."',user_id)")->where('task_id',$view_tasks->id)->sum('manager');

  }


}

 // dd($view_task);

  return view('mainSetting.view_kra_form',['kra' => $kra,'view_task' => $view_task,'kra_id' => $id,'existtkra' =>$exsitkra,'assign_id' => $assign_id,'user_fill' => $user_fill,'manager_fill' => $manager_fill]);
}



function export_kra_user($kra_id,$assign_id){


  
  $view_task = DB::table('kra_task_user');
  $view_task->where('assign_id',$assign_id);
  $view_task = $view_task->where('kra_id',$kra_id)->get();
 
  
  foreach($view_task as  $view_tasks){
    
    $view_tasks->sub_task = DB::table('kra_sub_task_user')->where('task_id',$view_tasks->id)->get();
    $view_tasks->con_sum = DB::table('kra_sub_task_user')->where('task_id',$view_tasks->id)->sum('contribution');
    $view_tasks->actual_sum = DB::table('kra_sub_task_user')->where('task_id',$view_tasks->id)->sum('actual');
    $view_tasks->manager_sum = DB::table('kra_sub_task_user')->where('task_id',$view_tasks->id)->sum('manager');

  }



  
  $columns = array('Tasks', 'Contriduction', 'Measurment', 'Target', 'Actual','Manager Feedback','Remark','Manager Remark');

    
  $filename = public_path("uploads/csv/KRA_Form_'".time()."'_report.csv");
  $handle = fopen($filename, 'w+');
  fputcsv($handle, $columns);

       $i = 1;
      foreach($view_task as $view_tasks) {

        fputcsv($handle, array($view_tasks->task.' ( Task )',$view_tasks->con_sum,$view_tasks->measurment,$view_tasks->target,$view_tasks->actual_sum,$view_tasks->manager_sum,$view_tasks->actual_remark,$view_tasks->manager_remark));

        foreach($view_tasks->sub_task as $subtask) {

         fputcsv($handle, array($subtask->sub_task.' ( Sub Task )',$subtask->contribution,'','',$subtask->actual,$subtask->manager,'',''));
    
        }
    }
      
     fclose($handle);

     $headers = array(
      'Content-Type' => 'text/csv'
     
      );


  return Response()->download($filename);

}



function insert_kra(Request $request){


      $user_id =  Auth::guard('main_users')->user()->id;
  $manager = DB::table('main_users')->where('id',Auth::guard('main_users')->user()->reporting_manager)->where('isactive',1)->select('emailaddress')->first();

  $hr = DB::table('main_users')->where('emprole',4)->where('isactive',1)->orderBy('id','desc')->select('emailaddress')->first();

$sendemail = array(Auth::guard('main_users')->user()->emailaddress,$manager->emailaddress,$hr->emailaddress??'');
  
  $role =  Auth::guard('main_users')->user()->emprole;

  $user_id =  Auth::guard('main_users')->user()->id;
  $manager =  Auth::guard('main_users')->user()->reporting_manager;
  $hr = DB::table('main_users')->where('isactive',1)->orderBy('id','DESC')->where('emprole',4)->select('id')->first();
  $showuser = implode(',',array($user_id,$manager,$hr->id??0));
  
  if($request->existtkra == 0){

 
  
  foreach($request->task as $k => $task){

  $arra = array(
    'user_id' => $showuser,
    'assign_id' => $request->assign_id,
    'kra_id' => $request->kra_id,
    'task' => $task,
    'measurment' => $request->measurment[$k],
    'target' => $request->target[$k],
    'actual_remark' => $request->user_remark[$k],
    'manager_remark' => $request->manager_remark[$k]??'',
    'created_by' => $user_id,
    'updated_by' => $user_id,
    'created_at' =>  date('Y-m-d h:i:s'),
    'updated_at' => date('Y-m-d h:i:s'),
    
        
      );
    
      $last_id = DB::table('kra_task_user')->insertGetId($arra);

      foreach($request->sub_task[$k] as $key => $subtask){

        $subtask = array(
          'user_id' => $showuser,
          'task_id' => $last_id,
          'sub_task' => $subtask,
          'contribution' => $request->contribution[$k][$key],
          'actual' => $request->user_actual[$k][$key],
          'manager' => $request->manager_actual[$k][$key]??0,
           'measurement' => $request->sub_measurement[$k][$key]??'',
            'target' => $request->sub_target[$k][$key]??0,
          'created_by' => $user_id,
      'updated_by' => $user_id,
      'created_at' =>  date('Y-m-d h:i:s'),
      'updated_at' => date('Y-m-d h:i:s'),
        );
      
        DB::table('kra_sub_task_user')->insert($subtask);
    
      }


 }



             $subject = 'KRA Confimation';
               $from = 'suitecrm14@gmail.com';
               $fromname = 'Not_reply';

               $content =   intimation(Auth::guard('main_users')->user()->userfullname,'Submitted',date('Y-m-d'),'KRA Form');
    
               $userEmail  = MultiSendEmail($sendemail,$subject,$from,$fromname,$content);
             


 DB::table('kra_status')->insert(['kra_id' =>$request->kra_id,'user_id' => $user_id,'show_user_id' => $showuser ]);

 return response()->json(['status' => 200, 'msg' => 'successfully Added']);

}else{


    
  foreach($request->task_id as $k => $task_id){

    $arra = array(
       'manager_remark' => $request->manager_remark[$k]??'',
      'updated_by' => $user_id,
     
    
      'updated_at' => date('Y-m-d h:i:s'),
      
          
        );
      
        $last_id = DB::table('kra_task_user')->where('id',$task_id)->update($arra);
  
        foreach($request->sub_task_id[$k] as $key => $subtask_id){
  
          $subtask = array(
        
            
           
       'manager' => $request->manager_actual[$k][$key]??0,
           
        'updated_by' => $user_id,
       
        'updated_at' => date('Y-m-d h:i:s'),
          );
        
          DB::table('kra_sub_task_user')->where('id',$subtask_id)->update($subtask);
      
        }
  
  
   }
  
   return response()->json(['status' => 200, 'msg' => 'successfully updated']);


}


  

}

function view_user_kra_form(){

  $user_id =  Auth::guard('main_users')->user()->id;

    $user_kra = DB::table('kra_assign_form_user')->join('main_users','kra_assign_form_user.user_id','=','main_users.id')->join('kra_master','kra_assign_form_user.form_id','=','kra_master.id')->join('main_positions','kra_master.designation','=','main_positions.id')->whereRaw("find_in_set('".$user_id."',kra_assign_form_user.show_user_id)")->select('kra_master.*','main_positions.positionname','main_users.userfullname','main_users.id as user_id','kra_assign_form_user.id as assign_id')->get();
    foreach($user_kra as $user_kras){
      $user_kras->user_fill = DB::table('kra_task_user')->where('assign_id',$user_kras->assign_id)->where('actual_remark','!=','')->count();
      $user_kras->manager_fill = DB::table('kra_task_user')->where('assign_id',$user_kras->assign_id)->where('manager_remark','!=','')->count();
       
    }

   
return view('mainSetting.view_user_kra_form',['form' => $user_kra]);

}


function send_kra(Request $request){

   $user_id =  Auth::guard('main_users')->user()->id;
  $end_date = date('Y-m-d', strtotime('+7 days'));
  $user_list = DB::table('main_users')->where('isactive',1)->whereIn('position_id',$request->designation_id)->select('id','reporting_manager')->get();
  $hr =   DB::table('main_users')->where('isactive',1)->where('emprole',4)->orderBy('id','DESC')->select('id')->first();
  foreach ($user_list as $key => $user_lists) {
    $show_user_id = array($user_lists->id,$user_lists->reporting_manager,$hr->id??0);
   $array = array(
    'user_id' => $user_lists->id,
    'show_user_id' => implode(',', $show_user_id),
    'form_id' => $request->kra_id,
    'state_date' => date('Y-m-d'),
    'end_date'  => $end_date,
    'created_by' => $user_id,
    'created_at' => date('Y-m-d h:i:s'),

   );

   DB::table('kra_assign_form_user')->insert($array);

  }
  return response()->json(['status' => 200, 'msg' => 'successfully Send']);

}


}