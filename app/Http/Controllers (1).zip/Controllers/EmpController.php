<?php

namespace App\Http\Controllers;
namespace Illuminate\Support\Facades;
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;


//use Illuminate\Support\Facades\Auth;
use DB;
use Session;
use Mail;
use URL;
use Hash;
use Auth;
use Validator;
use App\Main_users;
use App\Mail\sendEmail;
use Carbon\Carbon;

use DateTime;
use DatePeriod;
use DateInterval;

use App\Http\Controllers\MainusersController;


class EmpController extends Controller
{



   public function addEmp(Request $request){

    $userId = Auth::guard('main_users')->user()->id??0;
    
    if(!isset($request->userid)){
    $validator = Validator::make($request->all(), [
     
       'email' => 'unique:main_users,emailaddress|required',
     
  ]);

      if($validator->fails()){
              return response()->json(['status' => 205,'msg' => $validator->errors()->first()]);
      }
    }
     
     
     
    $password = mt_rand(1000,99999);

   $arr = array(
    'emprole' =>$request->role,
    'emp_category' =>$request->emp_category,
    'card_number' =>$request->crdno,
    'bussinessunit' =>$request->bsnit??0,
    'userstatus' =>'new',
    'prefix' =>$request->prefix,
    'firstname' =>$request->fname,
    'lastname' =>$request->lname,
    'join_date' =>$request->doj,
    'leave_date' =>$request->dol,
    'experience' =>$request->yoe,
    'workphone' =>$request->workphn,
    'extension' =>$request->extno,
    'modeofentry' =>$request->modeemp,
    'userfullname' =>$request->fname.' '.$request->lname,
    'emailaddress' =>$request->email,
    'medicalpolicy' =>$request->mpcst,
    'position_id' =>$request->positions??0,
    'createddate' =>date('Y-m-d H:i:s'),
    'isactive' =>1,
    'employeeId' => $request->empcode??0,
    'userid' =>$request->empid??0,
    'employee_status' =>$request->empstatus??0,
    'reporting_manager' =>$request->reptmng??0,
    'company_id' =>0,
    'department_id' =>$request->dprt??0,
    'jobtitle_id' =>$request->jobtitle??0,
    'tourflag' =>0,
    'themes' =>'default',


   );


 

   if(isset($request->userid)){

    $updateuser = DB::table('main_users')->where('id',$request->userid)->update($arr);

      return response()->json(['status' => 203, 'msg' => 'Update successfully']);


   }else{


    $array = array(
    'password' => Hash::make($password)
    );

    $merge = array_merge($arr,$array);
   
   $userlastid = DB::table('main_users')->insertGetId($merge);


   if($userlastid){

    $project_list_free_pool = DB::table('tm_projects')->where('is_active',1)->where('base_project',30)->where('project_status','in-progress')->get();
  if(!empty($project_list_free_pool)){
   foreach($project_list_free_pool as $project_list_free_pools){
   $get_task = DB::table('tm_project_tasks')->where('project_id',$project_list_free_pools->id)->where('task_status','in-progress')->get();
    $project_assign = array(
      'project_id' => $project_list_free_pools->id,
      'emp_id' => $userlastid,
      'created_by' => $userId,
      'modified_by' => $userId,
      'is_active' => 1,
      'created' => date('Y-m-d h:i:s'),
      'modified' => date('Y-m-d h:i:s'),

    );
    DB::table('tm_project_employees')->insert($project_assign);
    
    if(!empty($get_task)){

      foreach($get_task as $get_tasks){

        $assin_user = array(
          'project_id' =>  $project_list_free_pools->id,
          'task_id' => $get_tasks->task_id,
          'project_task_id' => $get_tasks->id,
          'emp_id' => $userlastid,
          'created_by' => $userId,
          'modified_by' => $userId,
          'is_active' => 1,
          'created' => date('Y-m-d h:i:s'),
          'modified' => date('Y-m-d h:i:s'),					  
        );
        DB::table('tm_project_task_employees')->insert($assin_user);
  
      }

    }



   }


  }

      

        $to = $request->email;
        $subject = 'No Reply - Kloudrac HRMS';
        $from = 'suitecrm14@gmail.com';
        $fromname = 'Not_reply';
       
        $content = joining_emp($request->fname.' '.$request->lname,$request->empcode,$password); 


    $mail = sendMail($to,$subject,$from,$fromname,$content);
    if($mail){

     

      return response()->json(['status' => 200, 'msg' => 'successfully Create User Check Mail in password','userid' =>$userlastid]);


    }else{

       return response()->json(['status' => 200, 'msg' => 'successfully Create User Check Mail in password','userid' =>$userlastid]);

    }

        
   }else{

     return response()->json(['status' => 201, 'state' => 'Not add']);
   }

   }

   }



           protected function sendpassword($to, $subject, $from, $fromname, $content)
    {
        try {
            $mail = Mail::send([], [], function ($message) use ($to, $subject, $from, $fromname, $content) {

                $message->from($from, $fromname);
                $message->to($to);
                $message->subject($subject);
                $message->setBody($content, 'text/html'); // for HTML rich messages
            });

            if ($mail) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            throw new HttpException(500, $e->getMessage());
        }
    }


public function addsalary($id){
    
      $userId = Auth::guard('main_users')->user()->id??0;

   $gatsalay = DB::table('grc_empsalarydetails')->where('user_id',$id)->first();


 
 return view('admin.add_sallary',['getsalary' =>  $gatsalay,'currentuser' => $userId]);

}

public function insetsalary(Request $request){

$inst = array(
'ifsc' => $request->acclassType,
'accountnumber' => $request->accno,
'account_type' => $request->acctype,
'accountholder_name' => $request->actname,
'bankname' => $request->bankname,
'currency_id' => $request->currncy,
'salary' => $request->salaryamt,
'user_id' => $request->userid,
'salarytype' => $request->pay,
'project_commission' => $request->procommison,
'status' => 1,
'created_at' => date('Y-m-d H:i:s'),
'updated_at' => date('Y-m-d H:i:s'),
);



 if(sizeof(DB::table('grc_empsalarydetails')->where('user_id','=',$request->userid)->get()) > 0){

      DB::table('grc_empsalarydetails')->where('user_id','=',$request->userid)->update($inst);

    return response()->json(['status' => 203, 'msg' => 'Update successfully']);
    }else{

       DB::table('grc_empsalarydetails')->insert($inst);
      return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

    }


}

public function addpersaninfo($id){

  $getpersion = DB::table('grc_emppersonaldetails')->where('user_id',$id)->first();
 // dd($getpersion);
 
 return view('admin.personalinfo',['persoanlinfo' => $getpersion]);

}



public function insetpersanalinfo(Request $request){


  $pernal = array(
  'user_id' => $request->userid,
   'blood_group' => $request->bloodgroup,
    'ethnic_code' => $request->ethnic,
     'genderid' => $request->gender,
      'maritalstatusid' => $request->maritalstaus,
      'nationalityid' => $request->nationalty,
       'race_code' => $request->racecode,
        'dob' => $request->dob,
        'status' =>1,
        'created_at' => date('Y-m-d H:i:s'),
         'updated_at' => date('Y-m-d H:i:s'),


  );

   if(sizeof(DB::table('grc_emppersonaldetails')->where('user_id','=',$request->userid)->get()) > 0){

      DB::table('grc_emppersonaldetails')->where('user_id','=',$request->userid)->update($pernal);

    return response()->json(['status' => 203, 'msg' => 'Update successfully']);
    }else{

       DB::table('grc_emppersonaldetails')->insert($pernal);
      return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

    }
}

public function addcontact($id){

  $contatinfo= DB::table('grc_empcommunicationdetails')->where('user_id',$id)->first();
 
 return view('admin.add_contact',['contactinfo' => $contatinfo]);

}

public function addexperiance($id){

  $experience = DB::table('grc_empexperiancedetails')->where('user_id',$id)->where('status',1)->get();


 
 return view('admin.add_exeperiance',compact('experience'));

}

public function addeducation($id){

   $education = DB::table('grc_empeducationdetails')->join('main_education_list','main_education_list.id','=','grc_empeducationdetails.education_level')->join('main_course_list','main_course_list.id','=','grc_empeducationdetails.course')->where('grc_empeducationdetails.user_id',$id)->where('grc_empeducationdetails.status',1)->select('grc_empeducationdetails.*','main_education_list.name as eduname','main_course_list.name as coursename')->get();
  // dd($education);
 
 return view('admin.add_education',compact('education'));

}

public function addtraining($id){

    $training = DB::table('main_training')->where('user_id',$id)->where('status',1)->get();
 
 return view('admin.add_training',compact('training'));

}

public function addvisa($id){

   $visa = DB::table('grc_empvisadetails')->where('user_id',$id)->where('status',1)->get();
 
 return view('admin.add_visa',compact('visa'));

}

public function addassetes($id){

     $assest = DB::table('grc_assets')->where('user_id',$id)->where('status',1)->get();
     
     $currentuser = Auth::guard('main_users')->user()->id??0;
 
 return view('admin.add_assets',['assest' => $assest,'currentuser' => $currentuser]);

}

public function deleteemp($id){
  
     $del = Main_users::where('id','=',$id)->delete();
     if($del){
      return redirect('employees')->with('message', 'Successfully Delete Users');;
     }
    
}

public function editemp($id){
    
     
  
     $editData = Main_users::where('id','=',$id)->first();

     return view('admin.add_emp',['editData' => $editData,'currentuser' => $id]);
    
}





public function getstate(Request $request){


 $getstate = DB::table('alm_states')->where('country_id','=',$request->countryid)->get();
  $state = '';
 $state .= '<select class="form-control" id="state"><option value="">Select State</option>';


 foreach ($getstate as $key => $value) {

 $state .= '<option value='.$value->id.'>'.$value->name.'</option>';
  
 }

 $state .= '</select>';

 return response()->json(['status' => 200, 'state' => $state]);




}


public function getcourse(Request $request){


 $getstate = DB::table('main_course_list')->where('edu_id','=',$request->eduid)->get();
  $state = '';
 $state .= '<select class="form-control" id="coursedate"><option value="">Select State</option>';


 foreach ($getstate as $key => $value) {

 $state .= '<option value='.$value->id.'>'.$value->name.'</option>';
  
 }

 $state .= '</select>';

 return response()->json(['status' => 200, 'course' => $state]);


}

public function getreportingmanager(Request $request){


 $getstate = DB::table('main_users')->where('department_id','=',$request->departid)->where('emprole',3)->get();
  $state = '';
 $state .= '<select class="form-control" id="state"><option value="">Select Manager</option>';

  if(!empty($getstate)){
 foreach ($getstate as $key => $value) {

 $state .= '<option value='.$value->id.'>'.$value->userfullname.'</option>';
  
 }
}

 $state .= '</select>';

 return response()->json(['status' => 200, 'manager' => $state]);




}



public function getcity(Request $request){

   $getcity = DB::table('alm_cities')->where('state_id','=',$request->stateid)->get();
  $state = '';
 $state .= '<select class="form-control" id="city"><option value="">Select City</option>';


 foreach ($getcity as $key => $value) {

 $state .= '<option value='.$value->id.'>'.$value->name.'</option>';
  
 }

 $state .= '</select>';

 return response()->json(['status' => 200, 'city' => $state]);
}


public function insertcontact(Request $request){

   $conct  = array(
    'user_id' =>$request->userid,
    'personalemail' =>$request->email,
    'personal_streetaddress' =>$request->p_Street,
    'perm_country' =>$request->country,
    'perm_state' =>$request->state,
    'perm_city' =>$request->city,
    'perm_pincode' =>$request->p_postalcode, 


     'current_streetaddress' =>$request->c_Street,
    
    'current_country' =>$request->c_Country,
    'current_state' =>$request->c_state,
    'current_city' =>$request->c_city,
    'current_pincode' =>$request->c_postalcode, 

    'emergency_number' =>$request->contactno,
    'emergency_name' =>$request->name,
    'emergency_email' =>$request->contact_email,
    'emergentcy_address' =>$request->offadd,
   
    'status' => 1,
    'created_at' =>date('Y-m-d H:i:s'),
    'updated_at'  => date('Y-m-d H:i:s'),
 
   );

    if(sizeof(DB::table('grc_empcommunicationdetails')->where('user_id','=',$request->userid)->get()) > 0){

      DB::table('grc_empcommunicationdetails')->where('user_id','=',$request->userid)->update($conct);

    return response()->json(['status' => 203, 'msg' => 'Update successfully']);
    }else{

       DB::table('grc_empcommunicationdetails')->insert($conct);
      return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

    }

}


public function insertexp(Request $request){


   $exp  = array(
    'user_id' =>$request->userid,
    'comp_name' =>$request->commpanyname,
    'comp_website' =>$request->website,
    'designation' =>$request->Designation,
    'from_date' =>$request->fromdate,
    'to_date' =>$request->todate,
    
    'status' => 1,
    'created_at' =>date('Y-m-d H:i:s'), 
    'updated_at' => date('Y-m-d H:i:s'),
 
   );

if(!empty($request->expid)){

   $exp12  = DB::table('grc_empexperiancedetails')->where('id',$request->expid)->update($exp);

       if($exp12){

         return response()->json(['status' => 203, 'msg' => 'Addedd successfully']);

       }


}else{

  
       $exp12  = DB::table('grc_empexperiancedetails')->insert($exp);

       if($exp12){

         return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

       }

}
     


}

public function delexp(Request $request){

  $userid = $request->userid;

 

  $del = DB::table('grc_empexperiancedetails')->where('id',$userid)->delete();
   if($del){

         return response()->json(['status' => 200, 'msg' => 'Delete successfully']);

       }

}

public function delassest(Request $request){

  $userid = $request->userid;



 

  $del = DB::table('grc_assets')->where('id',$userid)->delete();
   if($del){

         return response()->json(['status' => 200, 'msg' => 'Delete successfully']);

       }

}



public function insertedu(Request $request){
    
   $userid = Auth::guard('main_users')->user()->id;
  

   $edu  = array(
    'user_id' =>$request->userid,
    'education_level' =>$request->education,
    'institute_name' =>$request->Institution,
    'course' =>$request->course,
    'from_date' =>$request->fromdate,
    'to_date' =>$request->todate,
    
    'status' => 1,
    'created_at' =>date('Y-m-d H:i:s'), 
    'updated_at' => date('Y-m-d H:i:s'),
 
   );




if(!empty($request->eduid)){

   $exp12  = DB::table('grc_empeducationdetails')->where('id',$request->eduid)->update($edu);

       if($exp12){

         return response()->json(['status' => 203, 'msg' => 'Addedd successfully']);

       }


}else{

  
       $exp12  = DB::table('grc_empeducationdetails')->insert($edu);

       if($exp12){

         return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

       }

}


}


public function delete_education(Request $request){

    $userid = $request->userid;

 

  $del = DB::table('grc_empeducationdetails')->where('id',$userid)->delete();
   if($del){

         return response()->json(['status' => 200, 'msg' => 'Delete successfully']);

       }

}

public function deltraining(Request $request){

    $userid = $request->id;

 

  $del = DB::table('main_training')->where('id',$userid)->delete();
   if($del){

         return response()->json(['status' => 200, 'msg' => 'Delete successfully']);

       }

}

public function delvisa(Request $request){

    $userid = $request->id;

 

  $del = DB::table('grc_empvisadetails')->where('id',$userid)->delete();
   if($del){

         return response()->json(['status' => 200, 'msg' => 'Delete successfully']);

       }

}

public function updatefiletraining(Request $request){
    
    
      if($request->hasFile('editfile')) {
           $file = $request->file('editfile');

             $original_name = strtolower(trim($file->getClientOriginalName()));
             $name = time().rand(100,999).$original_name;

           //using the array instead of object
           //$image['filePath'] = $name;
           $file->move(public_path().'/uploads/attach/', $name);
           $image['attachfile'] = '/uploads/attach/'. $name;
          // $user->save();
        }
        
       // if(!empty($image)){
            
                if($request->trainingeditid){
                   
                     $exp12  = DB::table('main_training')->where('id',$request->trainingeditid)->update($image);

                   if($exp12){
            
                     return response()->json(['status' => 203, 'msg' => 'update successfully']);
            
                   }
                   
               }
            
        // }else{
            
        //      return response()->json(['status' => 202, 'msg' => 'Addedd successfully']);
            
        // }
     
    
}




  public function inserttraning(Request $request){

   // return $request->all();
   
   
   $userid = Auth::guard('main_users')->user()->id;

        
       if($request->hasFile('file')) {
           $file = $request->file('file');

             $original_name = strtolower(trim($file->getClientOriginalName()));
             $name = time().rand(100,999).$original_name;

           //using the array instead of object
           //$image['filePath'] = $name;
           $file->move(public_path().'/uploads/attach/', $name);
           $image['attachfile'] = '/uploads/attach/'. $name;
          // $user->save();
        }



         $image['user_id'] = $request->userid;
         $image['coursetype'] = $request->courseType;
          $image['courselevel'] = $request->courselevel;
           $image['trainingby'] = $request->trainingby;
            $image['fromdate'] = $request->fromdate;
             $image['todate'] = $request->todate;
              $image['descdata'] = $request->descdata;
               $image['status'] = 1;
               
               
               if($request->training_id){
                   
                     $exp12  = DB::table('main_training')->where('id',$request->training_id)->update($image);

                   if($exp12){
            
                     return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);
            
                   }
                   
               }else{
                   
                     $exp12  = DB::table('main_training')->insert($image);

                   if($exp12){
            
                     return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);
            
                   }
                               
                   
               }

            }

  public function insertvisa(Request $request){


         $image['user_id'] = $request->userid;
         $image['passport_number'] = $request->passportno;
          $image['passport_issue_date'] = $request->passportissue;
           $image['passport_expiry_date'] = $request->passportexpair;
            $image['visa_number'] = $request->visano;
             $image['visa_type'] = $request->visatype;
              $image['created_at'] = date('Y-m-d H:i:s');
               $image['updated_at'] = date('Y-m-d H:i:s');
               $image['status'] = 1;

               if(isset($request->edit_visa)){

                  $exp12  = DB::table('grc_empvisadetails')->where('id',$request->edit_visa)->update($image);

       if($exp12){

         return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

       }

               }else{

                  $exp12  = DB::table('grc_empvisadetails')->insert($image);

       if($exp12){

         return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

       }

               }


       $exp12  = DB::table('grc_empvisadetails')->insert($image);

       if($exp12){

         return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

       }

  }

  public function insertassest(Request $request){



      $image['user_id'] = $request->userid;
         $image['name'] = $request->assestname;
          $image['number'] = $request->serialno;
           $image['descdata'] = $request->descdata;
           
              $image['created_at'] = date('Y-m-d H:i:s');
               $image['updated_at'] = date('Y-m-d H:i:s');
               $image['status'] = 1;

               if(isset($request->edit_asset)){

                   $exp12  = DB::table('grc_assets')->where('id',$request->edit_asset)->update($image);

               if($exp12){

                 return response()->json(['status' => 203, 'msg' => 'Addedd successfully']);

               }


               }else{
          $exp12  = DB::table('grc_assets')->insert($image);

       if($exp12){

         return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

       }

               }


      

  }



public function updateprofile(Request $request){

         if($request->hasFile('profile')) {
           $file = $request->file('profile');

           $original_name = strtolower(trim($file->getClientOriginalName()));
             $name = time().rand(100,999).$original_name;

           //you also need to keep file extension as well
          // $name = $file->getClientOriginalName().'.'.$file->getClientOriginalExtension();

           //using the array instead of object
           //$image['filePath'] = $name;
           $file->move(public_path().'/uploads/attach/', $name);
           $image['profileimg'] = '/uploads/attach/'. $name;
          // $user->save();
        }

       

          if(isset($request->userid)){

                   $exp12  = DB::table('main_users')->where('id',$request->userid)->update($image);

               if($exp12){

                 return response()->json(['status' => 200, 'msg' => 'Addedd successfully']);

               }else{


                  return response()->json(['status' => 201, 'msg' => 'Not Change']);
               }

}

}


public function changepassord(Request $request){



   $email = Auth::guard('main_users')->user()->emailaddress;

   $oldpass  = Hash::make($request->cpassword);
    $newpass  = Hash::make($request->newpsd);


   $checkpass = DB::table('main_users')->where('id',$request->userid)->first();

   

    if (!Hash::check($request->cpassword, $checkpass->password)) {
      
         return response()->json(['status' => 201, 'msg' => 'Not Password successfully']);
    }

      $upated =  DB::table('main_users')->where('emailaddress',$email)->update(['password' =>$newpass]);


  if($upated){

        return response()->json(['status' => 200, 'msg' => 'Change Password successfully']);

      }




}


public function changethemes(Request $request){

  //return $request->all();

  $checkpass = DB::table('main_users')->where('id',$request->userid)->update(['themes' => $request->themes]);

  if($checkpass){

        return response()->json(['status' => 200, 'msg' => 'Change themes']);

      }else{

         return response()->json(['status' => 201, 'msg' => 'Not Change']);


      }

}

//========================= Availbale Leave ==========================

public function appyleave(){

    return view('admin.applyleave');
    
}




public function addappyleave(Request $request){

   //$framdat = $_POST['formdata'];

 $userid = Auth::guard('main_users')->user()->id;
 //dd($request->all());
 $arrayDate = json_decode($request->leaveDate);

usort($arrayDate, function($a, $b) {
    return strtotime($a) - strtotime($b);
});



   $leavedate = $arrayDate;
   $leavetype = json_decode($request->leavetype);
   $leavetime = json_decode($request->leavetime);

     $countdate = count($leavedate);



     if($request->select_commnet == 'Other'){

      $comment = $request->commnet;

     }else{

       $comment = $request->select_commnet;

     }
     
     list($leaveid,$totalleave,$leavecode) = explode('#',$request->leavemode);

     if($leavecode == 'CL'){
     $apply_leave = 0;
     for($i=0; $i<$countdate; $i++){
          $apply_leave +=  $leavetype[$i];
     }

     $avail_leave =  (new MainusersController)->avaliableleave($userid,$request->leavemode);


     if($avail_leave < $apply_leave){

         return response()->json(['status' => 205, 'msg' => 'You Have Not More Leave In Your Bucket']);

     }
   }

     if($leaveid == 1){

      $color = '#FF0000';

     }else if($leaveid == 2){

        $color = '#49FF33';

     }else{

        $color = '#334FFF';

     }
 
   
   
     $userEmail = Auth::guard('main_users')->user()->emailaddress;
      $reporting_mng = Auth::guard('main_users')->user()->reporting_manager;
       $mnager = DB::table('main_users')->where('id',$reporting_mng)->select('*')->first();
       $mnagerEmail = $mnager->emailaddress;
       
       $leaveavail = $request->leaveinyear;
    
    for($i=0; $i<$countdate; $i++){
        
     $leaveavail -=  $leavetype[$i];
        $leave = array(
        
        'user_id' => $userid,
        'leaveday'=>($leavetype[$i] == 0.5)?2:1 ,
        'leavetypeid' => $leaveid,
        'from_date' => $leavedate[$i],
        'to_date' => $leavedate[$i],
        'leavestatus' =>'Pending for approval', 
        'rep_mang_id' => $reporting_mng,
        'appliedleavescount' => $leavetype[$i],
        'lwp' => ($leaveavail < 0)?abs($leaveavail):0,
        'avail' => ($leaveavail > 0)?abs($leaveavail):0,
        'roll_over' =>  $leaveavail,
        'timesift' => ($leavetime[$i] == '')?0:$leavetime[$i],
        'reason' => $comment,
        'createdby' =>$userid, 
        'modifiedby' => $userid,
    
        'isactive' => 1,
        'createddate' => date('Y-m-d H:i:s'),
        'modifieddate' => date('Y-m-d H:i:s'),
        
        );
        
        
         $exp12  = DB::table('main_leaverequest')->insert($leave);

      
    $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content =   templete_leave_request(Auth::guard('main_users')->user()->userfullname,$mnager->userfullname, date('d M Y', strtotime($leavedate[$i])),1,$leavecode,$comment);

  
  
    $userEmail  = sendMail($mnager->emailaddress,$subject,$from,$fromname,$content);

    DB::table('main_notification')->insert(['sender_id' =>$userid,'reciver_id' =>  $reporting_mng ,'msg' => 'Request Leave for '. $leavedate[$i],'status' => 1]);

        

    }
    

       if($exp12){

        // $totalleave = array(
        // 'total_year_leave' => $request->leaveinyear,
        // 'month_leave' => $request->leaveinmonth,
        // 'unpaid_leave' => $request->Unpaid,
        // 'used_leave' => $request->leavedays,
        // );

        // DB::table('total_leave_list')->where('user_id',$userid)->update($totalleave);



        // if(!empty($arrayDate)){

        // $subject = 'Leave Request ';
        // $from = 'usrivastava@kloudrac.com';
        // $fromname = 'Not_Replay';
        // $content = '';
        // $content .='Dear '.Auth::guard('main_users')->user()->userfullname.' Apply Leave this Date '.implode(',', $arrayDate);

        //   $sendemail =  MultiSendEmail([$userEmail,$mnagerEmail],$subject,$from,$fromname,$content);

        //       //$userEmail  = sendMail($userEmail,$subject,$from,$fromname,$content);

        //   if($sendemail == true && $userEmail == true){

        //      return response()->json(['status' => 200, 'msg' => 'Send Email successfully']);

        //   }else{

        //      return response()->json(['status' => 201, 'msg' => 'Not successfully']);

        //   }

        // }
       

         return response()->json(['status' => 200, 'msg' => 'Added successfully']);

       }else{
           
             return response()->json(['status' => 201, 'msg' => 'not Added successfully']);

           
       }
     
    
    
}




public function leavelist(){

   $userid = Auth::guard('main_users')->user()->id;
    $role = Auth::guard('main_users')->user()->emprole;
   $month = date('m');


  $leavelist = DB::table('main_leaverequest')->leftJoin('main_users', 'main_users.id', '=', 'main_leaverequest.user_id');
  if($role != 1 && $role != 4 && $role != 11){
 $leavelist ->where('main_leaverequest.user_id',$userid);
  }
 

  $leavelist  = $leavelist->orderBy('main_leaverequest.id','DESC')

  ->select('main_leaverequest.*','main_users.userfullname')
  ->get();


// $getleavecount = DB::table('grc_employeeleaves')->where(DB::raw("(DATE_FORMAT(grc_employeeleaves.leaveDate,'%m'))"), ">=", $month)->select(DB::raw('SUM(grc_employeeleaves.leave_type) AS leaveCount'))->first();

// if(isset($getleavecount)){

//   $getleavecount->drtDate =date('M');

// }




   return view('admin.applyaproval',['leavelist' =>$leavelist]);

}




function export_leave(Request $request){
    
     $userid = Auth::guard('main_users')->user()->id;
    $role = Auth::guard('main_users')->user()->emprole;
   $month = date('m');


  $leavelist = DB::table('main_leaverequest')->leftJoin('main_users', 'main_users.id', '=', 'main_leaverequest.user_id');
 
 $leavelist ->where('main_leaverequest.user_id',$request->user_id);
 $leavelist ->where('main_leaverequest.leavestatus',$request->status);
  
 

  $leavelist  = $leavelist->orderBy('main_leaverequest.id','DESC')

  ->select('main_leaverequest.*','main_users.userfullname')
  ->get();
  
  
      $columns = array('S.No', 'Employee ', 'Leave Type', 'Date','Day', 'Status');

    
    $filename = public_path("uploads/csv/leave_'".time()."'_report.csv");
    $handle = fopen($filename, 'w+');
    fputcsv($handle, $columns);

         $i = 1;
        foreach($leavelist as $leavelists) {
            
             if($leavelists->leavetypeid ==1){
                        $title = 'CL';
                       
                    }else if($leavelists->leavetypeid ==2){
                         $title = 'RH';
                        
                    }else if($leavelists->leavetypeid ==5){
                          $title = 'MyLeave';
                         
                    }else if($leavelists->leavetypeid ==4){
                        
                         $title = 'Maternity Leave';
                      
                        
                    }

           fputcsv($handle, array($i++, ucwords($leavelists->userfullname), $title, $leavelists->from_date, $leavelists->appliedleavescount,$leavelists->leavestatus));
        }
        
       fclose($handle);

       $headers = array(
        'Content-Type' => 'text/csv'
       
        );


    return Response()->download($filename);
    
}




public function leavereport(){


 

   $userid = Auth::guard('main_users')->user()->id;

   $month = date('m');
   $now = date('Y-m');


  $leavelist = DB::table('main_leaverequest')->leftJoin('main_users', 'main_users.id', '=', 'main_leaverequest.user_id')->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), ">=", $now)

  ->select('main_leaverequest.*','main_users.userfullname','main_users.employeeId')
  ->get();



   $leavename = DB::table('main_leaverequest')->leftJoin('main_users', 'main_users.id', '=', 'main_leaverequest.user_id')->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), ">=", $now)->groupBy('main_leaverequest.user_id')

  ->select('main_leaverequest.*','main_users.userfullname','main_users.id as userid')
  ->get();



   return view('admin.leave_report',['leavelist' =>$leavelist,'leavename' =>$leavename]);


}

public function exportcsv(Request $request)
{




   // $reviews = Reviews::getReviewExport($this->hw->healthwatchID)->get();

     $userid = Auth::guard('main_users')->user()->id;

   $month = date('m');


if(isset($_GET['month']) && isset($_GET['id'])){

  $month = $_GET['month'];
  $userid = $_GET['id'];



    $reviews = DB::table('grc_employeeleaves')->leftJoin('main_users', 'main_users.id', '=', 'grc_employeeleaves.user_id')->leftJoin('total_leave_list', 'total_leave_list.user_id', '=', 'grc_employeeleaves.user_id')->where(DB::raw("(DATE_FORMAT(grc_employeeleaves.leaveDate,'%m'))"), "=",$month)->where('grc_employeeleaves.user_id',$userid)

  ->select('grc_employeeleaves.*','total_leave_list.total_year_leave','total_leave_list.month_leave','total_leave_list.used_leave','total_leave_list.unpaid_leave','main_users.userfullname','main_users.employeeId')
  ->get();


}else{

    $reviews = DB::table('grc_employeeleaves')->leftJoin('main_users', 'main_users.id', '=', 'grc_employeeleaves.user_id')->leftJoin('total_leave_list', 'total_leave_list.user_id', '=', 'grc_employeeleaves.user_id')->whereRaw("find_in_set($userid,show_user_id)")

  ->select('grc_employeeleaves.*','total_leave_list.total_year_leave','total_leave_list.month_leave','total_leave_list.used_leave','total_leave_list.unpaid_leave','main_users.userfullname','main_users.employeeId')
  ->get();

}



    $columns = array('S.No', 'Employee Name', 'Employee Code', 'Date of Leave', 'Type of Leave','Comments','Status');

    
    $filename = public_path("uploads/csv/leave_'".time()."'_report.csv");
    $handle = fopen($filename, 'w+');
    fputcsv($handle, $columns);

         $i = 1;
        foreach($reviews as $review) {

        $useridshowid = array_filter(explode(',',$review->show_user_id));
                                                
            if(count($useridshowid) > 5){

              if($review->manager ==1 && $review->hr ==1 && $review->admin ==1 && $review->director == 1){
                $status = 'Approved';
  
              }else if($review->manager == 2 || $review->hr ==2 || $review->admin ==2 || $review->director == 2){
  
                $status = 'Rejected';
  
              }else{
  
                $status = 'Pending';
  
              }

            }else{

              if($review->manager ==1 && $review->hr ==1 && $review->admin ==1){
                $status = 'Approved';
  
              }else if($review->manager == 2 || $review->hr ==2 || $review->admin ==2){
  
                $status = 'Rejected';
  
              }else{
  
                $status = 'Pending';
  
              }

            }

            
 

           fputcsv($handle, array($i++, ucwords($review->userfullname), $review->employeeId, $review->leaveDate, $review->leave_mode, $review->comment,$status));
        }
        
       fclose($handle);

       $headers = array(
        'Content-Type' => 'text/csv'
       
        );


    return Response()->download($filename);
 
 
}


public function leavetype(Request $request){
    
  // dd($request->all());
    
    $userid = Auth::guard('main_users')->user()->id;
    
    list($leaveid,$totalleaveall,$leavecode) = explode('#',$request->leavetype);
    $now = date('Y-m');
    $takenleave = 0;
    $totalleave = DB::table('main_employeeleaves')->where('user_id',$userid)->first();
    $userdetails = DB::table('main_users')->where('id',$userid)->first();


    if($leavecode == 'CL'){
        // $lessMonth = date('m');
        // $lesscountmonthless = (int)date('m') - 1;
       
         $startDate = date('Y').'-01';
         $endDate = date('Y-m', strtotime(date('Y-m').'+-1 months'));
        
          $joinDate = date('Y',strtotime($userdetails->join_date));
          
          if((int)$joinDate >= (int)date('Y')){
                $joinmonth =(int) date('m',strtotime($userdetails->join_date));

                $lesscountmonthless =   (int)date('m') - $joinmonth;
                $lesscountmonthless  =  ($lesscountmonthless <= 0)?1:$lesscountmonthless;
                

          }else{

            $lesscountmonthless = (int)date('m') - 1;
            

          }

         
        
        $lessCountMonth = 0;
        for($i = 0;$i < (int)$lesscountmonthless; $i++){
            $lessCountMonth += 1.5;
        }
        
     
        
         $preleave = DB::table('main_leaverequest')->where('isactive',1)->where('leavestatus','Approved')->whereBetween(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), [$startDate, $endDate])->where('leavetypeid',(int)$leaveid)->where('user_id',$userid)->orderBy(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%m'))"), 'asc')->groupBy(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%m'))"))->select(DB::raw('SUM(main_leaverequest.appliedleavescount) as leaveCount'),DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%m'))"))->get();
         
          //$preMonthleaveAvail = 0;
           
          $preLeaveMonth = 0;
         if(count($preleave) > 0){
            foreach($preleave as $preleaves) {


             $preLeaveMonth +=$preleaves->leaveCount;
             $preMonthleaveAvail = $lessCountMonth - $preLeaveMonth;
                
                // if($preleaves->leaveCount > 1.5){
                //      $preLeaveMonth = 0;
                     
                //      $preMonthleaveAvail = 0;
                     
                // }else{
                    
                //      $preLeaveMonth +=$preleaves->leaveCount;
                //       $preMonthleaveAvail = $lessCountMonth - $preLeaveMonth;

                      
                // }
                
            }

         
             
            
         }else{
             $preLeaveMonth = 0;
             
              $preMonthleaveAvail = $lessCountMonth - $preLeaveMonth;

               
         }
        

     
       
     
        
    // $avaliableleave  =0;
    // $takenleave  =0;
    // $currentYear = date('Y');
    // $currentMonth = date('m');
    
    //  $avaiLeave = DB::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Rejected','Cancel'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), "=", date('Y-m'))->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('roll_over')->get();
   
    //   if(isset($avaiLeave) && !empty($avaiLeave)){
    // foreach($avaiLeave as $avaiLeaves){
       
    //     $avaliableleave +=$avaiLeaves->roll_over;
    // }  
    //  if($avaliableleave < 0 ){
         
    //       $avaliableleave = 0;
    //  }
    
    // }else{
    //     $avaliableleave = 0;
        
    // }
    $takenleave  =0;
    $takeleave = DB::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Rejected','Cancel'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), "=", $now)->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
  
    if(isset($takeleave) && !empty($takeleave)){
    foreach($takeleave as $takeleaves){
        
        $takenleave +=$takeleaves->appliedleavescount;
        
        
     
    }  
    }else{
        
        $takenleave = 0;
        
    }


     
     
     $Totalavaliableleave =   ($preMonthleaveAvail < 0)?0: $preMonthleaveAvail - $takenleave;



      if($Totalavaliableleave < 0){
       return 0;
      }else{

       return $Totalavaliableleave + 1.5 + caryforward($userid);

      }
        
    }elseif($leavecode == 'RH'){

       $takenleave = 0;
        
         $takeleave = Db::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Rejected','Cancel'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.createddate,'%Y'))"), "=", date('Y'))->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
 
    if(isset($takeleave) && !empty($takeleave)){
         foreach($takeleave as $takeleaves){
        $takenleave +=$takeleaves->appliedleavescount;
    }
        
    }else{
        
        $takenleave = 0;
        
    }
   
        
        
         return $totalleaveall - $takenleave;
    
    }elseif($leavecode == 'ML'){

      $takenleave = 0;
        
          $takeleave = Db::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Cancel','Rejected'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.createddate,'%Y'))"), "=", date('Y'))->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
 
    if(isset($takeleave) && !empty($takeleave)){
         foreach($takeleave as $takeleaves){
        $takenleave +=$takeleaves->appliedleavescount;
    }
        
    }else{
        
        $takenleave = 0;
        
    }
   
        
        
         return $totalleaveall - $takenleave;
        
    }elseif($leavecode == 'MyL'){
        
          $takeleave = Db::table('main_leaverequest')->where('isactive',1)->whereNotIn('leavestatus',['Cancel','Rejected'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.createddate,'%Y'))"), "=", date('Y'))->where('leavetypeid',$leaveid)->where('user_id',$userid)->select('appliedleavescount')->get();
 
    if(isset($takeleave) && !empty($takeleave)){
         foreach($takeleave as $takeleaves){
        $takenleave +=$takeleaves->appliedleavescount;
    }
        
    }else{
        
        $takenleave = 0;
        
    }
   
        
        
         return $totalleaveall - $takenleave;
        
    }
}


public function aproveleave(Request $request){
    
   // return $request->all();

  $userid = Auth::guard('main_users')->user()->emprole;
  
 $leaveid = $request->leaveid;
 $user_id = $request->user_id;
 $leavecount = $request->leavecount;
 
   $total_leave = DB::table('total_leave_list')->where('user_id',$user_id)->first();
   
   $leavereject = DB::table('grc_employeeleaves')->where('id',$leaveid)->first();
   $leaveuser = DB::table('main_users')->where('id',$leavereject->user_id)->select('userfullname','emailaddress')->first();

 

 
   if($request->status == 'Approve'){

    $status = 1;


    $subject = 'Leave Approve ';
    $from = 'usrivastava@kloudrac.com';
    $fromname = 'Not_reply';
    $content = '';
    $content .='Dear '.$leaveuser->userfullname.' Your Leave Approved by'.Auth::guard('main_users')->user()->userfullname;
    
    if($leavereject->leaveTitle == 'CL'){
          DB::table('total_leave_list')->where('user_id',$user_id)->update(['total_year_leave' => $total_leave->total_year_leave - $leavecount ]);
    }else if($leavereject->leaveTitle == 'RH'){
          DB::table('total_leave_list')->where('user_id',$user_id)->update(['restricted' => $total_leave->restricted - $leavecount]);
    }else if($leavereject->leaveTitle == 'ML'){
          DB::table('total_leave_list')->where('user_id',$user_id)->update(['maternity' => $total_leave->maternity - $leavecount]);
    }else if($leavereject->leaveTitle == 'MyL'){
          DB::table('total_leave_list')->where('user_id',$user_id)->update(['myleave' => $total_leave->myleave - $leavecount]);
    }
    
    
      
      
      DB::table('grc_employeeleaves')->where('id',$leaveid)->update(['manager' => 1]);
      $userEmail  = sendMail($leaveuser->emailaddress,$subject,$from,$fromname,$content);
     return response()->json(['status' => 200, 'msg' => 'Successfully Approved']);
         

   }else{

     $status = 2;

     
    $subject = 'Leave Approve Details';
    $from = 'usrivastava@kloudrac.com';
    $fromname = 'Not_reply';
    $content = '';
    $content .='Dear '.$leaveuser->userfullname.' Your Leave Rejected by'.Auth::guard('main_users')->user()->userfullname;

     DB::table('grc_employeeleaves')->where('id',$leaveid)->update(['manager' => 2]);
      $userEmail  = sendMail($leaveuser->emailaddress,$subject,$from,$fromname,$content);
     return response()->json(['status' => 200, 'msg' => 'Successfully Reject']);
         


   };
  
//   if($userid == 1){

//   $updatedate = DB::table('grc_employeeleaves')->where('id',$leaveid)->update(['director'=>$status]);


//   if($updatedate){

//     if($status ==2){

//       $totalleave =  DB::table('total_leave_list')->where('user_id',$user_id)->first();
//       $leavereject = DB::table('grc_employeeleaves')->where('id',$leaveid)->first();
//       $month = $totalleave->month_leave + $leavecount;
//       $year = $totalleave->total_year_leave + $leavecount;
   
//       if($totalleave->used_leave > 0){
//       $leavearr['used_leave'] = $totalleave->used_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       if($totalleave->unpaid_leave > 0){
//       $leavearr['unpaid_leave'] = $totalleave->unpaid_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       $leavearr['total_year_leave'] = $year;
//       $leavearr['month_leave'] = $month;
   
     
   
//       DB::table('total_leave_list')->where('user_id',$user_id)->update($leavearr);
   
//      }

//      $userEmail  = sendMail($leaveuser->emailaddress,$subject,$from,$fromname,$content);

//      if($userEmail){
//       return response()->json(['status' => 200, 'msg' => 'Successfully Added']);

//      }else{
//       return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//      }

    

//   }else{

//      return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//   }

//   }elseif ($userid == 3) {


//      $updatedata = DB::table('grc_employeeleaves')->where('id',$leaveid)->update(['manager'=>$status,'reason' => $request->reason]);


//   if($updatedata){

//     if($status ==2){

//       $totalleave =  DB::table('total_leave_list')->where('user_id',$user_id)->first();
//       $leavereject = DB::table('grc_employeeleaves')->where('id',$leaveid)->first();
//       $month = $totalleave->month_leave + $leavecount;
//       $year = $totalleave->total_year_leave + $leavecount;
   
//       if($totalleave->used_leave > 0){
//       $leavearr['used_leave'] = $totalleave->used_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       if($totalleave->unpaid_leave > 0){
//       $leavearr['unpaid_leave'] = $totalleave->unpaid_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       $leavearr['total_year_leave'] = $year;
//       $leavearr['month_leave'] = $month;
   
     
   
//       DB::table('total_leave_list')->where('user_id',$user_id)->update($leavearr);
   
//      }

//      $userEmail  = sendMail($leaveuser->emailaddress,$subject,$from,$fromname,$content);

//      if($userEmail){
//       return response()->json(['status' => 200, 'msg' => 'Successfully Added']);

//      }else{
//       return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//      }

//   }else{

//      return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//   }
//     # code...
//   }elseif ($userid == 4) {


//      $updatedata = DB::table('grc_employeeleaves')->where('id',$leaveid)->update(['hr'=>$status]);


//   if($updatedata){

//     if($status ==2){

//       $totalleave =  DB::table('total_leave_list')->where('user_id',$user_id)->first();
//       $leavereject = DB::table('grc_employeeleaves')->where('id',$leaveid)->first();
//       $month = $totalleave->month_leave + $leavecount;
//       $year = $totalleave->total_year_leave + $leavecount;
   
//       if($totalleave->used_leave > 0){
//       $leavearr['used_leave'] = $totalleave->used_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       if($totalleave->unpaid_leave > 0){
//       $leavearr['unpaid_leave'] = $totalleave->unpaid_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       $leavearr['total_year_leave'] = $year;
//       $leavearr['month_leave'] = $month;
   
     
   
//       DB::table('total_leave_list')->where('user_id',$user_id)->update($leavearr);
   
//      }

//      $userEmail  = sendMail($leaveuser->emailaddress,$subject,$from,$fromname,$content);

//      if($userEmail){
//       return response()->json(['status' => 200, 'msg' => 'Successfully Added']);

//      }else{
//       return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//      }

//   }else{

//      return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//   }
   
//   }else

//       $updatedata = DB::table('grc_employeeleaves')->where('id',$leaveid)->update(['admin'=>$status]);
 

//   if($updatedata){

//     if($status ==2){

//       $totalleave =  DB::table('total_leave_list')->where('user_id',$user_id)->first();
//       $leavereject = DB::table('grc_employeeleaves')->where('id',$leaveid)->first();
//       $month = $totalleave->month_leave + $leavecount;
//       $year = $totalleave->total_year_leave + $leavecount;
   
//       if($totalleave->used_leave > 0){
//       $leavearr['used_leave'] = $totalleave->used_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       if($totalleave->unpaid_leave > 0){
//       $leavearr['unpaid_leave'] = $totalleave->unpaid_leave - ($leavereject->leave_type == 1.0)?1.0:0.5;
//       }
//       $leavearr['total_year_leave'] = $year;
//       $leavearr['month_leave'] = $month;
   
     
   
//       DB::table('total_leave_list')->where('user_id',$user_id)->update($leavearr);
   
//      }

//      $userEmail  = sendMail($leaveuser->emailaddress,$subject,$from,$fromname,$content);

//      if($userEmail){
//       return response()->json(['status' => 200, 'msg' => 'Successfully Added']);

//      }else{
//       return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//      }

//   }else{

//      return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);

//   }

   }

   public function checkdateleave(Request $request){
       
      // dd($request->all());
    $currentDate = date('Y-m-d');
     $monthYear = date('Y-m');
    $userid = Auth::guard('main_users')->user()->id;
     list($leaveid,$totalleave,$leavecode)  = explode('#',$request->leavemode);
    $dayname = date('D', strtotime($request->selectedDate));
    $month_year = date('Y-m', strtotime($request->selectedDate));
    $first_day = date("Y-m-d", strtotime("-1 months"));
     $last_day = date("Y-m-d", strtotime("+1 month"));; 
       
   
    
    if($dayname == 'Sun' || $dayname == 'Sat'){

      return response()->json(['status' => 202, 'msg' => 'Weeked Off']);

    }

    if($first_day  > $request->selectedDate){

       return response()->json(['status' => 202, 'msg' => 'Passed Date Not Apply Leave ']);

    }
      if(2020 < date('Y') ){
          
          if($leavecode == 'CL'){

     $checkleave  = DB::table('main_leaverequest')->where('leavestatus','Approved')->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), $month_year)->where('leavetypeid',$leaveid)->where('user_id',$userid)->count();

      if($checkleave > 5){

         return response()->json(['status' => 201, 'msg' => 'You Have already More than this month']);
             

      }

     }
      }
      

    if($leavecode == 'MyL'){
        
         $checkleave  = DB::table('main_leaverequest')->whereNotIn('leavestatus',['Rejected','Cancel'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), "=", $monthYear)->where('leavetypeid',$leaveid)->where('user_id',$userid)->count();
        
         if($checkleave == 0 ){
             
             return response()->json(['status' => 200, 'msg' => 'added']);
             
         }else{
             
               return response()->json(['status' => 201, 'msg' => 'Not Apply MyLeave This Year']);
             
         }
        
    }
    
        if($leavecode == 'ML'){
        
         $checkleave  = DB::table('main_leaverequest')->whereNotIn('leavestatus',['Rejected','Cancel'])->where(DB::raw("(DATE_FORMAT(main_leaverequest.from_date,'%Y-%m'))"), "=", $monthYear)->where('leavetypeid',$leaveid)->where('user_id',$userid)->count();
        
         if($checkleave == 0 ){
             
             return response()->json(['status' => 200, 'msg' => 'added']);
             
         }else{
             
               return response()->json(['status' => 201, 'msg' => 'Not Apply Maternity Leave This Year']);
             
         }
        
    }
    

    $checkleave  = DB::table('main_leaverequest')->whereNotIn('leavestatus',['Rejected','Cancel'])->whereDate('from_date',$request->selectedDate)->where('user_id',$userid);
    
    if($checkleave->count() ==0){

      $holidatleave  = DB::table('main_holidaydates')->whereDate('holidaydate',$request->selectedDate);
    // dd($holidatleave->first()->groupid);
      if($holidatleave->count() == 0 && $leavecode == 'CL'){

        return response()->json(['status' => 200, 'msg' => 'added']);
       
      }else if($holidatleave->count() == 0  && $leavecode == 'MyL'){ 
        
        return response()->json(['status' => 200, 'msg' => 'added']);
        
      }else if($holidatleave->count() == 0  && $leavecode == 'ML'){ 
        
        return response()->json(['status' => 200, 'msg' => 'added']);
        
      }else if($holidatleave->count() == 0  && $leavecode == 'RH'){
          
              return response()->json(['status' => 201, 'msg' => 'Apply Leave In CL']);
           
        
      }else if($holidatleave->first()->groupid == "3" && $leavecode == 'RH'){
          
           return response()->json(['status' => 200, 'msg' => 'added']);

      }else if($holidatleave->count() != 0 && $holidatleave->first()->groupid == 2){   

           return response()->json(['status' => 201, 'msg' => 'Fixed HoliDay']);
           
    
      }else if($holidatleave->count() != 0 && $leavecode == 'RH'){
          
          
           return response()->json(['status' => 201, 'msg' => 'Not Apply Leave In CL']);
          
        
          
      }else{

        return response()->json(['status' => 201, 'msg' => ' Apply RH For This Date']);

      }
    

    }else{

      $userdetails = $checkleave->leftJoin('main_users','main_leaverequest.user_id','=','main_users.id')->leftJoin('main_users as rmuser','main_users.reporting_manager','=','rmuser.id')->select('main_leaverequest.*','main_users.userfullname','rmuser.userfullname as reportingmanager')->first();

      if($userdetails->leaveday == 1){

        $days =  'Full Day';

      }else{

         $days =  'Half Day';

      }
      

                    
                    if($userdetails->leavetypeid ==1){
                        $title = 'CL';
                     
                    }else if($userdetails->leavetypeid ==2){
                         $title = 'RH';
                        
                        
                    }else if($userdetails->leavetypeid ==5){
                          $title = 'MyLeave';
                          
                    }else if($userdetails->leavetypeid ==4){
                        
                         $title = 'Maternity Leave';
                        
                        
                    }
                    
             



       $html = '';
      $html .= '<div class="row">
                 <div class="col-md-3">
                   <label class="col-form-label"> Employee</label>
                 </div>
                  <div class="col-md-3">
                    '.$userdetails->userfullname.'
                 </div>
                  <div class="col-md-3">
                  <label class="col-form-label"> Leave Type</label>
                 </div>
                  <div class="col-md-3">
                 '.$title.'
                 </div>
                  <div class="col-md-3">
                  <label class="col-form-label"> Date</label>
                 </div>
                  <div class="col-md-3">
                    '.date('d-M-Y',strtotime($userdetails->from_date)).'
                 </div>
                 <div class="col-md-3">
                   <label class="col-form-label">Status</label>
                 </div>
                  <div class="col-md-3">
                    '.$userdetails->leavestatus.'
                 </div>
                 <div class="col-md-3">
                  <label class="col-form-label"> Leave For</label>
                 </div>
                  <div class="col-md-3">
                    '.$days.'
                 </div>
                 <div class="col-md-3">
                  <label class="col-form-label"> Days</label>
                 </div>
                  <div class="col-md-3">
                    1
                 </div>

                  <div class="col-md-3">
                   <label class="col-form-label"> Reporting Manager</label>
                 </div>
                  <div class="col-md-3">
                    '.$userdetails->reportingmanager.'
                 </div>';
                 
if($userdetails->leavestatus == 'Pending for approval'){
    
                  $html .= '<div class="col-md-6">
<button class="btn float-right bg-danger text-white" onclick="cancelleave('.$userdetails->id.')">Cancel</button>
                 </div>';
                 
                 }
                
              $html .= '</div>';


      return response()->json(['status' => 203, 'msg' => 'already add Leave','details' =>  $html ]);

    }


   }
   
   public function addyearlyleave(){
       
       $month = date('m');
       
       // $userid = Auth::guard('main_users')->user()->id;
        
        $totalleave = DB::table('total_leave_list')->get();
         $leave = 0;
        foreach($totalleave as $totalleaves){
            
         
            
            DB::table('total_leave_list')->where('user_id',$totalleaves->user_id)->update(['total_year_leave' =>$totalleaves->total_year_leave + 18 ]);
            
        }
       
   }
   
   public function add_month_leave(){

  $gettotoleleave = DB::table('total_leave_list')->get();
  if(isset($gettotoleleave)){

    foreach($gettotoleleave as  $gettotoleleaves){
      DB::table('total_leave_list')->where('user_id',$gettotoleleaves->user_id)->update(['month_leave' => $gettotoleleaves->month_leave + 1.5]);
    }
  

  }


}


public function cancelleave(Request $request){

 // return $request->all();

  $userid = Auth::guard('main_users')->user()->id;

 // $getleave = DB::table('main_leaverequest')->where('id',$request->leaveid)->first();
 // $totalgetleave = DB::table('total_leave_list')->where('user_id',$userid)->first();


//   if($getleave->leave_mode == 'Casual Leave'){

//     $arr = array(
//      'total_year_leave' => (int)$totalgetleave->total_year_leave + 1
//     );

//   }else if($getleave->leave_mode == 'Restricted Leave'){
//      $arr = array(
//      'restricted' => $totalgetleave->restricted + 1
//     );

//   }else if($getleave->leave_mode == 'Maternity Leave'){
//      $arr = array(
//      'maternity' => $totalgetleave->maternity + 1
//     );

//      }else if($getleave->leave_mode == 'Maternity Leave'){
//      $arr = array(
//      'myleave' => $totalgetleave->myleave + 1
//     );

//   }

  //$updattotalleave = DB::table('total_leave_list')->where('user_id',$userid)->update($arr);
  $updattotalleave = DB::table('main_leaverequest')->where('id',$request->leaveid)->delete();

   if($updattotalleave){

    return response()->json(['status' => 200, 'msg' => 'Successfully Remove Leave' ]);

   }else{

    return response()->json(['status' => 201, 'msg' => 'Something Went to Worng']);

   }

}


public function uploadusercsv(Request $request){

        if ($request->input('upload') != null ){
  
        $file = $request->file('upload_attadance');
  
        // File Details 
        $filename = $file->getClientOriginalName();
        $extension = $file->getClientOriginalExtension();
        $tempPath = $file->getRealPath();
        $fileSize = $file->getSize();
        $mimeType = $file->getMimeType();
  
        // Valid File Extensions
        $valid_extension = array("csv");

         $subject = 'User Password Details';
    $from = 'usrivastava@kloudrac.com';
    $fromname = 'Not_Reply';
    $content = '';
   
  
        
  
        // 2MB in Bytes
        $maxFileSize = 2097152; 
  
        // Check file extension
        if(in_array(strtolower($extension),$valid_extension)){
  
          // Check file size
          if($fileSize <= $maxFileSize){
  
            // File upload location
            $location = 'uploadcsv';
  
            // Upload file
            // $file->move($location,$filename);
             $file->move(public_path().'/uploadcsv/', $filename);
            // Import CSV to Database
            $filepath = public_path($location."/".$filename);

           // dd($filepath);
  
            // Reading file
            $file = fopen($filepath,"r");
  
            $importData_arr = array();
            $i = 0;
  
            while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
               $num = count($filedata);
               
               // Skip first row (Remove below comment if you want to skip the first row)
               if($i == 0){
                  $i++;
                  continue; 
               }
               for ($c=0; $c < $num; $c++) {
                  $importData_arr[$i][] = $filedata[$c];
               }
               $i++;
            }
            fclose($file);
  
      // dd($importData_arr);
  
            // Insert to MySQL database
            foreach($importData_arr as $importData){

          

           //   $role = DB::table('main_roles')->where('rolename',trim($importData[0]))->first();
                 $password = uniqid();

                // $content = 'Dear Your Email is  '.$importData[4].' and Password is ' .$password ."  <a href='http://howzze.com/'>Login In HRMS</a>";
                 
           
            //     $insertData = array(
            //     'id' =>   $importData[0],
            //     'emprole' =>   $importData[1],
            //     'firstname' => $importData[2],
            //     'lastname' => $importData[3],
            //     'userfullname' => $importData[2].' '.$importData[3],
            //     'join_date' =>  date('Y-m-d',strtotime($importData[4])),
            //     'emailaddress' => $importData[5],
            //     'password' => Hash::make($password),
            //      'isactive' =>1,
            //      'employeeId' => $importData[6],
            //      'emp_category' => $importData[7],
            //      'department_id' => $importData[8],
            //      'reporting_manager' => $importData[9],
            //      'themes' => 'default',
                
            //     );
            //  //sendMail($importData[4],$subject,$from,$fromname,$content);
            //  $lastid = DB::table('main_users')->insertGetId($insertData);
            
            $getuser = DB::table('main_users')->where('id',$importData[0])->first();
             if(isset($getuser)){
                 
                  $leave = array(
                 'user_id' => $getuser->id,
                 'total_year_leave' => isset($importData[1])?$importData[1]:18.00,
                 'used_leave' => isset($importData[2])?$importData[2]:0.00,
                 'year' => isset($importData[3])?$importData[3]:date('Y'),
                 
                 
                 );
                 
                 DB::table('total_leave_list')->where('user_id',$getuser->id)->update($leave);
                 
             }
            
                 
                //  $lastid = DB::table('total_leave_list')->insert($leave);

           
            
          //  }

              // }else{

              //    Session::flash('message','Something went to Worng');
              //    Session::flash('alert','danger');

              // }
              
  
            }
            
              Session::flash('message','Import Successful.');
              Session::flash('alert','primary');
  
  
           
          }else{
            Session::flash('message','File too large. File must be less than 2MB.');
            Session::flash('alert','danger');
          }
  
        }else{
           Session::flash('message','Invalid File Extension.');
           Session::flash('alert','danger');
        }
  
        // Redirect to index
      return redirect()->back();
  
      }

}

public function auto_rejected_leave(){

   $currentDate =   Date('Y-m-d');
   $getleaveList = DB::table('main_leaverequest')->where('leavestatus','Pending for approval')->where('isactive')->get();

   foreach ($getleaveList as $key => $getleaveLists) {
       
       $user_details = DB::table('main_users')->where('id',$getleaveLists->user_id)->first();

    $leaveDate = date('Y-m-d',strtotime("+7 day", strtotime($getleaveLists->from_date)));

    if($leaveDate <= $currentDate){

      DB::table('main_leaverequest')->where('id',$getleaveLists->id)->update(['leavestatus' => 'Rejected']);
      
             if($getleaveLists->leavetypeid == 1){

        $leaveType = "CL";

     }else if($getleaveLists->leavetypeid == 2){

      $getleaveLists = "RH";

     }else{

      $getleaveLists = "My Leave";

     }

      
      
    $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content =   templete_leave_confirmation($user_details->userfullname, date('d M Y', strtotime($getleaveLists->from_date)),$getleaveLists->appliedleavescount,$leaveType,'Rejected',$getleaveLists->reason);

  
     $userEmail  = sendMail($user_details->emailaddress,$subject,$from,$fromname,$content);
     
   }
    }

}


public function birthday_mail(){

  $currentDate =   Date('Y-m-d');
  $birthday_date =   Date('m-d');
  $joining_date =   Date('d');
  $to = 'asharma@kloudrac.com';
  $birthday = DB::table('main_users')->join('grc_emppersonaldetails','main_users.id','=','grc_emppersonaldetails.user_id')->where('main_users.isactive',1)
             ->where(DB::raw("(DATE_FORMAT(grc_emppersonaldetails.dob,'%m-%d'))"), "=", $birthday_date)->select('main_users.*','grc_emppersonaldetails.dob')->get();


    if(isset($birthday)) {

      foreach($birthday as $birthdays){

      $subject =  ' Today is '. $birthdays->userfullname. ' Birthday';
      $from = 'suitecrm14@gmail.com';
      $fromname = 'Not_reply';
      $content =   birthday($birthdays->userfullname,$subject,$birthdays->employeeId,$birthdays->emailaddress,$birthdays->join_date);
    
      $userEmail  = sendMail($to,$subject,$from,$fromname,$content);
      }


    }        
            
    
    
     $joining =  DB::table('main_users')->where('main_users.isactive',1)
    ->where(DB::raw("(DATE_FORMAT(main_users.join_date,'%d'))"), "=", $joining_date)->get(); 

    if(isset($joining)){

      foreach($joining as $joinings){

        $date1 = new DateTime($joinings->join_date);
       
           $date2 = new DateTime($currentDate);
  
            $diff = $date1->diff($date2);
  
            $total_month =  (($diff->format('%y') * 12) + $diff->format('%m'));
           
            if($total_month >= 6){
  
              if($total_month % 6 == 0){
  
               $total_month_year =  $diff->format('%y years %m months');

               $subject = $joinings->userfullname . ' Completed '.  $total_month_year;
               $from = 'suitecrm14@gmail.com';
               $fromname = 'Not_reply';

               $content =   birthday($joinings->userfullname,$subject,$joinings->employeeId,$joinings->emailaddress,$joinings->join_date);
    
               $userEmail  = sendMail($to,$subject,$from,$fromname,$content);
             
              }
  
            }
          
  
      }

    }


}

function cancel_leave(Request $request){

  

$update = DB::table('main_leaverequest')->where('id',$request->leave_id)->update(['leavestatus' => 'Cancel']);

  $leave = DB::table('main_leaverequest')->where('id',$request->leave_id)->first();
  


   $user_details = DB::table('main_users')->where('id',$leave->user_id)->first();
   
   $manage = DB::table('main_users')->where('id',$user_details->reporting_manager)->first();
DB::table('main_attendance')->where('user_id',$leave->user_id)->whereDate('entry_date',$leave->from_date)->delete();


       if($leave->leavetypeid == 1){

        $leaveType = "CL";

     }else if($leave->leavetypeid == 2){

      $leaveType = "RH";

     }else{

      $leaveType = "My Leave";

     }


    $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content =   templete_leave_confirmation($user_details->userfullname, date('d M Y', strtotime($leave->from_date)),$leave->appliedleavescount,$leaveType,($leave->leavestatus == 'Cancel')?'Canceled':$leave->leavestatus,$leave->reason);

  
     $userEmail  = sendMail($user_details->emailaddress,$subject,$from,$fromname,$content);
    $userEmail  = sendMail($manage->emailaddress,$subject,$from,$fromname,$content);

    DB::table('main_notification')->insert(['sender_id' =>$user_details->id,'reciver_id' => $user_details->reporting_manager,'msg' => 'Cancel Leave for '. $leave->from_date,'status' => 1]);

  return response()->json(['status' => 200, 'msg' => 'Successfully Cancel Leave']);

}


function export_user(Request $request){



  $user_list = DB::table('main_users')->join('main_roles','main_users.emprole','=','main_roles.id')->where('main_users.emprole','!=',1);

   
    if($request->role == 'active'){
      $user_list->where('main_users.isactive','=',1);
    }
    if($request->role == 'inactive'){
      $user_list->where('main_users.isactive','!=',1);
    }
    if($request->role != 'inactive' && $request->role != 'active' && $request->role != 'all'){
      $user_list->where('main_users.emprole',$request->role);
    }

  

  $user_list = $user_list->select('main_users.*','main_roles.rolename')->get();


  $columns = array('S.No', 'Employee Name', 'Role', 'Email', 'ID','Status');

    
  $filename = public_path("uploads/csv/User_'".time()."'_report.csv");
  $handle = fopen($filename, 'w+');
  fputcsv($handle, $columns);

       $i = 1;
      foreach($user_list as $user_lists) {
        

       if($user_lists->isactive == 1){
        $status = 'Active';

       }elseif($user_lists->isactive == 3){
        $status = 'Resigned';

       }else{
        $status = 'Inactive';

       }

        

         fputcsv($handle, array($i++, ucwords($user_lists->userfullname), $user_lists->rolename, $user_lists->emailaddress, $user_lists->employeeId, $status));
      }
      
     fclose($handle);

     $headers = array(
      'Content-Type' => 'text/csv'
     
      );


  return Response()->download($filename);



}

function project_complete_enddate(){

  $current_date=date('Y-m-d');
  $i = 0;
  $project = DB::table('tm_projects')->where('project_status','in-progress')->get();
  foreach ($project as $key => $projects) {

    if($projects->end_date < $current_date){
      DB::table('tm_projects')->where('id',$projects->id)->update(['project_status' => 'completed']);
    
    }
   
  }

 
}


}