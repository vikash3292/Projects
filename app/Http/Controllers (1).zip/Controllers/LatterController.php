<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
//use Illuminate\Support\Facades\Auth;
use DB;
use Session;
use Auth;
use Mail;
use URL;
use Hash;

use PermissionHelper;
use App\Department;
use Validator;

class LatterController extends Controller
{
   
   
   public function addlatter(){
       
       return view('latter/add_letter');
   }
   
      public function latterhistory(){
       
       return view('latter/latter_history');
   }
   

}
