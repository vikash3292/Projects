<?php



namespace App\Http\Controllers;



use Illuminate\Http\Request;



use Illuminate\Support\Facades\Input;



//use Illuminate\Support\Facades\Auth;



use DB;



use Session;



use Auth;



use Mail;



use URL;



use Hash;



use Validator;



use Illuminate\Support\Str;



use App\Main_users;



use DateTime;





use App\Mail\sendEmail;



use Carbon\Carbon;









class AccountModuleController extends Controller



{

 function client_management(){





 	return view('accountmodule.client_mng');

 }



 public function add_client(){



 	return view('accountmodule.add_client');



 }





    public function get_account_client(Request $request){



        



         $userid = Auth::guard('main_users')->user()->id;



        



        $html = '';



        



        $getAccount = DB::table('main_lead_list')->leftjoin('main_users','main_lead_list.created_by','=','main_users.id')->where('main_lead_list.created_by',$userid)->where('lead_status',5)->select('main_lead_list.*','main_users.userfullname')->get();



        



        $i = 1;



        if(isset($getAccount)){



        foreach($getAccount as $getAccounts){



            



            $edit = URL::to('edit-client').'/'.$getAccounts->id;



             $view = URL::to('view-account').'/'.$getAccounts->id;



            



        $html .='      <tr>



                                                <td>'.$i++.'</td>



                                                <td>'.$getAccounts->company.'</td>



                                                 <td>'.$getAccounts->fname.' '.$getAccounts->lname.'</td>



                                                <td>'.$getAccounts->website.'</td>



                                                <td>'.$getAccounts->phone.'</td>



                                                <td>'.$getAccounts->userfullname.'</td>



                                                <td title="View">



                                                   



                                                    <a href="'.$edit.'"> <i class="mdi mdi-pen text-warning"



                                                            title="Edit"></i></a>



                                                            



                                                    



                                                </td>



                                            </tr>';



        }



        }



        if(count($getAccount) == 0){


             $html .='      <tr>



                                                <td colspan="6">No Record Found</td>


                                            </tr>';

        }



        



        if($getAccount){

            	return response()->json(['status' => 200, 'msg' => 'successfully', 'account' => $html]);


        }else{

            	return response()->json(['status' => 202, 'msg' => 'Not successfully']);


        }



    }



    



      function delete_account_data(Request $request){



           // dd($request->all());



            $get = DB::table('main_lead_list')->where('id',$request->account_lead)->delete();



            DB::table('addition_info')->where('lead_id',$request->account_lead)->delete();



            DB::table('bill_address')->where('lead_id',$request->account_lead)->delete();



             DB::table('shipping_address')->where('lead_id',$request->account_lead)->delete();



             



             return response()->json(['status' => 200, 'msg' => 'successfully Delected']);



            



        } 



function edit_client($id){



	$account_edit = DB::table('main_lead_list')->where('id',$id)->first();



	



	return view('accountmodule.edit_client',['acc_edit' => $account_edit,'client_id' =>$id ]);

}



function edit_account_client(Request $request){

	$arr = array(

     'owner' => $request->lead_ownere,

     'phone' => $request->phone,

     'fname' => $request->fname,

     'company' => $request->company,

     'website' => $request->website,

     'ac_type' => $request->ac_type,

     'street' => $request->address,

     'desc' => $request->desc,

     'lead_status' => 5,



	);



if(isset($request->client_id)){



	DB::table('main_lead_list')->where('id',$request->client_id)->update($arr);

	 	return response()->json(['status' => 200, 'msg' => 'successfully updated']);



}else{



	DB::table('main_lead_list')->insert($arr);

	 	return response()->json(['status' => 200, 'msg' => 'successfully Add']);



}



}





function work_order(){



	$userid = Auth::guard('main_users')->user()->id;

	$getworkorder = DB::table('tm_work_order')->join('main_users','main_users.id','=','tm_work_order.sale_persone')->where('tm_work_order.created_by',$userid)->where('tm_work_order.status',1)->select('tm_work_order.*','main_users.userfullname')->get();



	return view('accountmodule.work_order',['work_order_list' => $getworkorder]);

}



function add_work_order(){



  $userid = Auth::guard('main_users')->user()->id;



  $get_org = DB::table('main_lead_list')->where('owner',$userid)->get();



	return view('accountmodule.add_work_order',['get_org' => $get_org]);



}



function work_order_add(Request $request){

 

  $userid = Auth::guard('main_users')->user()->id;





    if(isset($request->work_id)){





    $arr = array(

         'work_order_name' => $request->work_order_name,

         'work_order_no' => $request->work_order_no,

         'order_date' => $request->work_order_date,

         'work_amt' => $request->work_amt,

         'project_name' => $request->project_name,

         'sale_persone' => $request->sales,

         'status' => $request->status,

         

         

         'updated_by' => $userid,

        

         'updated_at' => date('Y-m-d h:i:s'),



        );



        DB::table('tm_work_order')->where('id',$request->work_id)->update($arr);

    return response()->json(['status' => 200, 'msg' => 'successfully Updated']);



    }else{





    $arr = array(

         'work_order_name' => $request->work_order_name,

         'work_order_no' => $request->work_order_no,

         'work_amt' => $request->work_amt,

         'project_name' => $request->project_name,

         'sale_persone' => $request->sales,

         'status' => $request->status,

         

         'created_by' => $userid,

         'updated_by' => $userid,

         'created_at' => date('Y-m-d h:i:s'),

         'updated_at' => date('Y-m-d h:i:s'),



        );



        DB::table('tm_work_order')->insert($arr);

    return response()->json(['status' => 200, 'msg' => 'successfully Added']);



    }

	

}



function edit_work_order($id){



    $edit_work_order = DB::table('tm_work_order')->where('id',$id)->first();

    $single_milestone = DB::table('work_order_milestone')->where('work_order_id',$id)->orderBy('id','DESC')->first();



return view('accountmodule.edit_work_order',['edit_list' => $edit_work_order,'work_id' => $id,'single_milestone' => $single_milestone ]);

}



function view_work_order($id){





 $milestone = DB::table('work_order_milestone')->where('work_order_id',$id)->get();



    $view_order = DB::table('tm_work_order')->join('main_users','main_users.id','=','tm_work_order.sale_persone')->where('tm_work_order.id',$id)->select('tm_work_order.*','main_users.userfullname')->first();



       $scope_view = DB::table('tm_scope')->join('tm_work_order','tm_work_order.id','=','tm_scope.work_order_id')->join('main_users','main_users.id','=','tm_scope.created_by')->join('main_users as modified','modified.id','=','tm_scope.updated_by')->where('tm_scope.work_order_id',$id)->select('tm_scope.*','main_users.userfullname as created_name','modified.userfullname as modifile_name','tm_work_order.work_order_name')->first();



return view('accountmodule.view_work_order',['view_work' => $view_order,'get_milestone' => $milestone,'work_id' => $id,'scope_view' => $scope_view]);

}



function delete_work_order($id){



DB::table('tm_work_order')->where('id',$id)->delete();

echo "<script>alertify.success('Successfully Delected'); </script>";

return redirect()->back();



}



function send_letter(){



    $user_list = DB::table('main_users')->where('isactive',1)->get();

    $letter_list = DB::table('latter_management')->where('is_active',1)->get();



    return view('accountmodule.add_letter',['user_list' =>$user_list,'letter_list' => $letter_list]);

}



function get_letter(Request $request){



     $letter_list = DB::table('latter_management')->where('id',$request->letter_id)->first();

         return response()->json(['status' => 200, 'letter' => $letter_list->letter]);





}



function send_email(Request $request){



    $user_list = DB::table('main_users')->where('id',$request->users)->first();

     $letter_list = DB::table('latter_management')->where('id',$request->letter)->first();



      $subject = $letter_list->latter_name;

    $from = 'usrivastava@kloudrac.com';

    $fromname = 'no_reply';

    $content = $request->letter_data;

    $sendemail = sendMail($user_list->emailaddress,$subject,$from,$fromname,$content);

    if($sendemail){

   return response()->json(['status' => 200, 'msg' => 'Successfully Send Email']);

    }else{



    	 return response()->json(['status' => 200, 'msg' => 'Not Send Email']);



    }



   



}





function add_milstone_work_order(Request $request){



      $user_id =  Auth::guard('main_users')->user()->id;



    $addArr = array(

      'work_order_id' => $request->work_id,

      'milestone_name' => $request->milestone_name,

      'start_date' => $request->milestone_start_date,

      'end_date' => $request->milestone_end_date,

      'created_by' =>  $user_id,

      'modifed_by' =>  $user_id,

      'created_at' => date('Y-m-d h:i:s'),

      'modifed_at' => date('Y-m-d h:i:s'),

      'color' => $request->milestone_color,

      'description' => $request->milestone_desc,





    );

   if(isset($request->milstone_id)){



    $inst = DB::table('work_order_milestone')->where('id',$request->milstone_id)->update($addArr);

    return response()->json(['status' => 200, 'msg' => 'Successfully Added']);



   }else{



    $inst = DB::table('work_order_milestone')->insert($addArr);

    return response()->json(['status' => 200, 'msg' => 'Successfully Added']);



   }

    



}



function edit_milstone_work_order(Request $request){



        $milestone = DB::table('work_order_milestone')->where('id',$request->milstone_id)->first();



    return response()->json(['status' => 200, 'milstone' => $milestone]);



}



function delete_milstone_work_order(Request $request){



    $del = DB::table('tm_milestone')->where('id',$request->milstone_id)->delete();



    return response()->json(['status' => 200, 'msg' => 'Successfully Deleteed']);





}



function all_milstone_work_order(Request $request){





$get_milestone = DB::table('work_order_milestone')->where('work_order_id',$request->work_id)->orderBy('id','ASC')->get();





$single_milestone = DB::table('work_order_milestone')->where('work_order_id',$request->work_id)->orderBy('id','DESC')->first();





$html = '';

$i = 1;

foreach ($get_milestone as $key => $get_milestones) {

    $html .= '<tr>

    <td>'.$i++.'</td>

    <td>'.$get_milestones->milestone_name.'</td>

    <td>'.$get_milestones->color.'</td>

    <td>'.$get_milestones->start_date.'</td>

    <td>'.$get_milestones->end_date.'</td>

    <td>'.substr($get_milestones->description,0,20).'</td>';





    $html .= '<td>';

  

    



    $html .= '<i  onclick="edit_milstonr('.$get_milestones->id.')" class="mdi mdi-pencil text-warning" data-toggle="tooltip" title="" data-original-title="Edit"></i>';



 if($get_milestones->id == $single_milestone->id){



$html .= '<i onclick="delete_milstonr(this,'.$get_milestones->id.')" class="fa fa-trash font-blue" data-toggle="tooltip" title="" data-original-title="Delete"></i>';



                                                     

    }





    $html .= '</td></tr>';

}





return response()->json(['status' => 200, 'milstone' => $html]);









}





function get_last_work_order(Request $request){





        $milestone = DB::table('work_order_milestone')->where('work_order_id',$request->work_id)->orderBy('id','DESC')->first();

        if(isset($milestone) && !empty($milestone)){



            return response()->json(['status' => 200, 'milstone' => $milestone->end_date]);





        }else{



            return response()->json(['status' => 201, 'milstone' => '']);





        }

        



}



function add_new_project_work_order(Request $request){







     $user_id =  Auth::guard('main_users')->user()->id;



     //    $project_name = DB::table('tm_projects')->where('project_name',$request->project)->count();



     // if($project_name > 0){



     //           return response()->json(['status' => 202, 'msg' => ' Project Allready Exist']);



     //          }





       $project12 = array(



           'project_name' => $request->project,



            'project_status' => $request->project_status,



             'base_project' => $request->base_project,



              'project_category' => $request->category,



               'builder' => $request->builder,

               'location' => $request->location,

               'project_temp_id' => $request->project_temp_id,

               'temp_id' => $request->temp_id,

               'work_order_no' => $request->work_order_no,

               'description' => $request->project,



                'client_id' => $request->project_client,



                'currency_id' => $request->currecy,



                 'project_type' => $request->checkval,



                  'estimated_hrs' => $request->estimated,



                   'start_date' => $request->from_date,



                   'end_date' => $request->to_date,



                   'created_by' => $user_id,



                   'modified_by' => $user_id,



                   'manager_id' => $request->manager,

                   'coordinator' => $request->coordinator,

                   'stage' => $request->stage,



                   'is_active' => 1,



                   'created' => date('Y-m-d h:i:s'),



                   'modified' => date('Y-m-d h:i:s'),



           



           );



       



             $lastinstid = DB::table('tm_projects')->insertGetId($project12);

      

             $lastinstid = DB::getPdo()->lastInsertId();

   

            



           if($lastinstid){



            $get_work_mistone = DB::table('work_order_milestone')->where('work_order_id',$request->work_id)->get();



            foreach ($get_work_mistone as $key => $get_work_mistones) {

                

                $addArr = array(

      'project_id' => $lastinstid,

      'milestone_name' => $get_work_mistones->milestone_name,

      'start_date' => $get_work_mistones->start_date,

      'end_date' => $get_work_mistones->end_date,

      'created_by' =>  $user_id,

      'modifed_by' =>  $user_id,

      'created_at' => date('Y-m-d h:i:s'),

      'modifed_at' => date('Y-m-d h:i:s'),

      'color' => $get_work_mistones->color,

      'description' => $get_work_mistones->description,

    );



                    $inst = DB::table('tm_milestone')->insert($addArr);



            }



               



               $addmanager = array(



                   'project_id' => $lastinstid,



                   'emp_id' => $request->manager,



                   'manager_id' => 1,



                   'created_by' => $user_id,



                   'modified_by' =>  $user_id,



                   'is_active' => 1,



                   'created' => date('Y-m-d h:i:s'),



                   'modified' =>  date('Y-m-d h:i:s'),



                   



                   );



               $folder = array(

              'project_id' => $lastinstid,

              'folder_name' => $request->project,

              'created_by' => $user_id,

              'create_at' => date('Y-m-d h:i:s')



                );



                  DB::table('tm_folder')->insert($folder);



    



          DB::table('tm_project_employees')->insert($addmanager);



          



           $addcreator = array(



                   'project_id' => $lastinstid,



                   'emp_id' => $user_id,



                   'created_by' => $user_id,



                   'modified_by' =>  $user_id,



                   'manager_id' => 2,



                   'is_active' => 1,



                   'created' => date('Y-m-d h:i:s'),



                   'modified' =>  date('Y-m-d h:i:s'),



                   



                   );



                 

                 DB::table('tm_project_employees')->insert($addcreator);

                 DB::table('tm_work_order')->where('id',$request->work_id)->update(['status' => 2]);



                 return response()->json(['status' => 200, 'msg' => 'Successfully add Project','project_id'=>$lastinstid]);



               



           }else{



               



         return response()->json(['status' => 201, 'msg' => 'Not add Project']);



               



           }



        



}



function scope_of_work(){



  $scopelist = DB::table('tm_scope')->join('tm_work_order','tm_work_order.id','=','tm_scope.work_order_id')->join('main_users','main_users.id','=','tm_scope.created_by')->join('main_users as modified','modified.id','=','tm_scope.updated_by')->select('tm_scope.*','main_users.userfullname as created_name','modified.userfullname as modifile_name','tm_work_order.work_order_name')->get();



  return view('accountmodule.scope_of_work',['scope_list' =>$scopelist]);

}



function add_scope(){





     $user_id =  Auth::guard('main_users')->user()->id;



     $work_order = DB::table('tm_work_order')->where('created_by',$user_id)->get();



  return view('accountmodule.add_scope',['work_order' => $work_order]);



}



function insert_scope(Request $request){



   $user_id =  Auth::guard('main_users')->user()->id;



   if(isset($request->scope_id)){



      DB::table('tm_scope')->where('id',$request->scope_id)->update([

  'scope_name' => $request->scope_name,

  'work_order_id' => $request->work_order,

  'org_name' => $request->org_name,

  'contact_no' => $request->content_no,

  

  'updated_by' => $user_id,

 

  'modifiled_at' => date('Y-m-d h:i:s'),

  





  ]);



   }else{



      DB::table('tm_scope')->insert([

  'scope_name' => $request->scope_name,

  'work_order_id' => $request->work_order,

  'org_name' => $request->org_name,

  'contact_no' => $request->content_no,

  'created_by' => $user_id,

  'updated_by' => $user_id,

  'created_at' => date('Y-m-d h:i:s'),

  'modifiled_at' => date('Y-m-d h:i:s'),

  





  ]);



   }









         return response()->json(['status' => 200, 'msg' => 'Successfully Added']);



     



}



function view_scope($id){



    $view_scope = DB::table('tm_scope')->join('tm_work_order','tm_work_order.id','=','tm_scope.work_order_id')->join('main_users','main_users.id','=','tm_scope.created_by')->join('main_users as modified','modified.id','=','tm_scope.updated_by')->where('tm_scope.id',$id)->select('tm_scope.*','main_users.userfullname as created_name','modified.userfullname as modifile_name','tm_work_order.work_order_name')->first();





   return view('accountmodule.view_scope',['view_scope' => $view_scope]);





}



function edit_scope($id){

  $user_id =  Auth::guard('main_users')->user()->id;



   $work_order = DB::table('tm_work_order')->where('created_by',$user_id)->get();





    $edit_scope = DB::table('tm_scope')->where('tm_scope.id',$id)->first();

   return view('accountmodule.edit_scope',['edit_scope' => $edit_scope,'work_order' => $work_order,'scope_id' => $id]);





}



function delete_scope($id){



DB::table('tm_scope')->where('id',$id)->delete();

return redirect()->back();



}



function expense(){





 $project_list = [];

  $user_id =  Auth::guard('main_users')->user()->id;

  $role =  Auth::guard('main_users')->user()->emprole;





  if(!empty($_GET['user'])){

      $project_list = DB::table('tm_project_employees')->join('tm_projects','tm_projects.id','=','tm_project_employees.project_id')->where('tm_project_employees.emp_id','=',$_GET['user'])->orderBy('tm_projects.project_name','ASC')->select('tm_projects.*')->get();

  }

  
  $user_list = DB::table('main_users')->where('isactive',1)->orderby('userfullname','ASC');
  if($role !=1 && $role != 11 && $role != 4){
   $user_list->where('id',$user_id);   
  }
  
  $user_list = $user_list ->get();



  $expense_list = DB::table('expenses')->leftjoin('tm_projects','tm_projects.id','=','expenses.project_id')->leftjoin('main_users','main_users.id','=','expenses.createdby');

  if($role !=1 && $role !=11 && $role !=4){

   $expense_list->where('expenses.createdby',$user_id);

  }
  

 if(!empty($_GET['user'])){

if($_GET['user'] != 'all'){
  $expense_list->where('expenses.createdby',$_GET['user']);
}
 
$expense_list->where(DB::raw("(DATE_FORMAT(expenses.expense_date,'%Y'))"), "=", $_GET['year']);


 }
 
 if(!empty($_GET['project'])){
     
      $expense_list->where('tm_projects.id',$_GET['project']);
 }
 
  if(!empty($_GET['status'])){
     
      $expense_list->where('expenses.status',$_GET['status']);
 }
 
  if(!empty($_GET['month'])){
     
      $expense_list->where(DB::raw("(DATE_FORMAT(expenses.expense_date,'%m'))"), "=", $_GET['month']);
 }
 
   if(!empty($_GET['expense_date'])){
     
      $expense_list->where(DB::raw("(DATE_FORMAT(expenses.expense_date,'%Y-%m-%d'))"), "=", $_GET['expense_date']);
 }
 
   if(!empty($_GET['reimbursable_date'])){
     
      $expense_list->where(DB::raw("(DATE_FORMAT(expenses.modifieddate,'%Y-%m-%d'))"), "=", $_GET['reimbursable_date']);
 }



  $expense_list = $expense_list->orderBy('expenses.id','DESC')->select('expenses.*','tm_projects.project_name','main_users.userfullname')->get();
  foreach($expense_list as $expense_lists){
    $exp = [];
    $appval_date = [];
     $expense_approval = DB::table('expense_approval')->where('expense_id' , $expense_lists->id);
     
      if(!empty($_GET['manager_date'])){
     
      $expense_approval->where(DB::raw("(DATE_FORMAT(expense_approval.created_at,'%Y-%m-%d'))"), "=", $_GET['manager_date'])->where('expense_approval.user_type',1);
      }
      
      
       if(!empty($_GET['account_date'])){
     
      $expense_approval->where(DB::raw("(DATE_FORMAT(expense_approval.created_at,'%Y-%m-%d'))"), "=", $_GET['account_date'])->where('expense_approval.user_type',2);
      }
     
     $expense_approval = $expense_approval->get(); 
      foreach($expense_approval as $expense_approvals){
        $exp[] = $expense_approvals->status;
        $appval_date[] = $expense_approvals->created_at; 
      }
     $expense_lists->approaval_status = $exp;
     $expense_lists->approaval_date = $appval_date;
     unset($exp);
     unset($appval_date);
  }
  
  if($role ==1 || $role == 11){
      
        $expense_data = [];
  foreach($expense_list as $expense_listss){
      if(empty($expense_listss->approaval_status) && $expense_listss->status !='saved'){
          $expense_data[] = $expense_listss;
      }elseif(!empty($expense_listss->approaval_status) && $expense_listss->approaval_status[0] == 'approved' && $expense_listss->status !='saved'){
           $expense_data[] = $expense_listss;
     
          
      }
  }
  
  $expense_list = $expense_data;
      
  }
  $expense_approval_other = [];
  if($role ==3){
    
     $expense_approval_other = DB::table('expense_approval')->join('expenses','expenses.id','=','expense_approval.expense_id')->join('main_users','main_users.id','=','expenses.createdby')->where('expense_approval.approvel_user_id',$user_id)->orderBy('expenses.id','DESC')->select('expenses.*','expense_approval.status as aproval_status','expense_approval.id as approval_id','main_users.userfullname')->get();
     
     foreach($expense_approval_other as $expense_lists){
    $exp1 = [];
    $appval_date1 = [];
     $expense_approval = DB::table('expense_approval')->where('expense_id' , $expense_lists->id)->get(); 
      foreach($expense_approval as $expense_approvals){
        $exp1[] = $expense_approvals->status;
        $appval_date1[] = $expense_approvals->created_at; 
      }
     $expense_lists->approaval_status = $exp1;
     $expense_lists->approaval_date = $appval_date1;
     unset($exp1);
     unset($appval_date1);
     }
  }
  

  


   

  if(!empty($_GET['export'])){



    $columns = array('S.No', 'Employee', 'Expense', 'Project', 'Apply Date','Expense Date','R Amount','Amount','Status');

    
    $filename = public_path("uploads/csv/expenses_'".time()."'_report.csv");
    $handle = fopen($filename, 'w+');
    fputcsv($handle, $columns);

         $i = 1;
        foreach($expense_list as $expenses) {
          $created = date('d-M-Y',strtotime($expenses->createddate));
          $expensed = date('d-M-Y',strtotime($expenses->expense_date));


           fputcsv($handle, array($i++, ucwords($expenses->userfullname), $expenses->expense_name, $expenses->project_name??'', $created, $expensed,$expenses->reimbursed_ammount??0,$expenses->expense_amount,$expenses->status));
        }
        
       fclose($handle);

       $headers = array(
        'Content-Type' => 'text/csv'
       
        );


    return Response()->download($filename);
 


   }



  foreach($expense_list as $expense_lists){
    $expense_lists->reciept = DB::table('expense_receipts')->where('expense_id',$expense_lists->id)->groupBy('receipt_name')->get();
  }


  

  return view('accountmodule.expenses_list',['userlist' => $user_list,'expense_list' => $expense_list, 'project_list' => $project_list,'expense_approval_other' =>  $expense_approval_other]);





}



function get_user_project(Request $request){





  $project_list = DB::table('tm_project_employees')->join('tm_projects','tm_projects.id','=','tm_project_employees.project_id')->where('tm_project_employees.emp_id','=',$request->user_id)->select('tm_projects.*')->get();



  $html = '';

   $html .= '<option value="">Select Option</option>';

  foreach ($project_list as $key => $project_list) {

   $html .= '<option value='.$project_list->id.'>'.$project_list->project_name.'</option>';

  }



       return response()->json(['status' => 200, 'project' => $html]);





}



function add_expense(){



    $user_id =  Auth::guard('main_users')->user()->id;





  $project_list = DB::table('tm_project_employees')->join('tm_projects','tm_projects.id','=','tm_project_employees.project_id')->where('tm_project_employees.emp_id','=',$user_id)->where('tm_projects.project_status','!=','completed')->orderBy('tm_projects.project_name','ASC')->select('tm_projects.*')->get();





   return view('accountmodule.add_expenses',['project_list' => $project_list]);





}



function all_trip(Request $request){



  $get_trip = DB::table('expense_trips')->get();



  $html = '';

   $html .= '<option value="">Select Option</option>';

  foreach ($get_trip as $key => $get_trips) {

   $html .= '<option value='.$get_trips->id.'>'.$get_trips->trip_name.'</option>';

  }



       return response()->json(['status' => 200, 'trip' => $html]);





}



function add_trip(Request $request){



    $user_id =  Auth::guard('main_users')->user()->id;





  $arr = array(

    'trip_name' => $request->trip_name,

    'from_date' => $request->from_date,

    'to_date' => $request->to_date,

    'description' => $request->desc,

    'createdby' => $user_id,

    'modifiedby' => $user_id,
    'isactive' => 1,

    'createddate' => date('Y-m-d h:i:s'),

    'modifieddate' => date('Y-m-d h:i:s'),





  );



  DB::table('expense_trips')->insert( $arr);



    return response()->json(['status' => 200, 'msg' => 'Successfully Added']);





}



function insert_expeses(Request $request){



      $user_id =  Auth::guard('main_users')->user()->id;
      $manager_id =  Auth::guard('main_users')->user()->reporting_manager;
      $accountant = DB::table('main_users')->where('emprole',11)->orderBy('id','DESC')->select('id')->first();
    


        $arr = array(

       
          'project_id' => $request->project_list,

          'expense_voucher_number' => vouchar_no(),

          'expense_name' => $request->expenses_name,

          'expense_date' => $request->expenses_date,

          'expense_amount' => $request->expenses_amt,
         
          'expense_currency_id' => $request->currency,
          'certification' => $request->certification??'',

          'category_id' => $request->category,
          'reimbursed_ammount' => $request->reimbursable_amt,
          'is_reimbursable' =>$request->reim,

        
          'is_from_advance' => $request->advance,

          'trip_id' => $request->trip,

          'description' => $request->desc,
         
          'status' => ($request->submit_status == 2)?'submitted' : 'saved',
          
          'createdby' => $user_id,

          'modifiedby' => $user_id,

          'createddate' => date('Y-m-d h:i:s'),

          'modifieddate' => date('Y-m-d h:i:s'),
          'isactive' => 1,
          'submit_status' => $request->submit_status,

        );

if($request->submit_status == 2){

 $username = Auth::guard('main_users')->user()->userfullname;
 $status = ($request->submit_status == 2)?'submitted' : 'saved';

  $subject = 'No Reply - Kloudrac HRMS';
  $from = 'suitecrm14@gmail.com';
  $fromname = 'Not_reply';
  $content = expense_request($username,vouchar_no(),$request->expenses_name,$request->expenses_date,$request->desc,$status);

  $userEmail  = sendMail(Auth::guard('main_users')->user()->emailaddress,$subject,$from,$fromname,$content);

      

}
        
   

        if(isset($request->expense_id)){

         

          $inst  = DB::table('expenses')->where('id',$request->expense_id)->update($arr);
          
           if($request->submit_status == 2){
            
            DB::table('expense_approval')->insert(['expense_id' =>$request->expense_id,'approvel_user_id' => $manager_id,'view' => 1,'user_type' => 1,'created_at' =>date('Y-m-d h:i:s')]);
             DB::table('expense_approval')->insert(['expense_id' =>$request->expense_id,'approvel_user_id' => $accountant->id,'user_type' => 2,'created_at' =>date('Y-m-d h:i:s')]);
         }

            DB::table('tm_expenses_timeline')->insert(['user_id' =>$user_id,'expense_id' =>$request->expense_id,'msg' =>($request->submit_status ==1)?'Save This expense':'Submited This expense' ]);

            return response()->json(['status' => 201, 'msg' => 'Successfully Updated']);


        }else{



          $inst  = DB::table('expenses')->insertGetId($arr);

           if($request->submit_status == 2){
         
           DB::table('expense_approval')->insert(['expense_id' =>$inst,'approvel_user_id' => $manager_id,'view' => 1,'user_type' => 1,'created_at' =>date('Y-m-d h:i:s')]);
           DB::table('expense_approval')->insert(['expense_id' =>$inst,'approvel_user_id' => $accountant->id,'user_type' => 2,'created_at' =>date('Y-m-d h:i:s')]);
           }
         
      if($request->hasFile('receipt')) {

        foreach($request->file('receipt') as $file){



        $original_name = strtolower(trim($file->getClientOriginalName()));

          $ext = $file->getClientOriginalExtension();

          $name = time().rand(100,999).$original_name;

        $file->move(public_path().'/uploads/expenses_receipts/', $name);

        $filename =  $name;

        $array = array(
          'expense_id' => $inst,
          'receipt_name' => $original_name,
          'receipt_filename' => $name,
          'receipt_file_type' => $ext,
          'createdby' => $user_id,
          'modifieddate' => date('Y-m-d h:i:s'),
          'isactive' => 1,

        );

        DB::table('expense_receipts')->insert($array);


     }

     }




          DB::table('tm_expenses_timeline')->insert(['user_id' =>$user_id,'expense_id' =>$inst,'msg' =>($request->submit_status ==1)?'Save This expense':'Submited This expense' ]);



            if($inst){



              return response()->json(['status' => 200, 'msg' => 'Successfully Added']);


        }else{



              return response()->json(['status' => 201, 'msg' => 'Not Successfully Added']);


        }



        }


}



function update_r_amt(Request $request){




      $user_id =  Auth::guard('main_users')->user()->id;





  DB::table('expenses')->where('id',$request->expenses_id)->update(['reimbursed_ammount' => $request->r_amount,'modifiedby' => $user_id]);

   DB::table('tm_expenses_timeline')->insert(['user_id' =>$user_id,'expense_id' =>$request->expenses_id,'msg' =>'Reimbursable Amount Updated']);

    return response()->json(['status' => 200, 'msg' => 'Successfully Updated']);



}



function update_status_expeses(Request $request){

    

    $user_id =  Auth::guard('main_users')->user()->id;



    DB::table('expenses')->where('id',$request->exp_id)->update(['status' => $request->status,'modifiedby' => $user_id]);

    

    DB::table('tm_expenses_timeline')->insert(['user_id' =>$user_id,'expense_id' =>$request->exp_id,'msg' =>'Status have Changed']);
 
     $expense = DB::table('expenses')->join('main_users','main_users.id','=','expenses.createdby')->where('expenses.id',$request->exp_id)->select('expenses.*','main_users.userfullname','main_users.emailaddress')->first();
   
    $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content = expense_confarmation($expense->userfullname,$expense->expense_voucher_number	,$expense->expense_name,$expense->expense_date,$expense->description,$expense->status);
  
    $userEmail  = sendMail($expense->emailaddress,$subject,$from,$fromname,$content);
  
   
    return response()->json(['status' => 200, 'msg' => 'Successfully Updated']);





}



function edit_expenses($id){



      $user_id =  Auth::guard('main_users')->user()->id;


  $project_list = DB::table('tm_project_employees')->join('tm_projects','tm_projects.id','=','tm_project_employees.project_id')->where('tm_project_employees.emp_id','=',$user_id)->select('tm_projects.*')->get();



  $expense_edit = DB::table('expenses')->where('id',$id)->first();

 
    $expense_edit->reciept = DB::table('expense_receipts')->where('expense_id',$expense_edit->id)->groupBy('receipt_name')->get();
  





   return view('accountmodule.edit_expenses',['project_list' => $project_list,'expense_edit' => $expense_edit,'expense_id' => $id]);







}



function view_expenses($id){



    $user_id =  Auth::guard('main_users')->user()->id;

  $expense_view = DB::table('expenses')->leftjoin('tm_projects','tm_projects.id','=','expenses.project_id')->leftjoin('main_users','main_users.id','=','expenses.createdby')->leftjoin('expense_categories','expense_categories.id','=','expenses.category_id')->leftjoin('expense_trips','expense_trips.id','=','expenses.trip_id')->where('expenses.id','=',$id)->select('expenses.*','tm_projects.project_name','main_users.userfullname','expense_categories.expense_category_name as cat_name','expense_trips.trip_name as trip')->first();


    $exp = [];
    $approval_date = [];
     $expense_approval = DB::table('expense_approval')->where('expense_id' , $expense_view->id)->get(); 
      foreach($expense_approval as $expense_approvals){
        $exp[] = $expense_approvals->status;
        $approval_date[] = $expense_approvals->created_at;
      }
     $expense_view->approaval_status = $exp;
     $expense_view->approaval_date = $approval_date;

 

  $expense_view->reciept = DB::table('expense_receipts')->where('expense_id',$expense_view->id)->groupBy('receipt_name')->get();


  $expense_timeline = DB::table('tm_expenses_timeline')->join('expenses','expenses.id','=','tm_expenses_timeline.expense_id')->join('main_users','main_users.id','=','tm_expenses_timeline.user_id')->where('tm_expenses_timeline.expense_id',$id)->select('tm_expenses_timeline.*','main_users.userfullname')->get();





   return view('accountmodule.view_expenses',['expense_view' => $expense_view,'expense_id' => $id,'expense_timeline' => $expense_timeline ]);



}



function delete_expenses($id){



  DB::table('expenses')->where('id',$id)->delete();

 return redirect()->back();

}

function expenses_approvel(Request $request){


  $nsid = json_decode($request->expenses);

  
    if($request->status == 'Approve'){
  

   foreach ($nsid as $key => $nsids) {
    
  
 
   $req_daitails = DB::table('expense_approval')->join('expenses','expenses.id','=','expense_approval.expense_id')->join('main_users','main_users.id','=','expenses.createdby')->where('expense_approval.id',$nsids)->where('expense_approval.status','pending')->orderBy('expenses.id','DESC')->select('expenses.*','expense_approval.status as aproval_status','expense_approval.id as approval_id','main_users.userfullname','main_users.emailaddress','expense_approval.approvel_user_id')->first();
    
   

  $status = 'approved';
  $update = DB::table('expense_approval')->where('id',$nsids)->update(['status' =>$status,'view' => 1,'created_at'=> date('Y-m-d h:i:s') ]);
            DB::table('expense_approval')->where('expense_id',$req_daitails->id)->update(['view' => 1]);
    $update = DB::table('expenses')->where('id',$req_daitails->id)->update(['status' =>$status ]);
  

   $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content = expense_confarmation($req_daitails->userfullname,$req_daitails->expense_voucher_number	,$req_daitails->expense_name,$req_daitails->expense_date,$req_daitails->description,$status );
  
 
    //dd($userdetails->emailaddress);
  
    $userEmail  = sendMail($req_daitails->emailaddress,$subject,$from,$fromname,$content);

 
 }


  return response()->json(['status' => 200, 'msg' => 'Successfully Approved']);

}


 if($request->status == 'reject'){
  
  $status = 'rejected';
   foreach ($nsid as $key => $nsids) {

    $req_daitails = DB::table('expense_approval')->join('expenses','expenses.id','=','expense_approval.expense_id')->join('main_users','main_users.id','=','expenses.createdby')->where('expense_approval.id',$nsids)->where('expense_approval.status','pending')->orderBy('expenses.id','DESC')->select('expenses.*','expense_approval.status as aproval_status','expense_approval.id as approval_id','main_users.userfullname','main_users.emailaddress','expense_approval.approvel_user_id')->first();
    $update = DB::table('expense_approval')->where('id',$nsids)->update(['status' =>$status ,'created_at'=> date('Y-m-d h:i:s') ]);
 
      $update = DB::table('expenses')->where('id',$req_daitails->id)->update(['status' =>$status ]);
    


    
       $subject = 'No Reply - Kloudrac HRMS';
    $from = 'suitecrm14@gmail.com';
    $fromname = 'Not_reply';
    $content = expense_confarmation($req_daitails->userfullname,$req_daitails->expense_voucher_number	,$req_daitails->expense_name,$req_daitails->expense_date,$req_daitails->description,$status);
  
    $userEmail  = sendMail($req_daitails->emailaddress,$subject,$from,$fromname,$content);

  
    
 }

 return response()->json(['status' => 200, 'msg' => 'Successfully Rejected']);

 }




}

function expense_approval_indivial(Request $request){
    
     $user_id =  Auth::guard('main_users')->user()->id;
     $exp_id = $request->exp_id;
     $status = $request->status;
     if($status == 1){
         DB::table('expense_approval')->where('expense_id',$exp_id)->where('approvel_user_id',$user_id)->update(['status' => 'approved','created_at' => date('Y-m-d h:i:s')]);
           DB::table('expense_approval')->where('expense_id',$exp_id)->update(['view' =>1]);
           DB::table('expenses')->where('id',$exp_id)->update(['status' =>'approved']);
          return response()->json(['status' => 200, 'msg' => 'Successfully approved']);

     }
     
       if($status == 2){
         DB::table('expense_approval')->where('expense_id',$exp_id)->where('approvel_user_id',$user_id)->update(['status' => 'rejected' ,'created_at' => date('Y-m-d h:i:s')]);
           DB::table('expenses')->where('id',$exp_id)->update(['status' =>'rejected']);
             return response()->json(['status' => 200, 'msg' => 'Successfully rejected']);
     }
     
    
}



}