<?php

namespace App\Http\Controllers;
namespace Illuminate\Support\Facades;
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;


//use Illuminate\Support\Facades\Auth;
use DB;
use Session;
//use Input;
use Mail;
use URL;
use Hash;
use Auth;
use Validator;
use App\Main_users;
use App\Mail\sendEmail;
use Carbon\Carbon;

class OrgController extends Controller
{
    
    
        private function customMsg(){
        
        return $customMessages = [
        
        'required' => 'This  field is required.',
        'emailaddress.required' => 'this is Email for required',
        
    ];
    }


public function list_org(){
    
    $listorg = DB::table('org')->where('status',1)->get();
   //d($vieworg);
    
    return view('org.listorg',['vieworg' => $listorg]);
    
}

public function view_org($id){
    
  $listorg = DB::table('org')->where('id',$id)->where('status',1)->first();
    
  return view('org.vieworg',['vieworg' => $listorg]);
    
}

public function edit_org($id){
    
      $editorg = DB::table('org')->where('id',$id)->where('status',1)->first();
     
      return view('org.editorg',['editworg' => $editorg]);
    
}

public function add_org(Request $request){
    
    $viewmodule = DB::table('site_menu')->where('is_active',1)->whereNotIn('id',[86,89])->where('parent_menu_id',0)->get();
    $randno = org_number();
    $userid = Auth::guard('main_users')->user()->id;
    
           if($request->isMethod('post')) 
       { 
           
         
           
           $validator = Validator::make($request->all(), [
            'orgname' => 'required',
            'offeialname' => 'required',
             'licenseno' => 'required',
              'term' => 'required',
               'orgemail' => 'unique:org,email|required',
                'gstno' => 'required',
                 'totalemp' => 'required',
                  'customertype' => 'required',
                   'pan_no' => 'required',
                    'face_icon' => 'required',
                     'small_icon' => 'required',
                      'large_icon' => 'required',
                       'module' => 'required',
                        'org_desc' => 'required',
                         'country' => 'required',
                          'state' => 'required',
                           'city' => 'required',
                            'phone' => 'required',
                             'strret' => 'required', 
                             'zip_code' => 'required',
            
        ],$this->customMsg());

         if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }
        
             if($request->hasFile('face_icon')) {
           $file = $request->file('face_icon');

             $original_name = strtolower(trim($file->getClientOriginalName()));
             $name = time().rand(100,999).$original_name;

           //using the array instead of object
           //$image['filePath'] = $name;
           $file->move(public_path().'/uploads/attach/', $name);
           $fav_icone = '/uploads/attach/'. $name;
          // $user->save();
        }else{
            
            $fav_icone = '';
            
        }
        
              if($request->hasFile('small_icon')) {
           $file = $request->file('small_icon');

             $original_name = strtolower(trim($file->getClientOriginalName()));
             $name = time().rand(100,999).$original_name;

           //using the array instead of object
           //$image['filePath'] = $name;
           $file->move(public_path().'/uploads/attach/', $name);
           $small_icone = '/uploads/attach/'. $name;
          // $user->save();
        }else{
            
            $small_icone = '';
            
        }
        
              if($request->hasFile('large_icon')) {
           $file = $request->file('large_icon');

             $original_name = strtolower(trim($file->getClientOriginalName()));
             $name = time().rand(100,999).$original_name;

           //using the array instead of object
           //$image['filePath'] = $name;
           $file->move(public_path().'/uploads/attach/', $name);
           $large_icone = '/uploads/attach/'. $name;
          // $user->save();
        }else{
            
            $large_icone = '';
            
        }
        
        $addorg = array(
            
            'org_name' => $request->orgname,
             'org_code' => $request->orgname,
              'phone' => $request->phone,
               'email' => $request->orgemail,
                'gst_no' => $request->gstno,
                 'pan_no' => $request->pan_no,
                 'total_emp' =>$request->totalemp, 
                  'term' => $request->term,
                   'fav_icon' => $fav_icone,
                    'small_logo' => $small_icone,
                     'large_logo' => $large_icone,
                      'no_of_user' => $request->licenseno,
                       'module' => json_encode($request->module), 
                       'org_desc' => $request->org_desc,
                        'country' => $request->country,
                         'state' => $request->state,
                          'city' => $request->city,
                           'street' => $request->strret,
                            'zip_code' => $request->zip_code, 
                            'created_by' => $userid,
                             'updated_by' => $userid,
                              'created_at' => date('Y-m-d H:i:s'),
                              'updated_at' => date('Y-m-d H:i:s'),
                              'official_name' => $request->offeialname,
                              'customer_type' => $request->customertype,
                              'status' => 1,
            );
            
            $inst = DB::table('org')->insert($addorg);
            if($inst){
                
            redirect('/view-org')->with('msg','Successfully Added Orgnazation')->with('alert','success');
                
            }else{
                
                redirect('/add-org')->with('msg','Not Added Orgnazation')->with('alert','danger');
                
            }
            
            
        
       }
    
    return view('org.addorg',['modulelist' => $viewmodule,'unique' => $randno]);
    
}





}
