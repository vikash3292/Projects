<?php



namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Input;

//use Illuminate\Support\Facades\Auth;

use DB;

use Session;

use Auth;

use Mail;

use URL;

use Hash;

use Validator;

use Illuminate\Support\Str;

use App\Main_users;



class AppraisalController extends Controller

{



	public function appraisal_list(){



		$user_id =  Auth::guard('main_users')->user()->id;

  $position_id =  Auth::guard('main_users')->user()->position_id;

  

  //$kra_form = DB::table('kra_master')->join('main_positions','kra_master.designation','=','main_positions.id')->where('kra_master.designation',$position_id)->select('kra_master.*','main_positions.positionname')->get();

  

  $kra_form = DB::table('appraisal_assign_form_user')->join('main_users','appraisal_assign_form_user.user_id','=','main_users.id')->join('appraisal_master','appraisal_assign_form_user.form_id','appraisal_master.id')->join('main_positions','appraisal_master.designation','=','main_positions.id')->where('appraisal_assign_form_user.user_id',$user_id)->select('appraisal_master.*','main_positions.positionname','main_users.userfullname','appraisal_assign_form_user.id as appraisal_assign_id')->get();

  foreach($kra_form  as $user_appraisals){



    $user_appraisals->user_fill = DB::table('appraisal_form')->where('assign_id',$user_appraisals->appraisal_assign_id)->where('created_by','!=','')->count();

    $user_appraisals->manager_fill = DB::table('appraisal_form')->where('assign_id',$user_appraisals->appraisal_assign_id)->where('updated_by','!=','')->count();

  



  }







  return view('appraisal.appraisal_list',['form' => $kra_form]);



	

    }

    



    function appraisal_form($form_id,$assign_id){



        
   $assgin_date = DB::table('appraisal_assign_form_user')->join('main_users','appraisal_assign_form_user.user_id','=','main_users.id')->where('appraisal_assign_form_user.id',$assign_id)->select('main_users.reporting_manager')->first();

     

        $assign_form = DB::table('appraisal_assign_form_user')->where('id',$assign_id)->first();



        $count  = DB::table('appraisal_form')->where('form_id',$form_id)->where('assign_id',$assign_id)->count();

 

         if($count > 0){



          $edit = DB::table('appraisal_form')->where('form_id',$form_id)->where('assign_id',$assign_id)->first();

          $get_qiestion = DB::table('appraisal_question')->where('form_id',$form_id)->get();



          return view('appraisal.appraisal_form',['count' => $count ,'edit' => $edit,'assign' => $assign_form ,'question' => $get_qiestion ,'form_id' => $form_id,'assign_id'=> $assign_id ,'mng' => $assgin_date->reporting_manager]);





         }else{



          $get_qiestion = DB::table('appraisal_question')->where('form_id',$form_id)->get();



          return view('appraisal.appraisal_form',['count' => $count ,'assign' => $assign_form ,'question' => $get_qiestion ,'form_id' => $form_id,'assign_id'=> $assign_id,'mng' => $assgin_date->reporting_manager]);



 



         }

        

         





     





    }



	public function appraisal_fill_form($id){





        $year = date('Y');





        $appraisalform = DB::table('appraisal_form')->where('status',1)->get();



          $appraisalfilledform = DB::table('users_appraisal_form')->where('appraisal_list_id','=',$id)->where(DB::raw("(DATE_FORMAT(users_appraisal_form.date,'%Y'))"), "=",$year)->first();







		return view('appraisal.appraisal_form_fill',['appraisalform' =>$appraisalform,'appraisal_request_id' => $id,'appraisalfilledform' => $appraisalfilledform ]);

	}



		public function user_appraisal_list(){



			$user_id = Auth::guard('main_users')->user()->id;





     $appraisal =[];

      $user_appraisal = DB::table('appraisal_assign_form_user')->join('main_users','appraisal_assign_form_user.user_id','=','main_users.id')->join('appraisal_master','appraisal_assign_form_user.form_id','=','appraisal_master.id')->join('main_positions','appraisal_master.designation','=','main_positions.id')->whereRaw("find_in_set('".$user_id."',appraisal_assign_form_user.show_user_id)")->select('appraisal_master.*','main_positions.positionname','main_users.userfullname','main_users.id as user_id','appraisal_assign_form_user.id as appraisal_assign_id')->get();

     

      foreach($user_appraisal as $user_appraisals){

        $user_appraisals->user_fill = DB::table('appraisal_form')->where('assign_id',$user_appraisals->appraisal_assign_id)->count();

        if($user_appraisals->user_fill > 0){

          $appraisal[] = $user_appraisals;

        }

        $user_appraisals->manager_fill = DB::table('appraisal_form')->where('assign_id',$user_appraisals->appraisal_assign_id)->where('upDated_by','!=','')->count();

         

      }

           

      



		return view('appraisal.appraisal_list',['form' =>$appraisal]);

	}





	

    



    public function sendappraisalemail(Request $request){



      //  return $request->all();



    	 $emailArray = json_decode(stripslashes($request->email),true);





    		$subject = 'Appraisal Email';

    		$from = 'ujjval@mailinator.com';

    		$fromname = 'Ujjval Srivastava';

    		

    			$content = '';

    			$content .= 'Appraisal Email please Portal';







    	 for($i=0;$i<count($emailArray);$i++){



    	 	$user = DB::table('main_users')->where('emailaddress','=',$emailArray[$i])->first();



        $appraisaluser = array($user->id,$user->reporting_manager,1);



    	 	$arr = array(

          'user_id' => $user->id,

    	 		'emp_id' => implode(',', $appraisaluser),

    	 		'date' => date('Y-m-d'),

    	 		'status' =>0



    	 	);



    	 	$int = DB::table('appraisal_list')->insert($arr);

    	





    	 }



    	   if($int){

    	       

    	          $semdemail = MultiSendEmail($emailArray, $subject, $from, $fromname, $content);

    	          

    	          if($semdemail){

    	              

    	              return response()->json(['status' => 200, 'msg' => 'Successfully Send Email']);

    	              

    	          }else{

    	              

    	              return response()->json(['status' => 201, 'msg' => 'Not Send Email']);

    	              

    	          }



           		



           }else{



           		return response()->json(['status' => 201, 'msg' => 'not Send Email']);



           }





    	

    }



    public function addappraisalform(Request $request){



        $userid = Auth::guard('main_users')->user()->id;



        $year = date('Y');

  

       

        $arr['appraisal_list_id'] = $request->appraisal_request_id;

        

         

            $arr['user_values'] = $request->usermarksval;

              $arr['codinator_values'] = $request->condinatorval??0;

               $arr['head_values'] = $request->headval??0;

                $arr['total_user_mark'] = $request->totalusermarks??0;

                 $arr['total_codinator_mark'] = $request->condinatortotal??0;

                  $arr['total_head_mark'] = $request->headtotal??0;

                  $arr['date'] = date('Y-m-d');





        

        $cnt = DB::table('users_appraisal_form')->where('appraisal_list_id','=',$request->appraisal_request_id)->where(DB::raw("(DATE_FORMAT(users_appraisal_form.date,'%Y'))"), "=",$year);

       

       if($cnt->count() > 0){

        $formdetails = $cnt->first(); 





              $oldusers = json_decode($formdetails->user_id);

              $currentuser = array($userid);



              $merge = array_merge($currentuser,$oldusers);



              $arr['user_id'] = json_encode($merge);



        $appraisal = DB::table('users_appraisal_form')->where('appraisal_list_id','=',$request->appraisal_request_id)->update($arr);



       }else{



         $arr['user_id'] = json_encode(array($userid));



        $appraisal = DB::table('users_appraisal_form')->insert($arr);





       }



     

         if($appraisal){



                return response()->json(['status' => 200, 'msg' => 'Successfully Added']);



           }else{



                return response()->json(['status' => 201, 'msg' => 'not added']);



           }





    }

    

    public function cronyealyappraisaladd(){

        

        $today = date('m-d');

        

        $user = DB::table('main_users')->whereNotIn('emprole',[1,2,3,4])->get();

        

        foreach($user as $key => $users){

            

            $joindate = date('m-d',strtotime('-1 day',strtotime($users->join_date)));

            $curentdate = date('Y-m-d',strtotime('+1 day',strtotime(date('Y-m-d')))); 

            

            if($joindate == $today){

                

                DB::table('main_yealy_appraisal_list')->insert(['user_id' => $users->id,'date' =>$curentdate,'status' => 1]);

            }

            

        }

        

        

    }



    function appraisal_master(){



        

  $form = DB::table('appraisal_master')->join('main_positions','appraisal_master.designation','=','main_positions.id')->select('appraisal_master.*','main_positions.positionname')->get();



  



        return view('appraisal.appraisal_master',['list' => $form]);

    }



    

function save_appraisal(Request $request){



    $user_id =  Auth::guard('main_users')->user()->id;

  

   

    

       $arr['name' ] = $request->name;

       $arr['designation'] = $request->designation;

       $arr['created_by'] = $user_id;

       $arr['updated_by' ] = $user_id;

       $arr['created_at'] = date('Y-m-d H:i:s');

       $arr['updated_at'] = date('Y-m-d H:i:s');

  

       DB::table('appraisal_master')->where('designation',$request->designation)->update(['status' =>'Inactive']);

  

  

   if(isset($request->kra_id)){

  

    $arr['status'] = $request->status;

  

    DB::table('appraisal_master')->where('id',$request->kra_id)->update($arr);

    return response()->json(['status' => 200, 'msg' => 'successfully updated']);

  

  

   }else{

  

   

    DB::table('appraisal_master')->insert($arr);

    return response()->json(['status' => 200, 'msg' => 'successfully Added']);

  

  

   }

  

   

  }

  

    

function send_appraisal(Request $request){



    $user_id =  Auth::guard('main_users')->user()->id;

   $end_date = date('Y-m-d', strtotime('+7 days'));

    $hr =   DB::table('main_users')->where('isactive',1)->where('emprole',4)->orderBy('id','DESC')->select('id')->first();

   foreach ($request->user_id as $key => $user_lists) {

     $reporting = DB::table('main_users')->where('id',$user_lists)->first();

     if(DB::table('appraisal_assign_form_user')->where('user_id',$user_lists)->where('form_id',$request->kra_id)->count() > 0){

      return response()->json(['status' => 205, 'msg' => 'already Send']);

     }

     $show_user_id = array($user_lists,$reporting->reporting_manager,$hr->id??0,1);

    $array = array(

     'user_id' => $user_lists,

     'show_user_id' => implode(',', $show_user_id),

     'form_id' => $request->kra_id,

     'state_date' => date('Y-m-d'),

     'end_date'  => $end_date,

     'created_by' => $user_id,

     'created_at' => date('Y-m-d h:i:s'),

 

    );

 

    DB::table('appraisal_assign_form_user')->insert($array);

 

   }

   return response()->json(['status' => 200, 'msg' => 'successfully Send']);

 

 }

 



 function appraisal_question($id){





    return view('appraisal.appraisal_question',['form_id' => $id ]);

  

  }



  function fetch_appraisal_question(Request $request){



    $form = DB::table('appraisal_question')->where('form_id',$request->form_id)->get();









    return view('appraisal.ajex_question',['form' => $form]);

  }





  

function appraisal_insert_question(Request $request){





    $user_id =  Auth::guard('main_users')->user()->id;

  

    if(isset($request->question_id)){

  

      $q = array(

        'form_id' => $request->form_id,

        'desc' => $request->desc,

        'question' => $request->question,

        'type' => $request->type,

        'category' => $request->category,

        'ans' => json_encode($request->answer),

        'required' => $request->required_field,

        'created_by' => $user_id,

        'updated_by' => $user_id,

        'created_at' => date('Y-m-d h:i:s'),

        'updated_at' => date('Y-m-d h:i:s'),

        

          );

  

          DB::table('appraisal_question')->where('id',$request->question_id)->update($q);

   return response()->json(['status' => 200, 'msg' => 'updated successfully']);

  

  

    }else{

  

  

      $q = array(

        'form_id' => $request->form_id,

        

        'desc' => $request->desc,

        'question' => $request->question,

        'category' => $request->category,

          'type' => $request->type,

        'ans' => json_encode($request->answer),

        'required' => $request->required_field,

        'created_by' => $user_id,

        'updated_by' => $user_id,

        'created_at' => date('Y-m-d h:i:s'),

        'updated_at' => date('Y-m-d h:i:s'),

        

          );

  

          DB::table('appraisal_question')->insert($q);

   return response()->json(['status' => 200, 'msg' => 'successfully Added']);

  

  

    }

  

  

  

  }



  function edit_question($id){



    $edit =  DB::table('appraisal_question')->where('id',$id)->first();



  return view('appraisal.edit_question',['edit' => $edit]);



  }



  function insert_appraisal_form(Request $request){



    $user_id =  Auth::guard('main_users')->user()->id;
  $manager = DB::table('main_users')->where('id',Auth::guard('main_users')->user()->reporting_manager)->where('isactive',1)->select('emailaddress')->first();

  $hr = DB::table('main_users')->where('emprole',4)->where('isactive',1)->orderBy('id','desc')->select('emailaddress')->first();


$sendemail = array(Auth::guard('main_users')->user()->emailaddress,$manager->emailaddress??'',$hr->emailaddress??'');

    $count = DB::table('appraisal_form')->where('form_id',$request->form_id)->where('assign_id',$request->assign_id)->count();

   if($count == 0){





    $arr = array(

   'form_id' => $request->form_id,

   'assign_id' => $request->assign_id,

   'emp_name' => $request->emp_name,

   's_date' => $request->s_date,

   'e_date' => $request->e_date,

   

   'mng_name' => $request->mng_name,

   'job_funcational_area' => json_encode($request->job_question),



   'job_desc' => json_encode($request->job_desc),

   'job_emp_rating' => json_encode($request->job_answer),

   'job_emp_stre_obs' => $request->emp_stre,

   'job_emp_weak_obs' => $request->emp_weak,



   'cust_funcational_area' => json_encode($request->cust_question),

   'cust_desc' => json_encode($request->cust_desc),

   'cust_emp_rating' => json_encode($request->cust_answer),

   'cust_emp_stre_obs' => $request->cust_emp_stre,

   'cust_emp_weak_obs' => $request->cust_emp_weak,

   

   'comm_funcational_area' => json_encode($request->comm_question),

   'comm_desc' => json_encode($request->comm_desc),

   'comm_emp_rating' => json_encode($request->comm_answer),

   'comm_emp_stre_obs' => $request->comm_emp_stre,

   'comm_emp_weak_obs' => $request->comm_emp_weak,

   

   'inter_funcational_area' => json_encode($request->inter_question),

   'inter_desc' => json_encode($request->inter_desc),

   'inter_emp_rating' => json_encode($request->inter_answer),

   'inter_emp_stre_obs' => $request->inter_emp_stre,

   'inter_emp_weak_obs' => $request->inter_emp_weak,

   



   'emp_sign' => $request->sign,

   'created_by' => $user_id,

   'created_at' => date('Y-m-d h:i:s'),







    );



    DB::table('appraisal_form')->insert($arr);


               $subject = 'Appraisal Confimation';
               $from = 'suitecrm14@gmail.com';
               $fromname = 'Not_reply';

               $content =   intimation(Auth::guard('main_users')->user()->userfullname,'Submitted',date('Y-m-d'),'Appraisal Form');
    
               $userEmail  = MultiSendEmail($sendemail,$subject,$from,$fromname,$content);
             

    return response()->json(['status' => 200, 'msg' => 'successfully Added']);





  }else{





    $get_first = DB::table('appraisal_form')->where('form_id',$request->form_id)->where('assign_id',$request->assign_id)->first();

  



    $arr = array(

     

      'review_date' => $request->review_date,

      'job_mng_rating' => json_encode($request->mng_job_answer),

      'job_mng_stre_obs' => $request->mng_stre,

      'job_mng_weak_obs' => $request->mng_weak,

      'job_mng_recommendation' => $request->mng_weak,

  

      'cust_mng_rating' => json_encode($request->mng_cust_answer),

      'cust_mng_stre_obs' => $request->cust_mng_stre,

      'cust_mng_weak_obs' => $request->cust_mng_weak,

      'cust_mng_recommendation' => $request->cust_mng_recommendation,

      

     

      'comm_mng_rating' => json_encode($request->mng_comm_answer),

      'comm_mng_stre_obs' => $request->comm_mng_stre,

      'comm_mng_weak_obs' => $request->comm_mng_weak,

      'comm_mng_recommendation' => $request->comm_mng_recommendation,



      'inter_mng_rating' => json_encode($request->mng_inter_answer),

      'inter_mng_stre_obs' => $request->inter_mng_stre,

      'inter_mng_weak_obs' => $request->inter_mng_weak,

      'inter_mng_recommendation' => $request->inter_mng_recommendation,

      

   

      'mng_sign' => $request->mng_sign,

      'updated_by' => $user_id,

      'updated_at' => date('Y-m-d h:i:s'),

   

   

   

       );

   

       DB::table('appraisal_form')->where('id',$get_first->id)->update($arr);

       return response()->json(['status' => 200, 'msg' => 'successfully Added']);





     

  }



  }

    

}

